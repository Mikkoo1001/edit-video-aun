/* Service worker — makes the editor installable as an app and lets it open without a connection.
 * Strategy: NETWORK FIRST. The network answer is always used when it comes (a new upload of the site is picked up at once; files are versioned by ?v=
 * and the server sends no-cache). The saved copy is used ONLY when the network fails — or, for the page itself (navigation), when it is slower than 3 s.
 * Scripts / styles / fonts are matched by their EXACT url (with ?v=): an old copy of a file is never mixed with a newer page.
 * Never touched: /api/* (AI calls), non-GET, Range requests (video), other origins. */
const CACHE = 'subed-shell-v4';
const SHARE = 'subed-share';
const NAV_TIMEOUT = 3000;

const OFFLINE_PAGE = '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>กำลังเชื่อมต่อ…</title>' +
  '<body style="margin:0;display:grid;place-items:center;min-height:100vh;background:#111;color:#ddd;font:16px/1.6 system-ui,sans-serif;text-align:center;padding:24px">' +
  '<div><div style="font-size:40px">📶</div><p>เชื่อมต่ออินเทอร์เน็ตไม่ได้ชั่วคราว<br>งานที่ตัดไว้ถูกเก็บในเครื่องแล้ว ไม่หาย<br>กำลังลองเปิดใหม่อัตโนมัติ…</p>' +
  '<button onclick="location.reload()" style="padding:10px 22px;border-radius:999px;border:0;background:#3ea6ff;color:#000;font-size:16px">ลองใหม่ตอนนี้</button></div>' +
  '<script>setTimeout(function(){location.reload()},4000)</script></body>';
self.addEventListener('install', e => {
  e.waitUntil((async () => { try { await (await caches.open(CACHE)).add(new Request(new URL('./', self.location).href, { cache: 'reload' })); } catch (err) {} self.skipWaiting(); })());
});
self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== CACHE && k !== SHARE) await caches.delete(k);
    await self.clients.claim();
  })());
});

/** Share target: gallery / Files app -> Share -> this app. The shared files arrive as real data (not a gallery reference), so they are always readable. */
async function takeShare(req) {
  const back = n => Response.redirect(new URL('./?shared=' + n, self.location).href, 303);
  try {
    const files = (await req.formData()).getAll('media').filter(f => f && f.size);
    const c = await caches.open(SHARE);
    for (const k of await c.keys()) await c.delete(k);
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      await c.put('/__shared/' + i, new Response(f, { headers: { 'Content-Type': f.type || 'video/mp4', 'X-Name': encodeURIComponent(f.name || 'video.mp4'), 'X-Modified': String(f.lastModified || Date.now()) } }));
    }
    return back(files.length);
  } catch (err) { return back(0); }
}

self.addEventListener('fetch', e => {
  const req = e.request, url = new URL(req.url);
  if (req.method === 'POST' && url.origin === self.location.origin && /\/share-target$/.test(url.pathname)) { e.respondWith(takeShare(req)); return; }
  if (req.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/api/') || req.headers.has('range')) return;
  const nav = req.mode === 'navigate';
  e.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const key = nav ? new Request(new URL('./', self.location).href) : req;        // every page load is the app shell
    const network = fetch(req).then(res => { if (res && res.ok && res.type === 'basic') cache.put(key, res.clone()).catch(() => {}); return res; });
    try {
      if (!nav) return await network;                                              // no time limit for files: a slow phone connection must not fall back to an old copy
      return await Promise.race([network, new Promise((_, rej) => setTimeout(() => rej(new Error('slow')), NAV_TIMEOUT))]);
    } catch (err) {
      const hit = await cache.match(key);                                          // exact match only
      if (hit) { network.catch(() => {}); return hit; }
      return network.catch(() => new Response(OFFLINE_PAGE, { status: 200, headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' } }));
    }
  })());
});
