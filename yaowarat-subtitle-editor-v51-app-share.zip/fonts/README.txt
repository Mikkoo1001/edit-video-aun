ฟอนต์ที่เพิ่มจากไฟล์ของผู้ใช้:
  FCMahaNakhon-Medium.woff / FCMahaNakhonFlat-Medium.woff  (FC มหานคร และ มหานคร Flat · Fontcraft · ใช้ฟรีเฉพาะงานไม่เชิงพาณิชย์ — ดู FC_Maha_Nakhon_License.txt)
  TorsilpThamnganMangThoe.woff  (Torsilp ThamnganMangThoe)
  มีน้ำหนักเดียว (Medium) — อยากหนาขึ้นให้ใช้แถบ "ความหนา" ในแอป
ฟอนต์ที่ไม่มีไฟล์และถูกเอาออกแล้ว: Prohibition, WarGod (ถ้าได้ไฟล์มา ใช้แท็บ ฟอนต์ > "เพิ่มฟอนต์ของคุณ" หรือทำตาม FONTS-GUIDE.md)

อนุพันธ์ Bd / SB, Prompt Bd, Bebas Neue, Bangers โหลดจาก Google Fonts อัตโนมัติ ไม่ต้องวางไฟล์

ฟอนต์โปรด: แท็บ ฟอนต์ > "ฟอนต์โปรด" แสดงฟอนต์ที่บันทึกไว้ (ค่าเริ่มต้น = ชุดเดียวกับในวิดีโอ CapCut)
กดค้างที่การ์ดฟอนต์ (หรือแตะรูป 🔖 ที่มุมการ์ด) เพื่อเพิ่ม / ลบจากโปรด — เก็บไว้ในเครื่องนี้

ไฟล์ฟอนต์ที่ใส่มาแล้ว:
  Anuphan-Variable.ttf     (Anuphan แบบ variable ปรับความหนา 100–700 ได้ต่อเนื่อง · OFL)
  FCKrungThep-Bold.ttf     (FC Krung Thep Bold · ใช้งานไม่เชิงพาณิชย์ — ดูไฟล์ License ของผู้ทำฟอนต์)

คลังฟอนต์ไทย (ย้ายมาจาก Shadow Caption Lab): ไฟล์ .woff 27 ตระกูลอยู่ในโฟลเดอร์นี้ ประกาศไว้ใน css/fonts-lib.css
(IBM Plex Sans Thai, K2D, Bai Jamjuree, Chakra Petch, Krub, Niramit, Athiti, Noto Sans Thai/Serif Thai, Pridi, Taviraj, Trirong, Maitree, Mali, Itim,
Playpen Sans Thai, Sriracha, Charm, Charmonman, Chonburi, Pattaya, Srisakdi ฯลฯ — ใบอนุญาต OFL) · เบราว์เซอร์โหลดเฉพาะตัวที่ใช้
อัปโหลดฟอนต์ของคุณเองได้ที่แท็บ ฟอนต์ > "เพิ่มฟอนต์ของคุณ" (เก็บไว้ในเบราว์เซอร์ ไม่ต้องวางไฟล์ในโฟลเดอร์)

ดูขั้นตอนเพิ่มฟอนต์ใหม่ให้พรีวิวกับส่งออกตรงกันที่ fonts/FONTS-GUIDE.md

รายการฟอนต์เวอร์ชันนี้: นอกจากตัวหลักของแต่ละตระกูลแล้ว มีตัวเลือกน้ำหนักล็อกไว้ให้ 45 ตัว (Light / ExtraBold / Black / Regular) เช่น Kanit Black, Prompt Light, Trirong Black, Playpen ExtraBold — ใช้ไฟล์เดิมทั้งหมด ไม่ต้องเพิ่มไฟล์ใหม่
