/* =====================================================================
 * SubEd.arrangeFx — what a scene can DO besides showing a clip. Shared by the preview (ui/arrange.js) and the exporter
 * (export/arrange-export.js), so what you see and hear is what is rendered.
 *
 *   VISUAL  scene.fx = { tr, trDur, motion, amt }
 *     tr      'cut' | 'dissolve' | 'flash' | 'dip' | 'slide'      how the scene comes in (over trDur seconds), against the previous
 *                                                                  scene's LAST picture (a frozen copy, so only one clip plays at a time)
 *     motion  'none' | 'zoomIn' | 'zoomOut' | 'punch' | 'shake'  movement inside the scene; amt = how much (zoom 0.12 = 12 %)
 *   SOUND   scene.sfx = 'whoosh' | 'hit' | 'pop' | 'ding' | 'riser' | 'glitch' | null   played so that its PEAK lands on the scene's first frame
 *
 * Sounds are synthesised here (no files to ship, identical samples for preview and export). 48 kHz mono Float32Array each.
 * No DOM at load time except inside player (AudioContext, created on first use).
 * ===================================================================== */
(function (S) {
  'use strict';
  const RATE = 48000;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const TR = { cut: 'ตัดตรง', dissolve: 'ดิสโซล์ฟ', flash: 'แฟลชขาว', dip: 'ดำเข้า', slide: 'สไลด์' };
  const MOTION = { none: 'ไม่มี', zoomIn: 'ซูมเข้า', zoomOut: 'ซูมออก', punch: 'พั้นช์ (ซูมกระแทก)', shake: 'สั่น' };
  const SFX = { whoosh: 'วู้ช', hit: 'ฮิต (กระแทก)', pop: 'ป๊อป', ding: 'ติ๊ง', riser: 'ไรเซอร์', glitch: 'กลิตช์' };

  /* ------------------------------------------------------------ packs: a look and its sound, chosen together */
  const PACKS = [
    { key: 'none',          label: 'ไม่มีเอฟเฟกต์',    tr: 'cut',      trDur: 0.25, motion: 'none',    amt: 0.12, sfx: null },
    { key: 'popCut',        label: 'ตัด + ป๊อป',       tr: 'cut',      trDur: 0.25, motion: 'none',    amt: 0.12, sfx: 'pop' },
    { key: 'flashHit',      label: 'แฟลช + ฮิต',       tr: 'flash',    trDur: 0.18, motion: 'none',    amt: 0.12, sfx: 'hit' },
    { key: 'punchHit',      label: 'พั้นช์ + ฮิต',     tr: 'cut',      trDur: 0.25, motion: 'punch',   amt: 0.22, sfx: 'hit' },
    { key: 'zoomWhoosh',    label: 'ซูมเข้า + วู้ช',   tr: 'cut',      trDur: 0.25, motion: 'zoomIn',  amt: 0.15, sfx: 'whoosh' },
    { key: 'zoomOutWhoosh', label: 'ซูมออก + วู้ช',    tr: 'cut',      trDur: 0.25, motion: 'zoomOut', amt: 0.15, sfx: 'whoosh' },
    { key: 'slideWhoosh',   label: 'สไลด์ + วู้ช',     tr: 'slide',    trDur: 0.3,  motion: 'none',    amt: 0.12, sfx: 'whoosh' },
    { key: 'dissolveDing',  label: 'ดิสโซล์ฟ + ติ๊ง',  tr: 'dissolve', trDur: 0.5,  motion: 'zoomIn',  amt: 0.06, sfx: 'ding' },
    { key: 'dipRiser',      label: 'ดำเข้า + ไรเซอร์', tr: 'dip',      trDur: 0.45, motion: 'none',    amt: 0.12, sfx: 'riser' },
    { key: 'glitchShake',   label: 'สั่น + กลิตช์',    tr: 'cut',      trDur: 0.25, motion: 'shake',   amt: 0.12, sfx: 'glitch' }
  ];
  const packByKey = k => PACKS.find(p => p.key === k) || null;
  /** Put a pack's look AND sound on a scene. */
  function applyPack(scene, key) {
    const p = packByKey(key); if (!p) return false;
    scene.fx = { tr: p.tr, trDur: p.trDur, motion: p.motion, amt: p.amt };
    scene.sfx = p.sfx; scene.sfxManual = false;
    return true;
  }
  /** Which pack a scene currently is (same transition, motion and sound), or null when it is a custom mix. */
  function packOf(scene) {
    const fx = scene.fx || {}, tr = fx.tr || 'cut', mo = fx.motion || 'none', sf = scene.sfx || null;
    const p = PACKS.find(p => p.tr === tr && p.motion === mo && p.sfx === sf);
    return p ? p.key : null;
  }
  /** The sound that normally goes with a look: the transition decides first, then the movement. */
  function suggestSfx(fx) {
    fx = fx || {};
    const byTr = { flash: 'hit', dip: 'riser', dissolve: 'ding', slide: 'whoosh' }, byMo = { punch: 'hit', zoomIn: 'whoosh', zoomOut: 'whoosh', shake: 'glitch' };
    return byTr[fx.tr] || byMo[fx.motion] || null;
  }

  /* ------------------------------------------------------------ pictures */
  const ease = p => p * p * (3 - 2 * p);
  /**
   * Draw one picture of a scene. drawBase(ctx) paints the clip frame over the whole w×h canvas.
   * tin = seconds since the scene started, len = scene length, prev = canvas holding the previous scene's last picture (or null).
   */
  function drawScene(ctx, w, h, drawBase, fx, tin, len, prev) {
    fx = fx || {};
    const motion = fx.motion || 'none', amt = fx.amt == null ? 0.12 : fx.amt, tr = fx.tr || 'cut', trd = Math.max(0.05, fx.trDur || 0.25);
    const p = clamp(len > 0 ? tin / len : 0, 0, 1);
    let k = 1, dx = 0, dy = 0;
    if (motion === 'zoomIn') k = 1 + amt * ease(p);
    else if (motion === 'zoomOut') k = 1 + amt * (1 - ease(p));
    else if (motion === 'punch') { const d = Math.max(0, 1 - tin / 0.3); k = 1 + amt * d * d; }
    else if (motion === 'shake') { const d = Math.max(0, 1 - tin / 0.4); k = 1.04; dx = Math.sin(tin * 58) * w * 0.012 * d; dy = Math.cos(tin * 47) * h * 0.008 * d; }
    const inTr = tin < trd && tr !== 'cut', q = inTr ? clamp(tin / trd, 0, 1) : 1;
    const slide = inTr && tr === 'slide' && prev;
    ctx.save();
    if (slide) ctx.translate((1 - q) * w, 0);
    ctx.translate(w / 2 + dx, h / 2 + dy); ctx.scale(k, k); ctx.translate(-w / 2, -h / 2);
    drawBase(ctx);
    ctx.restore();
    if (!inTr) return;
    if (tr === 'dissolve' && prev) { ctx.save(); ctx.globalAlpha = 1 - q; ctx.drawImage(prev, 0, 0, w, h); ctx.restore(); }
    else if (slide) ctx.drawImage(prev, -q * w, 0, w, h);
    else if (tr === 'flash') { ctx.fillStyle = 'rgba(255,255,255,' + ((1 - q) * 0.95).toFixed(3) + ')'; ctx.fillRect(0, 0, w, h); }
    else if (tr === 'dip') { ctx.fillStyle = 'rgba(0,0,0,' + (1 - q).toFixed(3) + ')'; ctx.fillRect(0, 0, w, h); }
  }

  /* ------------------------------------------------------------ sounds */
  const cache = {};
  function lcg(seed) { let s = seed >>> 0; return () => ((s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296) * 2 - 1; }
  function norm(a, peak) { let m = 0; for (let i = 0; i < a.length; i++) m = Math.max(m, Math.abs(a[i])); const g = m > 0 ? peak / m : 1; for (let i = 0; i < a.length; i++) a[i] *= g; return a; }
  /** Band-passed noise whose centre frequency moves f0 -> f1 (state-variable filter). */
  function sweepNoise(n, f0, f1, q, env, seed) {
    const out = new Float32Array(n), rnd = lcg(seed); let lo = 0, bp = 0;
    for (let i = 0; i < n; i++) {
      const u = i / n, f = f0 * Math.pow(f1 / f0, u), g = 2 * Math.sin(Math.PI * f / RATE), x = rnd();
      const hp = x - lo - q * bp; bp += g * hp; lo += g * bp;
      out[i] = bp * env(u);
    }
    return out;
  }
  const BUILD = {
    whoosh() { const n = Math.round(0.6 * RATE); return { peak: 0.42, data: norm(sweepNoise(n, 250, 5200, 0.55, u => Math.pow(Math.sin(Math.PI * Math.min(1, u / 0.7 * 0.5 + (u > 0.7 ? 0.5 : 0))), 1.4) * (u > 0.7 ? Math.max(0, 1 - (u - 0.7) / 0.3) : u / 0.7), 11), 0.85) }; },
    hit() {
      const n = Math.round(0.55 * RATE), out = new Float32Array(n), rnd = lcg(7); let ph = 0;
      for (let i = 0; i < n; i++) { const t = i / RATE, f = 48 + 110 * Math.exp(-t * 26); ph += 2 * Math.PI * f / RATE; out[i] = Math.sin(ph) * Math.exp(-t * 7) + rnd() * Math.exp(-t * 90) * 0.5; }
      return { peak: 0.004, data: norm(out, 0.95) };
    },
    pop() { const n = Math.round(0.12 * RATE), out = new Float32Array(n); let ph = 0; for (let i = 0; i < n; i++) { const t = i / RATE, f = 380 + 900 * Math.exp(-t * 38); ph += 2 * Math.PI * f / RATE; out[i] = Math.sin(ph) * Math.exp(-t * 34); } return { peak: 0.002, data: norm(out, 0.8) }; },
    ding() { const n = Math.round(0.9 * RATE), out = new Float32Array(n); for (let i = 0; i < n; i++) { const t = i / RATE; out[i] = (Math.sin(2 * Math.PI * 1760 * t) + 0.5 * Math.sin(2 * Math.PI * 2637 * t) + 0.25 * Math.sin(2 * Math.PI * 3520 * t)) * Math.exp(-t * 5.5); } return { peak: 0.001, data: norm(out, 0.7) }; },
    riser() { const n = Math.round(1.2 * RATE), out = sweepNoise(n, 200, 6500, 0.7, u => Math.pow(u, 2.2), 23); let ph = 0; for (let i = 0; i < n; i++) { const u = i / n; ph += 2 * Math.PI * (180 + 1900 * u * u) / RATE; out[i] = out[i] * 0.7 + Math.sin(ph) * Math.pow(u, 2.4) * 0.5; } return { peak: 1.18, data: norm(out, 0.8) }; },
    glitch() {
      const n = Math.round(0.3 * RATE), out = new Float32Array(n), rnd = lcg(5); let f = 300, hold = 0, ph = 0, on = 1;
      for (let i = 0; i < n; i++) { if (hold <= 0) { hold = Math.round((0.012 + Math.abs(rnd()) * 0.03) * RATE); f = 150 + Math.abs(rnd()) * 1800; on = rnd() > -0.35 ? 1 : 0; } hold--; ph += 2 * Math.PI * f / RATE; out[i] = (Math.sin(ph) > 0 ? 1 : -1) * 0.5 * on * Math.exp(-(i / n) * 2.2); }
      return { peak: 0.002, data: norm(out, 0.6) };
    }
  };
  /** { data: Float32Array(48 kHz mono), peak: seconds from the start of the sound to its loudest moment } */
  function synth(type) { if (!BUILD[type]) return null; return cache[type] || (cache[type] = BUILD[type]()); }

  /** Events [{ t, type, vol }] (t = when the peak must land, seconds from the start of the rendered range) -> mix(planes, n, startFrame)
   *  which ADDS the sounds into the 48 kHz blocks an audio encoder is about to take (startFrame = index of the block's first sample). */
  function makeMixer(events) {
    const list = [];
    (events || []).forEach(e => { const s = synth(e.type); if (s) list.push({ from: Math.round((e.t - s.peak) * RATE), data: s.data, vol: e.vol == null ? 1 : e.vol }); });
    if (!list.length) return null;
    list.sort((a, b) => a.from - b.from);
    return function mix(planes, n, start) {
      for (const e of list) {
        const a = Math.max(start, e.from), b = Math.min(start + n, e.from + e.data.length);
        if (b <= a) continue;
        for (let c = 0; c < planes.length; c++) { const pl = planes[c]; for (let i = a; i < b; i++) pl[i - start] += e.data[i - e.from] * e.vol; }
      }
      for (let c = 0; c < planes.length; c++) { const pl = planes[c]; for (let i = 0; i < n; i++) { const v = pl[i]; if (v > 1) pl[i] = 1; else if (v < -1) pl[i] = -1; } }   // sum of voice + effects must not wrap
    };
  }

  /** Preview playback: schedule a sound so its peak lands `delay` seconds from now. */
  const player = {
    ac: null, live: [],
    ctx() { if (!this.ac) { const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return null; this.ac = new AC(); } if (this.ac.state === 'suspended') this.ac.resume().catch(() => {}); return this.ac; },
    play(type, vol, delay) {
      const s = synth(type), ac = this.ctx(); if (!s || !ac) return;
      const buf = ac.createBuffer(1, s.data.length, RATE); buf.copyToChannel(s.data, 0);
      const src = ac.createBufferSource(), g = ac.createGain(); src.buffer = buf; g.gain.value = vol == null ? 1 : vol;
      src.connect(g); g.connect(ac.destination);
      const when = ac.currentTime + Math.max(0, (delay || 0) - s.peak);
      src.start(when); this.live.push(src); src.onended = () => { const i = this.live.indexOf(src); if (i >= 0) this.live.splice(i, 1); };
      // the lead-in of a sound that peaks later (whoosh) would start in the past: skip into it instead
      if ((delay || 0) < s.peak) { try { src.stop(); } catch (e) {} this.live.pop(); const s2 = ac.createBufferSource(); s2.buffer = buf; s2.connect(g); s2.start(0, s.peak - (delay || 0)); this.live.push(s2); s2.onended = () => { const i = this.live.indexOf(s2); if (i >= 0) this.live.splice(i, 1); }; }
    },
    stop() { this.live.splice(0).forEach(s => { try { s.stop(); } catch (e) {} }); }
  };

  S.arrangeFx = { PACKS: PACKS, packByKey: packByKey, applyPack: applyPack, packOf: packOf, suggestSfx: suggestSfx, TR: TR, MOTION: MOTION, SFX: SFX, drawScene: drawScene, synth: synth, makeMixer: makeMixer, player: player, RATE: RATE };
})(window.SubEd);
