/* =====================================================================
 * Render layer — "Motion Graphics ข้อความ": extra text layers that move on keyframes (CapCut style).
 *
 *   project.motion.layers[]  each layer is plain JSON:
 *     { id, kind:'text'|'image', start, end, // seconds on the SAME clock as the subtitle lines (source-clip time)
 *       text (kind text) · img (asset id) + w (width, ref px) + key:{on,tol} (kind image: item / character / logo picture),
 *       plate:{on,color,radius,padX,padY} (a button / label plate behind the text), pixel (block size, 0 = off), glitch:{inD,outD},
 *       rest {x,y,scale,rot} + anim {inId,inD,loopId,outId,outD} (the layer's resting pose and its in / loop / out moves; kf are built from them),
 *       z: 'front' | 'back',              // เลเยอร์: front = in FRONT of the caption text, back = BEHIND it
 *       font, weight, italic, color, size,// size in the same reference px as style.size (so preview == export)
 *       outline:{on,color,width}, shadow:{on,color,opacity,dx,dy,blur}, glow:{on,color,intensity,range},
 *       kf: [ { t, x, y, scale, rot, alpha, ease } ] }
 *     kf.t     seconds from the layer's start
 *     x, y     centre of the text as a fraction of the picture (0..1)
 *     scale    1 = 100 %          rot  degrees          alpha  0..1
 *     ease     the graph (curve) used while going from THIS keyframe to the next one — same list as CapCut "Graphs"
 *
 * Like the caption (caption-canvas.js) this file reads ONLY its arguments, so the live preview, the three exporters and
 * any future worker all draw the very same pixels. Drawing order per frame (see composeFrame):
 *     video  ->  layers with z:'back'  ->  caption text  ->  layers with z:'front'
 * ===================================================================== */
(function (S) {
  'use strict';

  /* ----------------------------------------------------------------- easing ("Graphs") */
  const PI = Math.PI;
  const outB = p => { const c1 = 1.70158, c3 = c1 + 1, q = p - 1; return 1 + c3 * q * q * q + c1 * q * q; };
  const bounceOut = p => {
    const n = 7.5625, d = 2.75;
    if (p < 1 / d) return n * p * p;
    if (p < 2 / d) { p -= 1.5 / d; return n * p * p + 0.75; }
    if (p < 2.5 / d) { p -= 2.25 / d; return n * p * p + 0.9375; }
    p -= 2.625 / d; return n * p * p + 0.984375;
  };
  const EASES = [
    { id: 'linear',     th: 'Linear',      f: p => p },
    { id: 'easeIn',     th: 'Ease In',     f: p => 1 - Math.cos(p * PI / 2) },
    { id: 'quadIn',     th: 'Quad In',     f: p => p * p },
    { id: 'cubicIn',    th: 'Cubic In',    f: p => p * p * p },
    { id: 'easeOut',    th: 'Ease Out',    f: p => Math.sin(p * PI / 2) },
    { id: 'quadOut',    th: 'Quad Out',    f: p => 1 - (1 - p) * (1 - p) },
    { id: 'cubicOut',   th: 'Cubic Out',   f: p => 1 - Math.pow(1 - p, 3) },
    { id: 'easeInOut',  th: 'Ease InOut',  f: p => -(Math.cos(PI * p) - 1) / 2 },
    { id: 'quadInOut',  th: 'Quad InOut',  f: p => p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2 },
    { id: 'cubicInOut', th: 'Cubic InOut', f: p => p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2 },
    { id: 'back',       th: 'เด้งเกิน',     f: outB },                                                       // overshoots, then settles
    { id: 'backIn',     th: 'ดึงถอยก่อน',   f: p => { const c1 = 1.70158; return (c1 + 1) * p * p * p - c1 * p * p; } },
    { id: 'bounce',     th: 'เด้งดึ๋ง',      f: bounceOut },
    { id: 'elastic',    th: 'ยืดหยุ่น',      f: p => p <= 0 ? 0 : p >= 1 ? 1 : Math.pow(2, -10 * p) * Math.sin((p * 10 - 0.75) * (2 * PI / 3)) + 1 },
    { id: 'hold',       th: 'ค้างไว้',       f: () => 0 }                                                      // value stays until the next keyframe, then jumps
  ];
  const EASE_BY_ID = {}; EASES.forEach(e => { EASE_BY_ID[e.id] = e.f; });
  const easeFn = id => EASE_BY_ID[id] || EASE_BY_ID.linear;

  /* ----------------------------------------------------------------- keyframes */
  const PROPS = ['x', 'y', 'scale', 'rot', 'alpha'];
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const num = (v, d) => (v == null || isNaN(+v) ? d : +v);

  /** The look of the layer `rel` seconds after its start: { x, y, scale, rot, alpha }. Before the first keyframe / after the last one it holds. */
  function sample(layer, rel) {
    const kf = layer.kf;
    if (!kf || !kf.length) return { x: 0.5, y: 0.5, scale: 1, rot: 0, alpha: 1 };
    if (rel <= kf[0].t || kf.length === 1) return pick(kf[0]);
    const last = kf[kf.length - 1];
    if (rel >= last.t) return pick(last);
    let i = 0; while (i < kf.length - 2 && rel >= kf[i + 1].t) i++;
    const a = kf[i], b = kf[i + 1], span = b.t - a.t, p = span > 1e-6 ? (rel - a.t) / span : 1, e = easeFn(a.ease)(clamp(p, 0, 1));
    const o = {};
    PROPS.forEach(k => { o[k] = a[k] + (b[k] - a[k]) * e; });
    return o;
  }
  function pick(k) { return { x: k.x, y: k.y, scale: k.scale, rot: k.rot, alpha: k.alpha }; }

  /** Bring a layer (maybe loaded from an old / hand-edited project) into a complete, sorted, valid shape. */
  function normalize(layer) {
    const st = S.state.project.style, d = defaults();
    layer.id = layer.id || newId();
    layer.text = String(layer.text == null ? '' : layer.text);
    layer.start = Math.max(0, num(layer.start, 0));
    layer.end = Math.max(layer.start + 0.05, num(layer.end, layer.start + 2));
    layer.z = layer.z === 'back' ? 'back' : 'front';
    layer.font = layer.font || (st && st.font) || d.font;
    layer.weight = num(layer.weight, d.weight); layer.italic = !!layer.italic;
    layer.color = layer.color || '#ffffff'; layer.size = clamp(num(layer.size, d.size), 4, 400);
    layer.outline = Object.assign({ on: true, color: '#000000', width: 2 }, layer.outline);
    layer.shadow = Object.assign({ on: true, color: '#000000', opacity: 100, dx: 6, dy: 6, blur: 0 }, layer.shadow);
    layer.glow = Object.assign({ on: false, color: '#ffffff', intensity: 60, range: 12 }, layer.glow);
    layer.hidden = !!layer.hidden;
    layer.kind = layer.kind === 'image' ? 'image' : 'text';
    if (layer.kind === 'image') { layer.img = layer.img || ''; layer.w = clamp(num(layer.w, 120), 6, 1600); layer.key = Object.assign({ on: false, tol: 30 }, layer.key); layer.text = layer.text || ''; }
    layer.plate = Object.assign({ on: false, color: '#d81212', radius: 0.3, padX: 0.85, padY: 0.4 }, layer.plate);
    layer.pixel = clamp(num(layer.pixel, 0), 0, 12);
    layer.glitch = Object.assign({ inD: 0, outD: 0 }, layer.glitch);
    layer.glitch.inD = clamp(num(layer.glitch.inD, 0), 0, 3); layer.glitch.outD = clamp(num(layer.glitch.outD, 0), 0, 3);
    if (!Array.isArray(layer.kf) || !layer.kf.length) layer.kf = [{}];
    layer.kf.forEach(k => {
      k.t = Math.max(0, num(k.t, 0)); k.x = num(k.x, 0.5); k.y = num(k.y, 0.5); k.scale = Math.max(0, num(k.scale, 1));
      k.rot = num(k.rot, 0); k.alpha = clamp(num(k.alpha, 1), 0, 1); k.ease = EASE_BY_ID[k.ease] ? k.ease : 'linear';
    });
    layer.kf.sort((a, b) => a.t - b.t);
    if (!layer.rest || typeof layer.rest !== 'object') layer.rest = restOf(layer.kf);
    layer.rest = { x: num(layer.rest.x, 0.5), y: num(layer.rest.y, 0.5), scale: Math.max(0.01, num(layer.rest.scale, 1)), rot: num(layer.rest.rot, 0) };
    layer.anim = layer.anim && typeof layer.anim === 'object' ? Object.assign({ inId: 'none', loopId: 'none', outId: 'none', inD: null, outD: null }, layer.anim) : null;
    return layer;
  }
  /** The resting pose of a set of keyframes = the most visible one (a leaving move ends invisible, an entering one starts invisible). */
  function restOf(kf) {
    let r = kf[kf.length - 1];
    kf.forEach(k => { if (k.alpha > r.alpha + 1e-6 || (Math.abs(k.alpha - r.alpha) < 1e-6 && k.scale > 0.01 && (r.scale <= 0.01 || Math.abs(k.scale - 1) <= Math.abs(r.scale - 1)))) r = k; });
    return { x: r.x, y: r.y, scale: r.scale > 0.01 ? r.scale : 1, rot: r.rot };
  }
  function defaults() { const st = (S.state && S.state.project.style) || {}; return { font: st.font || "'Kanit',sans-serif", weight: st.weight || 700, size: Math.round((st.size || 32) * 1.25) }; }
  let seq = 0;
  function newId() { return 'mg' + Date.now().toString(36) + (seq++).toString(36); }

  function makeLayer(o) {
    o = o || {};
    const d = defaults(), start = Math.max(0, num(o.start, 0));
    return normalize(Object.assign({
      text: '?', start: start, end: start + 3, z: 'front', font: d.font, weight: d.weight, italic: false, color: '#ffffff', size: d.size,
      outline: { on: true, color: '#000000', width: 2 },
      shadow: { on: true, color: '#000000', opacity: 100, dx: 6, dy: 6, blur: 0 },        // hard offset "extruded" shadow, like the example clip
      glow: { on: true, color: '#ffffff', intensity: 45, range: 10 },
      kf: [{ t: 0, x: 0.5, y: 0.5, scale: 1, rot: 0, alpha: 1, ease: 'linear' }]
    }, o));
  }

  /* ----------------------------------------------------------------- presets: a ready-made set of keyframes */
  // Each takes the resting look { x, y } and the layer length (s) and returns the keyframes. The LAST keyframe is the resting pose.
  const K = (t, o, ease) => Object.assign({ t: t, x: 0.5, y: 0.5, scale: 1, rot: 0, alpha: 1, ease: ease || 'linear' }, o);
  const PRESETS = [
    { id: 'none',  th: 'นิ่ง',        make: (b) => [K(0, b)] },
    // like the "?" in the CapCut example: pops in, tilts its head FORWARD (clockwise, like a curious head tilt), holds the lean,
    // and at the very end tilts BACK a little (counter-clockwise)
    { id: 'tilt',  th: 'เอียงหน้า-หลัง', make: (b, L) => {
        L = Math.max(0.8, L); const t1 = Math.min(0.3, L * 0.25), t2 = Math.min(0.6, L * 0.45), t3 = Math.max(t2 + 0.05, L - 0.5);
        return [K(0, { x: b.x, y: b.y, scale: 0, rot: 0, alpha: 0 }, 'back'),
                K(t1, { x: b.x, y: b.y, scale: 1.12, rot: 17 }, 'quadInOut'),
                K(t2, { x: b.x, y: b.y, scale: 1, rot: 13 }, 'quadInOut'),
                K(t3, { x: b.x, y: b.y, scale: 1, rot: 13 }, 'quadInOut'),
                K(L, { x: b.x, y: b.y, scale: 1, rot: -7 })]; } },
    { id: 'pop',   th: 'ป๊อปเด้ง',     make: (b) => [K(0, { x: b.x, y: b.y, scale: 0, alpha: 0 }, 'back'), K(0.35, b)] },
    { id: 'slam',  th: 'ซูมกระแทก',   make: (b) => [K(0, { x: b.x, y: b.y, scale: 3, alpha: 0 }, 'quadOut'), K(0.22, b)] },
    { id: 'spin',  th: 'หมุนเข้า',     make: (b) => [K(0, { x: b.x, y: b.y, scale: 0, rot: -180, alpha: 0 }, 'back'), K(0.5, b)] },
    { id: 'slide', th: 'เลื่อนเข้า',    make: (b) => [K(0, { x: b.x - 0.35, y: b.y, alpha: 0 }, 'cubicOut'), K(0.4, b)] },
    { id: 'drop',  th: 'ตกลงมาเด้ง',   make: (b) => [K(0, { x: b.x, y: b.y - 0.35, alpha: 0 }, 'bounce'), K(0.6, b)] },
    { id: 'float', th: 'ลอยขึ้นหาย',   make: (b, L) => [K(0, b, 'cubicOut'), K(Math.max(0.3, L), { x: b.x, y: b.y - 0.22, scale: 1.15, alpha: 0 })] },
    { id: 'pulse', th: 'เต้นตุบๆ',     make: (b, L) => { const o = [], n = Math.max(2, Math.round(L / 0.5)); for (let i = 0; i <= n; i++) o.push(K(i * L / n, { x: b.x, y: b.y, scale: i % 2 ? 1.18 : 1 }, 'quadInOut')); return o; } },
    { id: 'shake', th: 'สั่น',          make: (b, L) => { const o = [], n = Math.max(4, Math.round(L / 0.08)); for (let i = 0; i <= n; i++) o.push(K(i * L / n, { x: b.x, y: b.y, rot: i === n ? 0 : (i % 2 ? 7 : -7) }, 'quadInOut')); return o; } },
    { id: 'blink', th: 'กะพริบ',       make: (b, L) => { const o = [], n = Math.max(2, Math.round(L / 0.25)); for (let i = 0; i <= n; i++) o.push(K(i * L / n, { x: b.x, y: b.y, alpha: i % 2 ? 0 : 1 }, 'hold')); o[n].alpha = 1; return o; } },
    { id: 'out',   th: 'ป๊อปเข้า-ออก', make: (b, L) => [K(0, { x: b.x, y: b.y, scale: 0, alpha: 0 }, 'back'), K(0.3, b, 'hold'), K(Math.max(0.35, L - 0.25), b, 'backIn'), K(Math.max(0.5, L), { x: b.x, y: b.y, scale: 0, alpha: 0 })] }
  ];

  /* ----------------------------------------------------------------- in / loop / out moves (CapCut "Animations": เข้า · ค้าง · ออก) */
  // A layer keeps its RESTING pose in layer.rest and the chosen moves in layer.anim; the keyframes are built from them (compose), so the
  // layer can be dragged / resized without breaking its entrance. Each move carries a `use` line: what it is good for.
  const OFF = { l: -0.45, r: 1.45, t: -0.45, b: 1.45 };                       // fully outside the picture (as a fraction of it)
  const Pz = (b, o) => Object.assign({}, b, o);
  const IN_MOVES = [
    { id: 'none', th: 'ไม่มี', use: 'โผล่ทันทีไม่มีท่า' },
    { id: 'fade', th: 'จางเข้า', dur: 0.35, use: 'ปุ่ม ป้ายชื่อ ข้อความ — เหมาะกับของที่โผล่ต่อคิวทีละอัน', make: (b, d) => [K(0, Pz(b, { y: b.y + 0.04, alpha: 0 }), 'quadOut'), K(d, b)] },
    { id: 'pop', th: 'ป๊อปเด้ง', dur: 0.35, use: 'ข้อความ สติกเกอร์ ไอคอน อีโมจิ — เด้งขึ้นมาแบบมีชีวิต', make: (b, d) => [K(0, Pz(b, { scale: 0, alpha: 0 }), 'back'), K(d, b)] },
    { id: 'slam', th: 'ซูมกระแทก', dur: 0.22, use: 'คำเน้น ข้อความตัวใหญ่ ป้ายประกาศ — กระแทกลงมาเต็มแรง', make: (b, d) => [K(0, Pz(b, { scale: b.scale * 3, alpha: 0 }), 'quadOut'), K(d, b)] },
    { id: 'slideL', th: 'เลื่อนเข้าจากซ้าย', dur: 0.45, use: 'ไอเท็ม ภาพตัวละคร โลโก้ แถบข้อความ — สไลด์เข้าจากขอบซ้าย', make: (b, d) => [K(0, Pz(b, { x: OFF.l }), 'cubicOut'), K(d, b)] },
    { id: 'slideR', th: 'เลื่อนเข้าจากขวา', dur: 0.45, use: 'ไอเท็ม ภาพตัวละคร โลโก้ แถบข้อความ — สไลด์เข้าจากขอบขวา', make: (b, d) => [K(0, Pz(b, { x: OFF.r }), 'cubicOut'), K(d, b)] },
    { id: 'slideT', th: 'เลื่อนลงจากบน', dur: 0.45, use: 'ป้ายห้อย แบนเนอร์ ข้อความหัวเรื่อง — ไหลลงมาจากขอบบน', make: (b, d) => [K(0, Pz(b, { y: OFF.t }), 'cubicOut'), K(d, b)] },
    { id: 'slideB', th: 'ผุดจากขอบล่าง', dur: 0.5, use: 'ภาพตัวละคร คน ตัวการ์ตูน — โผล่ขึ้นมาจากล่างจอ', make: (b, d) => [K(0, Pz(b, { y: OFF.b }), 'back'), K(d, b)] },
    { id: 'slideLtilt', th: 'สไลด์เข้าซ้าย+เอียง', dur: 0.6, use: 'ไอเท็ม/สิ่งของ เช่น โทรศัพท์ ของวิเศษ — พุ่งเข้ามาเอียงๆ แล้วตั้งตรง', make: (b, d) => [K(0, Pz(b, { x: OFF.l, rot: b.rot - 30 }), 'cubicOut'), K(d * 0.72, Pz(b, { x: b.x + 0.015, rot: b.rot + 7 }), 'quadInOut'), K(d, b)] },
    { id: 'spinzoom', th: 'หมุนซูมเข้า', dur: 0.6, use: 'แผง การ์ด โลโก้ หน้าจอเกม — หมุนเล็กๆ แล้วขยายเข้ามาเต็ม', make: (b, d) => [K(0, Pz(b, { scale: 0.05, rot: b.rot - 40, alpha: 0 }), 'cubicOut'), K(d * 0.2, Pz(b, { scale: b.scale * 0.2, rot: b.rot - 34, alpha: 1 }), 'cubicOut'), K(d, b)] },
    { id: 'drop', th: 'ตกลงมาเด้ง', dur: 0.7, use: 'ไอเท็มที่หล่นลงมา ป้ายราคา ของรางวัล — ตกแล้วเด้งดึ๋ง', make: (b, d) => [K(0, Pz(b, { y: OFF.t }), 'bounce'), K(d, b)] },
    { id: 'spin', th: 'หมุนเข้า', dur: 0.5, use: 'ดาว เหรียญ ไอคอน — หมุนเป็นวงเข้ามา', make: (b, d) => [K(0, Pz(b, { scale: 0, rot: b.rot - 180, alpha: 0 }), 'back'), K(d, b)] }
  ];
  // loop moves: the pose at step i (0 = rest) every `half` seconds, easing between them
  const sg = i => (i === 0 ? 0 : (i % 2 ? 1 : -1));
  const LOOP_MOVES = [
    { id: 'none', th: 'ค้างนิ่ง', use: 'อยู่นิ่งๆ' },
    { id: 'swing', th: 'แกว่ง', half: 0.55, ease: 'easeInOut', pose: (b, i) => Pz(b, { rot: b.rot + sg(i) * 7 }), use: 'ไอเท็มห้อย โทรศัพท์ ป้าย — แกว่งซ้ายขวาเบาๆ' },
    { id: 'bob', th: 'ลอยขึ้นลง', half: 0.6, ease: 'easeInOut', pose: (b, i) => Pz(b, { y: b.y + sg(i) * 0.012 }), use: 'ตัวละคร ไอเท็ม สติกเกอร์ — ลอยขึ้นลงให้ดูมีชีวิต' },
    { id: 'pulse', th: 'เต้นตุบๆ', half: 0.35, ease: 'quadInOut', pose: (b, i) => Pz(b, { scale: b.scale * (i % 2 ? 1.1 : 1) }), use: 'หัวใจ ปุ่มกด ลูกศรชี้ — ดึงสายตา' },
    { id: 'breathe', th: 'หายใจ', half: 0.9, ease: 'easeInOut', pose: (b, i) => Pz(b, { scale: b.scale * (i % 2 ? 1.04 : 1) }), use: 'ภาพตัวละคร โลโก้ — ขยายหดช้าๆ' },
    { id: 'wobble', th: 'ส่ายเบาๆ', half: 0.25, ease: 'quadInOut', pose: (b, i) => Pz(b, { rot: b.rot + sg(i) * 3.5 }), use: 'เครื่องหมาย ? ! ข้อความ — ส่ายเหมือนสงสัย' },
    { id: 'shake', th: 'สั่น', half: 0.06, ease: 'linear', pose: (b, i) => Pz(b, { x: b.x + sg(i) * 0.006, rot: b.rot + sg(i) * 2 }), use: 'ตกใจ ระเบิด คำเตือน — สั่นถี่ๆ' },
    { id: 'blink', th: 'กะพริบ', half: 0.3, ease: 'hold', pose: (b, i) => Pz(b, { alpha: i % 2 ? 0.15 : 1 }), use: 'ไฟเตือน ลูกศร ปุ่มกดตรงนี้ — ติดๆดับๆ' }
  ];
  const OUT_MOVES = [
    { id: 'none', th: 'ไม่มี', use: 'หายไปทันทีตอนจบ' },
    { id: 'fadeOut', th: 'จางหาย', dur: 0.3, use: 'ได้กับทุกอย่าง — ค่อยๆ จางออก', make: (b, d) => [K(0, b, 'quadIn'), K(d, Pz(b, { alpha: 0 }))] },
    { id: 'shrink', th: 'ย่อหาย', dur: 0.3, use: 'ข้อความ สติกเกอร์ ไอคอน — ย่อจนหาย', make: (b, d) => [K(0, b, 'backIn'), K(d, Pz(b, { scale: 0, alpha: 0 }))] },
    { id: 'outL', th: 'เลื่อนออกซ้าย', dur: 0.4, use: 'ไอเท็ม ภาพตัวละคร โลโก้', make: (b, d) => [K(0, b, 'cubicIn'), K(d, Pz(b, { x: OFF.l }))] },
    { id: 'outR', th: 'เลื่อนออกขวา', dur: 0.4, use: 'ไอเท็ม ภาพตัวละคร โลโก้', make: (b, d) => [K(0, b, 'cubicIn'), K(d, Pz(b, { x: OFF.r }))] },
    { id: 'outT', th: 'ลอยขึ้นออกบน', dur: 0.4, use: 'ป้าย ข้อความ บอลลูน', make: (b, d) => [K(0, b, 'cubicIn'), K(d, Pz(b, { y: OFF.t }))] },
    { id: 'outB', th: 'จมลงล่าง', dur: 0.4, use: 'ภาพตัวละคร คน — ดำดิ่งลงล่างจอ', make: (b, d) => [K(0, b, 'cubicIn'), K(d, Pz(b, { y: OFF.b }))] },
    { id: 'floatUp', th: 'ลอยขึ้นจางหาย', dur: 0.8, use: 'เครื่องหมาย ? ! อีโมจิ ข้อความ', make: (b, d) => [K(0, b, 'cubicOut'), K(d, Pz(b, { y: b.y - 0.1, scale: b.scale * 1.1, alpha: 0 }))] },
    { id: 'spinOut', th: 'หมุนซูมออก', dur: 0.5, use: 'แผง การ์ด โลโก้', make: (b, d) => [K(0, b, 'backIn'), K(d, Pz(b, { scale: 0.05, rot: b.rot + 40, alpha: 0 }))] }
  ];
  const find = (list, id) => list.find(x => x.id === id) || list[0];

  /** Keyframes for a layer of `len` seconds resting at pose b: [in] · [loop / hold] · [out]. */
  function compose(b, len, o) {
    o = o || {}; const di = find(IN_MOVES, o.inId), dl = find(LOOP_MOVES, o.loopId), dout = find(OUT_MOVES, o.outId);
    let inD = di.make ? clamp(num(o.inD, di.dur), 0.08, Math.max(0.08, len * 0.6)) : 0;
    let outD = dout.make ? clamp(num(o.outD, dout.dur), 0.08, Math.max(0.08, len * 0.5)) : 0;
    if (inD + outD > len * 0.98) { const f = len * 0.98 / (inD + outD); inD *= f; outD *= f; }
    const kf = [], rest = Pz(b, { alpha: 1 });
    if (inD) di.make(rest, inD).forEach(k => kf.push(k)); else kf.push(K(0, rest, 'linear'));
    const t0 = inD, t1 = len - outD;
    if (dl.pose && t1 - t0 >= dl.half * 1.2) {
      const n = Math.min(160, Math.floor((t1 - t0) / dl.half));
      for (let i = 0; i <= n; i++) kf.push(K(t0 + i * dl.half, dl.pose(rest, i), dl.ease));
      kf.push(K(t1, rest, 'easeInOut'));
    } else if (outD) kf.push(K(t0 < t1 ? t1 : t0, rest, 'linear'));
    if (outD) dout.make(rest, outD).forEach(k => kf.push(Object.assign({}, k, { t: t1 + k.t })));
    kf.sort((a, b2) => a.t - b2.t);
    const out = [];                                           // two keyframes at the same moment: the later one wins
    kf.forEach(k => { if (out.length && Math.abs(out[out.length - 1].t - k.t) < 0.004) out[out.length - 1] = k; else out.push(k); });
    return out.map(k => { k.t = Math.round(k.t * 1000) / 1000; ['x', 'y', 'scale', 'rot', 'alpha'].forEach(f => { k[f] = Math.round(k[f] * 10000) / 10000; }); return k; });
  }
  /** Rebuild the keyframes from rest + anim (after the layer was moved, resized or its length changed). */
  function recompose(L) {
    if (!L.anim) return L;
    L.kf = compose(L.rest, Math.max(0.1, L.end - L.start), L.anim);
    return L;
  }
  /** Pick the in / loop / out moves of a layer (null leaves that part alone) and rebuild its keyframes. */
  function setAnim(L, part) {
    const a = L.anim || { inId: 'none', loopId: 'none', outId: 'none', inD: null, outD: null };
    Object.keys(part).forEach(k => { a[k] = part[k]; });
    L.anim = a; return recompose(L);
  }
  function shiftAll(L, dx, dy) {
    L.rest.x += dx; L.rest.y += dy;
    if (L.anim) recompose(L); else L.kf.forEach(k => { k.x += dx; k.y += dy; });
  }
  function setRest(L, field, val) {
    const old = L.rest[field]; L.rest[field] = val;
    if (L.anim) recompose(L);
    else L.kf.forEach(k => { if (field === 'scale') k.scale = old > 1e-6 ? k.scale * val / old : val; else k[field] += val - old; });
  }

  /* ----------------------------------------------------------------- picture assets (items, characters, logos) */
  const ASSETS = {};                                                      // id -> { id, name, url, w, h, img, ready, keyed }
  function registerAsset(a) {
    const old = ASSETS[a.id]; if (old && old.url === a.url) return old.ready;
    const rec = { id: a.id, name: a.name || '', url: a.url, w: a.w || 0, h: a.h || 0, img: null, keyed: {} };
    rec.ready = new Promise(res => {
      const im = new Image();
      im.onload = () => { rec.img = im; rec.w = im.naturalWidth || rec.w; rec.h = im.naturalHeight || rec.h; CACHE.clear(); if (S.bus) S.bus.emit('motion:asset', { id: rec.id }); res(rec); };
      im.onerror = () => res(rec); im.src = a.url;
    });
    ASSETS[a.id] = rec; return rec.ready;
  }
  function loadAssets(map) { Object.keys(map || {}).forEach(id => registerAsset({ id: id, name: map[id].name, url: map[id].url, w: map[id].w, h: map[id].h })); }
  function getAsset(id) { return ASSETS[id] || null; }
  /** Wait until every picture used by the project is decoded (the exporters call this before the first frame). */
  function ready(project) {
    const list = (project.motion && project.motion.layers) || [], ids = {}, ps = [];
    list.forEach(L => { if (L.kind === 'image' && L.img && ASSETS[L.img] && !ids[L.img]) { ids[L.img] = 1; ps.push(ASSETS[L.img].ready); } });
    return Promise.all(ps);
  }
  /** The picture with its plain background removed: flood fill from the border over pixels close to the corner colour. */
  function keyedCanvas(rec, tol) {
    const key = Math.round(tol); if (rec.keyed[key]) return rec.keyed[key];
    const W = rec.w, H = rec.h, c = document.createElement('canvas'); c.width = W; c.height = H;
    const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(rec.img, 0, 0);
    const id = x.getImageData(0, 0, W, H), d = id.data, idx = (px, py) => (py * W + px) * 4;
    const cs = [idx(0, 0), idx(W - 1, 0), idx(0, H - 1), idx(W - 1, H - 1)];
    if (cs.some(i => d[i + 3] < 200)) { rec.keyed[key] = rec.img; return rec.img; }            // a picture that already has a see-through background
    const bg = [0, 1, 2].map(ch => (d[cs[0] + ch] + d[cs[1] + ch] + d[cs[2] + ch] + d[cs[3] + ch]) / 4);
    const thr = Math.max(4, tol * 2.55), dist = i => Math.sqrt((d[i] - bg[0]) ** 2 + (d[i + 1] - bg[1]) ** 2 + (d[i + 2] - bg[2]) ** 2);
    const seen = new Uint8Array(W * H), q = new Int32Array(W * H); let qh = 0, qt = 0;
    const push = (px, py) => { const p = py * W + px; if (seen[p]) return; if (dist(p * 4) > thr) return; seen[p] = 1; q[qt++] = p; };
    for (let i = 0; i < W; i++) { push(i, 0); push(i, H - 1); } for (let j = 0; j < H; j++) { push(0, j); push(W - 1, j); }
    while (qh < qt) { const p = q[qh++], px = p % W, py = (p - px) / W; if (px > 0) push(px - 1, py); if (px < W - 1) push(px + 1, py); if (py > 0) push(px, py - 1); if (py < H - 1) push(px, py + 1); }
    for (let p = 0; p < W * H; p++) {
      if (seen[p]) { d[p * 4 + 3] = 0; continue; }
      const px = p % W, py = (p - px) / W;                                                     // soft edge: a kept pixel touching the removed area fades with its colour distance
      if ((px > 0 && seen[p - 1]) || (px < W - 1 && seen[p + 1]) || (py > 0 && seen[p - W]) || (py < H - 1 && seen[p + W])) { const f = (dist(p * 4) - thr) / (thr * 0.6); if (f < 1) d[p * 4 + 3] = Math.round(255 * Math.max(0.15, f)); }
    }
    x.putImageData(id, 0, 0); rec.keyed[key] = c; return c;
  }

  /* ----------------------------------------------------------------- the layer bitmap (cached) */
  // The layer (text with plate / pixel look, or a picture) is painted ONCE into a small canvas with its glow and shadow, then every frame
  // just places that bitmap with the keyframed move / scale / rotate / opacity. Painting it into its own bitmap also keeps opacity
  // clean: the glow and shadow fade together with the layer instead of ghosting through it.
  const CACHE = new Map(), CACHE_MAX = 48;
  function scratch() { return scratch.c || (scratch.c = document.createElement('canvas').getContext('2d')); }
  function fontSpec(L, px) { return (L.italic ? 'italic ' : '') + (L.weight || 700) + ' ' + px + 'px ' + L.font; }
  function shadowRgba(sh) {
    const o = sh.opacity == null || isNaN(+sh.opacity) ? 100 : clamp(+sh.opacity, 0, 100);
    return o >= 100 ? sh.color : S.util.hexToRgba(sh.color, +(o / 100).toFixed(3));
  }
  /** Supersampling: when a keyframe scales the layer up, the bitmap is painted bigger so it stays sharp. */
  function superOf(L) { let m = 1; L.kf.forEach(k => { if (k.scale > m) m = k.scale; }); return clamp(Math.ceil(m * 2) / 2, 1, 3); }
  function shade(hex, amt) {
    const n = parseInt(String(hex).replace('#', ''), 16) || 0, r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255, t = amt < 0 ? 0 : 255, a = Math.abs(amt);
    return 'rgb(' + Math.round(r + (t - r) * a) + ',' + Math.round(g + (t - g) * a) + ',' + Math.round(b + (t - b) * a) + ')';
  }
  function rrPath(c, x, y, w, h, r) { r = Math.max(0, Math.min(r, w / 2, h / 2)); c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  const LIMIT = 4096;
  function newCanvas(W, H) { const k = Math.min(1, LIMIT / W, LIMIT / H), cv = document.createElement('canvas'); cv.width = Math.max(2, Math.floor(W * k)); cv.height = Math.max(2, Math.floor(H * k)); return { cv: cv, k: k, c: cv.getContext('2d') }; }

  function textBitmap(L, scale, ss) {
    const den = scale * ss, px = Math.max(1, L.size * den), lh = px * 1.22, lines = String(L.text).split('\n');
    const m = scratch(); m.font = fontSpec(L, px);
    let tw = 1; lines.forEach(s => { tw = Math.max(tw, m.measureText(s).width); });
    const th = lines.length * lh, pl = L.plate && L.plate.on ? L.plate : null, padX = pl ? px * pl.padX : 0, padY = pl ? px * pl.padY : 0;
    const ol = L.outline.on ? Math.max(0, +L.outline.width || 0) * den : 0;
    const gl = L.glow.on ? S.render.glowLayers(L.glow) : [];
    const glowR = gl.reduce((a, l) => Math.max(a, l.blur + Math.abs(l.dx || 0)), 0) * den;
    const sdx = L.shadow.on ? (+L.shadow.dx || 0) / 100 * px : 0, sdy = L.shadow.on ? (+L.shadow.dy || 0) / 100 * px : 0;
    const sbl0 = L.shadow.on ? Math.max(0, +L.shadow.blur || 0) * den : 0, pix = L.pixel > 0, sbl = pix ? 0 : sbl0;
    const extra = Math.ceil(px * 0.25 + ol + glowR * 1.6 + sbl * 1.6 + Math.max(Math.abs(sdx), Math.abs(sdy)) + (pl ? px * 0.2 : 0) + 6);
    const bw = tw + 2 * padX, bh = th + 2 * padY, W = Math.ceil(bw + 2 * extra), H = Math.ceil(bh + 2 * extra);
    const N = newCanvas(W, H), cv = N.cv, k = N.k, c = N.c, cx = W / 2, cy0 = extra + padY + lh / 2;
    const paintText = (g, f, withGlow, hard) => {                                // f = how many canvas px one layout unit is
      g.save(); g.scale(f, f); g.font = fontSpec(L, px); g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineJoin = 'round'; g.miterLimit = 2;
      const each = fn => lines.forEach((s, i) => fn(s, cx, cy0 + i * lh));
      const stroke = () => each((s, x, y) => { g.lineWidth = ol * 2; g.strokeText(s, x, y); });
      if (L.shadow.on && (sdx || sdy || sbl)) {                                  // drop shadow, cast once by the outermost shape
        g.save(); g.shadowColor = shadowRgba(L.shadow); g.shadowBlur = hard ? 0 : sbl * f; g.shadowOffsetX = sdx * f; g.shadowOffsetY = sdy * f;
        if (ol > 0) { g.strokeStyle = L.outline.color; stroke(); } g.fillStyle = ol > 0 ? L.outline.color : L.color; each((s, x, y) => g.fillText(s, x, y)); g.restore();
      }
      if (withGlow) gl.forEach(l => { g.save(); g.globalAlpha = l.a; g.shadowColor = L.glow.color; g.shadowBlur = l.blur * den * f; g.shadowOffsetX = (l.dx || 0) * den * f; g.shadowOffsetY = 0; g.fillStyle = L.glow.color; each((s, x, y) => g.fillText(s, x, y)); g.restore(); });
      if (ol > 0) { g.strokeStyle = L.outline.color; stroke(); }
      g.fillStyle = L.color; each((s, x, y) => g.fillText(s, x, y)); g.restore();
    };
    if (pl) {                                                                     // the button / label plate
      c.save(); c.scale(k, k);
      const x0 = extra, y0 = extra, r = Math.min(px * pl.radius, bh / 2, bw / 2), ln = Math.max(1, px * 0.06);
      c.shadowColor = 'rgba(0,0,0,.5)'; c.shadowBlur = px * 0.2 * k; c.shadowOffsetY = px * 0.1 * k;
      const gr = c.createLinearGradient(0, y0, 0, y0 + bh); gr.addColorStop(0, shade(pl.color, 0.3)); gr.addColorStop(0.5, pl.color); gr.addColorStop(1, shade(pl.color, -0.4));
      c.fillStyle = gr; rrPath(c, x0, y0, bw, bh, r); c.fill();
      c.shadowColor = 'transparent'; c.lineWidth = ln; c.strokeStyle = shade(pl.color, -0.62); c.stroke();
      c.fillStyle = 'rgba(255,255,255,.17)'; rrPath(c, x0 + px * 0.07, y0 + px * 0.07, bw - px * 0.14, bh * 0.4, Math.max(0, r * 0.8)); c.fill();
      c.restore();
    }
    if (pix) {                                                                    // pixel look: letters painted on a coarse grid, then enlarged without smoothing
      const bu = Math.max(1, L.pixel * den), lw = Math.max(1, Math.ceil(W / bu)), lhh = Math.max(1, Math.ceil(H / bu));
      const low = document.createElement('canvas'); low.width = lw; low.height = lhh; const lc = low.getContext('2d', { willReadFrequently: true });
      paintText(lc, 1 / bu, false, true);
      const id = lc.getImageData(0, 0, lw, lhh), d = id.data; for (let i = 3; i < d.length; i += 4) d[i] = d[i] >= 110 ? 255 : 0; lc.putImageData(id, 0, 0);
      c.save(); c.imageSmoothingEnabled = false;
      gl.forEach(l => { c.save(); c.globalAlpha = l.a; c.shadowColor = L.glow.color; c.shadowBlur = l.blur * den * k; c.shadowOffsetX = (l.dx || 0) * den * k; c.shadowOffsetY = 0; c.drawImage(low, 0, 0, lw * bu * k, lhh * bu * k); c.restore(); });
      c.drawImage(low, 0, 0, lw * bu * k, lhh * bu * k); c.restore();
    } else paintText(c, k, true, false);
    return { cv: cv, ox: W / 2 * k, oy: H / 2 * k, k: k, ss: ss, w: W / ss, h: H / ss, tw: bw / ss, th: bh / ss };
  }

  function imageBitmap(L, scale, ss) {
    const rec = ASSETS[L.img]; if (!rec || !rec.img || !rec.w) return null;
    const den = scale * ss, wpx = Math.max(2, L.w * den), hpx = wpx * rec.h / rec.w, src = L.key && L.key.on ? keyedCanvas(rec, L.key.tol) : rec.img;
    const gl = L.glow.on ? S.render.glowLayers(L.glow) : [], glowR = gl.reduce((a, l) => Math.max(a, l.blur + Math.abs(l.dx || 0)), 0) * den;
    const small = Math.min(wpx, hpx), sdx = L.shadow.on ? (+L.shadow.dx || 0) / 100 * small * 0.5 : 0, sdy = L.shadow.on ? (+L.shadow.dy || 0) / 100 * small * 0.5 : 0, sbl = L.shadow.on ? Math.max(0, +L.shadow.blur || 0) * den : 0;
    const extra = Math.ceil(glowR * 1.6 + sbl * 1.6 + Math.max(Math.abs(sdx), Math.abs(sdy)) + 6), W = Math.ceil(wpx + 2 * extra), H = Math.ceil(hpx + 2 * extra);
    const N = newCanvas(W, H), cv = N.cv, k = N.k, c = N.c; c.imageSmoothingEnabled = true; c.imageSmoothingQuality = 'high';
    const at = (g) => g.drawImage(src, extra * k, extra * k, wpx * k, hpx * k);
    if (L.shadow.on && (sdx || sdy || sbl)) { c.save(); c.shadowColor = shadowRgba(L.shadow); c.shadowBlur = sbl * k; c.shadowOffsetX = sdx * k; c.shadowOffsetY = sdy * k; at(c); c.restore(); }
    gl.forEach(l => { c.save(); c.globalAlpha = l.a; c.shadowColor = L.glow.color; c.shadowBlur = l.blur * den * k; c.shadowOffsetX = (l.dx || 0) * den * k; c.shadowOffsetY = 0; at(c); c.restore(); });
    at(c);
    return { cv: cv, ox: W / 2 * k, oy: H / 2 * k, k: k, ss: ss, w: W / ss, h: H / ss, tw: wpx / ss, th: hpx / ss };
  }

  function bitmap(L, scale) {
    const ss = superOf(L), den = scale * ss, img = L.kind === 'image';
    if (img) { const rec = ASSETS[L.img]; if (!rec || !rec.img) return null; }
    const key = (img ? ['I', L.img, L.w, JSON.stringify(L.key)] : ['T', L.text, L.font, L.weight, L.italic, L.color, L.size, JSON.stringify(L.outline), JSON.stringify(L.plate), L.pixel])
      .concat([JSON.stringify(L.shadow), JSON.stringify(L.glow), den.toFixed(3)]).join('\u0001');
    const hit = CACHE.get(key);
    if (hit) { CACHE.delete(key); CACHE.set(key, hit); return hit; }
    const out = img ? imageBitmap(L, scale, ss) : textBitmap(L, scale, ss);
    if (!out) return null;
    CACHE.set(key, out); if (CACHE.size > CACHE_MAX) CACHE.delete(CACHE.keys().next().value);
    return out;
  }

  /* ----------------------------------------------------------------- drawing */
  const visibleAt = (L, t) => !L.hidden && t >= L.start - 1e-6 && t < L.end - 1e-6;
  const hasBody = L => (L.kind === 'image' ? !!L.img : !!L.text);
  const rnd = n => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
  const hashId = id => { let h = 0; for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0; return Math.abs(h % 997); };

  /** Draw every layer of one group ('back' = behind the caption, 'front' = in front of it) that is on screen at time t. */
  function draw(ctx, w, h, t, project, scale, which) {
    const M = project.motion, list = M && M.layers; if (!list || !list.length) return;
    for (let i = 0; i < list.length; i++) {
      const L = list[i]; if ((L.z === 'back' ? 'back' : 'front') !== which || !visibleAt(L, t) || !hasBody(L)) continue;
      const rel = t - L.start, st = sample(L, rel); if (st.alpha <= 0.002 || st.scale <= 0.002) continue;
      drawOne(ctx, w, h, L, st, scale, rel);
    }
  }
  function glitchAmt(L, rel) {
    const g = L.glitch; if (!g) return 0; const len = L.end - L.start; let a = 0;
    if (g.inD > 0 && rel < g.inD) a = Math.max(a, 1 - rel / g.inD);
    if (g.outD > 0 && rel > len - g.outD) a = Math.max(a, (rel - (len - g.outD)) / g.outD);
    return clamp(a, 0, 1);
  }
  function drawOne(ctx, w, h, L, st, scale, rel) {
    const b = bitmap(L, scale); if (!b) return;
    const gi = rel == null ? 0 : glitchAmt(L, rel), seed = hashId(L.id || 'x') + Math.floor((rel || 0) * 24) * 13;
    if (gi > 0 && rnd(seed) < gi * 0.28) return;                                 // flicker: the layer drops out for a frame
    const dx = -b.ox / b.ss / b.k, dy = -b.oy / b.ss / b.k, dw = b.cv.width / b.ss / b.k, dh = b.cv.height / b.ss / b.k;
    ctx.save();
    ctx.globalAlpha *= clamp(st.alpha, 0, 1);
    ctx.translate(st.x * w, st.y * h); if (st.rot) ctx.rotate(st.rot * PI / 180); if (st.scale !== 1) ctx.scale(st.scale, st.scale);
    ctx.imageSmoothingEnabled = L.pixel > 0 ? false : true; ctx.imageSmoothingQuality = 'high';
    if (gi > 0) {                                                                // glitch: horizontal bands slide sideways
      const n = 10, bh = b.cv.height / n;
      for (let i = 0; i < n; i++) {
        const sh = rnd(seed + i * 7.3) < 0.6 ? (rnd(seed + i * 3.1) - 0.5) * 2 * gi * dw * 0.45 : 0;
        ctx.drawImage(b.cv, 0, i * bh, b.cv.width, bh, dx + sh, dy + i * dh / n, dw, dh / n + 0.5);
      }
    } else ctx.drawImage(b.cv, dx, dy, dw, dh);
    ctx.restore();
  }

  /** Where a layer sits on a w x h picture right now (for the selection frame): centre, half sizes, rotation. null when it is not on screen. */
  function boxAt(L, t, w, h, scale) {
    if (!visibleAt(L, t)) return null;
    const st = sample(L, t - L.start), b = bitmap(L, scale); if (!b) return null;
    return { cx: st.x * w, cy: st.y * h, hw: b.tw * st.scale / 2, hh: b.th * st.scale / 2, rot: st.rot, st: st };
  }

  /** Make sure the fonts the layers use are loaded (the caller redraws afterwards). */
  function fontsNeeded(project) {
    const list = (project.motion && project.motion.layers) || [], out = [];
    list.forEach(L => { if (L.kind !== 'image') out.push({ font: L.font, italic: !!L.italic, weight: L.weight || 700, text: L.text }); });
    return out;
  }
  function clearCache() { CACHE.clear(); }

  S.motionText = { EASES: EASES, PRESETS: PRESETS, PROPS: PROPS, IN_MOVES: IN_MOVES, LOOP_MOVES: LOOP_MOVES, OUT_MOVES: OUT_MOVES, easeFn: easeFn, sample: sample,
    normalize: normalize, makeLayer: makeLayer, newId: newId, restOf: restOf, compose: compose, recompose: recompose, setAnim: setAnim, shiftAll: shiftAll, setRest: setRest,
    registerAsset: registerAsset, loadAssets: loadAssets, getAsset: getAsset, ready: ready,
    draw: draw, drawOne: drawOne, boxAt: boxAt, visibleAt: visibleAt, fontsNeeded: fontsNeeded, clearCache: clearCache };
})(window.SubEd);
