/* =====================================================================
 * Render layer — draws a frame (video + burned-in caption) onto a canvas.
 * Reads ONLY its arguments (never DOM controls), so it can be driven by the
 * preview, an exporter, a Worker or an AI-generated style alike.
 *
 * Animations are registered by id. A canvas animation maps progress p (0..1) and the font size in px (fp)
 * to { alpha, scale, dx, dy (px, +down), rot (rad), blur (px), reveal (0..1: words appear one by one) }.
 * Their length is style.fxDur seconds (0.01-3, per line or global); `duration` is only the default.
 * (The live preview uses matching CSS keyframes named fx-<id> in css/app.css — add both when adding an animation.)
 * ===================================================================== */
(function (S) {
  'use strict';
  const hexToRgba = S.util.hexToRgba;

  const animations = S.createRegistry('caption animation');
  const clamp01 = v => Math.max(0, Math.min(1, v));
  const easeOut = p => 1 - Math.pow(1 - p, 3);
  const easeBack = p => { const c1 = 1.70158, c3 = c1 + 1, q = p - 1; return 1 + c3 * q * q * q + c1 * q * q; };
  const easeBounce = p => {
    const n = 7.5625, d = 2.75;
    if (p < 1 / d) return n * p * p;
    if (p < 2 / d) { p -= 1.5 / d; return n * p * p + 0.75; }
    if (p < 2.5 / d) { p -= 2.25 / d; return n * p * p + 0.9375; }
    p -= 2.625 / d; return n * p * p + 0.984375;
  };
  const A = { dur: 0.22 };
  animations.register('fade',  { duration: A.dur, at: p => ({ alpha: p }) });
  animations.register('pop',   { duration: A.dur, at: p => ({ alpha: clamp01(p * 2), scale: 0.7 + 0.3 * easeBack(p) }) });
  animations.register('slide', { duration: A.dur, at: (p, fp) => ({ alpha: p, dy: (1 - easeOut(p)) * 0.35 * fp }) });          // เลื่อนขึ้น
  animations.register('slidedown',  { duration: 0.3, at: (p, fp) => ({ alpha: p, dy: -(1 - easeOut(p)) * 0.8 * fp }) });
  animations.register('slideleft',  { duration: 0.3, at: (p, fp) => ({ alpha: p, dx: -(1 - easeOut(p)) * 1.6 * fp }) });       // วิ่งเข้าจากซ้าย
  animations.register('slideright', { duration: 0.3, at: (p, fp) => ({ alpha: p, dx: (1 - easeOut(p)) * 1.6 * fp }) });        // วิ่งเข้าจากขวา
  animations.register('zoom',   { duration: 0.3, at: p => ({ alpha: clamp01(p * 2), scale: 1.8 - 0.8 * easeOut(p) }) });       // ซูมเข้า (ใหญ่ → ปกติ)
  animations.register('bounce', { duration: 0.5, at: p => ({ alpha: clamp01(p * 4), scale: 0.3 + 0.7 * easeBounce(p) }) });    // เด้ง
  animations.register('drop',   { duration: 0.5, at: (p, fp) => ({ alpha: clamp01(p * 5), dy: -(1 - easeBounce(p)) * 1.6 * fp }) });   // ตกลงมาแล้วเด้ง
  animations.register('spin',   { duration: 0.4, at: p => ({ alpha: clamp01(p * 2), scale: 0.6 + 0.4 * easeBack(p), rot: -(1 - easeBack(p)) * 0.5 }) });   // หมุนเข้า
  animations.register('blur',   { duration: 0.4, at: (p, fp) => ({ alpha: p, blur: (1 - p) * 0.3 * fp }) });                   // เบลอ → ชัด
  animations.register('typing', { duration: 0.6, at: p => ({ alpha: 1, reveal: p }) });
  // CapCut "Zoom In" family: small -> full size (zoomin), small + bright -> full size and normal colour (zoomcolor),
  // and a slow push-in that lasts the whole line (slowzoom: `whole` = its length is the cue's length, not fxDur).
  animations.register('zoomin',    { duration: 0.3, at: p => ({ alpha: clamp01(p * 2.5), scale: 0.35 + 0.65 * easeOut(p) }) });
  animations.register('zoomcolor', { duration: 0.4, at: p => ({ alpha: clamp01(p * 2.5), scale: 0.35 + 0.65 * easeOut(p), bright: (1 - easeOut(p)) * 1.2 }) });
  animations.register('slowzoom',  { duration: 1, whole: true, at: p => ({ alpha: 1, scale: 1 + 0.12 * p }) });                                       // ขึ้นทีละคำ

  // ---- CSS-like timing functions + keyframe sampling --------------------------------------------------------------
  // The animations moved from Shadow Caption Lab are written ONCE as keyframes (the same numbers as the CSS keyframes in
  // css/app.css, which draw the live preview) and sampled here for the burned-in export.
  function bezier(x1, y1, x2, y2) {
    return function (x) {
      if (x <= 0) return 0; if (x >= 1) return 1;
      let lo = 0, hi = 1, t = x;
      for (let i = 0; i < 32; i++) {
        const cx = 3 * x1 * t * (1 - t) * (1 - t) + 3 * x2 * t * t * (1 - t) + t * t * t;
        if (Math.abs(cx - x) < 1e-5) break;
        if (cx < x) lo = t; else hi = t;
        t = (lo + hi) / 2;
      }
      return 3 * y1 * t * (1 - t) * (1 - t) + 3 * y2 * t * t * (1 - t) + t * t * t;
    };
  }
  const EASE = { linear: p => p, out: bezier(0, 0, 0.58, 1), in: bezier(0.42, 0, 1, 1), inout: bezier(0.42, 0, 0.58, 1), spring: bezier(0.3, 0.7, 0.4, 1), wipe: bezier(0.6, 0, 0.2, 1) };
  const TKEYS = ['s', 'sx', 'sy', 'dx', 'dy', 'px', 'py', 'rot', 'skx'];
  const T0 = { s: 1, sx: 1, sy: 1, dx: 0, dy: 0, px: 0, py: 0, rot: 0, skx: 0 };
  function interpList(list, p, ease, lerp) {
    if (!list.length) return undefined;
    if (p <= list[0][0]) return list[0][1];
    for (let i = 1; i < list.length; i++) {
      if (p <= list[i][0]) { const a = list[i - 1], b = list[i], k = (p - a[0]) / Math.max(1e-9, b[0] - a[0]); return lerp(a[1], b[1], ease(k)); }
    }
    return list[list.length - 1][1];
  }
  const lerpN = (a, b, k) => a + (b - a) * k;
  const lerpT = (a, b, k) => { const o = {}; TKEYS.forEach(key => { o[key] = lerpN(a[key], b[key], k); }); return o; };
  /** frames: [[offset 0..1, { a: opacity, c: colour mix 0..1, b: blur (em), w: wipe 0..1, s/sx/sy/dx/dy/px/py/rot/skx: transform }], ...]
   *  Like CSS, every property is interpolated only between the frames that define it, with `ease` applied between each pair of frames.
   *  Result is in pixels / radians (fp = font px, bw / bh = the caption block). */
  function sampleKF(frames, p, ease, fp, bw, bh) {
    const ch = pick => frames.map(f => [f[0], pick(f[1])]).filter(x => x[1] !== undefined);
    const a = interpList(ch(o => o.a), p, ease, lerpN), c = interpList(ch(o => o.c), p, ease, lerpN), b = interpList(ch(o => o.b), p, ease, lerpN), w = interpList(ch(o => o.w), p, ease, lerpN);
    const t = interpList(ch(o => (TKEYS.some(k => k in o) ? Object.assign({}, T0, o) : undefined)), p, ease, lerpT) || T0;
    const r = { alpha: a == null ? 1 : a, scale: t.s, sx: t.sx, sy: t.sy, dx: t.dx * fp + t.px * (bw || 0), dy: t.dy * fp + t.py * (bh || 0), rot: t.rot * Math.PI / 180, skx: t.skx * Math.PI / 180 };
    if (c != null) r.col = c;
    if (b != null) r.blur = b * fp;
    if (w != null) r.wipe = w;
    return r;
  }
  const KF = {
    fade:   [[0, { a: 0 }], [1, { a: 1 }]],
    up:     [[0, { a: 0, dy: 0.6 }], [1, { a: 1, dy: 0 }]],
    zoomIn: [[0, { a: 0, s: 2.4 }], [1, { a: 1, s: 1 }]],
    bounce: [[0, { a: 0, s: 0.4 }], [0.55, { a: 1, s: 1.14 }], [0.78, { s: 0.96 }], [1, { a: 1, s: 1 }]],
    drop:   [[0, { a: 0, dy: -1.2 }], [0.55, { a: 1, dy: 0.08 }], [0.75, { dy: -0.04 }], [1, { a: 1, dy: 0 }]],
    tilt:   [[0, { a: 0, rot: -10, s: 0.8 }], [1, { a: 1, rot: 0, s: 1 }]],
    rubber: [[0, { a: 0, sx: 1, sy: 1 }], [0.2, { a: 1 }], [0.3, { sx: 1.25, sy: 0.75 }], [0.4, { sx: 0.75, sy: 1.25 }], [0.5, { sx: 1.15, sy: 0.85 }], [0.65, { sx: 0.95, sy: 1.05 }], [0.75, { sx: 1.05, sy: 0.95 }], [1, { a: 1, sx: 1, sy: 1 }]],
    glitch: [[0, { a: 0, px: -0.04 }], [0.1, { a: 1, px: 0.03, py: -0.02, skx: -8 }], [0.2, { px: -0.03, py: 0.01, skx: 6 }], [0.3, { px: 0.02, py: 0, skx: 0 }], [0.4, { px: -0.02, py: 0.02, skx: -4 }],
            [0.5, { px: 0, py: 0, skx: 0 }], [0.65, { px: 0.015 }], [0.8, { px: -0.01 }], [1, { a: 1, px: 0, py: 0, skx: 0 }]],
    shake:  [[0, { a: 0, dx: 0 }], [0.08, { a: 1, dx: -0.08 }], [0.24, { dx: 0.08 }], [0.4, { dx: -0.06 }], [0.56, { dx: 0.06 }], [0.72, { dx: -0.03 }], [0.88, { dx: 0.03 }], [1, { a: 1, dx: 0 }]],
    flicker:[[0, { a: 0 }], [0.08, { a: 1 }], [0.12, { a: 0.15 }], [0.2, { a: 1 }], [0.28, { a: 0.3 }], [0.36, { a: 1 }], [0.44, { a: 0.6 }], [0.52, { a: 1 }], [1, { a: 1 }]],
    pulse:  [[0, { s: 1 }], [0.5, { s: 1.07 }], [1, { s: 1 }]],
    float:  [[0, { dy: 0 }], [0.5, { dy: -0.09 }], [1, { dy: 0 }]],
    wave:   [[0, { dy: 0 }], [0.5, { dy: -0.16 }], [1, { dy: 0 }]],
    colour: [[0, { c: 0 }], [0.5, { c: 1 }], [1, { c: 0 }]]
  };
  const kfAt = (frames, ease) => (p, fp, bw, bh) => sampleKF(frames, p, ease, fp, bw, bh);

  // whole-line animations from the lab (length = style.fxDur, like the older ones)
  animations.register('flip',    { duration: 0.52, at: p => { const e = EASE.out(p); return { alpha: e, sy: Math.max(0.001, Math.cos((1 - e) * Math.PI / 2)) }; } });
  animations.register('rubber',  { duration: 0.8, at: kfAt(KF.rubber, EASE.linear) });
  animations.register('glitch',  { duration: 0.6, at: kfAt(KF.glitch, EASE.linear) });
  animations.register('shake',   { duration: 0.56, at: kfAt(KF.shake, EASE.linear) });
  animations.register('flicker', { duration: 0.7, at: kfAt(KF.flicker, EASE.linear) });
  animations.register('tilt',    { duration: 0.42, at: kfAt(KF.tilt, EASE.out) });
  animations.register('wipe',    { duration: 0.56, at: p => ({ alpha: 1, wipe: EASE.wipe(p) }) });
  // continuous: the whole line keeps moving while it is on screen (period in s)
  animations.register('pulse',   { duration: 1.1, inf: true, period: 1.1, at: kfAt(KF.pulse, EASE.inout) });
  animations.register('float',   { duration: 2, inf: true, period: 2, at: kfAt(KF.float, EASE.inout) });
  // word by word: every word runs `unitDur` s, the next one starts `style.fxStep` ms later
  animations.register('wordhl',     { duration: 0.35, unit: 'word', hl: true, unitDur: 0.35, at: p => ({ alpha: 1, col: p > 0 && p < 1 ? 1 : 0 }) });
  animations.register('wordbounce', { duration: 0.42, unit: 'word', unitDur: 0.42, at: kfAt(KF.bounce, EASE.spring) });
  animations.register('wordfade',   { duration: 0.36, unit: 'word', unitDur: 0.36, at: kfAt(KF.fade, EASE.out) });
  animations.register('wordup',     { duration: 0.38, unit: 'word', unitDur: 0.38, at: kfAt(KF.up, EASE.out) });
  animations.register('wordzoom',   { duration: 0.32, unit: 'word', unitDur: 0.32, at: kfAt(KF.zoomIn, EASE.out) });
  animations.register('wordreveal', { duration: 0.001, unit: 'word', unitDur: 0.001, at: p => ({ alpha: p > 0 ? 1 : 0 }) });
  // letter by letter (the stagger is shorter: 18% of the word step, at least 25 ms)
  animations.register('chartype',   { duration: 0.001, unit: 'char', unitDur: 0.001, at: p => ({ alpha: p > 0 ? 1 : 0 }) });
  animations.register('charfade',   { duration: 0.36, unit: 'char', unitDur: 0.36, at: kfAt(KF.fade, EASE.out) });
  animations.register('charbounce', { duration: 0.42, unit: 'char', unitDur: 0.42, at: kfAt(KF.bounce, EASE.spring) });
  animations.register('chardrop',   { duration: 0.6, unit: 'char', unitDur: 0.6, at: kfAt(KF.drop, EASE.spring) });
  animations.register('charup',     { duration: 0.36, unit: 'char', unitDur: 0.36, at: kfAt(KF.up, EASE.out) });
  animations.register('wave',       { duration: 0.9, unit: 'char', inf: true, period: 0.9, unitDur: 0.9, at: kfAt(KF.wave, EASE.inout) });
  animations.register('colorrun',   { duration: 1.2, unit: 'char', inf: true, period: 1.2, unitDur: 1.2, at: kfAt(KF.colour, EASE.inout) });

  /** Letters of a string: a Thai consonant with its vowel / tone marks is ONE letter (Intl.Segmenter), so the marks never come apart. */
  let segmenter = null;
  function graphemes(str) {
    if (window.Intl && Intl.Segmenter) {
      if (!segmenter) segmenter = new Intl.Segmenter('th', { granularity: 'grapheme' });
      return Array.from(segmenter.segment(str), x => x.segment);
    }
    return Array.from(str);
  }
  const animOf = st => (st && st.fx && st.fx !== 'none' && animations.has(st.fx)) ? animations.get(st.fx) : null;
  /** How many things move one at a time in `cue` (words, or letters) — 0 for a whole-line animation. */
  function unitCount(cue, anim) {
    if (!anim || !anim.unit) return 0;
    if (anim.unit === 'word') return cue.words.length;
    return cue.words.reduce((n, w) => n + graphemes((w.word || '').trim()).length, 0);
  }
  /** Stagger + length (s) for the per-word / per-letter animations of `cue`. Everything must be on screen before the line ends,
   *  so a short line squeezes the step (the last unit starts by 80% of the line at the latest). Used by the preview too. */
  function unitTiming(cue, st, anim, n) {
    const stepMs = Math.max(10, +st.fxStep || 350);
    let step = (anim.unit === 'char' ? Math.max(25, Math.round(stepMs * 0.18)) : stepMs) / 1000;
    const base = anim.unitDur || 0.4, len = Math.max(0.2, cue.end - cue.start);
    if (n > 1 && (n - 1) * step + (anim.hl ? step : base) > len * 0.8) step = Math.max(0.01, (len * 0.8 - base) / (n - 1));
    return { step: step, dur: anim.hl ? step : base };
  }

  // ---- ending animations: the last `fxOutDur` seconds of the line ---------------------------------------------------
  const OUT_KINDS = ['fade', 'zoom', 'down', 'shrink', 'blur'];
  function outLength(st, cue) {
    if (!st || !st.fxOut || st.fxOut === 'none' || OUT_KINDS.indexOf(st.fxOut) < 0) return 0;
    const d = +st.fxOutDur > 0 ? +st.fxOutDur : 0.4;
    return Math.min(Math.min(3, Math.max(0.05, d)), Math.max(0.05, (cue.end - cue.start) * 0.6));
  }
  /** p 0..1 through the ending -> alpha, scale, dy (px), blur (px) */
  function outAt(kind, p, fp) {
    const e = EASE.in(Math.min(1, Math.max(0, p))), r = { alpha: 1 - e, scale: 1, dy: 0, blur: 0 };
    if (kind === 'zoom') r.scale = 1 + 0.6 * e;
    else if (kind === 'down') r.dy = 0.5 * e * fp;
    else if (kind === 'shrink') r.scale = 1 - 0.7 * e;
    else if (kind === 'blur') r.blur = 0.3 * e * fp;
    return r;
  }
  /** Seconds after the line starts when its intro (all stagger included) is over: Infinity for continuous motion. */
  function introEnd(cue, st) {
    const anim = animOf(st);
    if (!anim) return 0;
    if (anim.inf) return Infinity;
    if (anim.unit) { const n = unitCount(cue, anim), tm = unitTiming(cue, st, anim, n); return Math.max(0, n - 1) * tm.step + tm.dur; }
    return anim.whole ? Infinity : animLength(anim, st);
  }
  /** Does the caption bitmap change between frames at time t (intro, motion or ending running)? */
  function isLive(cue, st, t) {
    if (t - cue.start < introEnd(cue, st)) return true;
    const od = outLength(st, cue);
    return od > 0 && t >= cue.end - od;
  }
  const mixHex = (a, b, k) => {
    if (!(a && b && a[0] === '#' && b[0] === '#' && a.length === 7 && b.length === 7) || k <= 0) return a;
    const n = x => parseInt(x.slice(1), 16), A = n(a), B = n(b), ch = sh => Math.round(((A >> sh) & 255) + ((((B >> sh) & 255) - ((A >> sh) & 255)) * Math.min(1, k)));
    return '#' + ((1 << 24) | (ch(16) << 16) | (ch(8) << 8) | ch(0)).toString(16).slice(1);
  };

  /** How long (s) the intro of `style` lasts: its own fxDur (0.01-3) or the animation's default. */
  function animLength(anim, style) { const d = style && +style.fxDur; return d > 0 ? Math.min(3, Math.max(0.01, d)) : anim.duration; }

  // Export size presets: short-side pixels + target bitrate.
  const presets = {
    '480p':  { shortSide: 480,  bitrate: 4000000 },
    '720p':  { shortSide: 720,  bitrate: 8000000 },
    '1080p': { shortSide: 1080, bitrate: 14000000 },
    '2k':    { shortSide: 1440, bitrate: 24000000 }
  };

  function computeExportDims(videoW, videoH, preset) {
    const vw = videoW || 1280, vh = videoH || 720;
    const shortTarget = (presets[preset] || presets['1080p']).shortSide;
    const scale = shortTarget / Math.min(vw, vh);
    return { w: Math.max(2, Math.round(vw * scale / 2) * 2), h: Math.max(2, Math.round(vh * scale / 2) * 2) };
  }

  /** Glow = a stack of PURE blurs of the text shape (no offset copies of the letters, which showed up as ghost / striped text).
   *  Each layer is { dx, dy, blur, a }: offset in PREVIEW pixels, blur radius in PREVIEW pixels, alpha 0..1. The canvas renderer
   *  (x scale, shadow-only) and the live preview (CSS text-shadow) read the same list so the two look the same.
   *  range -> how far the light spreads; intensity -> how many / how strong the layers are.
   *  type 'halo' = even soft bloom; 'burst' = wider bloom that also spreads a little sideways (CapCut glow 1). */
  function glowLayers(gl) {
    const R = Math.max(1, +gl.range || 1), I = Math.min(1, Math.max(0, (+gl.intensity || 0) / 100)), out = [];
    const burst = gl.type === 'burst';
    const bands = burst ? [[0.45, 2.2], [1.1, 1.8], [2.2, 1.3]] : [[0.4, 2.2], [0.9, 1.8], [1.6, 1.2]];   // [blur x range, passes at full intensity]
    bands.forEach(bd => {
      const blur = +(R * bd[0]).toFixed(2), p = I * bd[1], full = Math.floor(p), frac = p - full;
      for (let i = 0; i < full; i++) out.push({ dx: 0, dy: 0, blur: blur, a: 1 });
      if (frac > 0.04) out.push({ dx: 0, dy: 0, blur: blur, a: +frac.toFixed(3) });
    });
    if (burst && I > 0) {        // sideways spread: two soft layers shifted LESS than their own blur, so they merge into one smooth bloom
      const blur = +(R * 1.6).toFixed(2), d = +(blur * 0.45).toFixed(2), a = +(0.55 * I).toFixed(3);
      out.push({ dx: d, dy: 0, blur: blur, a: a }, { dx: -d, dy: 0, blur: blur, a: a });
    }
    return out;
  }
  const glowBurstLayers = glowLayers;       // old name kept for anything still calling it

  /** Drop shadow geometry (CapCut model): angle in degrees (0 = right, 90 = up, -45 = down-right), distance in preview px.
   *  Old projects have no angle: -45 gives dx = dy = dist, exactly the look they were saved with. */
  function shadowOffset(sh, size) {
    if (size > 0 && sh.dx != null && sh.dy != null && !isNaN(+sh.dx) && !isNaN(+sh.dy)) return { dx: +(+sh.dx / 100 * size).toFixed(3), dy: +(+sh.dy / 100 * size).toFixed(3) };   // "เงาเหลื่อม": offset as % of the letter size (scales with it)
    const a = (sh.angle == null || isNaN(+sh.angle) ? -45 : +sh.angle) * Math.PI / 180, r = (+sh.dist || 0) * Math.SQRT2;
    return { dx: +(r * Math.cos(a)).toFixed(3), dy: +(-r * Math.sin(a)).toFixed(3) };
  }
  /** Shadow colour with its own opacity (0-100, missing = 100) as a CSS colour. */
  /** Dark soft edge around the letters (style.halo): `layers` stacked blurs of the text shape in black. blur is % of the font size. */
  function haloLayers(h, size) {
    if (!(h && h.on)) return [];
    const n = Math.max(0, Math.min(4, Math.round(+h.layers || 0))), blur = +(Math.max(0, +h.blur || 0) / 100 * size).toFixed(3), a = Math.min(1, Math.max(0, (+h.alpha || 0) / 100));
    const out = [];
    for (let i = 0; i < n; i++) out.push({ blur: blur, a: a });
    return out;
  }
  function shadowColorCss(sh) {
    const o = sh.opacity == null || isNaN(+sh.opacity) ? 100 : Math.min(100, Math.max(0, +sh.opacity));
    return o >= 100 ? sh.color : hexToRgba(sh.color, +(o / 100).toFixed(3));
  }

  function roundRectPath(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  /** Rows of a caption. There is NO automatic wrapping: a bigger font only makes the line bigger. A new row starts only where the
   *  user pressed Enter (word.nl = a hard line break before that word). */
  function wrapCueWords(ctx, words, maxWidth) {
    const lines = [];
    let cur = [], curWidth = 0;
    const spaceW = maxWidth ? ctx.measureText(' ').width : 0;
    words.forEach(w => {
      if (w.nl && cur.length) { lines.push(cur); cur = []; curWidth = 0; }
      if (maxWidth) {                                                  // "ตัดบรรทัดเอง" switched on: also wrap when a row gets wider than the picture
        const tw = ctx.measureText((w.word || '').trim()).width, extra = cur.length && !w.joined ? spaceW : 0;
        if (cur.length && curWidth + extra + tw > maxWidth) { lines.push(cur); cur = [w]; curWidth = tw; return; }
        curWidth += extra + tw;
      }
      cur.push(w);
    });
    if (cur.length) lines.push(cur);
    return lines;
  }

  /** Draw one cue. `scale` = canvas pixels per preview pixel. */
  function drawCaption(ctx, w, h, cue, t, scale, style) {
    if (style.textOff) return;                                   // ข้อความ switched off
    if ((style.hlOff || style.wgOff) && cue.words.some(x => x.color || x.glow)) {   // ไฮไลท์สี off: words drawn without own colour / glow · แสงจากสี off: the glow that came with a colour is dropped (the project keeps both)
      cue = Object.assign({}, cue, { words: cue.words.map(x => { const y = Object.assign({}, x); if (style.hlOff) { delete y.color; delete y.glow; } else if (y.glow && y.glow.auto) delete y.glow; return y; }) });
    }
    const fontPx = Math.max(1, +(style.size * scale).toFixed(2));        // keep the decimal: the preview shows 97.1% as 97.1%, so the export must not round it to a whole pixel
    const weight = style.weight || (style.bold ? 700 : 400);   // a font option can fix its own weight (อนุพันธ์ Bd/SB)
    const outlineOn = style.outline.on, outlineColor = style.outline.color;
    // Outline width follows the editor's look: with no thickness the stroke is centred on the glyph edge (so W/2 shows outside, like the
    // old live preview); with thickness the outline sits OUTSIDE the thickness ring (T + W).
    const outlineW = style.outline.width * scale;
    const bgOn = style.bg.on;
    const bgColor = hexToRgba(style.bg.color, style.bg.opacity);
    const mode = style.hlOff ? 'off' : (style.karaokeMode || (style.karaoke ? 'all' : 'off')), color = style.color, accent = style.highlight;
    const sh = style.shadow, shadowOn = !!(sh && sh.on);
    const haloL = haloLayers(style.halo, style.size);

    // Draw one piece of text: outline (if any) then fill. The shadow is cast ONCE, by the outermost shape
    // (the outline when there is one, else the fill) — casting it from both would stack two shadows.
    const gl0 = style.glow;
    // Where the letter SHAPE is parked while only its shadow is wanted on the picture. It is put just past the nearest top / bottom
    // edge of the frame (a few hundred px away) and its shadow offset back. It used to be thrown 3x the frame size sideways: the
    // shadow's source layer then spanned several thousand px, which is bigger than the max texture size of many phone GPUs, so the
    // glow / shadow silently disappeared there (sometimes - it depends on the frame size and the GPU). Returns the position to
    // draw the shape at plus the shadow offset that brings its shadow back (device px).
    function park(x, y, strokeW, sc) {
      const m = ctx.getTransform ? ctx.getTransform() : null;
      if (m && Math.abs(m.b) < 1e-6 && Math.abs(m.c) < 1e-6 && m.d > 0) {
        const yDev = m.d * y + m.f, filt = ctx.filter && ctx.filter !== 'none' ? 60 : 0;
        const pad = (fontPx * 1.6 + strokeW + 8) * m.d + filt;
        const D = yDev < h / 2 ? -(yDev + pad) : (h - yDev + pad);          // device px, positive = down
        return { x: x, y: y + D / m.d, sx: 0, sy: -D };
      }
      const OFF = Math.max(w, h) * 3 / (sc || 1);                            // rotated (or no getTransform): the old far-sideways parking
      return { x: x - OFF, y: y, sx: OFF * (sc || 1), sy: 0 };
    }
    // `gl` = the glow of the piece being drawn: the line's own, or (per-word glow) the line's overlaid with that word's override.
    // The glow is cast ONLY as a blurred shadow: the letter shape is drawn far off-screen and its shadow offset back, so no copy of
    // the letters (which looked like striped ghost text) ever lands on the picture  just smooth light around the real text.
    function paintGlow(gl, text, x, y, sc) {
      const base = ctx.globalAlpha, T = (style.thick || 0) * scale, lw = outlineOn ? (T > 0 ? (outlineW + T) * 2 : outlineW) : T * 2;
      const pk = park(x, y, lw, sc);
      glowLayers(gl).forEach(l => {
        ctx.globalAlpha = base * l.a;
        ctx.shadowColor = gl.color; ctx.shadowBlur = l.blur * scale;
        ctx.shadowOffsetX = pk.sx + l.dx * scale; ctx.shadowOffsetY = pk.sy + l.dy * scale;
        ctx.fillStyle = gl.color; ctx.strokeStyle = gl.color;
        ctx.fillText(text, pk.x, pk.y);
        if (lw > 0) { ctx.lineWidth = lw; ctx.strokeText(text, pk.x, pk.y); }
      });
      ctx.globalAlpha = base; ctx.shadowColor = 'transparent'; ctx.shadowBlur = 0; ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 0;
    }
    // "ขอบมืดรอบตัวอักษร": the same trick as the glow, in black, stacked `layers` times
    function paintHalo(text, x, y, sc) {
      const base = ctx.globalAlpha, T = (style.thick || 0) * scale, lw = outlineOn ? (T > 0 ? (outlineW + T) * 2 : outlineW) : T * 2;
      const pk = park(x, y, lw, sc);
      haloL.forEach(l => {
        ctx.shadowColor = hexToRgba('#000000', l.a); ctx.shadowBlur = l.blur * scale;
        ctx.shadowOffsetX = pk.sx; ctx.shadowOffsetY = pk.sy;
        ctx.fillStyle = '#000000'; ctx.strokeStyle = '#000000';
        ctx.fillText(text, pk.x, pk.y);
        if (lw > 0) { ctx.lineWidth = lw; ctx.strokeText(text, pk.x, pk.y); }
      });
      ctx.globalAlpha = base; ctx.shadowColor = 'transparent'; ctx.shadowBlur = 0; ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 0;
    }
    // Text is painted in PHASES over the whole caption — glow, shadow, outline, thickness, fill — never word by word.
    // Painting a word completely (glow + outline + fill) before the next one let the NEXT word's glow / outline / shadow
    // land on top of the previous word's finished letters (the end of a word looked eaten or washed out).
    // `fxo` (word / letter animations): this piece's own alpha / scale / offset, applied around every phase of that piece.
    const queue = [];
    function paintText(text, x, y, fill, gl, fxo) { queue.push({ text: text, x: x, y: y, fill: fill, gl: S.subtitle.glowFor(gl || gl0, fill), fxo: fxo || null }); }
    function withItem(it, fn) {
      const f = it.fxo;
      if (!f) { fn(); return; }
      if (f.alpha <= 0.002) return;                                           // not on screen yet
      ctx.save();
      ctx.globalAlpha *= f.alpha;
      ctx.translate(it.x + f.dx, it.y + f.dy);
      if (f.rot) ctx.rotate(f.rot);
      if (f.skx) ctx.transform(1, 0, Math.tan(f.skx), 1, 0, 0);
      ctx.scale(f.scale * f.sx, f.scale * f.sy);
      ctx.translate(-it.x, -it.y);
      fn();
      ctx.restore();
    }
    function flushText(sc) {
      const T = (style.thick || 0) * scale;
      const noShadow = () => { ctx.shadowColor = 'transparent'; ctx.shadowBlur = 0; ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 0; };
      if (haloL.length) queue.forEach(it => withItem(it, () => paintHalo(it.text, it.x, it.y, sc)));
      queue.forEach(it => { if (it.gl && it.gl.on && it.gl.intensity > 0) withItem(it, () => paintGlow(it.gl, it.text, it.x, it.y, sc)); });
      if (shadowOn) {         // shadow only: the shape is parked just off the frame and its shadow offset back, so nothing but the shadow shows
        const so = shadowOffset(sh, style.size), shCss = shadowColorCss(sh);
        queue.forEach(it => withItem(it, () => {
          const pk = park(it.x, it.y, outlineOn ? (T > 0 ? (outlineW + T) * 2 : outlineW) : T * 2, sc);
          ctx.shadowColor = shCss; ctx.shadowBlur = sh.blur * (1 - (style.sharp || 0) / 100) * scale;
          ctx.shadowOffsetX = so.dx * scale + pk.sx; ctx.shadowOffsetY = so.dy * scale + pk.sy;
          if (outlineOn) { ctx.lineWidth = (T > 0 ? (outlineW + T) * 2 : outlineW); ctx.strokeStyle = outlineColor; ctx.strokeText(it.text, pk.x, pk.y); }
          else if (T > 0) { ctx.lineWidth = T * 2; ctx.strokeStyle = it.fill; ctx.strokeText(it.text, pk.x, pk.y); }
          else { ctx.fillStyle = it.fill; ctx.fillText(it.text, pk.x, pk.y); }
        }));
        noShadow();
      }
      if (outlineOn) queue.forEach(it => withItem(it, () => { ctx.lineWidth = (T > 0 ? (outlineW + T) * 2 : outlineW); ctx.strokeStyle = outlineColor; ctx.strokeText(it.text, it.x, it.y); }));
      if (T > 0) queue.forEach(it => withItem(it, () => { ctx.lineWidth = T * 2; ctx.strokeStyle = it.fill; ctx.strokeText(it.text, it.x, it.y); }));
      queue.forEach(it => withItem(it, () => { ctx.fillStyle = it.fill; ctx.fillText(it.text, it.x, it.y); }));
      queue.length = 0;
    }

    ctx.font = (style.italic ? 'italic ' : '') + weight + ' ' + fontPx + 'px ' + style.font;
    try { ctx.fontKerning = 'normal'; ctx.textRendering = 'optimizeLegibility'; } catch (e) { /* older browsers: defaults already apply Thai shaping (mark / mkmk / ccmp / liga / calt) */ }   // Thai fonts (FC Maha Nakhon …) need these features so tone marks and vowels sit correctly
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.lineJoin = (style.sharp || 0) >= 50 ? 'miter' : 'round'; ctx.miterLimit = 3;

    const lines = wrapCueWords(ctx, cue.words, style.autoWrap ? w * 0.88 : 0);
    if (!lines.length) return;
    const lineHeight = fontPx * 1.3;
    const totalH = lines.length * lineHeight;
    const lineWidths = lines.map(line => ctx.measureText(S.subtitle.joinWords(line)).width);
    const blockW = Math.max.apply(null, lineWidths);

    let topY;
    if (style.pos === 'top') topY = h * 0.06;
    else if (style.pos === 'mid') topY = h * 0.44;
    else if (style.pos === 'custom') topY = h * Math.min(0.97, Math.max(0.05, style.posY == null ? 0.62 : style.posY)) - totalH / 2;
    else topY = h * 0.91 - totalH;

    let alpha = 1, dy = 0, dx = 0, sc = 1, sx = 1, sy = 1, rot = 0, skx = 0, blur = 0, bright = 0, reveal = null, wipe = null;
    const lt = t - cue.start;
    const anim = animOf(style), perUnit = !!(anim && anim.unit), unitKind = perUnit ? anim.unit : 'all';
    if (anim && !perUnit) {                                   // the whole line moves at once
      const dur = anim.whole ? Math.max(0.2, cue.end - cue.start) : animLength(anim, style);
      let p = -1;
      if (anim.inf) p = lt >= 0 ? (lt % anim.period) / anim.period : 0;                // continuous: loops for as long as the line is on screen
      else if (lt >= 0 && lt < dur) p = Math.min(1, lt / dur);
      if (p >= 0) {
        const r = anim.at(p, fontPx, blockW, totalH);
        if (r.alpha != null) alpha = r.alpha;
        if (r.scale != null) sc = r.scale;
        sx = r.sx == null ? 1 : r.sx; sy = r.sy == null ? 1 : r.sy;
        dy = r.dy || 0; dx = r.dx || 0; rot = r.rot || 0; skx = r.skx || 0; blur = r.blur || 0; bright = r.bright || 0;
        if (r.reveal != null) reveal = r.reveal;
        if (r.wipe != null) wipe = r.wipe;
      }
    }
    // ending animation: the last fxOutDur seconds of the line (on top of whatever the intro left)
    const od = outLength(style, cue);
    if (od > 0 && t >= cue.end - od) {
      const o = outAt(style.fxOut, (t - (cue.end - od)) / od, fontPx);
      alpha *= o.alpha; sc *= o.scale; dy += o.dy; blur += o.blur;
    }
    const tm = perUnit ? unitTiming(cue, style, anim, unitCount(cue, anim)) : null;
    /** the animated state of unit `i` (word or letter) at this moment, or null = finished / nothing to animate */
    function unitFx(i) {
      const start = i * tm.step;
      let p;
      if (anim.inf) p = lt < start ? 0 : ((lt - start) % anim.period) / anim.period;
      else if (lt < start) p = 0;
      else if (lt >= start + tm.dur) return null;
      else p = (lt - start) / tm.dur;
      return Object.assign({ alpha: 1, scale: 1, sx: 1, sy: 1, dx: 0, dy: 0, rot: 0, skx: 0 }, anim.at(p, fontPx, 0, 0));
    }

    const cx = style.posX != null ? w * Math.min(0.95, Math.max(0.05, style.posX)) : w / 2, cy = topY + totalH / 2;
    ctx.save();
    ctx.globalAlpha = alpha * (style.opacity == null ? 100 : style.opacity) / 100;
    if ((blur > 0.3 || bright > 0.02) && 'filter' in ctx) {                                 // (no ctx.filter, e.g. Safari: it is a plain fade)
      ctx.filter = (blur > 0.3 ? 'blur(' + blur.toFixed(2) + 'px) ' : '') + (bright > 0.02 ? 'brightness(' + (1 + bright).toFixed(2) + ')' : '');
    }
    ctx.translate(cx + dx, cy + dy);
    if (rot) ctx.rotate(rot);
    if (skx) ctx.transform(1, 0, Math.tan(skx), 1, 0, 0);
    ctx.scale(sc * sx, sc * sy);
    ctx.translate(-cx, -cy);
    if (wipe != null && wipe < 1) {                          // ปัดเผย: the line is uncovered from left to right
      ctx.beginPath(); ctx.rect(cx - blockW / 2 - blockW * 0.4 - 8 * scale, topY - totalH, blockW * 1.8 * wipe + 16 * scale, totalH * 3); ctx.clip();
    }

    if (bgOn) {
      const padX = 14 * scale, padY = 5 * scale;
      ctx.fillStyle = bgColor;
      roundRectPath(ctx, cx - blockW / 2 - padX, topY - padY, blockW + padX * 2, totalH + padY * 2, 8 * scale);
      ctx.fill();
    }

    const nWords = lines.reduce((n, l) => n + l.length, 0), shown = reveal == null ? nWords : Math.min(nWords, Math.floor(reveal * nWords) + 1);
    let gi = 0, ui = 0;                                           // running word number across the lines (typing animation) · running letter number (letter animations)
    lines.forEach((line, li) => {
      const y = topY + lineHeight * li + lineHeight / 2;
      if (!perUnit && reveal == null && mode !== 'all' && mode !== 'stayAll' && !line.some(x => x.color || x.glow)) {
        const text = S.subtitle.joinWords(line);
        paintText(text, cx, y, color);
      } else {
        const spaceW = ctx.measureText(' ').width;
        const widths = line.map(x => ctx.measureText(x.word.trim()).width);
        const gap = i => (i > 0 && i < line.length && !line[i].joined) ? spaceW : 0;   // no gap inside an unspaced Thai phrase
        const lineW = widths.reduce((a, b) => a + b, 0) + line.reduce((n, _, i) => n + gap(i), 0);
        let x = cx - lineW / 2;
        line.forEach((wobj, wi) => {
          const wt = wobj.word.trim(), ww = widths[wi];
          if (gi++ >= shown) { x += ww + gap(wi + 1); ui += graphemes(wt).length; return; }      // typing: this word is not on screen yet
          const inRange = mode !== 'off' && t >= wobj.start && t < wobj.end;
          const wx = x + ww / 2;
          // karaoke on: the word's own colour IS its highlight (shown only while it is being read); off: static colour
          const stay = mode === 'stay' || mode === 'stayAll';      // สีค้าง: coloured from the moment the word is read until the line ends
          let fill = (wobj.hold && wobj.color && !style.hlOff) ? wobj.color        // painted by hand: always shows its colour
            : mode === 'off' ? (wobj.color || color)
            : stay ? (t >= wobj.start ? (wobj.color || (mode === 'stayAll' ? accent : color)) : color)
            : (inRange ? (wobj.color || (mode === 'all' ? accent : color)) : color);
          const idle = !!(wobj.glow && wobj.glow.auto && wobj.color && fill !== wobj.color);   // karaoke: colour not showing yet -> no glow either
          const wgl = idle ? gl0 : S.subtitle.wordGlow(wobj, gl0);
          if (unitKind === 'char') {                              // letter by letter: every letter is its own piece, positioned by the width of what precedes it
            const gs = graphemes(wt), cum = [0];
            for (let k = 1; k <= gs.length; k++) cum.push(ctx.measureText(gs.slice(0, k).join('')).width);
            gs.forEach((g, k) => {
              const r = unitFx(ui++);
              paintText(g, x + (cum[k] + cum[k + 1]) / 2, y, r && r.col ? mixHex(fill, accent, r.col) : fill, wgl, r);
            });
          } else if (unitKind === 'word') {
            const r = unitFx(gi - 1);
            paintText(wt, wx, y, r && r.col ? mixHex(fill, accent, r.col) : fill, wgl, r);
          } else {
            paintText(wt, wx, y, fill, wgl);
          }
          x += ww + gap(wi + 1);
        });
      }
    });
    flushText(sc);
    ctx.restore();
  }

  /** Remembers the last drawn caption bitmap. An exporter creates one per export and passes it to composeFrame: a caption only
   *  changes when a word starts / ends (or while its intro animation runs), so most frames reuse the bitmap instead of
   *  re-drawing glow / outline / shadow layers 60 times a second. The preview never passes one. */
  function makeCaptionCache() { return { canvas: null, key: '' }; }

  /** One output frame: source image + motion layers behind the caption + active caption + motion layers in front of it
   *  (js/render/motion-text.js). `source` is any CanvasImageSource. */
  function composeFrame(ctx, w, h, source, t, project, scale, cache) {
    ctx.clearRect(0, 0, w, h);
    ctx.drawImage(source, 0, 0, w, h);
    const M = S.motionText, hasM = !!(M && project.motion && project.motion.layers && project.motion.layers.length);
    if (hasM) M.draw(ctx, w, h, t, project, scale, 'back');          // เลเยอร์ "หลังข้อความ"
    paintCaption(ctx, w, h, t, project, scale, cache);
    if (hasM) M.draw(ctx, w, h, t, project, scale, 'front');         // เลเยอร์ "หน้าข้อความ"
  }

  /** The caption of the line showing at time t (nothing when no line is showing). */
  function paintCaption(ctx, w, h, t, project, scale, cache) {
    const idx = S.subtitle.indexAt(project.subtitle.cues, t);
    if (idx === -1) return;
    const cue = project.subtitle.cues[idx], st = S.subtitle.effectiveStyle(cue, project.style);
    if (cache && !isLive(cue, st, t)) {      // intro / continuous motion / ending animation running (or a whole-line zoom): draw live, it changes every frame
      const bits = cue.words.map(x => (t >= x.start ? 1 : 0) + (t >= x.end ? 1 : 0)).join('');
      const key = idx + '|' + cue.id + '|' + w + 'x' + h + '|' + bits;
      if (!cache.canvas || cache.canvas.width !== w || cache.canvas.height !== h) { cache.canvas = document.createElement('canvas'); cache.canvas.width = w; cache.canvas.height = h; cache.key = ''; }
      if (cache.key !== key) {
        const cctx = cache.canvas.getContext('2d');
        cctx.clearRect(0, 0, w, h);
        drawCaption(cctx, w, h, cue, t, scale, st);
        cache.key = key;
      }
      ctx.drawImage(cache.canvas, 0, 0);
      return;
    }
    drawCaption(ctx, w, h, cue, t, scale, st);
  }

  S.render = { animLength: animLength, animations: animations, presets: presets, computeExportDims: computeExportDims, drawCaption: drawCaption, composeFrame: composeFrame, makeCaptionCache: makeCaptionCache, glowBurstLayers: glowBurstLayers, glowLayers: glowLayers, haloLayers: haloLayers, shadowOffset: shadowOffset, shadowColorCss: shadowColorCss,
    graphemes: graphemes, unitCount: unitCount, unitTiming: unitTiming, outLength: outLength, outAt: outAt, introEnd: introEnd, isLive: isLive, animOf: animOf };
})(window.SubEd);
