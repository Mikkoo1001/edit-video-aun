/* ───────────────────────────────────────────────────────────────────────────────────────────────────────────
 * font-kit.js — ONE place that makes sure every font a caption needs is really loaded before it is drawn.
 *
 * Why: captions are painted on a <canvas> (live preview AND export, see js/ui/caption-overlay.js and
 * js/render/caption-canvas.js). A canvas can only draw a web font that is already downloaded — otherwise it
 * silently uses a fallback font and the caption looks different. So before drawing / exporting we load:
 *   - the project's font in every weight / italic that any line uses,
 *   - exactly the characters the captions contain (Google Fonts serves unicode-range pieces),
 *   - the whole font stack (first family AND the fallbacks).
 *
 * ADDING A NEW FONT — follow fonts/FONTS-GUIDE.md. Short version:
 *   1. a local file: put it in /fonts and add an @font-face in css/fonts-lib.css (one per weight / style);
 *      a Google font: add it to the Google Fonts <link> in index.html;
 *   2. add an <option> to #fontSel in index.html (value = CSS font stack; data-weight if the face fixes its weight);
 *   3. open the app, run   SubEd.fontKit.audit()   in the console (or the "ตรวจฟอนต์" button if present):
 *      every font must report "ok". Nothing else needs to change — preview and export both go through this file.
 * Fonts the user uploads in the app (js/ui/font-lib.js) are registered with document.fonts, so they are picked up here too.
 * ─────────────────────────────────────────────────────────────────────────────────────────────────────────── */
(function (S) {
  'use strict';
  const P = S.state.project;
  const firstFam = f => String(f || '').split(',')[0].replace(/["']/g, '').trim();
  const GENERIC = ['sans-serif', 'serif', 'monospace', 'cursive', 'fantasy', 'system-ui', 'inherit'];
  let lastReport = { ok: true, problems: [] };

  /** every {font stack, weight, italic} combination used by the project (global style + lines with their own look) */
  function usedFaces(project) {
    project = project || P;
    const st = project.style, set = {}, w0 = st.weight || (st.bold ? 700 : 400);
    const add = (font, italic, weight) => { if (font) set[(italic ? 'italic ' : '') + weight + '|' + font] = { font: font, italic: !!italic, weight: weight }; };
    add(st.font, st.italic, w0);
    (project.subtitle.cues || []).forEach(c => {
      const o = c.style; if (!o) return;
      add(o.font || st.font, o.italic != null ? o.italic : st.italic, o.weight != null ? o.weight : (o.bold != null ? (o.bold ? 700 : 400) : w0));
    });
    ((project.motion && project.motion.layers) || []).forEach(L => add(L.font, !!L.italic, L.weight || 700));   // motion text layers
    return Object.keys(set).map(k => set[k]);
  }
  function usedChars(project) {
    project = project || P;
    let used = 'กขคAa0123456789';
    (project.subtitle.cues || []).forEach(c => { used += c.text || ''; (c.words || []).forEach(w => { used += w.word || ''; }); });
    ((project.motion && project.motion.layers) || []).forEach(L => { used += L.text || ''; });
    return Array.from(new Set(Array.from(used))).join('');
  }

  /** Load everything the captions need. Resolves with a report: { ok, problems:[{family, why}] } — never rejects. */
  /** fonts AND the pictures of image layers (motion-text.js) are ready after this resolves */
  function ensure(project) {
    project = project || P;                                            // callers may pass nothing: the live project
    return ensureFonts(project).then(r => (S.motionText && S.motionText.ready ? S.motionText.ready(project) : Promise.resolve()).then(() => r));
  }
  function ensureFonts(project) {
    if (!document.fonts || !document.fonts.load) return Promise.resolve(lastReport = { ok: true, problems: [] });
    const faces = usedFaces(project), chars = usedChars(project);
    return Promise.all(faces.map(f => {
      const spec = (f.italic ? 'italic ' : '') + f.weight + ' 32px ' + f.font;
      return document.fonts.load(spec, chars).then(list => ({ f: f, spec: spec, n: list ? list.length : 0 }), () => ({ f: f, spec: spec, n: 0 }));
    })).then(res => {
      const problems = [];
      res.forEach(r => {
        const fam = firstFam(r.f.font);
        if (!fam || GENERIC.indexOf(fam.toLowerCase()) >= 0) return;
        let ok = false;
        try { ok = r.n > 0 && document.fonts.check(r.spec, chars); } catch (e) { ok = r.n > 0; }
        if (!ok && !problems.some(p => p.family === fam)) problems.push({ family: fam, why: r.n ? 'some characters are missing from the font' : 'no @font-face / font file found' });
      });
      return (lastReport = { ok: problems.length === 0, problems: problems });
    });
  }

  /** Check every font in the font list (#fontSel): each must have an @font-face (or be a system font) and load without error. */
  function audit() {
    const sel = document.getElementById('fontSel'), opts = sel ? Array.from(sel.options) : [];
    const registered = {}; if (document.fonts) document.fonts.forEach(ff => { registered[ff.family.replace(/["']/g, '').trim()] = (registered[ff.family.replace(/["']/g, '').trim()] || []).concat(ff.status); });
    const rows = opts.filter(o => !o.dataset.temp && GENERIC.indexOf(firstFam(o.value).toLowerCase()) < 0).map(o => {
      const fam = firstFam(o.value), st = registered[fam];
      return { option: o.textContent.trim(), family: fam, hasFontFace: !!st, status: st ? st.join(',') : '—' };
    });
    // Google Fonts families are registered lazily by the browser (only once used) — try loading each so the table is honest.
    return Promise.all(rows.map(r => (document.fonts && r.family ? document.fonts.load('700 24px "' + r.family + '"', 'กขคAa').then(l => { r.loadable = l.length > 0; }, () => { r.loadable = false; }) : null))).then(() => {
      rows.forEach(r => { r.result = r.loadable ? 'ok' : 'MISSING — add the @font-face / file (see fonts/FONTS-GUIDE.md)'; });
      const bad = rows.filter(r => r.result !== 'ok');
      console.table(rows.map(r => ({ font: r.option, family: r.family, result: r.result })));
      console.log(bad.length ? ('⚠ ' + bad.length + ' font(s) cannot be drawn: ' + bad.map(b => b.family).join(', ')) : '✓ all fonts load');
      return { rows: rows, bad: bad };
    });
  }

  /** Tell the user (toast) when a font the captions use could not be loaded — the picture would silently use another font. */
  function warnIfMissing() {
    if (lastReport.ok || !S.ui || !S.ui.toast) return;
    S.ui.toast('ฟอนต์ ' + lastReport.problems.map(p => p.family).join(', ') + ' โหลดไม่ได้ — ภาพจะใช้ฟอนต์สำรองแทน (ดู fonts/FONTS-GUIDE.md)', 6000);
  }

  S.fontKit = { warnIfMissing: warnIfMissing, ensure: ensure, audit: audit, usedFaces: usedFaces, usedChars: usedChars, report: () => lastReport, firstFamily: firstFam };
})(window.SubEd);
