/* =====================================================================
 * Bootstrap. Initialise UI modules (each only registers listeners; they talk
 * through SubEd.bus and SubEd.state, never through each other's internals).
 * Order matters only for listeners that must exist before the first emit: preview
 * subscribes to style:changed before stylePanel emits it at boot.
 * ===================================================================== */
(function (S) {
  'use strict';
  ['precise', 'tabs', 'preview', 'capOverlay', 'motionText', 'motionLib', 'fluid', 'wordSel', 'wordColor', 'stylePanel', 'player', 'timeline', 'captionPanel', 'exportPanel', 'media', 'extras', 'ccColor', 'fontFav', 'fontLib', 'compare', 'styleCopy', 'cuePosition', 'cueSelect', 'timeNudge', 'capFrame', 'cueSize', 'cueLayout', 'arrange', 'audioTrack', 'mainMute', 'voiceArrange', 'videoCut', 'sceneTrack', 'shorten', 'historyPanel', 'resume']
    .forEach(name => S.ui[name].init());
  S.bus.emit('app:ready');
})(window.SubEd);
