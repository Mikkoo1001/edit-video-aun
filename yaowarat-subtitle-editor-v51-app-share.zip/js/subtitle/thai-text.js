/* =====================================================================
 * Thai text helpers. No DOM.
 *
 * WHY THIS EXISTS: Whisper has no spaces in Thai, so its "word" timestamps come back as raw
 * sub-word fragments ("สวัส" "ดี" "คร" "ับ"). Showing them one per space — the old behaviour —
 * produced broken, unreadable captions. rebuildWords() glues the fragments back into one string,
 * cuts it into real Thai words (Intl.Segmenter) and re-attaches timing to every word.
 *
 *   S.thai.rebuildWords(rawWords) -> [{ word, start, end, joined }]
 *   S.thai.annotateSpacing(words, fullText)  -> marks each fragment with sp (space before it?), see below
 *   S.thai.visLen(text)           -> number of visible columns (combining marks count 0)
 *   S.thai.hasThai(text)
 *   S.thai.syllables(word)        -> estimated syllable count (พยางค์) of one displayed word
 * ===================================================================== */
(function (S) {
  'use strict';

  const THAI_RE = /[\u0E00-\u0E7F]/;
  const COMBINING_RE = /[\u0E31\u0E34-\u0E3A\u0E47-\u0E4E]/g;   // vowels above/below + tone marks: no width
  const wordSeg = (typeof Intl !== 'undefined' && Intl.Segmenter) ? new Intl.Segmenter('th', { granularity: 'word' }) : null;

  const hasThai = t => THAI_RE.test(t || '');
  const visLen = t => (t || '').replace(COMBINING_RE, '').length;

  /**
   * Cut one unspaced run into words -> [[from, to), ...] (indices into `run`).
   * Punctuation is glued to the word before it. Without Intl.Segmenter the run is cut into Thai
   * letter clusters instead (never splits a vowel/tone mark from its consonant).
   */
  function cutRun(run) {
    const cuts = [];
    if (wordSeg) {
      let cur = null;
      for (const p of wordSeg.segment(run)) {
        const end = p.index + p.segment.length;
        if (p.isWordLike === false && cur) { cur[1] = end; }
        else if (p.isWordLike === false) { cur = [p.index, end]; cuts.push(cur); }
        else { cur = [p.index, end]; cuts.push(cur); }
      }
      return cuts.length ? cuts : [[0, run.length]];
    }
    const re = /[\u0E40-\u0E44]?[\u0E01-\u0E2E][\u0E30-\u0E3A\u0E47-\u0E4E]*|[^\u0E00-\u0E7F]+|[\u0E00-\u0E7F]/g;
    let m;
    while ((m = re.exec(run))) cuts.push([m.index, m.index + m[0].length]);
    return cuts.length ? cuts : [[0, run.length]];
  }

  /** Need a visible space between these two neighbouring characters? (only when no Thai is involved on both sides) */
  function needSpace(prev, next, sp) {
    if (/^[.,!?;:%)\]}"'”’…。！？，、]/.test(next)) return false;
    if (/[(\[{"'“‘]$/.test(prev)) return false;
    const pt = THAI_RE.test(prev.slice(-1)), nt = THAI_RE.test(next.charAt(0));
    if (pt && nt) return false;                 // Thai fragment + Thai fragment: same word / same phrase
    // Latin fragment + Latin fragment with no space in the transcript ("Ul"+"ti"+"mate"+"trix"): one English word
    if (sp === false && /[A-Za-z0-9]$/.test(prev) && /^[A-Za-z0-9]/.test(next)) return false;
    return true;                                // Thai<->Latin/number, or Latin<->Latin
  }

  /**
   * Whisper returns English inside Thai audio as sub-word fragments ("Ul" "ti" "mate" "trix"), and the API
   * trims them, so the fragments alone cannot tell "Ultimatetrix" from "Ul timate trix". The response's own
   * full `text` does keep the real spacing: walk it in step with the fragments and mark every fragment
   * with sp = true/false (was there whitespace right before it). Unmatched fragments keep sp undefined.
   */
  function annotateSpacing(words, fullText) {
    const t = String(fullText || '');
    if (!t) return words;
    let pos = 0;
    (words || []).forEach(w => {
      const piece = String(w && w.word != null ? w.word : '').trim();
      if (!piece) return;
      const at = t.indexOf(piece, pos);
      if (at < 0 || at - pos > 12) return;        // can't line it up: leave sp undefined, don't lose our place
      const gap = t.slice(pos, at);
      w.sp = pos === 0 ? true : /\s/.test(gap);
      pos = at + piece.length;
    });
    return words;
  }

  function rebuildWords(raw) {
    // 1) one string + for every character the (interpolated) time it was spoken
    let text = '';
    const cs = [], ce = [];                     // per-character start / end time
    let lastEnd = 0;
    (raw || []).forEach(w => {
      const rawPiece = String(w && w.word != null ? w.word : '');
      const piece = rawPiece.trim();
      if (!piece) return;
      // was there a space before this fragment? raw leading space wins, else the alignment flag (annotateSpacing)
      const sp = /^\s/.test(rawPiece) ? true : (w && typeof w.sp === 'boolean' ? w.sp : undefined);
      let s = Number(w.start), e = Number(w.end);
      if (!isFinite(s)) s = lastEnd;
      if (!isFinite(e) || e < s) e = s;
      if (text && needSpace(text, piece, sp)) { text += ' '; cs.push(s); ce.push(s); }
      const n = piece.length;
      for (let k = 0; k < n; k++) { cs.push(s + (e - s) * k / n); ce.push(s + (e - s) * (k + 1) / n); }
      text += piece;
      lastEnd = e;
    });

    // 2) cut every unspaced run into words and re-attach timing
    const out = [];
    const runRe = /\S+/g;
    let m;
    while ((m = runRe.exec(text))) {
      const run = m[0], base = m.index;
      const pieces = hasThai(run) ? cutRun(run) : [[0, run.length]];
      pieces.forEach((p, i) => {
        const a = base + p[0], b = base + p[1];
        out.push({
          word: text.slice(a, b),
          start: cs[a], end: Math.max(ce[b - 1], cs[a]),
          joined: i > 0                            // no gap inside a Thai run; a gap where the original had a space
        });
      });
    }
    return out;
  }


  /* ---------- syllables (พยางค์) ----------
   * Rule-based estimate of how many syllables a Thai word is spoken with (no dictionary): vowel signs and leading vowels
   * are syllable nuclei, a consonant run with no vowel sign between two nuclei hides an extra "อะ" syllable (สงสัย = สง-สัย).
   * Right for ordinary words; Pali / Sanskrit loanwords with hidden syllables (ศาสนา) can be one short.
   * Non-Thai words: one syllable per vowel group (numbers: one). */
  const LEADS = '\u0E40\u0E41\u0E42\u0E43\u0E44';
  const MARKS = '\u0E30\u0E32\u0E33\u0E31\u0E34\u0E35\u0E36\u0E37\u0E38\u0E39\u0E47\u0E45';
  const CLUSTERS = new Set(['กร', 'กล', 'กว', 'ขร', 'ขล', 'ขว', 'คร', 'คล', 'คว', 'ตร', 'ปร', 'ปล', 'พร', 'พล', 'ฟร', 'ฟล', 'ทร', 'บร', 'บล', 'ดร',
    'หง', 'หญ', 'หน', 'หม', 'หย', 'หร', 'หล', 'หว', 'อย']);
  const sylCache = new Map();

  function thaiSyllables(raw) {
    let w = raw.replace(/\u0E24/g, '\u0E23\u0E36').replace(/\u0E26/g, '\u0E25\u0E36')       // ฤ ฦ = รึ ลึ
      .replace(/[\u0E48-\u0E4B\u0E4D\u0E4E\u0E2F\u0E46]/g, '')                               // tone marks, nikhahit, ฯ, ๆ
      .replace(/[\u0E17\u0E15\u0E28\u0E2A\u0E1E]\u0E23\u0E4C/g, '')                          // ทร์ ตร์ ศร์ สร์ พร์ (silent pair: จันทร์, ศาสตร์)
      .replace(/[\u0E01-\u0E2E][\u0E31\u0E34-\u0E3A\u0E47]*\u0E4C/g, '')                     // a silent letter (with its vowel) before ์
      .replace(/\u0E23\u0E23/g, '\u0E31');                                                    // รร = ั (ธรรม, กรรม)
    const toks = [];
    for (const ch of w) {
      if (LEADS.indexOf(ch) >= 0) toks.push({ k: 'L', c: ch });
      else if (MARKS.indexOf(ch) >= 0) toks.push({ k: 'M', c: ch });
      else if (ch >= '\u0E01' && ch <= '\u0E2E') toks.push({ k: 'C', c: ch });
    }
    let n = 0, run = [], afterN = false, leadOpen = false;
    const initOnly = r => r.length === 1 || (r.length === 2 && CLUSTERS.has(r.join('')));
    const half = m => m > 0 ? Math.ceil(m / 2) : 0;
    const initLen = r => (r.length >= 2 && CLUSTERS.has(r[r.length - 2] + r[r.length - 1])) ? 2 : (r.length ? 1 : 0);
    // a nucleus (with its own initial taken from the END of `run`) is reached: the consonants before it hide extra syllables
    const nucleus = () => {
      if (leadOpen) {                                   // the leading vowel's own initial consonant comes off the front first
        const k = (run.length >= 2 && CLUSTERS.has(run[0] + run[1])) ? 2 : 1;
        run = run.slice(Math.min(k, run.length)); leadOpen = false; afterN = true;
      }
      n += half(run.length - initLen(run) - (afterN ? 1 : 0)) + 1;     // -1: the first consonant after a nucleus is its final
      run = []; afterN = true;
    };
    for (let i = 0; i < toks.length; i++) {
      const t = toks[i], prev = toks[i - 1], next = toks[i + 1];
      if (t.k === 'L') {
        n += half(run.length - (leadOpen ? 2 : afterN ? 1 : 0)); run = []; n++; leadOpen = true; afterN = false;   // เทศ|ไทย: the last lead syllable keeps its initial + final
      } else if (t.k === 'M') {
        if (prev && prev.k === 'M') continue;           // two signs in a row = one syllable
        if (leadOpen && initOnly(run)) { run = []; leadOpen = false; afterN = true; }   // sign belongs to the leading vowel (เ-า, เ-ีย)
        else nucleus();
      } else {                                          // consonant
        if (prev && prev.k === 'M' && ((prev.c === '\u0E35' && t.c === '\u0E22') || (prev.c === '\u0E37' && t.c === '\u0E2D') || (prev.c === '\u0E31' && t.c === '\u0E27'))) continue;   // ีย ือ ัว: the second letter is part of the vowel
        const lastC = prev && prev.k === 'C';
        const asVowel = lastC && (t.c === '\u0E2D' || (t.c === '\u0E27' && (!next || next.k === 'C')));   // อ (ขอ) / ว (รวม) acting as a vowel
        if (asVowel && leadOpen && initOnly(run)) { run = []; leadOpen = false; afterN = true; }          // เ-อ (เธอ)
        else if (asVowel && !(afterN && !leadOpen && run.length === 0)) nucleus();
        else run.push(t.c);
      }
    }
    if (run.length) {                                   // trailing consonants: finals, maybe one hidden syllable (คน)
      if (leadOpen) n += half(run.length - 2);
      else if (afterN) n += half(run.length - 1);
      else n += Math.max(1, half(run.length));
    }
    return Math.max(1, n);
  }

  /** Syllables of one displayed word (Thai by rules above; Latin by vowel groups; digits 1). */
  function syllables(word) {
    const t = (word || '').trim();
    if (!t) return 0;
    if (sylCache.has(t)) return sylCache.get(t);
    let n = 0;
    t.split(/([\u0E00-\u0E7F]+)/).forEach(part => {            // split Thai from non-Thai pieces
      if (!part) return;
      if (THAI_RE.test(part)) n += thaiSyllables(part);
      else if (/[A-Za-z]/.test(part)) n += Math.max(1, (part.toLowerCase().replace(/e$/, '').match(/[aeiouy]+/g) || []).length);
      else if (/\d/.test(part)) n += 1;
    });
    n = Math.max(1, n);
    if (sylCache.size > 5000) sylCache.clear();
    sylCache.set(t, n);
    return n;
  }

  S.thai = { syllables: syllables, hasThai: hasThai, visLen: visLen, rebuildWords: rebuildWords, cutRun: cutRun, annotateSpacing: annotateSpacing };
})(window.SubEd);
