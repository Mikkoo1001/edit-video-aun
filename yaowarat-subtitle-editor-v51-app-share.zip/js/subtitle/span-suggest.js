/* =====================================================================
 * Where should a sentence start / end?  (the guide behind "ลากประโยคไปถึงตรงไหน")
 *
 * After the words of a sentence are edited (added, removed, re-spelled) its block no longer matches the voice. This module answers
 * "where does the speech for THESE words really sit?" so the timeline can show a target and the editor can snap / vibrate onto it.
 *
 *   S.subtitle.suggestSpan(cue) -> { start, end, source, matched, total, wordTimes } | null
 *       source 'speech' : the cue's words were matched (fuzzy, in order) against what was heard — subtitle.speech (the AI re-timing
 *                         run) or subtitle.words (the transcription that made the lines). New words with no match are placed by
 *                         the speaking pace of the matched ones, never over the neighbouring speech.
 *       source 'rate'   : nothing heard to compare with (typed by hand): start stays, end = start + characters / the speaking
 *                         pace of the other lines. Only an estimate.
 *   S.subtitle.fitToSpeech(idx)  applies it (start, end and every word's time) as one undo step.
 * Pure data in, numbers out: never touches the DOM.
 * ===================================================================== */
(function (S) {
  'use strict';
  S.subtitle = S.subtitle || {};
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const vis = t => (S.thai && S.thai.visLen) ? S.thai.visLen(t) : (t || '').length;
  const wlen = w => Math.max(1, vis((w.word || '').trim()));
  const BEFORE = 3, AFTER = 6;                       // how far around the sentence the heard words are searched (s)

  /** characters per second of the lines already on the timeline (median), a sane default when there is nothing to measure */
  function paceOf(except) {
    const r = [];
    S.state.project.subtitle.cues.forEach(c => {
      if (c === except) return;
      const d = c.end - c.start, n = vis((c.text || '').replace(/\s+/g, ''));
      if (d >= 0.3 && d <= 8 && n >= 2) r.push(n / d);
    });
    if (!r.length) return 7.5;
    r.sort((a, b) => a - b);
    return clamp(r[r.length >> 1], 3.5, 14);
  }

  /** Letter-level match of `q` (the sentence, spaces removed) inside `hs` (what was heard, spaces removed): semi-global alignment, so the
   *  sentence is fully aligned while the heard text may begin / end anywhere. Thai has no spaces and the heard words are cut differently
   *  from the typed ones ("ทุกคน" vs "ทุก"+"คน"), so words cannot be compared one to one: letters can.
   *  Returns { at: Int32Array (index in q -> index in hs or -1 for a gap / mismatch), hit: number of equal letters }. */
  function matchLetters(q, hs) {
    const n = q.length, m = hs.length, W = m + 1, MATCH = 2, MISS = -1, GAP = -1;
    const sc = new Int16Array((n + 1) * W), tb = new Uint8Array((n + 1) * W);        // tb: 1 diagonal, 2 skip a letter of q, 3 skip a letter of hs
    for (let i = 1; i <= n; i++) { sc[i * W] = i * GAP; tb[i * W] = 2; }
    for (let i = 1; i <= n; i++) {
      for (let j = 1; j <= m; j++) {
        const d = sc[(i - 1) * W + j - 1] + (q.charCodeAt(i - 1) === hs.charCodeAt(j - 1) ? MATCH : MISS);
        const u = sc[(i - 1) * W + j] + GAP, l = sc[i * W + j - 1] + GAP;
        let best = d, dir = 1;
        if (u > best) { best = u; dir = 2; }
        if (l > best) { best = l; dir = 3; }
        sc[i * W + j] = best; tb[i * W + j] = dir;
      }
    }
    let bj = 0, bv = -1e9;
    for (let j = 0; j <= m; j++) if (sc[n * W + j] > bv) { bv = sc[n * W + j]; bj = j; }      // free end: the best place to stop in the heard text
    const at = new Int32Array(n).fill(-1);
    let i = n, j = bj, hit = 0;
    while (i > 0) {
      const dir = j === 0 ? 2 : tb[i * W + j];
      if (dir === 1) { if (q.charCodeAt(i - 1) === hs.charCodeAt(j - 1)) { at[i - 1] = j - 1; hit++; } i--; j--; }
      else if (dir === 2) i--;
      else j--;
    }                                                                                         // (the heard text before the start is free: row 0 is all zeros)
    return { at: at, hit: hit };
  }

  /** Try to place the sentence's words inside the heard words `list`; null when too little of it can be found. */
  function placeIn(list, ws, minShare, dur, fallbackRate) {
    const norm = (S.ai && S.ai._norm) || (x => (x || '').toLowerCase().replace(/\s+/g, ''));
    let hs = '';
    const owner = [], off = [];                                    // for every letter of hs: which heard word, and the letter's place in it
    list.forEach((h, k) => { const t = norm(h.word); for (let o = 0; o < t.length; o++) { owner.push(k); off.push(o); } hs += t; });
    const parts = ws.map(w => norm(w.word));
    const q = parts.join('');
    if (!q.length || !hs.length) return null;
    const mt = matchLetters(q, hs);
    if (mt.hit < Math.max(2, Math.ceil(q.length * minShare))) return null;
    const timeAt = (idx, end) => { const h = list[owner[idx]], L = Math.max(1, norm(h.word).length); return h.start + (h.end - h.start) * (off[idx] + (end ? 1 : 0)) / L; };
    // each word: the first / last heard letter it was matched to
    const n = ws.length, times = new Array(n).fill(null), lastHs = new Array(n).fill(-1), firstHs = new Array(n).fill(-1);
    let pos = 0, cs = 0, ct = 0;
    parts.forEach((t, i) => {
      let f = -1, l = -1, got = 0;
      for (let c = 0; c < t.length; c++) { const x = mt.at[pos + c]; if (x >= 0) { if (f < 0) f = x; l = x; got++; } }
      pos += t.length;
      if (got >= Math.max(1, Math.ceil(t.length * 0.4))) {
        firstHs[i] = f; lastHs[i] = l;
        times[i] = { s: timeAt(f, false), e: Math.max(timeAt(l, true), timeAt(f, false)) };
        cs += wlen(ws[i]); ct += Math.max(0.05, times[i].e - times[i].s);
      }
    });
    const hitIdx = times.map((t, i) => t ? i : -1).filter(i => i >= 0);
    if (!hitIdx.length) return null;
    const rate = clamp(ct > 0 ? cs / ct : fallbackRate, 3.5, 14);
    const first = hitIdx[0], last = hitIdx[hitIdx.length - 1];
    const prevW = list[owner[firstHs[first]] - 1], nextW = list[owner[lastHs[last]] + 1];
    const lowBound = prevW ? prevW.end : 0, highBound = nextW ? nextW.start : dur;   // new words never run into the neighbouring speech
    for (let k = 0; k < n; k++) {                                                    // words with no counterpart: placed by pace between their neighbours
      if (times[k]) continue;
      let b = k; while (b < n && !times[b]) b++;
      const run = ws.slice(k, b), tot = run.reduce((z, w) => z + wlen(w), 0);
      let t0, t1;
      if (k === 0) { t1 = times[b].s; t0 = Math.max(lowBound, t1 - tot / rate); }
      else if (b === n) { t0 = times[k - 1].e; t1 = Math.min(highBound, t0 + tot / rate); }
      else { t0 = times[k - 1].e; t1 = Math.max(t0, times[b].s); }
      if (t1 < t0) t1 = t0;
      let acc = 0;
      run.forEach((w, r) => { const z = wlen(w); times[k + r] = { s: t0 + (t1 - t0) * acc / tot, e: t0 + (t1 - t0) * (acc + z) / tot }; acc += z; });
      k = b - 1;
    }
    let prev = times[0].s;                                                           // words stay in order
    times.forEach(t => { t.s = Math.max(t.s, prev); t.e = Math.max(t.e, t.s); prev = t.e; });
    return { times: times, matched: hitIdx.length, share: mt.hit / q.length };
  }

  S.subtitle.suggestSpan = function (cue) {
    const P = S.state.project, dur = P.media.duration || Infinity;
    if (!cue || !cue.words || !cue.words.length) return null;
    const ws = cue.words, n = ws.length;
    const heard = ((P.subtitle.speech && P.subtitle.speech.length) ? P.subtitle.speech : (P.subtitle.words || [])).filter(h => h && h.word);
    const total = ws.reduce((k, w) => k + wlen(w), 0), fb = paceOf(cue);
    if (heard.length) {
      const sorted = heard.slice().sort((a, b) => a.start - b.start);
      // 1) near the sentence (cheap, and a repeated phrase elsewhere cannot steal the match); 2) anywhere in the clip (the block was dragged far away)
      const near = sorted.filter(h => h.end > cue.start - BEFORE && h.start < cue.end + AFTER);
      const r = (near.length && placeIn(near, ws, 0.45, dur, fb)) || placeIn(sorted, ws, 0.7, dur, fb);
      if (r) {
        const start = clamp(r.times[0].s, 0, dur), end = clamp(Math.max(r.times[n - 1].e, start + 0.1), 0, dur);
        return { start: start, end: end, source: 'speech', matched: r.matched, total: n, wordTimes: r.times };
      }
    }
    const start = clamp(cue.start, 0, dur), end = clamp(start + Math.max(0.3, total / fb), 0, dur);
    return { start: start, end: Math.max(end, start + 0.1), source: 'rate', matched: 0, total: n, wordTimes: null };
  };

  /** Put the sentence where its words are spoken. One undo step. Returns the suggestion that was applied (or null). */
  S.subtitle.fitToSpeech = function (idx) {
    const cues = S.state.project.subtitle.cues, c = cues[idx];
    const g = S.subtitle.suggestSpan(c);
    if (!g) return null;
    if (S.history) S.history.record('timing');
    const o0 = c.start, o1 = c.end;
    c.start = g.start; c.end = g.end;
    if (g.wordTimes) c.words.forEach((w, i) => { w.start = g.wordTimes[i].s; w.end = g.wordTimes[i].e; });
    else if (o1 - o0 > 0.001) { const k = (c.end - c.start) / (o1 - o0); c.words.forEach(w => { w.start = c.start + (w.start - o0) * k; w.end = c.start + (w.end - o0) * k; }); }
    if (S.subtitle.sortCues()) S.bus.emit('cues:structure', { reason: 'timing-sort' });
    else S.bus.emit('cue:timing', { idx: idx });
    return g;
  };
})(window.SubEd);
