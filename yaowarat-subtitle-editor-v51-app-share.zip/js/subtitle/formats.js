/* =====================================================================
 * Subtitle file formats (SRT / VTT). Pure functions, no DOM, no download.
 * ===================================================================== */
(function (S) {
  'use strict';
  const pad = S.util.pad;
  S.subtitle = S.subtitle || {};

  function toSrtTime(t) {
    const total = Math.max(0, Math.round(t * 1000));      // whole milliseconds first, so 1.9996s can never print as ",1000"
    const h = Math.floor(total / 3600000), m = Math.floor(total / 60000) % 60, s = Math.floor(total / 1000) % 60, ms = total % 1000;
    return pad(h) + ':' + pad(m) + ':' + pad(s) + ',' + pad(ms, 3);
  }
  function toVttTime(t) { return toSrtTime(t).replace(',', '.'); }

  /** Cues clipped to a range ({start,end} in source seconds), shifted so 0 = the range start. `range` defaults to the trim.
   *  The Export tab passes the range its chip is on ("ทั้งคลิป" or "ตามที่ตัด"), so the subtitle FILE always matches the exported VIDEO. */
  S.subtitle.exportCues = function (project, range) {
    const r = range || project.trim;
    return project.subtitle.cues
      .filter(c => c.end > r.start && c.start < r.end && c.text && c.text.trim())   // empty lines would be invalid SRT/VTT blocks
      .map(c => ({
        text: c.text.trim(),                      // (an Enter in the line = a second row of the same subtitle block)
        start: Math.max(c.start, r.start) - r.start,
        end: Math.min(c.end, r.end) - r.start
      }))
      .sort((a, b) => a.start - b.start);        // SRT/VTT must be chronological
  };
  S.subtitle.toSRT = function (cues) {
    return cues.map((c, i) => (i + 1) + '\n' + toSrtTime(c.start) + ' --> ' + toSrtTime(c.end) + '\n' + c.text + '\n').join('\n');
  };
  S.subtitle.toVTT = function (cues) {
    return 'WEBVTT\n\n' + cues.map((c, i) => (i + 1) + '\n' + toVttTime(c.start) + ' --> ' + toVttTime(c.end) + '\n' + c.text + '\n').join('\n');
  };
})(window.SubEd);
