/* =====================================================================
 * Subtitle model operations + segmentation strategies. No DOM.
 *
 * words (raw, word-level timing)  --segmenter-->  cues (what the viewer sees)
 *
 * A segmenter is { run(words, options) -> cues[] }. Register new ones
 * (e.g. 'smart' segmentation by punctuation / pauses / meaning) without
 * touching the editor:   SubEd.segmenters.register('smart', { run(words, opts){...} })
 * then set  state.project.subtitle.segmentation.strategy = 'smart'.
 * ===================================================================== */
(function (S) {
  'use strict';
  const segmenters = S.segmenters = S.createRegistry('segmenter');
  const sub = () => S.state.project.subtitle;
  let seq = 0;
  S.subtitle = S.subtitle || {};
  S.subtitle.newCueId = () => 'c' + (++seq);

  /**
   * Every cue carries: id, text, start, end, words[], style.
   * `startTime` / `endTime` / `duration` are live aliases of start/end (kept in sync
   * automatically), so a cue always exposes the full Advanced-Editor shape:
   *   { id, text, startTime, endTime, duration, words, style }
   * `style` is a per-cue override object or null (= inherit the global style).
   * Aliases are enumerable getters, so JSON snapshots include them; cues restored
   * from JSON are re-decorated (see S.subtitle.decorateCue / normalizeCues).
   */
  S.subtitle.decorateCue = function (c) {
    if (!Object.prototype.hasOwnProperty.call(c, 'style')) c.style = null;
    if (!c.id) c.id = S.subtitle.newCueId();
    else { const m = /^c(\d+)$/.exec(c.id); if (m && +m[1] > seq) seq = +m[1]; }   // after a refresh the counter restarts: never reuse a restored id
    const d = Object.getOwnPropertyDescriptor(c, 'startTime');
    if (!d || !d.get) {                    // plain data props come from JSON snapshots — replace with live aliases
      delete c.startTime; delete c.endTime; delete c.duration;
      Object.defineProperty(c, 'startTime', { enumerable: true, configurable: true,
        get() { return this.start; }, set(v) { this.start = v; } });
      Object.defineProperty(c, 'endTime', { enumerable: true, configurable: true,
        get() { return this.end; }, set(v) { this.end = v; } });
      Object.defineProperty(c, 'duration', { enumerable: true, configurable: true,
        get() { return this.end - this.start; } });
    }
    return c;
  };
  S.subtitle.normalizeCues = function (cues) { (cues || []).forEach(S.subtitle.decorateCue); return cues; };

  /**
   * A cue's per-line override lives in cue.style (or null = inherit everything). Optional keys:
   *   colours   color, highlight, bgColor
   *   look      fx (animation), fxDur (its length, 0.01-3 s), fxStep (ms between words / letters), fxOut + fxOutDur (ending animation), weight, thick, sharp, italic, glow {on,color,intensity,range}, shadow {on,color,opacity,blur,dist,angle}
   *   position  pos ('bottom'|'mid'|'top'), posY (0.05-0.97, caption block centre as a fraction of picture height; wins over pos)
   *             no override = the line sits where the global style puts it
   * effectiveStyle() returns the style to DRAW this cue with: the global style plus the override.
   * Both the preview and the burned-in export go through it, so they always agree.
   */
  S.subtitle.effectiveStyle = function (cue, base) {
    const o = cue && cue.style;
    if (!o) return base;
    const st = Object.assign({}, base);
    if (o.color) st.color = o.color;
    if (o.highlight) st.highlight = o.highlight;
    if (o.bgColor) st.bg = Object.assign({}, base.bg, { color: o.bgColor });
    if (o.fx) st.fx = o.fx;
    if (o.fxDur > 0) st.fxDur = o.fxDur;                      // this line's own animation length (s)
    if (o.fxStep > 0) st.fxStep = o.fxStep;                   // ... its word / letter stagger (ms)
    if (o.fxOut) st.fxOut = o.fxOut;                          // ... its ending animation
    if (o.fxOutDur > 0) st.fxOutDur = o.fxOutDur;
    if (o.pos) st.pos = o.pos;
    if (o.posY != null) { st.pos = 'custom'; st.posY = o.posY; }
    if (o.posX != null) st.posX = o.posX;                    // free placement: centre of the caption block across the picture (0-1)
    if (o.scale) st.size = base.size * o.scale;              // free resize of this line only
    if (o.weight != null) { st.weight = o.weight; st.bold = o.weight >= 600; }
    if (o.thick != null) st.thick = o.thick;
    if (o.sharp != null) st.sharp = o.sharp;
    if (o.italic != null) st.italic = !!o.italic;
    if (o.glow) st.glow = Object.assign({}, base.glow, o.glow);
    if (o.shadow) st.shadow = Object.assign({}, base.shadow, o.shadow);
    return st;
  };

  /**
   * The glow ONE word is drawn with: the cue's glow (`base`, from effectiveStyle) overlaid with the word's own glow override
   * (word.glow = { on?, color?, intensity?, range? }). No override = the base object itself. Preview and export both use it.
   */
  S.subtitle.wordGlow = function (w, base) {
    if (!(w && w.glow)) return base;
    const g = Object.assign({}, base, w.glow);
    if (w.glow.color && w.glow.follow == null) g.follow = false;      // a word given its own glow colour keeps it
    return g;
  };
  /** The glow as it is DRAWN for text painted in `fill`: with `follow` on, the glow takes the colour of the text itself. */
  S.subtitle.glowFor = function (g, fill) {
    return g && g.follow && fill && fill[0] === '#' ? Object.assign({}, g, { color: fill }) : g;
  };

  /** Record an undo step, then mutate. All editing ops go through here. */
  function mutate(label, fn) {
    if (S.history) S.history.record(label);
    return fn();
  }

  // Fixed-size groups — identical to the original regroup().
  segmenters.register('words-per-line', {
    run(words, opts) {
      const size = opts.wordsPerLine, cues = [];
      for (let i = 0; i < words.length; i += size) {
        const slice = words.slice(i, i + size);
        cues.push({
          id: S.subtitle.newCueId(),
          start: slice[0].start,
          end: slice[slice.length - 1].end,
          words: slice,
          text: S.subtitle.joinWords(slice)
        });
      }
      return cues;
    }
  });

  /**
   * 'smart' — readable lines instead of fixed word counts.
   *   1. hard breaks: a line the AI (Gemini) already ended (word.brk), a long pause, end of sentence
   *   2. a chunk that still fits (opts.maxChars visible characters, MAX_DUR seconds) stays one cue
   *   3. longer chunks are cut into evenly sized lines, each cut chosen at the best nearby place:
   *      pauses, commas, before a conjunction; never after a linking word or before a closing particle
   *   4. tiny lines are avoided; every cue lingers a moment and is shown at least MIN_SHOW seconds
   */
  const HARD_GAP = 0.8, SOFT_GAP = 0.35, MAX_DUR = 6, MIN_SHOW = 0.7, LINGER = 0.15, MIN_CHARS = 6;
  const BREAK_BEFORE = new Set(['และ', 'หรือ', 'แต่', 'แต่ว่า', 'เพราะ', 'เพราะว่า', 'ซึ่ง', 'ถ้า', 'หาก', 'เมื่อ', 'ดังนั้น', 'อย่างไรก็ตาม', 'ส่วน', 'จึง', 'โดย',
    'and', 'but', 'or', 'because', 'which', 'when', 'if', 'so', 'then']);
  const NO_END = new Set(['ที่', 'ซึ่ง', 'และ', 'หรือ', 'แต่', 'เพราะ', 'ว่า', 'ของ', 'ใน', 'กับ', 'จาก', 'ให้', 'โดย', 'ถ้า', 'หาก', 'เมื่อ', 'จะ', 'การ', 'ความ',
    'a', 'an', 'the', 'of', 'to', 'in', 'on', 'at', 'for', 'and', 'but', 'or', 'with', 'by', 'from', 'that', 'is', 'are']);
  const NO_START = new Set(['ๆ', 'ฯ', 'ครับ', 'ค่ะ', 'คะ', 'นะ', 'นะครับ', 'นะคะ', 'จ้ะ', 'จ้า', 'ล่ะ', 'น่ะ']);
  const ENDS_SENTENCE = /[.!?…。！？]["')\]”’]*$/, ENDS_COMMA = /[,;:，、；：]["')\]”’]*$/;
  const bare = w => (w.word || '').trim().toLowerCase().replace(/^[^\w\u0E00-\u0E7F]+|[^\w\u0E00-\u0E7F]+$/g, '');

  function chunkLen(ws) { return S.thai.visLen(S.subtitle.joinWords(ws)); }

  /** Words -> chunks that can never share a line: a long pause, a sentence end, (optionally) a line the AI already ended. */
  function hardChunks(words, useBrk) {
    const chunks = [];
    let cur = [];
    words.forEach(w => {
      if (cur.length) {
        const p = cur[cur.length - 1];
        if (w.start - p.end >= HARD_GAP || ENDS_SENTENCE.test(p.word.trim()) || (useBrk && p.brk)) { chunks.push(cur); cur = []; }
      }
      cur.push(w);
    });
    if (cur.length) chunks.push(cur);
    return chunks;
  }

  /** lines (word arrays) -> cues, with readable timing: short linger, minimum on-screen time, never into the next cue. */
  function cuesFromLines(lines) {
    const cues = lines.map(ws => ({
      id: S.subtitle.newCueId(),
      start: ws[0].start,
      end: ws[ws.length - 1].end,
      words: ws,
      text: S.subtitle.joinWords(ws)
    }));
    cues.forEach((c, i) => {
      const limit = i < cues.length - 1 ? cues[i + 1].start - 0.02 : Infinity;
      c.end = Math.max(c.end, Math.min(c.end + LINGER, limit));
      if (c.end - c.start < MIN_SHOW) c.end = Math.max(c.end, Math.min(c.start + MIN_SHOW, limit));
    });
    return cues;
  }

  function splitChunk(ws, maxChars) {
    const out = [];
    let rest = ws;
    while (rest.length) {
      const total = chunkLen(rest), dur = rest[rest.length - 1].end - rest[0].start;
      if (rest.length === 1 || (total <= maxChars && dur <= MAX_DUR)) { out.push(rest); break; }
      const pieces = Math.max(2, Math.ceil(total / maxChars), Math.ceil(dur / MAX_DUR));
      const target = total / pieces;
      let best = -1, bestScore = -Infinity, cum = 0;
      for (let i = 1; i < rest.length; i++) {
        cum = chunkLen(rest.slice(0, i));
        const ldur = rest[i - 1].end - rest[0].start;
        if (i > 1 && (cum > maxChars || ldur > MAX_DUR)) break;
        const gap = rest[i].start - rest[i - 1].end;
        const prev = bare(rest[i - 1]), next = bare(rest[i]);
        let sc = -Math.abs(cum - target);
        sc += Math.min(gap, 1.2) * 12;
        if (ENDS_COMMA.test(rest[i - 1].word.trim())) sc += 8;
        if (BREAK_BEFORE.has(next)) sc += 6;
        if (NO_END.has(prev)) sc -= 10;
        if (NO_START.has(next)) sc -= 14;
        if (cum < MIN_CHARS) sc -= 12;
        if (total - cum < MIN_CHARS) sc -= 12;
        if (sc > bestScore) { bestScore = sc; best = i; }
      }
      if (best < 1) best = 1;
      out.push(rest.slice(0, best));
      rest = rest.slice(best);
    }
    return out;
  }

  segmenters.register('smart', {
    run(words, opts) {
      const base = opts.maxChars || 28;
      const useBrk = !opts.fromCues;
      const chunks = hardChunks(words, useBrk);

      const lines = [];
      chunks.forEach(ch => {
        // Latin text is narrower per character than Thai: allow longer lines
        const thai = ch.some(w => S.thai.hasThai(w.word));
        splitChunk(ch, thai ? base : Math.round(base * 1.5)).forEach(l => lines.push(l));
      });

      // glue lonely fragments (one short word between two pauses) onto the closest neighbour
      for (let i = 0; i < lines.length; i++) {
        if (chunkLen(lines[i]) >= MIN_CHARS || lines.length < 2) continue;
        const prev = lines[i - 1], next = lines[i + 1];
        const gp = prev ? lines[i][0].start - prev[prev.length - 1].end : Infinity;
        const gn = next ? next[0].start - lines[i][lines[i].length - 1].end : Infinity;
        const tryJoin = (a, b) => chunkLen(a.concat(b)) <= base * 1.15 && (b[b.length - 1].end - a[0].start) <= MAX_DUR;
        if (gp <= gn && gp < HARD_GAP && prev && tryJoin(prev, lines[i])) { prev.push(...lines[i]); lines.splice(i, 1); i--; }
        else if (gn < HARD_GAP && next && tryJoin(lines[i], next)) { lines[i].push(...next); lines.splice(i + 1, 1); i--; }
      }

      return cuesFromLines(lines);
    }
  });

  /* ---------------------------------------------------------------------------------------------
   * 'rhythm' — copy the SENTENCE SIZE of a reference clip (short punchy lines all the way through), cut where the
   * speaker's beats are.   e.g.  ทุกคน | เคยสงสัย | ไหมครับ | ว่า      อย่างที่เรา | รู้กันว่า      ทุกคน | รู้ หรือ ไม่ | ครับว่า
   *
   * A rhythm is plain JSON (it lives in a style profile, see style/style-copy.js, and in
   * project.subtitle.segmentation.rhythm):
   *   lines    [{ w: words, c: visible characters, s: seconds }]  the reference's lines (a record of what was measured)
   *   typical  { w, c, s }  the usual line      min { w, c }  shortest    max { w, c }  longest allowed
   *
   * Every line may hold min..max words / characters (1-3 words, ~3-12 characters for the built-in reference), the usual
   * size is only a gentle pull. WHERE to cut comes from the audio: a pause is the best place, then a comma, a closing
   * particle (ครับ, ไหม ...) or a conjunction. Grammar is a weak hint here (a line may end with ว่า or start with ครับ):
   * a pause always wins. A long pause or a sentence end always cuts.
   * --------------------------------------------------------------------------------------------- */
  const R_MAX_DUR = 4.5;
  const R_NO_END = new Set(['ที่', 'ซึ่ง', 'และ', 'แต่', 'เพราะ', 'ของ', 'ใน', 'กับ', 'จาก', 'ให้', 'โดย', 'ถ้า', 'หาก', 'เมื่อ', 'จะ', 'การ', 'ความ',
    'a', 'an', 'the', 'of', 'to', 'in', 'on', 'at', 'for', 'and', 'but', 'or', 'with', 'by', 'from', 'that']);
  const R_END_PARTICLE = new Set(['ครับ', 'ค่ะ', 'คะ', 'นะ', 'นะครับ', 'นะคะ', 'ไหม', 'ไหมครับ', 'มั้ย', 'เหรอ', 'หรอ', 'ล่ะ', 'น่ะ', 'เลย']);
  const clampN = (v, lo, hi, d) => (isFinite(+v) && v !== null && v !== '') ? Math.min(hi, Math.max(lo, +v)) : d;
  const med = a => { if (!a.length) return NaN; const s = a.slice().sort((x, y) => x - y), m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };

  /** The OPENING sentence form: its first lines are cut to a fixed syllable pattern (พยางค์ ต่อบรรทัด), e.g. 2-3-3 = ทุกคน | เคยสงสัย | ไหมครับว่า. */
  const OPENING_PATTERNS = [[2, 3, 3], [2, 3, 2], [3, 3]];
  S.subtitle.OPENING_PATTERNS = OPENING_PATTERNS;
  S.subtitle.normalizeOpening = function (o) {
    const ok = p => Array.isArray(p) && p.length >= 2 && p.length <= 4 && p.every(n => Number.isInteger(n) && n >= 1 && n <= 6);
    const pats = o && Array.isArray(o.patterns) ? o.patterns.filter(ok) : [];
    return { on: !(o && o.on === false), patterns: (pats.length ? pats : OPENING_PATTERNS).map(p => p.slice()) };
  };

  /** lines [{w,c,s}] (+ optional typical / min / max / opening) -> a complete, validated rhythm object. */
  S.subtitle.buildRhythm = function (lines, o) {
    o = o || {};
    const L = (Array.isArray(lines) ? lines : []).slice(0, 60).map(l => ({
      w: Math.round(clampN(l && l.w, 1, 12, 2)), c: Math.round(clampN(l && l.c, 1, 60, 8)), s: +clampN(l && l.s, 0.2, 8, 0.9).toFixed(2)
    }));
    const typical = o.typical ? { w: Math.round(clampN(o.typical.w, 1, 12, 3)), c: Math.round(clampN(o.typical.c, 2, 60, 10)), s: +clampN(o.typical.s, 0.2, 8, 0.9).toFixed(2) }
      : L.length ? { w: Math.round(med(L.map(l => l.w))), c: Math.round(med(L.map(l => l.c))), s: +med(L.map(l => l.s)).toFixed(2) } : { w: 3, c: 10, s: 0.9 };
    const max = o.max ? { w: Math.round(clampN(o.max.w, 1, 12, typical.w)), c: Math.round(clampN(o.max.c, 2, 60, typical.c)) }
      : L.length ? { w: Math.max.apply(null, L.map(l => l.w)), c: Math.max.apply(null, L.map(l => l.c)) } : { w: typical.w, c: Math.round(typical.c * 1.4) };
    max.w = Math.max(max.w, typical.w); max.c = Math.max(max.c, typical.c);
    const min = o.min ? { w: Math.round(clampN(o.min.w, 1, 12, 1)), c: Math.round(clampN(o.min.c, 1, 60, 3)) }
      : L.length ? { w: Math.min.apply(null, L.map(l => l.w)), c: Math.min.apply(null, L.map(l => l.c)) } : { w: 1, c: 3 };
    min.w = Math.min(min.w, typical.w); min.c = Math.min(min.c, typical.c);
    return { lines: L, typical: typical, min: min, max: max, opening: S.subtitle.normalizeOpening(o.opening) };
  };

  /** A rhythm from plain settings (no reference lines): lines of 1..wordsPerLine words, ~0.7 x maxChars characters usually. */
  S.subtitle.rhythmFromSettings = function (wordsPerLine, maxChars) {
    const w = Math.max(1, Math.round(wordsPerLine || 3)), mc = Math.max(4, Math.round(maxChars || 14));
    return S.subtitle.buildRhythm([], { typical: { w: w, c: Math.round(mc * 0.7), s: 0.9 }, max: { w: w, c: mc }, min: { w: 1, c: 3 } });
  };

  /** Any saved rhythm (older file, hand-edited JSON ...) -> a valid one; null when there is nothing usable. */
  S.subtitle.normalizeRhythm = function (r) {
    if (!r || typeof r !== 'object' || (!Array.isArray(r.lines) && !r.typical)) return null;
    return S.subtitle.buildRhythm(r.lines, r);
  };

  /**
   * The opening sentence (the first chunk of speech) as 2-3-3 / 2-3-2 / 3-3 SYLLABLES per line, cut only between words.
   * Tries every pattern and every way of cutting the first words; the best fit wins (syllables on target first, then a real
   * pause / comma / particle at each cut, never after a linking word or before a closing particle). Returns
   * { groups: [[word...], ...], used: words consumed } or null when no pattern fits within one syllable per line.
   */
  function openingPlan(ch, opening) {
    if (!opening || !opening.on || ch.length < 2) return null;
    const N = Math.min(ch.length, 14), syl = ch.slice(0, N).map(w => S.thai.syllables(w.word));
    const cutScore = e => {                                         // quality of cutting between word e-1 and e
      if (e >= ch.length) return 3;                                 // the sentence ends here
      const a = ch[e - 1], b = ch[e], gap = b.start - a.end, prev = bare(a), next = bare(b);
      let sc = 0;
      if (gap >= 0.12) sc += Math.min(gap, 0.7) * 20;
      if (ENDS_COMMA.test(a.word.trim())) sc += 5;
      if (R_END_PARTICLE.has(prev)) sc += 1;
      if (BREAK_BEFORE.has(next)) sc += 1;
      if (R_NO_END.has(prev)) sc -= 4;
      return sc;                                                    // (a line may start with ครับ — ทุกคน รู้หรือไม่ | ครับว่า)
    };
    let best = null;
    opening.patterns.forEach((pat, pi) => {
      const walk = (g, from, cuts, dev, sc) => {
        if (g === pat.length) {
          // a pattern that uses up the whole sentence is best; one that strands a 1-2 syllable orphan is bad (ทุกคน รู้หรือไม่ | ครับว่า, not 3-3 + ว่า)
          let rest = 0; for (let k = from; k < ch.length; k++) rest += S.thai.syllables(ch[k].word);
          const score = -dev * 10 + sc + (rest === 0 ? 6 : rest <= 2 ? -8 : 0) - pi * 2.5;   // listed order = preference: 2-3-3, then 2-3-2, then 3-3 (a real pause can still outweigh it)     // earlier pattern wins ties
          if (!best || score > best.score) best = { score: score, cuts: cuts.slice(), pat: pat };
          return;
        }
        let sum = 0;
        for (let e = from + 1; e <= N; e++) {
          sum += syl[e - 1];
          const d = Math.abs(sum - pat[g]);
          if (sum > pat[g] + 1) break;                                    // already too long
          if (d > 1 || dev + d > 1) continue;                             // at most ONE syllable off in the whole opening
          cuts.push(e); walk(g + 1, e, cuts, dev + d, sc + cutScore(e)); cuts.pop();
        }
      };
      walk(0, 0, [], 0, 0);
    });
    if (!best) return null;
    const groups = []; let from = 0;
    best.cuts.forEach(e => { groups.push(ch.slice(from, e)); from = e; });
    return { groups: groups, used: from, pattern: best.pat.join('-') };
  }
  S.subtitle.openingPlan = openingPlan;

  segmenters.register('rhythm', {
    run(words, opts) {
      let r = S.subtitle.normalizeRhythm(opts.rhythm);
      if (!r && S.styleCopy) r = S.subtitle.normalizeRhythm((S.styleCopy.lastProfile || S.styleCopy.REFERENCE_1).layout.rhythm);
      if (!r) r = S.subtitle.rhythmFromSettings(opts.wordsPerLine, opts.maxChars);
      const useBrk = !opts.fromCues;                    // a line the AI ended is a hint to cut there, not a rule
      const out = (v, lo, hi) => v < lo ? lo - v : v > hi ? v - hi : 0;
      const lines = [];
      hardChunks(words, false).forEach((ch, ci) => {
        const thai = ch.some(w => S.thai.hasThai(w.word)), scale = thai ? 1 : 1.4;   // Latin text is narrower per character
        const tc = r.typical.c * scale, tw = r.typical.w, ts = r.typical.s;
        const loC = r.min.c * scale, hiC = Math.round(r.max.c * scale * 1.1), loW = r.min.w, hiW = r.max.w;
        let i = 0;
        if (ci === 0) {                                                       // the opening sentence takes a fixed 2-3-3 / 2-3-2 / 3-3 shape
          const op = openingPlan(ch, r.opening);
          if (op) { op.groups.forEach(g => lines.push(g)); i = op.used; }
        }
        const first = lines.length;
        while (i < ch.length) {
          const left = ch.length - i;
          let best = 1, bestScore = -Infinity;
          for (let n = 1; n <= left; n++) {
            const seg = ch.slice(i, i + n), chars = chunkLen(seg), dur = seg[n - 1].end - seg[0].start;
            if (n > 1 && (chars > hiC || n > hiW || dur > R_MAX_DUR)) break;
            // size: free inside the reference's range, a gentle pull to its usual size
            let sc = -10 * (1.0 * out(chars, loC, hiC) / Math.max(tc, 5) + 0.8 * out(n, loW, hiW) / Math.max(tw, 2)
              + 0.25 * (Math.abs(chars - tc) / Math.max(tc, 5) + 0.6 * Math.abs(n - tw) / Math.max(tw, 2)) + 0.2 * Math.abs(dur - ts) / Math.max(ts, 0.6));
            if (i + n < ch.length) {
              const a = ch[i + n - 1], b = ch[i + n], gap = b.start - a.end, prev = bare(a), next = bare(b);
              if (gap >= 0.12) sc += Math.min(gap, 0.7) * 30;               // follow the audio: a real pause is the best place to cut
              if (ENDS_COMMA.test(a.word.trim())) sc += 6;
              if (R_END_PARTICLE.has(prev)) sc += 3;
              if (BREAK_BEFORE.has(next)) sc += 3;
              if (useBrk && a.brk) sc += 4;
              if (R_NO_END.has(prev)) sc -= 5;
              if (NO_START.has(next)) sc -= 4;
              if (ch.length - i - n === 1 && chunkLen(ch.slice(i + n)) < MIN_CHARS) sc -= 4;   // would leave a lonely word behind
            } else sc += 4;                                                  // the sentence ends here
            if (n === 1 && left > 1 && (NO_START.has(bare(ch[i])) || R_END_PARTICLE.has(bare(ch[i])))) sc -= 6;   // a closing particle alone (ครับ) is not a line
            if (sc > bestScore) { bestScore = sc; best = n; }
          }
          lines.push(ch.slice(i, i + best));
          i += best;
        }
        // a lonely short word at the end of a sentence joins the line before it when that still fits
        const last = lines.length - 1;
        if (last > first && lines[last].length === 1 && chunkLen(lines[last]) < MIN_CHARS) {
          const prevGap = lines[last][0].start - lines[last - 1][lines[last - 1].length - 1].end;
          const joined = lines[last - 1].concat(lines[last]);
          if (prevGap < 0.25 && chunkLen(joined) <= hiC && joined.length <= hiW) { lines[last - 1] = joined; lines.pop(); }
        }
      });
      return cuesFromLines(lines);
    }
  });

  /**
   * Rebuild cues with the active segmentation strategy.
   *   opts.from === 'words' (default): from the raw ASR words — used right after transcription.
   *   opts.from === 'cues':            from the words currently in the cues, so manual edits
   *                                    (text, timing, deleted lines) survive re-segmentation.
   *   opts.history === false:          do not record an undo step (the caller already did).
   */
  S.subtitle.regroup = function (opts) {
    const s = sub();
    const from = (opts && opts.from) || 'words';
    if (from === 'cues') { if (S.history && !(opts && opts.history === false)) S.history.record('regroup'); }   // history:false = the caller already recorded this step
    else if (S.history) S.history.clear();          // fresh transcript: editing history starts here
    const source = from === 'cues' ? s.cues.slice().sort((a, b) => a.start - b.start).flatMap(c => c.words) : s.words;
    s.cues = segmenters.get(s.segmentation.strategy).run(source, Object.assign({}, s.segmentation, { fromCues: from === 'cues' }));
    S.subtitle.normalizeCues(s.cues);
    S.state.ui.activeCue = -1;
    S.bus.emit('cues:structure', { reason: 'regroup' });
  };

  /**
   * Text of a run of words exactly as it is displayed: a space between words, except where a word is
   * flagged `joined` (it was split out of an unspaced Thai phrase, so it is drawn with no gap).
   */
  S.subtitle.joinWords = function (words) {
    return words.map((w, i) => (i ? (w.nl ? '\n' : (w.joined ? '' : ' ')) : '') + w.word.trim()).join('');   // w.nl = the user pressed Enter before this word (a hard new line)
  };

  /** Split typed text into tokens { text, joined }. Whitespace first; unspaced Thai runs use Intl.Segmenter when the browser has it. */
  const thSeg = (typeof Intl !== 'undefined' && Intl.Segmenter) ? new Intl.Segmenter('th', { granularity: 'word' }) : null;
  S.subtitle.tokenize = function (text) {
    const out = [];
    String(text == null ? '' : text).replace(/\r\n?/g, '\n').split('\n').forEach(line => {
      const from = out.length;
      line.trim().split(/\s+/).filter(Boolean).forEach(tok => {
        if (thSeg && /[\u0E00-\u0E7F]/.test(tok)) {
          const parts = Array.from(thSeg.segment(tok)).filter(x => x.isWordLike !== false).map(x => x.segment);
          if (parts.length) { parts.forEach((t, i) => out.push({ text: t, joined: i > 0 })); return; }
        }
        out.push({ text: tok, joined: false });
      });
      if (from > 0 && out.length > from) out[from].nl = true;     // Enter: this line starts on a new row (the only way a caption breaks into rows)
    });
    return out;
  };

  /**
   * Edit a cue's text. Keeps cue.words (what the preview and the burned-in export draw) in step
   * with cue.text (what SRT/VTT use). Same word count: timings are kept. Different count: words are
   * re-timed across the cue's span, weighted by character length.
   */
  S.subtitle.setCueText = function (idx, text, opts) {
    const c = sub().cues[idx];
    if (!c) return;
    const run = () => {
    c.text = String(text == null ? '' : text).replace(/\r\n?/g, '\n').replace(/[ \t]*\n[ \t\n]*/g, '\n');   // Enter = ONE row break (blank lines would also cut an SRT block in two)
    const tokens = S.subtitle.tokenize(c.text);
    if (tokens.length === c.words.length) {
      c.words.forEach((w, i) => { w.word = tokens[i].text; w.joined = tokens[i].joined; if (tokens[i].nl) w.nl = true; else delete w.nl; });
    } else {
      const total = tokens.reduce((n, t) => n + Math.max(1, t.text.length), 0), span = c.end - c.start;
      const colours = {}, glows = {}, holds = {};          // per-word colours / glows survive a retype when the word itself is unchanged
      c.words.forEach(o => { if (o.color) { colours[o.word.trim()] = o.color; if (o.hold) holds[o.word.trim()] = true; } if (o.glow) glows[o.word.trim()] = o.glow; });
      let acc = 0;
      c.words = tokens.map(t => {
        const w = Math.max(1, t.text.length), start = c.start + span * acc / total;
        acc += w;
        const nw = { word: t.text, joined: t.joined, start: start, end: c.start + span * acc / total };
        if (t.nl) nw.nl = true;
        if (colours[t.text]) { nw.color = colours[t.text]; if (holds[t.text]) nw.hold = true; }
        if (glows[t.text]) nw.glow = Object.assign({}, glows[t.text]);
        return nw;
      });
    }
    S.bus.emit('cue:text', { idx: idx });
    };
    // Record one undo step per editing gesture unless the caller already did
    // (the panel records once on focus, so a whole typing session is one step).
    if (opts && opts.history === false) run();
    else mutate('text', run);
  };

  /**
   * Change a cue's colour override. patch = { color?, highlight?, bgColor? }; a key set to null/'' is
   * cleared, and patch === null clears the whole override (back to the global style).
   * opts.history === false skips the undo record (a colour drag records once per gesture).
   */
  S.subtitle.setCueStyle = function (idx, patch, opts) {
    const c = sub().cues[idx];
    if (!c) return;
    const run = () => {
      if (patch === null) c.style = null;
      else {
        const next = Object.assign({}, c.style || {});
        Object.keys(patch).forEach(k => { if (patch[k]) next[k] = patch[k]; else delete next[k]; });
        c.style = Object.keys(next).length ? next : null;
      }
      S.bus.emit('cue:style', { idx: idx });
    };
    if (opts && opts.history === false) run();
    else mutate('style', run);
  };

  /**
   * Change any part of a cue's override (colours AND look). Unlike setCueStyle, 0 / false / 'none' are real values:
   * only null / undefined / '' clear a key. Objects (glow, shadow) are stored whole. patch === null clears everything.
   * opts.history === false skips the undo record (the caller records once per gesture).
   */
  S.subtitle.setCueLook = function (idx, patch, opts) {
    const c = sub().cues[idx];
    if (!c) return;
    const run = () => {
      if (patch === null) c.style = null;
      else {
        const next = Object.assign({}, c.style || {});
        Object.keys(patch).forEach(k => {
          const v = patch[k];
          if (v === null || v === undefined || v === '') delete next[k];
          else next[k] = (v && typeof v === 'object') ? JSON.parse(JSON.stringify(v)) : v;
        });
        c.style = Object.keys(next).length ? next : null;
      }
      S.bus.emit('cue:style', { idx: idx });
    };
    if (opts && opts.history === false) run();
    else mutate('style', run);
  };

  /**
   * The glow a word gets together with its own colour: the line's glow (strength / spread) turned on, but in the WORD's colour —
   * so one coloured word lights up orange while the rest of the line keeps its own (white) light. `auto` marks it as the one that
   * came with the colour (cleared again with the colour). Shared by the colour pickers and the auto-highlight.
   */
  S.subtitle.colorGlow = function (cue, w, color) {
    const base = S.subtitle.effectiveStyle(cue, S.state.project.style).glow || {};
    if (S.state.project.style.wgOff) return null;                  // style says: a coloured word does not glow (CapCut Aa)
    const g = Object.assign({}, w.glow, { on: true, color: color, follow: false, auto: true });
    // The line has no glow of its own (the CapCut Aa styles): the word gets a THIN glow in its colour, so the colour reads as colour (CapCut look)
    // instead of a red bloom. A line that does have a glow hands its strength / spread to the word, as before.
    if (!base.on) {
      if (!(w.glow && w.glow.intensity > 0)) g.intensity = 28;
      if (!(w.glow && w.glow.range > 0)) g.range = 7;
    } else {
      if (!(base.intensity > 0) && !(g.intensity > 0)) g.intensity = 60;
      if (!(base.range > 0) && !(g.range > 0)) g.range = 12;
    }
    return g;
  };

  /**
   * Colour ONE word of a cue (word.color = '#rrggbb'); null/'' clears it (back to the cue / global colour).
   * It is drawn by the preview and the burned-in export alike, and wins over the karaoke highlight.
   * opts.history === false skips the undo record (a colour drag records once per gesture).
   */
  S.subtitle.setWordColor = function (idx, wi, color, opts) {
    const c = sub().cues[idx];
    if (!c || !c.words[wi]) return;
    const run = () => {
      const w = c.words[wi];
      if (color) {
        w.color = color;
        if (!(opts && opts.hold === false)) w.hold = true;             // painted by hand: the colour stays on the word (not only while it is being read). The auto-highlight sets w.color itself, without hold
        if (!(opts && opts.glow === false)) w.glow = S.subtitle.colorGlow(c, w, color);   // the word glows in the colour it was just given (this word only)
      } else {
        delete w.color; delete w.hold;
        if (w.glow && (w.glow.auto || (opts && opts.clearGlow))) delete w.glow;   // colour cleared -> the glow that came with it goes too (clearGlow: the "clear colour" buttons also drop a glow colour picked by hand)
      }
      if (color) S.bus.emit('word:colored', { idx: idx, wi: wi });     // the preview shows this word in its new colour (+ glow) for a moment even if karaoke is not on it
      S.bus.emit('cue:text', { idx: idx });
    };
    if (opts && opts.history === false) run();
    else mutate('wordcolor', run);
  };

  /**
   * Glow ONE word of a cue on its own (word.glow). patch = { on?, color?, intensity?, range? } is merged into the word's
   * override; a key set to null is cleared; patch === null removes the override (the word follows the line's glow again).
   * Drawn by the preview and the burned-in export alike. opts.history === false skips the undo record.
   */
  S.subtitle.setWordGlow = function (idx, wi, patch, opts) {
    const c = sub().cues[idx];
    if (!c || !c.words[wi]) return;
    const run = () => {
      const w = c.words[wi];
      if (patch === null) delete w.glow;
      else {
        const next = Object.assign({}, w.glow || {});
        Object.keys(patch).forEach(k => { if (patch[k] === null || patch[k] === undefined || patch[k] === '') delete next[k]; else next[k] = patch[k]; });
        if (!patch.auto && patch.color) delete next.auto;        // a glow colour picked by hand is no longer "the one that came with the word colour"; tuning only strength / spread keeps the link (so clearing the word colour clears its glow too)
        if (Object.keys(next).length) w.glow = next; else delete w.glow;
      }
      S.bus.emit('cue:text', { idx: idx });
    };
    if (opts && opts.history === false) run();
    else mutate('wordglow', run);
  };

  /**
   * Make parts of cue `idx`'s look the DEFAULT for every line and word, without touching any text or timing.
   * `parts` chooses what is applied (every key defaults to true; pass false to skip):
   *   color, highlight, bg        text / highlight / background colour
   *   fx, weight, sharp, italic   animation / thickness (weight + extra thickness) / sharpness / italic
   *   glow, shadow                the whole glow / drop-shadow group
   *   words                       every word's own colour and own glow are cleared (all words follow the default)
   * Each chosen part is copied from the cue's effective look into project.style, and that override is cleared from
   * every cue, so all lines inherit it. Parts left out are not touched anywhere.
   * ONE undo step restores the cues AND the global style (history entry recorded with { style: true }).
   * Returns false when nothing was applied.
   */
  const PART_KEYS = { color: ['color'], highlight: ['highlight'], bg: ['bgColor'], fx: ['fx', 'fxDur', 'fxStep', 'fxOut', 'fxOutDur'], weight: ['weight', 'thick'],
    sharp: ['sharp'], italic: ['italic'], glow: ['glow'], shadow: ['shadow'] };
  S.subtitle.applyCueStyleToAll = function (idx, parts) {
    const cues = sub().cues, c = cues[idx];
    if (!c) return false;
    const want = {};
    Object.keys(PART_KEYS).concat('words').forEach(k => { want[k] = !(parts && parts[k] === false); });
    if (!Object.keys(want).some(k => want[k])) return false;
    if (S.history) S.history.record('style-all', { style: true });
    const st = S.state.project.style, eff = S.subtitle.effectiveStyle(c, st);   // read BEFORE any override is cleared
    if (want.color) st.color = eff.color;
    if (want.highlight) st.highlight = eff.highlight;
    if (want.bg) st.bg.color = eff.bg.color;
    if (want.fx) { st.fx = eff.fx; st.fxDur = eff.fxDur; st.fxStep = eff.fxStep; st.fxOut = eff.fxOut; st.fxOutDur = eff.fxOutDur; }
    if (want.weight) { st.weight = eff.weight; st.thick = eff.thick; st.bold = eff.bold; }
    if (want.sharp) st.sharp = eff.sharp;
    if (want.italic) st.italic = eff.italic;
    if (want.glow) st.glow = Object.assign(st.glow || {}, eff.glow);
    if (want.shadow) st.shadow = Object.assign(st.shadow || {}, eff.shadow);
    cues.forEach(cue => {
      if (cue.style) {
        Object.keys(PART_KEYS).forEach(k => { if (want[k]) PART_KEYS[k].forEach(key => { delete cue.style[key]; }); });
        if (!Object.keys(cue.style).length) cue.style = null;
      }
      if (want.words) cue.words.forEach(w => { delete w.color; delete w.glow; });
    });
    S.bus.emit('style:changed');
    S.bus.emit('cues:structure', { reason: 'style-all' });
    return true;
  };

  /**
   * Make EVERY line follow the main (global) position: drops each cue's own pos / posY override.
   * Used whenever the main position changes (chips, slider, style copy), so no line is left behind at an old spot.
   * record === false: the caller already recorded the undo step (history entry with { style: true }).
   * Returns how many lines had their own position (0 = nothing changed, no undo step, no redraw).
   */
  S.subtitle.clearCuePositions = function (record) {
    const own = sub().cues.filter(c => c.style && (c.style.pos || c.style.posY != null || c.style.posX != null));
    if (!own.length) return 0;
    if (record !== false && S.history) S.history.record('pos-all', { style: true });   // BEFORE the change: undo brings the old positions back
    own.forEach(c => {
      delete c.style.pos; delete c.style.posY; delete c.style.posX;
      if (!Object.keys(c.style).length) c.style = null;
    });
    S.bus.emit('cues:structure', { reason: 'pos-all' });
    return own.length;
  };

  /** Use line `idx`'s position (its own, else the main one) as the main position for ALL lines. One undo step. */
  S.subtitle.applyCuePositionToAll = function (idx) {
    const c = sub().cues[idx];
    if (!c) return false;
    const st = S.state.project.style, eff = S.subtitle.effectiveStyle(c, st);
    if (S.history) S.history.record('pos-all', { style: true });
    st.pos = eff.pos; if (eff.pos === 'custom') st.posY = eff.posY == null ? 0.62 : eff.posY;
    S.subtitle.clearCuePositions(false);
    S.bus.emit('style:changed');
    S.bus.emit('cues:structure', { reason: 'pos-all' });
    return true;
  };

  /**
   * Index of the cue showing at time t, or -1.
   * Cues may overlap (free timeline editing, like CapCut's separate text lanes). The caption layer shows ONE line at a time,
   * so when several are on at t the one that STARTED last wins (the newer line replaces the older one); a tie goes to the
   * later cue in the list. Preview, export and the timeline all go through here, so they always agree.
   */
  S.subtitle.indexAt = function (cues, t) {
    let best = -1;
    for (let i = 0; i < cues.length; i++) {
      const c = cues[i];
      if (t >= c.start && t < c.end && (best < 0 || c.start >= cues[best].start)) best = i;
    }
    return best;
  };

  /** Stable sort of the cue list by start time (in place). Returns true when the order changed. */
  S.subtitle.sortCues = function (cues) {
    const arr = cues || sub().cues;
    const sorted = arr.map((c, i) => ({ c: c, i: i })).sort((a, b) => (a.c.start - b.c.start) || (a.i - b.i));
    let changed = false;
    sorted.forEach((x, i) => { if (arr[i] !== x.c) changed = true; arr[i] = x.c; });
    return changed;
  };

  /**
   * Which timeline lane (row) each cue sits on. Returns { lanes: number[] (parallel to cues), count }.
   *   - cue.lane (a number) is the lane the user dropped the block on; those cues are placed first and keep it.
   *   - every other cue alternates 0,1,0,1 in time order (the two-row look of CapCut text tracks) and moves to the next
   *     free lane only when it would overlap another block in that lane.
   * A cue that still collides (two pinned blocks dragged on top of each other) is bumped to the first free lane.
   */
  S.subtitle.layoutLanes = function (cues) {
    const n = cues.length, lanes = new Array(n).fill(-1), perLane = [];
    const order = cues.map((c, i) => i).sort((a, b) => (cues[a].start - cues[b].start) || (a - b));
    const free = (lane, c) => !(perLane[lane] || []).some(o => c.start < o.end - 0.0005 && o.start < c.end - 0.0005);
    const put = (i, lane) => { lanes[i] = lane; (perLane[lane] = perLane[lane] || []).push(cues[i]); };
    const firstFree = (i, from) => { let l = from; while (!free(l, cues[i])) l++; return l; };
    order.forEach(i => {
      const L = cues[i].lane;
      if (typeof L === 'number' && L >= 0) put(i, free(L, cues[i]) ? L : firstFree(i, 0));
    });
    let k = 0;
    order.forEach(i => {
      const L = cues[i].lane, pref = k++ % 2;
      if (typeof L === 'number' && L >= 0) return;
      put(i, free(pref, cues[i]) ? pref : firstFree(i, 0));
    });
    return { lanes: lanes, count: perLane.length };
  };

  S.subtitle.removeCue = function (i) {
    if (!sub().cues[i]) return;
    mutate('delete', () => {
      sub().cues.splice(i, 1);
      if (S.state.ui.activeCue === i) S.state.ui.activeCue = -1;
      S.bus.emit('cues:structure', { reason: 'delete', index: i });
    });
  };

  /** Timing limits of a cue: only the clip itself. Cues may overlap and be dragged past each other (they go on separate lanes). */
  function bounds(idx) {
    const c = sub().cues[idx], media = S.state.project.media;
    return { lo: 0, hi: media.duration || Infinity, c: c };
  }

  /** Re-time words proportionally after a cue's span changed. */
  function rescaleWords(c, origStart, origEnd) {
    const olen = origEnd - origStart, nlen = c.end - c.start;
    if (olen <= 0.0001) return;
    const k = nlen / olen;
    c.words.forEach(w => {
      w.start = c.start + (w.start - origStart) * k;
      w.end = c.start + (w.end - origStart) * k;
    });
  }

  /**
   * Set a cue's start/end (seconds). Clamped to the clip only (overlap is allowed), minimum length 0.1s.
   * The list is kept in start-time order afterwards. Words are rescaled so karaoke stays in sync.
   * opts.history === false skips the undo record (drag records once per gesture).
   */
  S.subtitle.setCueTiming = function (idx, start, end, opts) {
    const b = bounds(idx); if (!b.c) return;
    const run = () => {
      const c = b.c, origStart = c.start, origEnd = c.end;
      let ns = Math.max(b.lo, Math.min(start, end - 0.1));
      let ne = Math.min(b.hi, Math.max(end, ns + 0.1));
      ns = Math.max(b.lo, Math.min(ns, ne - 0.1));
      c.start = ns; c.end = ne;
      rescaleWords(c, origStart, origEnd);
      if (S.subtitle.sortCues()) S.bus.emit('cues:structure', { reason: 'timing-sort' });
      else S.bus.emit('cue:timing', { idx: idx });
    };
    if (opts && opts.history === false) run();
    else mutate('timing', run);
  };

  /** Add a new empty cue at time t (default: playhead). It may overlap an existing line: it just goes on another lane. */
  S.subtitle.addCue = function (t) {
    const cues = sub().cues, media = S.state.project.media;
    const dur = media.duration || 0;
    if (!dur) return -1;
    t = (typeof t === 'number' && isFinite(t)) ? t : 0;
    let start = Math.min(Math.max(0, t), dur - 0.1);
    if (dur - start < 0.1) return -1;                      // the very end of the clip
    const next = cues.filter(c => c.start > start + 0.001).sort((a, b) => a.start - b.start)[0];
    let end = Math.min(start + 2, dur);
    if (next && next.start - start >= 0.3) end = Math.min(end, next.start);   // fit the gap when there is one, else overlap
    const idx = next ? cues.indexOf(next) : cues.length;
    mutate('add', () => {
      const cue = S.subtitle.decorateCue({ id: S.subtitle.newCueId(), start: start, end: end, text: '', words: [], style: null });
      cues.splice(idx, 0, cue);
      S.bus.emit('cues:structure', { reason: 'add', index: idx });
      S.bus.emit('cue:active', { idx: idx });
    });
    return idx;
  };

  /** Copy a cue. Placed right after the original when there is room, else on top of it. */
  S.subtitle.duplicateCue = function (idx) {
    const cues = sub().cues, src = cues[idx];
    if (!src) return -1;
    let at = idx + 1;
    mutate('duplicate', () => {
      const copy = S.subtitle.decorateCue({
        id: S.subtitle.newCueId(),
        start: src.start, end: src.end, text: src.text,
        words: JSON.parse(JSON.stringify(src.words)),
        style: src.style ? JSON.parse(JSON.stringify(src.style)) : null
      });
      const next = cues[idx + 1], media = S.state.project.media, len = src.end - src.start;
      if (next && next.start - src.end >= len) { copy.start = src.end; copy.end = src.end + len; }
      else if (!next && media.duration && src.end + len <= media.duration) { copy.start = src.end; copy.end = src.end + len; }
      const shift = copy.start - src.start;
      if (shift) copy.words.forEach(w => { w.start += shift; w.end += shift; });
      cues.splice(at, 0, copy);
      S.bus.emit('cues:structure', { reason: 'duplicate', index: at });
      S.bus.emit('cue:active', { idx: at });
    });
    return at;
  };

  /**
   * Split cue idx into two at time cut (default: midpoint, or the playhead when it
   * falls inside the cue). Words are partitioned by their timing so both halves
   * keep karaoke sync. Returns the index of the second half.
   */
  S.subtitle.splitCue = function (idx, cut) {
    const cues = sub().cues, c = cues[idx];
    if (!c) return -1;
    const MINL = 0.1;                                                  // shortest line either half may have
    if (c.end - c.start < MINL * 2) return -1;
    // a playhead INSIDE the line is honoured exactly (nudged in only if it is closer than MINL to an edge); only a missing /
    // outside playhead falls back to the middle. (It used to jump to the middle whenever the cut was within 0.05 s of an edge.)
    if (!(cut > c.start && cut < c.end)) cut = c.start + (c.end - c.start) / 2;
    cut = Math.min(c.end - MINL, Math.max(c.start + MINL, cut));
    mutate('split', () => {
      // each word goes to the side where MOST of it is spoken (its midpoint), not the side where it merely starts
      let w1 = [], w2 = [];
      c.words.forEach(w => { ((w.start + w.end) / 2 < cut ? w1 : w2).push(w); });
      if (c.words.length >= 2) {                                       // never leave one half without text
        if (!w1.length) w1.push(w2.shift());
        else if (!w2.length) w2.unshift(w1.pop());
      }
      // a word that straddles the cut is kept whole on one side, so its times are pulled inside that line (karaoke / export stay in step)
      const fit = (ws, a, b) => ws.forEach(w => { w.start = Math.min(b, Math.max(a, w.start)); w.end = Math.min(b, Math.max(w.start, w.end)); });
      fit(w1, c.start, cut); fit(w2, cut, c.end);
      const left = S.subtitle.decorateCue({ id: S.subtitle.newCueId(), start: c.start, end: cut, text: S.subtitle.joinWords(w1), words: w1, style: c.style });
      const right = S.subtitle.decorateCue({ id: S.subtitle.newCueId(), start: cut, end: c.end, text: S.subtitle.joinWords(w2), words: w2, style: c.style ? JSON.parse(JSON.stringify(c.style)) : null });
      if (typeof c.lane === 'number') { left.lane = c.lane; right.lane = c.lane; }     // both halves stay on the row the line was on
      cues.splice(idx, 1, left, right);
      S.bus.emit('cues:structure', { reason: 'split', index: idx });
      S.bus.emit('cue:active', { idx: idx });
    });
    return idx + 1;
  };

  /** Merge cue idx with the next cue. Text and words are concatenated. */
  S.subtitle.mergeCueWithNext = function (idx) {
    const cues = sub().cues, a = cues[idx], b = cues[idx + 1];
    if (!a || !b) return -1;
    mutate('merge', () => {
      a.end = Math.max(a.end, b.end);                     // lines may overlap: the merged line must not shrink
      a.words = a.words.concat(b.words);
      const at = (a.text || '').replace(/\s+$/, ''), bt = (b.text || '').replace(/^\s+/, '');
      a.text = at && bt ? at + (b.words[0] && b.words[0].nl ? '\n' : ' ') + bt : (at || bt);   // an Enter that sat at the join stays an Enter
      cues.splice(idx + 1, 1);
      if (S.state.ui.activeCue === idx + 1) S.state.ui.activeCue = idx;
      S.bus.emit('cues:structure', { reason: 'merge', index: idx });
      S.bus.emit('cue:active', { idx: idx });
    });
    return idx;
  };
})(window.SubEd);
