/* =====================================================================
 * UI: "ปรับขนาดเฉพาะบางประโยค" (สไตล์ sheet -> ข้อความ, under the global size slider).
 * Lists every line; tap lines to choose them, then the slider resizes ONLY the chosen ones. The value is stored in
 * each chosen cue's own override (cue.style.scale = a multiplier of the global size, see SubEd.subtitle.effectiveStyle),
 * the same key the corner handle on the preview writes, so preview and burned-in export already agree.
 * Lines that are not chosen keep following the global size (and move with it).
 * Listens: cue:style, cues:structure, cue:text. Calls: S.subtitle.setCueLook(), S.history.record().
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, P = S.state.project;
  const picked = new Set();                         // cue ids chosen in the list
  let rec = false;                                  // one slider drag = ONE undo step
  let open = false;

  const fmt = t => { t = Math.max(0, t || 0); const m = Math.floor(t / 60), s = t - m * 60; return m + ':' + (s < 10 ? '0' : '') + s.toFixed(1); };
  const scaleOf = c => (c.style && c.style.scale) || 1;
  const pct = k => Math.round(k * 1000) / 10;                       // multiplier -> % with one decimal (0.971 -> 97.1)
  const f1 = v => S.ui.precise.f1(v);
  const fpct = k => { const v = pct(k); return (Math.abs(v - Math.round(v)) < 0.05 ? String(Math.round(v)) : f1(v)) + '%'; };   // 100% / 97.1%
  const chosen = () => { const out = []; P.subtitle.cues.forEach((c, i) => { if (picked.has(c.id)) out.push(i); }); return out; };

  function prune() { const ids = new Set(P.subtitle.cues.map(c => c.id)); picked.forEach(id => { if (!ids.has(id)) picked.delete(id); }); }

  function renderList() {
    const list = $('csList'), cues = P.subtitle.cues;
    list.innerHTML = '';
    if (!cues.length) { const e = document.createElement('div'); e.className = 'cs-empty'; e.textContent = 'ยังไม่มีประโยค — สร้างซับก่อน'; list.appendChild(e); return; }
    cues.forEach((c, i) => {
      const row = document.createElement('button'); row.type = 'button'; row.className = 'cs-item' + (picked.has(c.id) ? ' on' : ''); row.dataset.id = c.id;
      const box = document.createElement('i'); box.className = 'cs-box';
      const tm = document.createElement('span'); tm.className = 'cs-time'; tm.textContent = fmt(c.start);
      const tx = document.createElement('span'); tx.className = 'cs-text'; tx.textContent = c.text || (c.words || []).map(w => w.word).join('') || '(ว่าง)';
      row.append(box, tm, tx);
      const k = scaleOf(c);
      if (Math.abs(k - 1) > 0.0005) { const b = document.createElement('b'); b.className = 'cs-badge'; b.textContent = fpct(k); row.appendChild(b); }
      list.appendChild(row);
    });
  }

  function syncControls() {
    const idxs = chosen(), cues = P.subtitle.cues;
    $('csCount').textContent = idxs.length ? 'เลือก ' + idxs.length + ' ประโยค' : 'ยังไม่ได้เลือก';
    $('csSizeRow').classList.toggle('off', !idxs.length);
    $('csReset').disabled = !idxs.some(i => cues[i].style && cues[i].style.scale);
    const k = idxs.length ? pct(scaleOf(cues[idxs[0]])) : 100;
    $('csScale').value = k; $('csScaleNum').textContent = f1(k);
    const mixed = idxs.length > 1 && idxs.some(i => Math.abs(pct(scaleOf(cues[i])) - k) > 0.05);
    $('csMixed').hidden = !mixed;
  }

  function refresh() { if (!open) return; prune(); renderList(); syncControls(); }

  function setScale(idxs, k, record) {
    if (!idxs.length) return;
    if (record && S.history) S.history.record('style');
    idxs.forEach(i => S.subtitle.setCueLook(i, { scale: Math.abs(k - 1) < 0.0005 ? null : +k.toFixed(4) }, { history: false }));
  }

  S.ui.cueSize = {
    init() {
      const toggle = $('csToggle'), pop = $('csPop'), video = S.dom.video;
      toggle.addEventListener('click', () => {
        open = !open; pop.hidden = !open; toggle.setAttribute('aria-pressed', open ? 'true' : 'false');
        if (open) { const a = P.subtitle.cues[S.state.ui.activeCue]; if (a && !picked.size) picked.add(a.id); }   // the line on screen starts chosen
        refresh();
      });
      $('csList').addEventListener('click', e => {
        const it = e.target.closest('.cs-item'); if (!it) return;
        const id = it.dataset.id, i = P.subtitle.cues.findIndex(c => c.id === id); if (i < 0) return;
        if (picked.has(id)) picked.delete(id); else picked.add(id);
        const c = P.subtitle.cues[i];
        if (picked.has(id) && video) { video.currentTime = c.start + 0.01; bus.emit('time:changed', video.currentTime); }   // show the line you just chose
        rec = false; renderList(); syncControls();
      });
      $('csAll').addEventListener('click', () => { P.subtitle.cues.forEach(c => picked.add(c.id)); rec = false; renderList(); syncControls(); });
      $('csNone').addEventListener('click', () => { picked.clear(); rec = false; renderList(); syncControls(); });
      $('csScale').addEventListener('input', () => {
        const k = Math.round(parseFloat($('csScale').value) * 10) / 1000, first = !rec; rec = true;   // 97.1 -> 0.971
        $('csScaleNum').textContent = f1(k * 100);
        setScale(chosen(), k, first);
      });
      $('csScale').addEventListener('change', () => { rec = false; });
      $('csReset').addEventListener('click', () => { rec = false; setScale(chosen().filter(i => P.subtitle.cues[i].style && P.subtitle.cues[i].style.scale), 1, true); });
      ['cue:style', 'cues:structure', 'cue:text'].forEach(ev => bus.on(ev, refresh));
    }
  };
})(window.SubEd);
