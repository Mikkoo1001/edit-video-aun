/* =====================================================================
 * UI: "ส่งออก" tab — CapCut-style settings (resolution / frame-rate / bitrate sliders + estimated size),
 * a full-screen progress page (back arrow -> "quit exporting?" dialog, cancel button), result preview + download. All rendering work is delegated to
 * SubEd.exporters (see export/exporters.js); this file only drives the panel.
 * Listens: trim:changed.
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, fmt = S.util.fmt, P = S.state.project;
  const video = S.dom.video, videoBox = S.dom.videoBox;
  let handle = null, lastUrl = null, wakeLock = null;
  let rangeOverride = null;                    // one-shot: export just this source-time range (a single scene), whatever the range chips say

  // ---- export settings (sliders) ----
  const RES = ['480p', '720p', '1080p', '2k'], RES_LABEL = ['480p', '720p', '1080p', '2K'];
  const RES_NOTE = ['ประหยัดพื้นที่ · ไฟล์เล็ก', 'ชัดพอสำหรับโซเชียล', 'ความละเอียดสูง · ใช้กันทั่วไป', 'คมชัดมาก · ไฟล์ใหญ่ · เครื่องช้าอาจนาน'];
  const FPS = [24, 25, 30, 50, 60];
  let brTouched = false;                       // false: the bitrate follows the recommended value for the chosen resolution / fps
  const resKey = () => RES[+$('xpRes').value] || '1080p';
  const fpsVal = () => FPS[+$('xpFps').value] || 30;
  function recommendedMbps() {
    const base = (S.render.presets[resKey()] || S.render.presets['1080p']).bitrate / 1e6;
    return Math.max(2, Math.min(100, Math.round(base * (fpsVal() > 30 ? 1.25 : 1))));
  }
  const bitrateBps = () => Math.round(+$('xpBr').value * 1e6);
  /** Position the slider fill (the track is painted with a gradient so the part before the thumb is coloured, like CapCut). */
  function paintRange(el) {
    const mn = +el.min, mx = +el.max, pct = mx > mn ? (+el.value - mn) / (mx - mn) * 100 : 0;
    el.style.setProperty('--p', pct + '%');
  }
  function refreshSettings() {
    if (!brTouched) $('xpBr').value = recommendedMbps();
    ['xpRes', 'xpFps', 'xpBr'].forEach(id => paintRange($(id)));
    $('xpResNote').textContent = RES_LABEL[+$('xpRes').value] + ' · ' + RES_NOTE[+$('xpRes').value];
    $('xpFpsNote').textContent = fpsVal() + ' fps' + (fpsVal() > 30 ? ' · ภาพลื่นขึ้น' : fpsVal() < 30 ? ' · ภาพแบบภาพยนตร์' : ' · มาตรฐาน');
    const rec = recommendedMbps(), br = +$('xpBr').value;
    $('xpBrVal').textContent = br + ' Mbps';
    $('xpBrNote').textContent = br === rec ? 'แนะนำสำหรับค่านี้ (' + rec + ')' : br > rec ? 'ภาพคมขึ้น · ไฟล์ใหญ่ขึ้น (' + br + ')' : 'ไฟล์เล็กลง · ภาพอาจแตก (' + br + ')';
    $('xpBrReset').hidden = brTouched === false || br === rec;
    updateEstimate();
  }
  /** Estimated file size = (video bitrate + audio) x length of what will be exported. */
  function updateEstimate() {
    const el = $('xpEst');
    if (!el) return;
    const r = chosenRange();
    const kept = S.videoCut ? S.videoCut.keptLength(r.start, r.end) : r.end - r.start;
    if (!(kept > 0)) { el.textContent = 'ขนาดไฟล์โดยประมาณ: –'; return; }
    const mb = kept * (bitrateBps() + 192000) / 8 / 1048576;
    el.textContent = 'ขนาดไฟล์โดยประมาณ: ' + (mb >= 1024 ? (mb / 1024).toFixed(2) + ' GB' : mb.toFixed(mb < 10 ? 1 : 0) + ' MB');
  }

  // ---- full-screen progress page ----
  let thumbUrl = '';
  function grabThumb() {
    try {
      const w = video.videoWidth, h = video.videoHeight;
      if (!w || !h) return '';
      const c = document.createElement('canvas'), k = Math.min(1, 360 / Math.max(w, h));
      c.width = Math.max(2, Math.round(w * k)); c.height = Math.max(2, Math.round(h * k));
      c.getContext('2d').drawImage(video, 0, 0, c.width, c.height);
      return c.toDataURL('image/jpeg', 0.7);
    } catch (e) { return ''; }
  }
  function overlayOpen(label) {
    const xo = $('xo');
    xo.hidden = false; xo.classList.remove('done'); $('xoDlg').hidden = true;
    $('xoTitle').textContent = 'กำลังส่งออกที่ ' + label + '…';
    $('xoSub').textContent = 'อาจใช้เวลาสักครู่ ระบบจะบันทึกวิดีโอให้อัตโนมัติเมื่อเสร็จ';
    $('xoPct').textContent = '0%'; $('xoBar').style.width = '0%'; $('xoStatus').textContent = '';
    $('xoResult').hidden = true; $('xoCancel').hidden = false; $('xoClose').hidden = true;
    const img = $('xoImg'); thumbUrl = grabThumb(); img.src = thumbUrl; img.style.display = thumbUrl ? '' : 'none';
    $('xoThumb').hidden = false; $('xoBack').hidden = false;
    document.body.classList.add('exporting');
  }
  function overlayClose() { $('xo').hidden = true; $('xoDlg').hidden = true; document.body.classList.remove('exporting'); }
  function askQuit(on) { if (handle || !on) $('xoDlg').hidden = !on; else overlayClose(); }
  function setProgress(pct) {
    const v = Math.max(0, Math.min(100, pct || 0));
    $('xoPct').textContent = (v < 10 ? v.toFixed(1) : Math.round(v)) + '%';
    $('xoBar').style.width = v + '%';
  }

  // keep the screen on while a long render runs (a phone that sleeps pauses the tab and the export dies)
  async function holdScreen() {
    try { if (navigator.wakeLock && navigator.wakeLock.request) wakeLock = await navigator.wakeLock.request('screen'); } catch (e) { wakeLock = null; }
  }
  function releaseScreen() { try { if (wakeLock) wakeLock.release(); } catch (e) {} wakeLock = null; }
  document.addEventListener('visibilitychange', () => { if (handle && document.visibilityState === 'visible' && !wakeLock) holdScreen(); });

  /** The source-time range to render: the whole clip, or just what is between the trim handles. */
  function chosenRange() {
    if (rangeOverride) return rangeOverride;
    const full = selectedChip('[data-range]').dataset.range === 'full';
    return full ? { start: 0, end: P.media.duration } : { start: P.trim.start, end: P.trim.end };
  }
  function updateDurHint() {
    const hint = $('expDurHint');
    if (!hint) return;
    const r = chosenRange();
    const kept = S.videoCut ? S.videoCut.keptLength(r.start, r.end) : r.end - r.start;
    hint.textContent = fmt(Math.max(0, kept)) + ' (' + fmt(r.start) + '–' + fmt(r.end) + ')' + (r.end - r.start - kept > 0.05 ? ' · ไม่รวมช่วงที่ลบ ' + fmt(r.end - r.start - kept) : '');   // the exact cut that will be rendered
    updateCueHint();
    updateEstimate();
  }

  /** One line under the range chips: which sentences the exported video / .SRT will contain, so a mismatch is visible BEFORE rendering. */
  function updateCueHint() {
    const el = $('expCueHint');
    if (!el) return;
    if (!P.media.duration) { el.textContent = ''; return; }
    const r = chosenRange(), list = S.subtitle.exportCues(P, r);
    if (!list.length) { el.textContent = 'ช่วง ' + fmt(r.start) + '–' + fmt(r.end) + ' · ไม่มีซับในช่วงนี้'; return; }
    const clip = t => { t = (t || '').trim(); return t.length > 16 ? t.slice(0, 16) + '…' : t; };
    el.textContent = 'ช่วง ' + fmt(r.start) + '–' + fmt(r.end) + ' · ซับ ' + list.length + ' ประโยค · แรก “' + clip(list[0].text) + '” · ท้าย “' + clip(list[list.length - 1].text) + '”';
  }

  function setExportStatus(msg, kind) {
    const el = $('exportStatus');
    el.textContent = msg || '';
    el.className = 'status' + (kind ? ' ' + kind : '');
  }
  function setBusy(busy) { $('exportBtn').disabled = !!busy; $('exportBtn').textContent = busy ? 'กำลังส่งออก…' : 'ส่งออก'; }
  function selectedChip(sel) { return document.querySelector(sel + '.active') || document.querySelector(sel); }

  function startExport() {
    if (S.ui.media && S.ui.media.copying()) {                  // the safety copy of the clip is still being made: export reads the copy
      setExportStatus('รอเก็บสำเนาคลิปให้เสร็จก่อนสักครู่...', '');
      S.ui.media.settled().then(startExport);
      return;
    }
    const range = chosenRange(); rangeOverride = null;       // read once: the override applies to this run only
    if (!P.media.file) { setExportStatus('กรุณาวางคลิปวิดีโอก่อน', 'err'); return; }
    if (!P.media.duration) { setExportStatus('ยังโหลดวิดีโอไม่เสร็จ', 'err'); return; }
    const arranged = !!(S.arrange && S.arrange.active());
    if (arranged && !S.arrange.ready()) { setExportStatus('เปิดจัดฉากไว้ แต่ยังไม่มีฉากที่ใส่คลิปภาพ — เพิ่มคลิปแล้วกด “จัดคลิปลงฉาก” หรือปิดจัดฉาก', 'err'); return; }
    if (!arranged && !video.videoWidth) { setExportStatus('ไฟล์นี้ไม่มีภาพ (ไฟล์เสียง) — เปิด “จัดฉาก” แล้วเพิ่มคลิปภาพก่อนส่งออก', 'err'); return; }
    const exporter = S.exporters.get(arranged ? 'arrange' : S.exporters.defaultId);
    holdScreen();
    const resLabel = RES_LABEL[+$('xpRes').value] || '1080p';
    overlayOpen(resLabel + ' · ' + fpsVal() + ' fps');
    handle = exporter.start({
      video: video,
      project: P,
      preset: resKey(),
      fps: fpsVal(),
      bitrate: bitrateBps(),
      range: range,
      format: selectedChip('[data-fmt]').dataset.fmt,
      previewWidth: (S.ui.preview.refWidth && S.ui.preview.refWidth()) || S.ui.preview.contentRect().w || videoBox.clientWidth,   // the MAIN-screen picture width, not the (shrunk) preview behind the export sheet
      onAttempt() {
        setBusy(true);
        $('xoResult').hidden = true;
        setProgress(0);
      },
      onStatus(msg, kind) { setExportStatus(msg, kind); $('xoStatus').textContent = msg || ''; $('xoStatus').classList.toggle('err', kind === 'err'); },
      onProgress: setProgress
    });
    handle.done.then(out => {
      handle = null;
      releaseScreen();
      setBusy(false);
      if (out.cancelled) {
        setExportStatus('ยกเลิกการส่งออกแล้ว', '');
        overlayClose();
      } else if (out.error) {
        setExportStatus(out.error, 'err');
        $('xo').classList.add('done');
        $('xoTitle').textContent = 'ส่งออกไม่สำเร็จ';
        $('xoSub').textContent = out.error;
        $('xoThumb').hidden = true; $('xoCancel').hidden = true; $('xoClose').hidden = false; $('xoStatus').textContent = '';
      } else {
        if (lastUrl) URL.revokeObjectURL(lastUrl);
        const url = lastUrl = URL.createObjectURL(out.blob);
        $('exportPreview').src = url;
        $('exportDownload').onclick = () => {
          const a = document.createElement('a');
          a.href = url; a.download = 'yaowarat-lingo-' + Date.now() + '.' + out.ext;
          document.body.appendChild(a); a.click(); document.body.removeChild(a);
        };
        const info = (out.blob.size / 1024 / 1024).toFixed(1) + ' MB • .' + out.ext + (out.frames ? ' • ' + out.frames + ' เฟรม' : '') + (out.note ? ' • ' + out.note : '');
        setExportStatus('ส่งออกสำเร็จ (' + info + ')', 'ok');
        $('xo').classList.add('done');
        $('xoTitle').textContent = 'ส่งออกสำเร็จ';
        $('xoSub').textContent = info;
        $('xoThumb').hidden = true; $('xoStatus').textContent = '';
        $('xoResult').hidden = false; $('xoCancel').hidden = true; $('xoClose').hidden = false; $('xoDlg').hidden = true;
        $('xoBar').style.width = '100%';
        keepInHistory(out, range);
      }
    });
  }

  /** Keep the finished video in "ประวัติการตัด" (never blocks or fails the export itself). */
  function keepInHistory(out, range) {
    if (!S.clipHistory || !out || !out.blob) return;
    const src = (P.media.file && P.media.file.name || 'วิดีโอ').replace(/\.[^.]+$/, '');
    const kept = S.videoCut ? S.videoCut.keptLength(range.start, range.end) : range.end - range.start;
    S.clipHistory.add(out.blob, { name: src + ' (ตัดแล้ว).' + out.ext, ext: out.ext, duration: kept, source: P.media.file && P.media.file.name || '' })
      .then(e => { if (e && S.ui.toast) S.ui.toast('บันทึกลงประวัติการตัดแล้ว — เปิดดูได้ที่หน้าเลือกคลิป', 3200); },
        err => { console.warn('[history]', err); if (S.ui.toast) S.ui.toast(err && err.code === 'full' ? 'พื้นที่เก็บในเบราว์เซอร์เต็ม — ไม่ได้บันทึกลงประวัติ (ไฟล์ที่ส่งออกยังดาวน์โหลดได้) ลบรายการเก่าเองแล้วลองใหม่' : 'บันทึกลงประวัติการตัดไม่สำเร็จ', 6000); });
  }

  S.ui.exportPanel = {
    range: chosenRange,                      // the source-time range the chips are on (the .SRT / .VTT download uses it too)
    /** Render only [start, end] (e.g. one scene of the main video) and offer it for download; the range chips are left as they were. */
    exportRange(r) {
      if (!r || !(r.end > r.start)) return false;
      S.ui.tabs.open('export');
      if (handle) { setExportStatus('กำลังส่งออกอยู่ — รอให้เสร็จหรือกดยกเลิกก่อน', 'err'); return false; }
      rangeOverride = { start: r.start, end: Math.min(r.end, P.media.duration || r.end) };
      startExport();
      return true;
    },
    init() {
      ['[data-range]', '[data-fmt]'].forEach(sel => {
        document.querySelectorAll(sel).forEach(chip => {
          chip.addEventListener('click', () => {
            document.querySelectorAll(sel).forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            updateDurHint();
          });
        });
      });
      $('xpRes').addEventListener('input', refreshSettings);
      $('xpFps').addEventListener('input', refreshSettings);
      $('xpBr').addEventListener('input', () => { brTouched = true; refreshSettings(); });
      $('xpBrReset').addEventListener('click', () => { brTouched = false; refreshSettings(); });
      refreshSettings();
      $('exportBtn').addEventListener('click', () => { if (!handle) startExport(); });
      // progress page: back arrow asks first, the red button cancels right away, "keep going" just closes the dialog
      $('xoBack').addEventListener('click', () => { if (handle) askQuit(true); else overlayClose(); });
      $('xoCancel').addEventListener('click', () => askQuit(true));
      $('xoKeep').addEventListener('click', () => askQuit(false));
      $('xoQuit').addEventListener('click', () => { if (handle) handle.cancel(); $('xoDlg').hidden = true; $('xoQuit').disabled = true; setTimeout(() => { $('xoQuit').disabled = false; }, 600); });
      $('xoClose').addEventListener('click', overlayClose);
      document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('xo').hidden) { if (handle) askQuit($('xoDlg').hidden); else overlayClose(); } });
      // moving a trim handle means "export what I cut": switch the range chip for the user (they can switch back)
      bus.on('cut:structure', () => updateDurHint());
      bus.on('cut:timing', () => updateDurHint());
      bus.on('trim:changed', () => {
        const trimmed = P.media.duration && (P.trim.start > 0.05 || P.trim.end < P.media.duration - 0.05);
        const want = document.querySelector('[data-range="' + (trimmed ? 'trim' : 'full') + '"]');
        if (want && !want.classList.contains('active')) {
          document.querySelectorAll('[data-range]').forEach(c => c.classList.remove('active'));
          want.classList.add('active');
        }
        updateDurHint();
      });
      bus.on('media:metadata', updateDurHint);
      bus.on('sheet:toggle', e => { if (e && e.open && e.tab === 'export') { updateDurHint(); refreshSettings(); } });
      ['cues:structure', 'cue:timing', 'cue:text'].forEach(e => bus.on(e, updateCueHint));
    }
  };
})(window.SubEd);
