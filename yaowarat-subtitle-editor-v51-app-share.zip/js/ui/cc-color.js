/* CapCut-style colour row (eyedropper + colour wheel + swatches) for every สไตล์ sub-tab,
 * select-words-then-tap-colour (text AND glow tabs; a coloured word also glows in that colour). The words come from the shared
 * selection in ui/word-sel.js: press-and-hold + drag in the text bar here, in the line's text box inside the tabs, or on the picture.
 * Also the ฟอนต์ / สไตล์ / แอนิเมชัน tab row and a working ⤢ expand. */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, P = S.state.project, state = S.state;
  const TARGET = { text: 'colorPick', stroke: 'outlineColor', glow: 'glowColor', bg: 'bgColor', shadow: 'shadowColor' };
  const PAL = S.ui.palette.PAL;                        // the CapCut colour row (ui/palette.js): the same palette is used for single words
  let sub = 'text';

  function fire(el, final) { el.dispatchEvent(new Event('input', { bubbles: true })); if (final !== false) el.dispatchEvent(new Event('change', { bubbles: true })); }

  /** words of the active cue that are selected (null = none) */
  function selectedWords() { const w = S.ui.wordSel.words(); return w.length ? w : null; }

  /** One tap = text colour AND glow colour (CapCut style). `first` = record an undo step (false while a colour wheel is dragged). */
  function pick(color, first, drag) {
    if (first == null) first = true;
    const hit = (sub === 'text' || sub === 'glow') ? selectedWords() : null;
    if (hit) {                                              // words are selected -> only those words change
      if (sub === 'glow') S.ui.wordSel.glow({ on: true, color: color, follow: false }, first);
      else S.ui.wordSel.color(color, first);                // text colour + a glow in the same colour
      paintSel();
      return;
    }
    if (sub === 'text') {                                   // whole line: the text colour and its glow move together
      $('glowChk').checked = true; $('glowFollow').checked = true;
      if (!(parseFloat($('glowInt').value) > 0)) { $('glowInt').value = 30; $('glowIntNum').textContent = '30'; }
    }
    const el = $(TARGET[sub]); if (el) { el.value = color; fire(el, !drag); }
    paintSel();
  }

  /** the swatch that matches the current colour gets the white ring (like CapCut) */
  function currentColor() {
    const c = P.subtitle.cues[state.ui.activeCue];
    if (sub === 'text' && c) { const hit = selectedWords(); if (hit && c.words[hit[0]]) return c.words[hit[0]].color || S.subtitle.effectiveStyle(c, P.style).color; }
    if (sub === 'glow' && c) { const hit = selectedWords(); if (hit && c.words[hit[0]] && c.words[hit[0]].glow && c.words[hit[0]].glow.color) return c.words[hit[0]].glow.color; }
    const el = $(TARGET[sub]); return el ? el.value : '';
  }
  function paintSel() {
    const cur = String(currentColor() || '').toLowerCase();
    document.querySelectorAll('#ccColorRow .tx-sw').forEach(b => b.classList.toggle('on', b.title.toLowerCase() === cur));
  }

  function buildRow() {
    const old = $('swatches'), row = document.createElement('div'); row.id = 'ccColorRow'; row.className = 'cc-colors';
    const eye = document.createElement('button'); eye.type = 'button'; eye.className = 'cc-eye'; eye.title = 'ดูดสี';
    eye.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m14 7 3 3M4 20l1-4 9-9a2 2 0 0 1 3 0l1 1a2 2 0 0 1 0 3l-9 9-4 1zM16 5l3 3"/></svg>';
    if (!window.EyeDropper) eye.style.opacity = '.35';
    eye.addEventListener('click', () => { if (window.EyeDropper) new window.EyeDropper().open().then(r => pick(r.sRGBHex, true)).catch(() => {}); });
    const wheel = document.createElement('label'); wheel.className = 'cc-wheel'; wheel.title = 'เลือกสีเอง';
    const inp = document.createElement('input'); inp.type = 'color'; wheel.appendChild(inp);
    let wRec = false;                                           // dragging the wheel = ONE undo step, and no heavy refresh per move
    inp.addEventListener('input', () => { pick(inp.value, !wRec, true); wRec = true; });
    inp.addEventListener('change', () => { wRec = false; pick(inp.value, false); });
    const list = document.createElement('div'); list.className = 'cc-swlist';
    PAL.forEach(c => {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'tx-sw big'; b.style.background = c; b.title = c;
      b.addEventListener('click', () => pick(c, true)); list.appendChild(b);
    });
    const none = document.createElement('button'); none.type = 'button'; none.className = 'cc-eye cc-none'; none.title = 'ไม่มีเงา';
    none.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="8"/><path d="m6.5 6.5 11 11"/></svg>';
    none.addEventListener('click', () => { const c = $('shadowChk'); c.checked = false; fire(c); });
    row.appendChild(none); row.appendChild(eye); row.appendChild(wheel); row.appendChild(list);
    ['pointerdown', 'mousedown'].forEach(ev => row.addEventListener(ev, e => { if (e.target.closest('button')) e.preventDefault(); }));   // keep the text selection alive
    old.style.display = 'none'; old.parentNode.insertBefore(row, old);
    const hint = document.createElement('p'); hint.className = 'hint cc-selhint'; hint.id = 'ccSelHint';
    hint.textContent = 'แตะสี → เปลี่ยนสีข้อความ + แสงเรืองแสงพร้อมกัน · อยากเปลี่ยนแค่บางคำ: แตะคำจากแถบด้านบน (แตะอีกคำเพื่อเลือกเป็นช่วง) หรือกดค้างที่คำบนพรีวิวแล้วลาก จากนั้นแตะสี (ไม่เลือก = ทั้งประโยค)';
    row.parentNode.insertBefore(hint, row.nextSibling);
    const chipsHost = document.createElement('div'); chipsHost.className = 'cc-chips'; row.parentNode.insertBefore(chipsHost, row);   // the line's words as buttons: tap = select
    S.ui.wordSel.makeChips(chipsHost);
    const show = () => { row.style.display = TARGET[sub] ? '' : 'none'; none.style.display = sub === 'shadow' ? '' : 'none'; hint.style.display = (sub === 'text' || sub === 'glow') ? '' : 'none'; chipsHost.style.display = (sub === 'text' || sub === 'glow') ? '' : 'none'; paintSel(); };
    ['style:changed', 'cue:active', 'cue:style', 'cue:text', 'cues:structure', 'wordsel:changed'].forEach(ev => bus.on(ev, paintSel));
    document.querySelectorAll('#subTabs button').forEach(b => b.addEventListener('click', () => { sub = b.dataset.sub; show(); }));
    show();
  }

  /** สีติด (static colour, no highlight) <-> ไฮไลท์: flips style.karaokeMode between 'off' and the mode that was in use before, so it stays in step with the
   *  แบบสี chips of the copy-style pane. Every word colour stays in the project; only WHEN it shows changes (preview and export read the same mode). */
  function toggleStay() {
    const st = P.style, cp = S.styleCopy;
    if (st.karaokeMode === 'off') {
      const back = st.karaokePrev && st.karaokePrev !== 'off' ? st.karaokePrev : 'custom';
      st.karaokeMode = back;
      if (cp) cp.modeOverride = (back === 'stay' || back === 'stayAll') ? back : null;      // a copied reference follows the switch from now on
    } else {
      st.karaokePrev = st.karaokeMode || 'custom';
      st.karaokeMode = 'off';
      if (cp) cp.modeOverride = 'off';
    }
    st.karaoke = st.karaokeMode !== 'off';
  }

  /** Two switches above the colour row: ไฮไลท์สี (word colours + their glow + the highlight colour) and ข้อความ (the whole caption text).
   *  They only HIDE: every colour / glow stays in the project, so switching back brings everything exactly as it was. Preview and export agree. */
  function buildToggles() {
    const anchor = $('subTabs'), row = document.createElement('div'); row.id = 'ccToggles'; row.className = 'cc-toggles';
    const defs = [['hlOff', 'ไฮไลท์สี', 'เปิด/ปิดสีของคำ (สีข้อความ + แสงที่มากับสี) · ปิด = ทุกคำใช้สีปกติ แต่สีที่ตั้งไว้ยังอยู่ครบ'], ['stay', 'สีติด', 'เปิด = สีติดแบบไม่ไฮไลท์ (คำที่มีสีจะติดสีตลอด ไม่รอตอนพูดถึง) · ปิด = ไฮไลท์ (สีขึ้นตอนพูดถึงคำนั้น) · ใช้แทนโหมดไฮไลท์ทีละคำ'], ['wgOff', 'แสงจากสี', 'เปิด/ปิดแสงที่ขึ้นมาพร้อมสีของคำ (ต้นแบบ CapCut ไม่มีแสง) · ปิด = คำสีไม่เรืองแสง'], ['textOff', 'ข้อความ', 'เปิด/ปิดการแสดงข้อความซับ (พรีวิวและตอนส่งออก) · ปิด = ซ่อนทั้งประโยค แต่ข้อความยังอยู่ครบ']];
    const btns = defs.map(d => {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'cc-tg'; b.dataset.key = d[0]; b.title = d[2]; b.setAttribute('role', 'switch');
      b.innerHTML = '<span class="cc-tg-l">' + d[1] + '</span><span class="cc-tg-s"><i></i></span><span class="cc-tg-v"></span>';
      b.addEventListener('click', () => {
        if (S.history) S.history.record('style', { style: true });      // the switch lives in the global style: keep it in the undo snapshot
        if (d[0] === 'stay') toggleStay(); else P.style[d[0]] = !P.style[d[0]];
        bus.emit('style:changed');
      });
      row.appendChild(b);
      return b;
    });
    const paint = () => btns.forEach(b => {
      const on = b.dataset.key === 'stay' ? P.style.karaokeMode === 'off' : !P.style[b.dataset.key];      // the stored flags say "off"; the switch shows "on" · สีติด is on while the highlight mode is 'off' (static colour)
      b.classList.toggle('on', on); b.setAttribute('aria-checked', on ? 'true' : 'false');
      b.querySelector('.cc-tg-v').textContent = on ? 'เปิด' : 'ปิด';
    });
    anchor.parentNode.insertBefore(row, anchor.nextSibling);
    ['style:changed', 'cue:style'].forEach(ev => bus.on(ev, paint));
    paint();
  }

  /** the editable text bar: press-and-hold + drag over its characters selects words (shared with the picture and the tab text boxes) */
  function trackSelection() {
    const ta = $('teInput'), ws = S.ui.wordSel;
    const save = () => {
      const c = P.subtitle.cues[state.ui.activeCue];
      if (!c || ta.value !== c.text) return;
      ws.setFromChars(ta.selectionStart, ta.selectionEnd, 'teInput');
    };
    ['select', 'keyup', 'pointerup', 'touchend', 'mouseup'].forEach(ev => ta.addEventListener(ev, () => setTimeout(save, 0)));
    document.addEventListener('selectionchange', () => { if (document.activeElement === ta) save(); });
    ta.addEventListener('input', () => { ws.clear('teInput'); });      // typing changes the words: the old selection no longer means anything
  }

  function buildTabs() {
    const pane = document.querySelector('.tab-pane[data-pane="style"]'), te = pane.querySelector('.te-row');
    const bar = $('subTabs');                                   // one tab row: ฟอนต์ | ข้อความ | ... | เงา | แอนิเมชัน | จัดวาง ...
    const grid = document.createElement('div'); grid.id = 'fontGrid'; grid.className = 'font-grid'; bar.parentNode.insertBefore(grid, bar.nextSibling);
    const sel = $('fontSel');
    const addChip = (o, i) => {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'font-chip'; b.dataset.i = i; b.dataset.cat = o.dataset.cat || 'sans';
      b.style.fontFamily = o.value; if (o.dataset.weight) b.style.fontWeight = o.dataset.weight;
      b.innerHTML = '<span>กขค Aa</span><small>' + o.textContent.replace(/\s*\(.*\)/, '') + '</small>';
      b.addEventListener('click', () => { sel.selectedIndex = i; fire(sel); mark(); });
      grid.appendChild(b);
      return b;
    };
    Array.from(sel.options).forEach((o, i) => addChip(o, i));
    const mark = () => grid.querySelectorAll('.font-chip').forEach(b => b.classList.toggle('on', +b.dataset.i === sel.selectedIndex));
    /** a font added while the app runs (uploaded file, Google Fonts name, installed font): one more option + one more tile */
    S.ui.ccColor.addFontOption = (value, label, cat) => {
      const o = document.createElement('option'); o.value = value; o.textContent = label; o.dataset.cat = cat || 'custom';
      o.style.fontFamily = value; sel.appendChild(o);
      const chip = addChip(o, sel.options.length - 1); mark();
      bus.emit('font:chip', chip);
      return o;
    };
    S.ui.ccColor.removeFontOption = value => {
      const idx = Array.from(sel.options).findIndex(o => o.value === value && o.dataset.cat !== 'temp');
      if (idx < 0) return;
      const chip = grid.querySelector('.font-chip[data-i="' + idx + '"]'); if (chip) chip.remove();
      sel.remove(idx);
      grid.querySelectorAll('.font-chip').forEach(b => { if (+b.dataset.i > idx) b.dataset.i = +b.dataset.i - 1; });   // later tiles shift down by one
      mark();
    };
    bus.on('style:changed', mark); mark();
    // the tab decides what the pane shows (css keys off data-st / data-sub): fonts have their own page; the preset row only belongs to ข้อความ
    bar.addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b || !b.dataset.sub) return;
      pane.dataset.st = b.dataset.sub === 'font' ? 'fonts' : 'styles';
      pane.dataset.sub = b.dataset.sub;
    });
    pane.dataset.sub = 'text';
    pane.dataset.st = 'styles';
  }

  function initExpand() {                                    // ⤢ : a tall, comfortable text box for long lines
    const ta = $('teInput'), btn = $('teExpand');
    btn.onclick = null;
    btn.addEventListener('click', () => { const big = !ta.classList.contains('big'); ta.classList.toggle('big', big); ta.rows = big ? 6 : 1; btn.classList.toggle('on', big); });
    const fit = () => { if (!ta.classList.contains('big')) { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 120) + 'px'; } else ta.style.height = ''; };
    ta.addEventListener('input', fit); bus.on('cue:active', () => setTimeout(fit, 0));
  }

  S.ui.ccColor = { selectedWords: selectedWords, init() { buildRow(); buildToggles(); trackSelection(); buildTabs(); initExpand(); } };
})(window.SubEd);
