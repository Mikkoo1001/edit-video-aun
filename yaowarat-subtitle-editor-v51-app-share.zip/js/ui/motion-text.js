/* =====================================================================
 * UI: "โมชันข้อความ" — Motion Graphics text layers (like the second orange text row + Graphs panel in CapCut).
 *
 *   sheet (tool "โมชันข้อความ")
 *     layer chips        every layer is one chip; "+ เพิ่ม" adds a new one at the playhead
 *     เลเยอร์             [อยู่หน้าข้อความ] [อยู่หลังข้อความ]   <- where the layer sits relative to the caption text
 *     ข้อความ / ท่า        the text, ready-made moves (ป๊อป, ซูม, ลอยขึ้น ...)
 *     คีย์เฟรม            ◆ list · add at the playhead · X / Y / ขนาด / หมุน / โปร่งใส of the picked keyframe · Graphs (easing curve)
 *     สไตล์               font, colour, size, outline, shadow, glow
 *     เวลา                start / end (with "use playhead" buttons)
 *   preview              drag the layer with a finger while the sheet is open (moves the picked keyframe)
 *   timeline             an orange bar per layer under the caption track, with ◆ at every keyframe:
 *                        tap = select · drag the body = move in time · drag the white ends = change start / end
 *
 * Drawing: two canvases in the preview — one UNDER the caption canvas (z:'back'), one OVER it (z:'front') — painted by the same
 * S.motionText.draw the exporters call, so the picture you edit is the picture you export.
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, state = S.state, P = state.project, M = P.motion, dom = S.dom, video = dom.video;
  const MT = () => S.motionText;
  let cvBack = null, cvFront = null, ctxB = null, ctxF = null, frameEl = null, hitEl = null;
  let track = null, tlScroll = null, timeline = null, raf = 0, sub = 'anim', built = false;
  const hooks = [];                                   // functions run at the end of renderPane(layer, root): used by ui/motion-lib.js
  const api = {};

  const dur = () => P.media.duration || 0;
  const cur = () => video.currentTime || 0;
  const layers = () => M.layers;
  const selLayer = () => M.layers.find(l => l.id === M.sel) || null;
  const selKf = L => (L && L.kf[Math.min(Math.max(0, M.kfSel | 0), L.kf.length - 1)]) || null;
  const rec = label => { if (S.history) S.history.record(label || 'motion'); };
  const r1 = (v, d) => +(+v).toFixed(d == null ? 3 : d);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const esc = t => String(t == null ? '' : t).replace(/[<>"&]/g, '');
  const toast = (m, ms) => { if (S.ui.toast) S.ui.toast(m, ms || 2200); };

  /* =============================================================== preview canvases */
  function build() {
    if (built) return true;
    const box = dom.videoBox, capCv = box && box.querySelector('.cap-cv');
    if (!box || !dom.capLayer) return false;
    const mk = cls => { const c = document.createElement('canvas'); c.className = 'mg-cv ' + cls; c.style.cssText = 'position:absolute;left:0;top:0;pointer-events:none;'; return c; };
    cvBack = mk('mg-back'); cvFront = mk('mg-front');
    // order inside the video box:  video · back layers · caption canvas · front layers · (DOM caption: handles / word picking)
    box.insertBefore(cvBack, capCv || dom.capLayer);
    box.insertBefore(cvFront, dom.capLayer);
    ctxB = cvBack.getContext('2d'); ctxF = cvFront.getContext('2d');
    frameEl = document.createElement('div'); frameEl.className = 'mg-frame'; frameEl.hidden = true; box.appendChild(frameEl);
    hitEl = document.createElement('div'); hitEl.className = 'mg-hit'; box.appendChild(hitEl);
    initDrag();
    built = true; return true;
  }

  function geometry() {
    const r = S.ui.preview.contentRect(), dpr = Math.min(window.devicePixelRatio || 1, 3);
    const w = Math.max(2, Math.round(r.w * dpr)), h = Math.max(2, Math.round(r.h * dpr));
    return { r: r, w: w, h: h, scale: w / (S.ui.preview.refWidth() || r.w || 1) };
  }

  function paint() {
    raf = 0;
    if (!build()) return;
    const g = geometry(), t = cur();
    [cvBack, cvFront].forEach(c => {
      c.style.left = g.r.x + 'px'; c.style.top = g.r.y + 'px'; c.style.width = g.r.w + 'px'; c.style.height = g.r.h + 'px';
      if (c.width !== g.w || c.height !== g.h) { c.width = g.w; c.height = g.h; }
    });
    ctxB.clearRect(0, 0, g.w, g.h); ctxF.clearRect(0, 0, g.w, g.h);
    if (M.layers.length) { MT().draw(ctxB, g.w, g.h, t, P, g.scale, 'back'); MT().draw(ctxF, g.w, g.h, t, P, g.scale, 'front'); }
    placeFrame(g, t);
    if (!video.paused && M.layers.length) schedule();                    // playing: keep the motion running between time events
  }
  function schedule() { if (!raf) raf = requestAnimationFrame(paint); }

  /** The dashed frame around the picked layer (editor only — never exported). */
  function placeFrame(g, t) {
    const L = selLayer(), open = document.body.classList.contains('sheet-open') && $('panels') && $('panels').querySelector('.tab-pane.active[data-pane="motion"]');
    if (!frameEl) return;
    const bx = L && open ? MT().boxAt(L, t, g.w, g.h, g.scale) : null;
    hitEl.classList.toggle('on', !!open && !!L);
    if (!bx) { frameEl.hidden = true; return; }
    const k = g.r.w / g.w, pad = 6;
    frameEl.hidden = false;
    frameEl.style.left = (g.r.x + bx.cx * k) + 'px'; frameEl.style.top = (g.r.y + bx.cy * k) + 'px';
    frameEl.style.width = (bx.hw * 2 * k + pad * 2) + 'px'; frameEl.style.height = (bx.hh * 2 * k + pad * 2) + 'px';
    frameEl.style.transform = 'translate(-50%,-50%) rotate(' + bx.rot + 'deg)';
  }

  /* =============================================================== drag the layer in the preview */
  function initDrag() {
    let d = null;
    hitEl.addEventListener('pointerdown', e => {
      const L = selLayer(); if (!L) return;
      const g = geometry(), bx = MT().boxAt(L, cur(), g.w, g.h, g.scale); if (!bx) return;
      const k = g.w / g.r.w, rect = hitEl.getBoundingClientRect();
      const px = (e.clientX - rect.left - g.r.x) * k, py = (e.clientY - rect.top - g.r.y) * k;
      // hit test in the layer's own (rotated) space, with a generous margin for fingers
      const a = -bx.rot * Math.PI / 180, dx = px - bx.cx, dy = py - bx.cy, lx = dx * Math.cos(a) - dy * Math.sin(a), ly = dx * Math.sin(a) + dy * Math.cos(a);
      const m = 28 * k;
      if (Math.abs(lx) > bx.hw + m || Math.abs(ly) > bx.hh + m) return;
      const all = sub !== 'kf';                                                   // keyframe tab: move this keyframe; any other tab: move the whole layer
      const kf = all ? null : ensureKfAtPlayhead(L); if (!all && !kf) return;
      d = { id: e.pointerId, sx: e.clientX, sy: e.clientY, x0: kf ? kf.x : 0, y0: kf ? kf.y : 0, kf: kf, all: all, lx: 0, ly: 0, rec: false, g: g };
      try { hitEl.setPointerCapture(e.pointerId); } catch (er) {}
      e.preventDefault();
    });
    hitEl.addEventListener('pointermove', e => {
      if (!d || e.pointerId !== d.id) return;
      if (!d.rec) { if (Math.hypot(e.clientX - d.sx, e.clientY - d.sy) < 3) return; rec('motion'); d.rec = true; if (!d.all) { const L0 = selLayer(); if (L0) L0.anim = null; } }   // dragging one keyframe = hand-made keyframes from now on
      const r = S.ui.preview.contentRect();
      if (d.all) {
        const L = selLayer(); if (!L) return; const ddx = (e.clientX - d.sx) / (r.w || 1), ddy = (e.clientY - d.sy) / (r.h || 1);
        MT().shiftAll(L, ddx - d.lx, ddy - d.ly); d.lx = ddx; d.ly = ddy;
      } else { d.kf.x = r1(clamp(d.x0 + (e.clientX - d.sx) / (r.w || 1), -0.5, 1.5)); d.kf.y = r1(clamp(d.y0 + (e.clientY - d.sy) / (r.h || 1), -0.5, 1.5)); }
      syncKfControls(); schedule(); bus.emit('motion:changed', { live: true });
    });
    const end = e => { if (d && e.pointerId === d.id) { d = null; renderTrack(); } };
    hitEl.addEventListener('pointerup', end); hitEl.addEventListener('pointercancel', end);
  }

  /** The keyframe the controls should edit at the playhead: an existing one within ~1 frame, else a new one (CapCut "auto keyframe"). */
  function ensureKfAtPlayhead(L) {
    const rel = cur() - L.start;
    if (rel < -0.001 || rel > L.end - L.start + 0.001) return selKf(L);          // playhead outside the layer: edit the picked keyframe
    const pk = selKf(L);
    if (pk && Math.abs(pk.t - rel) < 0.07) return pk;                           // the picked keyframe is under the playhead (tapping it in the list seeks here)
    const near = L.kf.findIndex(k => Math.abs(k.t - rel) < 0.07);
    if (near >= 0) { M.kfSel = near; return L.kf[near]; }
    if (L.kf.length === 1 && Math.abs(L.kf[0].t) < 0.001) { M.kfSel = 0; return L.kf[0]; }   // a still layer: edit its only pose
    return addKfAt(L, rel);
  }
  function addKfAt(L, rel) {
    rel = clamp(r1(rel), 0, r1(L.end - L.start));
    const s = MT().sample(L, rel), k = { t: rel, x: r1(s.x), y: r1(s.y), scale: r1(s.scale), rot: r1(s.rot, 1), alpha: r1(s.alpha), ease: 'linear' };
    L.kf.push(k); L.kf.sort((a, b) => a.t - b.t); M.kfSel = L.kf.indexOf(k);
    return k;
  }

  /* =============================================================== layer operations */
  function select(id, opts) {
    M.sel = id || null; M.kfSel = 0; renderPane(); renderTrack(); schedule();
    bus.emit('motion:selected', { id: M.sel });
    if (id && opts && opts.seek) { const L = selLayer(); if (L && (cur() < L.start || cur() >= L.end)) seek(L.start + 0.01); }
  }
  function seek(t) { video.currentTime = clamp(t, 0, dur() || t); bus.emit('time:changed', video.currentTime); }

  function addLayer(opts) {
    if (!dur()) { toast('เพิ่มวิดีโอก่อนครับ'); return null; }
    rec('motion');
    const t0 = clamp(cur(), 0, Math.max(0, dur() - 0.5));
    const L = MT().makeLayer(Object.assign({ start: t0, end: Math.min(dur(), t0 + 3), text: '?' }, opts || {}));
    if (!opts || !opts.kf) MT().setAnim(L, { inId: 'pop', outId: 'none' });
    M.layers.push(L); M.sel = L.id; M.kfSel = 0;
    afterStructure(); return L;
  }
  function removeLayer(id) {
    const i = M.layers.findIndex(l => l.id === id); if (i < 0) return;
    rec('motion'); M.layers.splice(i, 1);
    M.sel = M.layers.length ? M.layers[Math.min(i, M.layers.length - 1)].id : null; M.kfSel = 0; afterStructure();
  }
  function duplicateLayer(id) {
    const L = M.layers.find(l => l.id === id); if (!L) return;
    rec('motion'); const c = JSON.parse(JSON.stringify(L)); c.id = MT().newId(); const len = L.end - L.start;
    c.start = Math.min(Math.max(0, dur() - len), L.start + 0.3); c.end = c.start + len; c.rest.x = r1(c.rest.x + 0.04); c.rest.y = r1(c.rest.y + 0.04); if (c.anim) MT().recompose(c); else c.kf.forEach(k => { k.x = r1(k.x + 0.04); k.y = r1(k.y + 0.04); });
    M.layers.splice(M.layers.indexOf(L) + 1, 0, c); M.sel = c.id; afterStructure();
  }
  function afterStructure() { MT().clearCache(); renderPane(); renderTrack(); schedule(); bus.emit('motion:structure', { reason: 'edit' }); ensureFonts(); }
  function changed(live) { schedule(); if (!live) { renderTrack(); } bus.emit('motion:changed', { live: !!live }); }

  function applyPreset(L, id, noRec) {
    const p = MT().PRESETS.find(x => x.id === id); if (!p) return;
    if (!noRec) rec('motion');
    let rest = L.kf[L.kf.length - 1];                                            // the resting pose = the most visible keyframe (a leaving move ends invisible)
    L.kf.forEach(k => { if (k.alpha > rest.alpha + 1e-6 || (Math.abs(k.alpha - rest.alpha) < 1e-6 && k.scale > 0.01 && (rest.scale <= 0.01 || Math.abs(k.scale - 1) <= Math.abs(rest.scale - 1)))) rest = k; });
    const base = { x: rest.x, y: rest.y, scale: rest.scale > 0.01 ? rest.scale : 1, rot: 0, alpha: 1 }, len = Math.max(0.3, L.end - L.start);
    L.kf = p.make(base, len).map(k => Object.assign({}, k)); MT().normalize(L);
    // never let a keyframe sit past the end of the layer
    L.kf.forEach(k => { if (k.t > len) k.t = len; });
    L.anim = null; L.rest = MT().restOf(L.kf); M.kfSel = L.kf.length - 1;
  }


  /* =============================================================== template: "?" that tilts, placed at the end of the caption */
  /** Where the caption's text ends on the picture: { xr, yc } as fractions (right edge, vertical centre), measured by really drawing the line. */
  function captionEnd(cue) {
    try {
      const g = geometry(), w = 720, h = Math.max(2, Math.round(720 * g.r.h / Math.max(1, g.r.w))), scale = w / (S.ui.preview.refWidth() || g.r.w || 1);
      const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d');
      S.render.drawCaption(x, w, h, cue, Math.max(cue.start, cue.end - 0.01), scale, S.subtitle.effectiveStyle(cue, P.style));
      const d = x.getImageData(0, 0, w, h).data; let x1 = -1, y0 = h, y1 = -1;
      for (let yy = 0; yy < h; yy++) for (let xx = 0; xx < w; xx++) if (d[(yy * w + xx) * 4 + 3] > 24) { if (xx > x1) x1 = xx; if (yy < y0) y0 = yy; if (yy > y1) y1 = yy; }
      return x1 < 0 ? null : { xr: (x1 + 1) / w, yc: (y0 + y1 + 1) / 2 / h, refW: S.ui.preview.refWidth() || g.r.w };
    } catch (e) { return null; }
  }
  function cueNear(t) {
    const cues = P.subtitle.cues || []; if (!cues.length) return null;
    const i = S.subtitle.indexAt(cues, t); if (i >= 0) return cues[i];
    return cues.find(c => c.start >= t) || cues[cues.length - 1];
  }
  /** One tap: a "?" in the look of the example clip (white, hard dark shadow, soft glow) right after the end of the line that is on screen,
   *  popping in, tilting its head forward and, at the end, tilting back a little. Works on the caption at the playhead (or the next one). */
  function addQuestionTemplate() {
    if (!dur()) { toast('เพิ่มวิดีโอก่อนครับ'); return null; }
    const cue = cueNear(cur()), st = P.style, size = Math.round((st.size || 32) * 1.2);
    let start = clamp(cur(), 0, Math.max(0, dur() - 0.5)), end = Math.min(dur(), start + 3), x = 0.7, y = 0.62;
    if (cue) {
      start = cue.start + 0.08; end = Math.max(start + 0.8, cue.end);
      const ce = captionEnd(cue);
      if (ce) { x = ce.xr + (size * 0.34) / ce.refW; y = ce.yc - (size * 0.02) / ce.refW; }
    }
    rec('motion');
    const L = MT().makeLayer({ text: '?', z: 'front', start: start, end: Math.min(dur(), end), size: size, color: '#ffffff',
      font: st.font || undefined, weight: st.weight || 700, italic: false,
      outline: { on: false, color: '#000000', width: 0 },
      shadow: { on: true, color: '#0d1b22', opacity: 85, dx: 7, dy: 7, blur: 0 },
      glow: { on: true, color: '#ffffff', intensity: 55, range: 10 },
      kf: [{ t: 0, x: clamp(x, 0.05, 0.95), y: clamp(y, 0.05, 0.95), scale: 1, rot: 0, alpha: 1, ease: 'linear' }] });
    applyPreset(L, 'tilt', true);
    M.layers.push(L); M.sel = L.id; M.kfSel = 0;
    afterStructure(); seek(L.start + 0.01); return L;
  }

  /* =============================================================== fonts */
  function ensureFonts() { if (S.fontKit) S.fontKit.ensure(P).then(() => { MT().clearCache(); schedule(); }); }

  /* =============================================================== sheet (pane) */
  const SUBS = [['anim', 'ท่า'], ['kf', 'คีย์เฟรม'], ['style', 'สไตล์'], ['time', 'เวลา']];
  /** short name of a layer: its text, or the picture's file name */
  function label(l, i, n) { n = n || 10; if (l.kind === 'image') { const a = MT().getAsset(l.img); return ((a && a.name) || 'รูป').replace(/\.[a-z0-9]+$/i, '').slice(0, n); } return (l.text || '').split('\n')[0].slice(0, n) || ('เลเยอร์ ' + ((i || 0) + 1)); }
  let paneBuilt = false, fontSel = null;

  function pane() { return document.querySelector('.tab-pane[data-pane="motion"]'); }

  /** The font list is a copy of the style panel's #fontSel (fonts can be added while the app runs, so it is re-copied whenever it changed). */
  let fontSig = '';
  function syncFontList() {
    const src = $('fontSel'); if (!src || !fontSel) return;
    const opts = Array.from(src.options).filter(o => !o.dataset.temp && o.dataset.cat !== 'temp'), sig = opts.map(o => o.value + '|' + (o.dataset.weight || '') + '|' + o.textContent).join('\n');
    if (sig === fontSig) return; fontSig = sig;
    fontSel.innerHTML = '';
    opts.forEach(o => { const n = document.createElement('option'); n.value = o.value; n.dataset.weight = o.dataset.weight || ''; n.textContent = o.textContent.replace(/\s*\(.*\)/, ''); n.style.fontFamily = o.value; fontSel.appendChild(n); });
  }

  function renderPane() {
    const root = pane(); if (!root) return;
    if (!paneBuilt) buildPane(root); else syncFontList();
    const L = selLayer(), has = !!L;
    // layer chips
    const chips = $('mgChips');
    chips.innerHTML = M.layers.map((l, i) => '<div class="chip mg-chip' + (l.id === M.sel ? ' active' : '') + (l.hidden ? ' off' : '') + '" data-id="' + l.id + '"><i class="mg-dot ' + (l.z === 'back' ? 'b' : 'f') + '"></i>' + esc(label(l, i)) + '</div>').join('') +
      '<div class="chip mg-add" id="mgAddChip">+ เพิ่มเลเยอร์</div>';
    $('mgBody').hidden = !has; $('mgEmpty').hidden = has;
    if (!has) return;
    if ($('mgText').value !== L.text) { $('mgText').value = L.text; $('mgText').style.height = 'auto'; $('mgText').style.height = Math.min(120, $('mgText').scrollHeight) + 'px'; }
    root.querySelectorAll('[data-mgz]').forEach(b => b.classList.toggle('active', b.dataset.mgz === L.z));
    $('mgHide').classList.toggle('on', !!L.hidden);
    SUBS.forEach(s => { root.querySelector('[data-mgsub="' + s[0] + '"]').classList.toggle('on', s[0] === sub); root.querySelector('[data-mgpane="' + s[0] + '"]').hidden = s[0] !== sub; });
    root.querySelectorAll('[data-kind]').forEach(e => { e.hidden = e.dataset.kind !== L.kind; });          // text-only / picture-only controls
    if (L.kind === 'image') { const a = MT().getAsset(L.img); $('mgImgName').textContent = (a && a.name) || 'รูปภาพ'; if (a && $('mgImgThumb').getAttribute('src') !== a.url) $('mgImgThumb').src = a.url; }
    renderKfList(); syncKfControls(); syncStyleControls(); syncTimeControls();
    hooks.forEach(fn => { try { fn(L, root); } catch (e) { console.warn('[motion] hook', e); } });
    const zi = M.layers.indexOf(L); $('mgUp').disabled = zi >= M.layers.length - 1; $('mgDown').disabled = zi <= 0;
  }

  function curveSvg(id) {
    const f = MT().easeFn(id), n = 20, pts = [];
    for (let i = 0; i <= n; i++) { const p = i / n, y = clamp(f(p), -0.25, 1.25); pts.push((4 + p * 24).toFixed(1) + ',' + (28 - (y * 22 + 0)).toFixed(1)); }
    return '<svg viewBox="0 0 32 32"><path class="g" d="M4 28H28M4 6H28" /><polyline points="' + pts.join(' ') + '"/></svg>';
  }

  function buildPane(root) {
    paneBuilt = true;
    // ready-made moves
    $('mgPresets').innerHTML = MT().PRESETS.map(p => '<button type="button" class="chip" data-mgpre="' + p.id + '">' + p.th + '</button>').join('');
    // easing graphs
    $('mgEases').innerHTML = MT().EASES.map(e => '<button type="button" class="mg-ease" data-ease="' + e.id + '" title="' + e.th + '">' + curveSvg(e.id) + '<span>' + e.th + '</span></button>').join('');
    fontSel = $('mgFont'); syncFontList();

    root.addEventListener('click', e => {
      const t = e.target.closest('button,.chip,.mg-chip'); if (!t) return;
      if (t.id === 'mgAddChip') { addLayer(); return; }
      if (t.id === 'mgTplQ') { const n = addQuestionTemplate(); if (n) { play(); stopAfter(n.end + 0.3); } return; }
      if (t.classList.contains('mg-chip')) { select(t.dataset.id, { seek: true }); return; }
      const L = selLayer();
      if (t.dataset.mgsub) { sub = t.dataset.mgsub; renderPane(); return; }
      if (!L) return;
      if (t.dataset.mgz) { if (L.z !== t.dataset.mgz) { rec('motion'); L.z = t.dataset.mgz; renderPane(); renderTrack(); changed(); } return; }
      if (t.dataset.mgpre) { applyPreset(L, t.dataset.mgpre); renderPane(); changed(); seek(L.start + 0.01); play(); return; }
      if (t.dataset.ease) { const k = selKf(L); if (k) { rec('motion'); k.ease = t.dataset.ease; L.anim = null; syncKfControls(); changed(); previewSegment(L); } return; }
      if (t.dataset.kf != null) { M.kfSel = +t.dataset.kf; const k = selKf(L); if (k) seek(L.start + k.t); renderKfList(); syncKfControls(); renderTrack(); schedule(); return; }
      switch (t.id) {
        case 'mgKfAdd': { rec('motion'); L.anim = null; addKfAt(L, cur() - L.start); renderPane(); changed(); break; }
        case 'mgKfDel': { if (L.kf.length < 2) { toast('ต้องเหลืออย่างน้อย 1 คีย์เฟรม'); break; } rec('motion'); L.anim = null; L.kf.splice(M.kfSel, 1); M.kfSel = Math.min(M.kfSel, L.kf.length - 1); renderPane(); changed(); break; }
        case 'mgDel': removeLayer(L.id); break;
        case 'mgDup': duplicateLayer(L.id); break;
        case 'mgHide': rec('motion'); L.hidden = !L.hidden; renderPane(); changed(); break;
        case 'mgUp': { const i = M.layers.indexOf(L); if (i < M.layers.length - 1) { rec('motion'); M.layers.splice(i, 1); M.layers.splice(i + 1, 0, L); renderPane(); changed(); } break; }
        case 'mgDown': { const i = M.layers.indexOf(L); if (i > 0) { rec('motion'); M.layers.splice(i, 1); M.layers.splice(i - 1, 0, L); renderPane(); changed(); } break; }
        case 'mgPlay': seek(L.start + 0.01); play(); stopAfter(L.end + 0.3); break;
        case 'mgStartNow': { rec('motion'); shiftLayer(L, cur() - L.start, true); renderPane(); changed(); break; }
        case 'mgEndNow': { if (cur() > L.start + 0.1) { rec('motion'); L.end = r1(cur(), 2); renderPane(); changed(); } break; }
      }
    });

    // text
    let tRec = false;
    const grow = () => { const t = $('mgText'); t.style.height = 'auto'; t.style.height = Math.min(120, t.scrollHeight) + 'px'; };
    $('mgText').addEventListener('input', () => { grow(); const L = selLayer(); if (!L) return; if (!tRec) { rec('motion'); tRec = true; } L.text = $('mgText').value; MT().clearCache(); ensureFonts(); changed(true); renderTrackLabels(); renderChipLabels(); });
    $('mgText').addEventListener('change', () => { tRec = false; });
    $('mgText').addEventListener('blur', () => { tRec = false; });

    // sliders / inputs — one generic binder: [element id, getter(L,k) -> value, setter(L,k,v), decimals, unit label]
    const bind = (id, get, set, fmt, isKf) => {
      const el = $(id); if (!el) return; let recd = false;
      el.addEventListener('input', () => {
        const L = selLayer(); if (!L) return; if (!recd) { rec('motion'); recd = true; }
        const val = el.type === 'checkbox' ? el.checked : (el.type === 'color' || el.tagName === 'SELECT' ? el.value : +el.value);   // read BEFORE any re-sync below
        let kf = selKf(L);
        if (isKf) {                                                              // CapCut-style auto keyframe: editing at the playhead keys that moment
          L.anim = null;
          const n0 = L.kf.length; kf = ensureKfAtPlayhead(L) || kf;
          if (L.kf.length !== n0) { renderKfList(); renderTrack(); syncKfControls(); }
        }
        set(L, kf, val);
        const n = $(id + 'Num'); if (n) n.textContent = fmt ? fmt(get(L, kf)) : '';
        MT().clearCache(); changed(true);
        if (el.tagName === 'SELECT' || el.type === 'checkbox' || el.type === 'color') { if (el.tagName === 'SELECT') ensureFonts(); }
      });
      el.addEventListener('change', () => { recd = false; renderTrack(); });
      el.addEventListener('pointerup', () => { recd = false; });
    };
    api.bind = bind;
    // keyframe values
    bind('mgX', (L, k) => k.x * 100, (L, k, v) => { k.x = r1(v / 100); }, v => r1(v, 1) + '%', true);
    bind('mgY', (L, k) => k.y * 100, (L, k, v) => { k.y = r1(v / 100); }, v => r1(v, 1) + '%', true);
    bind('mgScale', (L, k) => k.scale * 100, (L, k, v) => { k.scale = r1(v / 100); }, v => Math.round(v) + '%', true);
    bind('mgRot', (L, k) => k.rot, (L, k, v) => { k.rot = r1(v, 1); }, v => Math.round(v) + '°', true);
    bind('mgAlpha', (L, k) => k.alpha * 100, (L, k, v) => { k.alpha = r1(v / 100); }, v => Math.round(v) + '%', true);
    // style
    bind('mgFont', (L) => L.font, (L, k, v) => { L.font = v; const o = fontSel.selectedOptions[0]; if (o && o.dataset.weight) L.weight = +o.dataset.weight; });
    bind('mgSize', (L) => L.size, (L, k, v) => { L.size = v; }, v => Math.round(v));
    bind('mgColor', (L) => L.color, (L, k, v) => { L.color = v; });
    bind('mgOlOn', (L) => L.outline.on, (L, k, v) => { L.outline.on = !!v; });
    bind('mgOlColor', (L) => L.outline.color, (L, k, v) => { L.outline.color = v; });
    bind('mgOlW', (L) => L.outline.width, (L, k, v) => { L.outline.width = v; }, v => r1(v, 1));
    bind('mgShOn', (L) => L.shadow.on, (L, k, v) => { L.shadow.on = !!v; });
    bind('mgShColor', (L) => L.shadow.color, (L, k, v) => { L.shadow.color = v; });
    bind('mgShDx', (L) => L.shadow.dx, (L, k, v) => { L.shadow.dx = v; }, v => Math.round(v));
    bind('mgShDy', (L) => L.shadow.dy, (L, k, v) => { L.shadow.dy = v; }, v => Math.round(v));
    bind('mgShBlur', (L) => L.shadow.blur, (L, k, v) => { L.shadow.blur = v; }, v => Math.round(v));
    bind('mgGlOn', (L) => L.glow.on, (L, k, v) => { L.glow.on = !!v; });
    bind('mgGlColor', (L) => L.glow.color, (L, k, v) => { L.glow.color = v; });
    bind('mgGlInt', (L) => L.glow.intensity, (L, k, v) => { L.glow.intensity = v; }, v => Math.round(v));
    bind('mgGlRange', (L) => L.glow.range, (L, k, v) => { L.glow.range = v; }, v => Math.round(v));
    // time
    const timeIn = (id, fn) => { const el = $(id); el.addEventListener('change', () => { const L = selLayer(); if (!L) return; const v = S.util.parseTime(el.value); if (isNaN(v)) { syncTimeControls(); return; } rec('motion'); fn(L, v); renderPane(); changed(); }); };
    $('mgKfT').addEventListener('change', () => {
      const L = selLayer(), k = selKf(L); if (!L || !k) return; const v = S.util.parseTime($('mgKfT').value);
      if (isNaN(v)) { syncKfControls(); return; }
      rec('motion'); L.anim = null; k.t = clamp(r1(v, 2), 0, r1(L.end - L.start, 2)); L.kf.sort((a, b) => a.t - b.t); M.kfSel = L.kf.indexOf(k);
      renderPane(); changed(); seek(L.start + k.t);
    });
    timeIn('mgStart', (L, v) => shiftLayer(L, v - L.start, true));
    timeIn('mgEnd', (L, v) => { L.end = Math.max(L.start + 0.1, Math.min(dur() || v, v)); });
    timeIn('mgLen', (L, v) => { L.end = Math.max(L.start + 0.1, Math.min(dur() || (L.start + v), L.start + v)); });
  }

  function shiftLayer(L, dt, keepLen) {
    const len = L.end - L.start; let s = clamp(L.start + dt, 0, Math.max(0, (dur() || 1e9) - len));
    L.start = r1(s, 2); L.end = r1(s + len, 2);
  }

  function renderChipLabels() { const el = $('mgChips'); if (!el) return; M.layers.forEach((l, i) => { const c = el.querySelector('.mg-chip[data-id="' + l.id + '"]'); if (c) c.lastChild.textContent = label(l, i); }); }

  function renderKfList() {
    const L = selLayer(), el = $('mgKfList'); if (!L || !el) return;
    el.innerHTML = L.kf.map((k, i) => '<button type="button" class="mg-kf' + (i === M.kfSel ? ' on' : '') + '" data-kf="' + i + '"><i></i><b>' + r1(k.t, 2) + 's</b></button>').join('');
  }
  /** values the sliders show: the look at the playhead when it is inside the layer (a keyframe's own values when it sits on one) */
  function shownVals(L, k) {
    const rel = cur() - L.start;
    if (rel >= -0.001 && rel <= L.end - L.start + 0.001) return MT().sample(L, Math.max(0, rel));
    return { x: k.x, y: k.y, scale: k.scale, rot: k.rot, alpha: k.alpha };
  }
  function syncKfControls() {
    const L = selLayer(), k0 = selKf(L); if (!L || !k0) return;
    const v = shownVals(L, k0), k = Object.assign({}, k0, v), onKey = Math.abs(cur() - L.start - k0.t) < 0.07;
    const set = (id, v, txt) => { const el = $(id); if (el && document.activeElement !== el) el.value = v; const n = $(id + 'Num'); if (n) n.textContent = txt; };
    set('mgX', r1(k.x * 100, 1), r1(k.x * 100, 1) + '%'); set('mgY', r1(k.y * 100, 1), r1(k.y * 100, 1) + '%');
    set('mgScale', Math.round(k.scale * 100), Math.round(k.scale * 100) + '%'); set('mgRot', Math.round(k.rot), Math.round(k.rot) + '°'); set('mgAlpha', Math.round(k.alpha * 100), Math.round(k.alpha * 100) + '%');
    $('mgEases').querySelectorAll('.mg-ease').forEach(b => b.classList.toggle('on', b.dataset.ease === k.ease));
    $('mgKfInfo').textContent = 'คีย์เฟรม ' + (M.kfSel + 1) + '/' + L.kf.length + ' · ที่ ' + r1(k0.t, 2) + ' วิ' + (M.kfSel < L.kf.length - 1 ? ' · กราฟนี้ใช้ช่วงไปคีย์ถัดไป' : ' · คีย์สุดท้าย (กราฟไม่มีผล)') + (onKey ? '' : ' · เส้นเวลาไม่ได้อยู่บนคีย์นี้: ปรับค่าแล้วจะเพิ่มคีย์ใหม่ตรงเส้นเวลา');
    $('mgKfDel').disabled = L.kf.length < 2;
    const kt = $('mgKfT'); if (kt && document.activeElement !== kt) kt.value = r1(k0.t, 2);
  }
  function syncStyleControls() {
    const L = selLayer(); if (!L) return;
    const v = (id, val, txt) => { const el = $(id); if (!el) return; if (el.type === 'checkbox') el.checked = !!val; else if (document.activeElement !== el) el.value = val; const n = $(id + 'Num'); if (n && txt != null) n.textContent = txt; };
    if (fontSel && document.activeElement !== fontSel) { const i = Array.from(fontSel.options).findIndex(o => o.value === L.font && (!o.dataset.weight || +o.dataset.weight === L.weight)); fontSel.selectedIndex = i >= 0 ? i : Math.max(0, Array.from(fontSel.options).findIndex(o => o.value === L.font)); }
    v('mgSize', L.size, Math.round(L.size)); v('mgColor', L.color);
    v('mgOlOn', L.outline.on); v('mgOlColor', L.outline.color); v('mgOlW', L.outline.width, r1(L.outline.width, 1));
    v('mgShOn', L.shadow.on); v('mgShColor', L.shadow.color); v('mgShDx', L.shadow.dx, Math.round(L.shadow.dx)); v('mgShDy', L.shadow.dy, Math.round(L.shadow.dy)); v('mgShBlur', L.shadow.blur, Math.round(L.shadow.blur));
    v('mgGlOn', L.glow.on); v('mgGlColor', L.glow.color); v('mgGlInt', L.glow.intensity, Math.round(L.glow.intensity)); v('mgGlRange', L.glow.range, Math.round(L.glow.range));
  }
  function syncTimeControls() {
    const L = selLayer(); if (!L) return;
    [['mgStart', L.start], ['mgEnd', L.end], ['mgLen', L.end - L.start]].forEach(a => { const el = $(a[0]); if (el && document.activeElement !== el) el.value = r1(a[1], 2); });
  }

  /** pause once the video passes `t` (used by the "ดูท่านี้" preview buttons) */
  function stopAfter(t) {
    const tick = () => { if (video.paused) return; if (video.currentTime >= t) { video.pause(); return; } requestAnimationFrame(tick); };
    requestAnimationFrame(tick);
  }
  function play() { try { const p = video.play(); if (p && p.catch) p.catch(() => {}); } catch (e) {} }
  /** after choosing a Graph: play the segment around the picked keyframe so the curve can be judged by eye */
  function previewSegment(L) {
    const k = selKf(L); if (!k) return;
    seek(L.start + Math.max(0, k.t - 0.05)); play();
    const next = L.kf[M.kfSel + 1], stopAt = L.start + (next ? next.t : k.t + 0.8) + 0.25;
    const tick = () => { if (video.paused || video.currentTime >= stopAt) { if (!video.paused) video.pause(); return; } requestAnimationFrame(tick); };
    requestAnimationFrame(tick);
  }

  /* =============================================================== timeline track */
  function renderTrack() {
    if (!track) return;
    const d = dur(), has = M.layers.length > 0 && d > 0;
    track.classList.toggle('has', has); document.body.classList.toggle('has-mg', has);
    if (!has) { track.innerHTML = ''; track.style.height = ''; return; }
    // overlapping layers stack on lanes
    const lanes = [], pos = new Map();
    M.layers.forEach(l => { let i = lanes.findIndex(e => e <= l.start + 1e-6); if (i < 0) { i = lanes.length; lanes.push(0); } lanes[i] = l.end; pos.set(l.id, i); });
    const LANE = 28, GAP = 3; track.style.height = (lanes.length * (LANE + GAP)) + 'px';
    track.innerHTML = M.layers.map(l => {
      const len = l.end - l.start, sel = l.id === M.sel;
      const kfs = l.kf.map((k, i) => '<i class="mg-d' + (sel && i === M.kfSel ? ' on' : '') + '" data-i="' + i + '" style="left:' + clamp(k.t / len * 100, 0, 100) + '%"></i>').join('');
      return '<div class="mg-block' + (sel ? ' sel' : '') + (l.z === 'back' ? ' back' : '') + (l.hidden ? ' off' : '') + '" data-id="' + l.id + '" style="left:' + (l.start / d * 100) + '%;width:' + (len / d * 100) + '%;top:' + (pos.get(l.id) * (LANE + GAP)) + 'px;height:' + LANE + 'px">' +
        '<span class="mg-name">' + esc(label(l, 0, 40)) + '</span>' + kfs + '<div class="rh l"></div><div class="rh r"></div></div>';
    }).join('');
  }
  function renderTrackLabels() { if (!track) return; M.layers.forEach(l => { const b = track.querySelector('.mg-block[data-id="' + l.id + '"] .mg-name'); if (b) b.textContent = label(l, 0, 40); }); }

  function initTrack() {
    track = $('mgTrack'); tlScroll = $('tlScroll'); timeline = $('timeline'); if (!track) return;
    const SNAP = 7;
    track.addEventListener('pointerdown', e => {
      const b = e.target.closest('.mg-block'); if (!b) return;
      const L = M.layers.find(l => l.id === b.dataset.id); if (!L) return;
      const diamond = e.target.closest('.mg-d');
      const mode = e.target.closest('.rh.l') ? 'left' : e.target.closest('.rh.r') ? 'right' : 'move';
      const first = M.sel !== L.id;
      if (first) select(L.id, { seek: false });
      const blk = track.querySelector('.mg-block[data-id="' + L.id + '"]');
      if (diamond && !first) { M.kfSel = +diamond.dataset.i; const k = selKf(L); if (k) seek(L.start + k.t); renderKfList(); syncKfControls(); renderTrack(); schedule(); return; }
      if (mode !== 'move' && (first || !blk.classList.contains('sel'))) return;
      const D = dur(), W = () => timeline.getBoundingClientRect().width || 1;
      const st = { x: e.clientX, sc: tlScroll.scrollLeft, s: L.start, e: L.end, mode: mode, moved: false, rec: false, id: e.pointerId };
      blk.setPointerCapture && blk.setPointerCapture(e.pointerId);
      const snapT = v => { const px = W() / D, c = [cur(), 0, D]; M.layers.forEach(o => { if (o !== L) c.push(o.start, o.end); }); let best = v, bd = SNAP / px; c.forEach(q => { const dd = Math.abs(q - v); if (dd < bd) { bd = dd; best = q; } }); return best; };
      const move = ev => {
        if (ev.pointerId !== st.id) return;
        if (!st.moved) { if (Math.abs(ev.clientX - st.x) < 4) return; st.moved = true; }
        if (!st.rec) { rec('motion'); st.rec = true; }
        const dt = ((ev.clientX - st.x) + (tlScroll.scrollLeft - st.sc)) / W() * D, len = st.e - st.s;
        if (st.mode === 'move') { let s = clamp(st.s + dt, 0, Math.max(0, D - len)); const a = snapT(s), b2 = snapT(s + len) - len; s = Math.abs(a - s) <= Math.abs(b2 - s) ? a : b2; L.start = r1(clamp(s, 0, Math.max(0, D - len)), 2); L.end = r1(L.start + len, 2); }
        else if (st.mode === 'left') { const s = clamp(snapT(st.s + dt), 0, st.e - 0.1); const shift = s - L.start; L.start = r1(s, 2); L.kf.forEach(k => { k.t = r1(Math.max(0, k.t - shift)); }); }
        else { L.end = r1(clamp(snapT(st.e + dt), L.start + 0.1, D), 2); }
        const len2 = L.end - L.start; blk.style.left = (L.start / D * 100) + '%'; blk.style.width = (len2 / D * 100) + '%';
        blk.querySelectorAll('.mg-d').forEach((el, i) => { el.style.left = clamp(L.kf[i].t / len2 * 100, 0, 100) + '%'; });
        syncTimeControls(); schedule(); bus.emit('motion:changed', { live: true });
      };
      const up = ev => {
        if (ev.pointerId !== st.id) return;
        blk.removeEventListener('pointermove', move); blk.removeEventListener('pointerup', up); blk.removeEventListener('pointercancel', up);
        if (!st.moved) { if (first) { const L2 = selLayer(); if (L2 && (cur() < L2.start || cur() >= L2.end)) seek(L2.start + 0.01); } if (!document.body.classList.contains('sheet-open') && S.ui.tabs) S.ui.tabs.open('motion'); }
        renderTrack(); renderPane(); schedule();
      };
      blk.addEventListener('pointermove', move); blk.addEventListener('pointerup', up); blk.addEventListener('pointercancel', up);
    });
  }

  /* =============================================================== boot */
  S.ui.motionText = {
    init() {
      build(); initTrack(); renderPane(); renderTrack();
      const redraw = () => schedule();
      ['time:changed', 'media:metadata', 'sheet:toggle', 'trim:changed', 'arrange:changed', 'arrange:render', 'cues:structure', 'style:changed'].forEach(ev => bus.on(ev, redraw));
      bus.on('motion:structure', () => { MT().clearCache(); renderPane(); renderTrack(); schedule(); ensureFonts(); });
      bus.on('sheet:toggle', e => { if (e && e.open && pane() && pane().classList.contains('active')) { if (!M.sel && M.layers.length) M.sel = M.layers[0].id; renderPane(); } renderTrack(); schedule(); });
      bus.on('media:metadata', () => { renderTrack(); });
      bus.on('media:selected', () => { M.layers.length = 0; M.sel = null; M.kfSel = 0; Object.keys(M.assets || {}).forEach(k => { delete M.assets[k]; }); MT().clearCache(); renderPane(); renderTrack(); schedule(); });
      bus.on('media:cleared', () => { M.layers.length = 0; M.sel = null; M.kfSel = 0; Object.keys(M.assets || {}).forEach(k => { delete M.assets[k]; }); renderPane(); renderTrack(); schedule(); });
      ['play', 'playing', 'seeked', 'pause'].forEach(ev => video.addEventListener(ev, redraw));
      let lastSync = 0;
      bus.on('time:changed', () => {
        const L = selLayer(), p = pane(); if (!L || !p || !p.classList.contains('active') || !document.body.classList.contains('sheet-open')) return;
        const now = performance.now(); if (!video.paused && now - lastSync < 120) return; lastSync = now;
        if (video.paused) { const rel = cur() - L.start, i = L.kf.findIndex(k => Math.abs(k.t - rel) < 0.07); if (i >= 0 && i !== M.kfSel) { M.kfSel = i; renderKfList(); renderTrack(); } }
        syncKfControls();
      });
      video.addEventListener('timeupdate', redraw);
      if (window.ResizeObserver) new ResizeObserver(redraw).observe(dom.videoBox);
      if (window.MutationObserver) { const mo = new MutationObserver(redraw); if ($('panels')) mo.observe($('panels'), { attributes: true, attributeFilter: ['class'], subtree: true }); mo.observe(document.body, { attributes: true, attributeFilter: ['class'] }); }
      window.addEventListener('resize', redraw);
      if (document.fonts && document.fonts.addEventListener) document.fonts.addEventListener('loadingdone', () => { MT().clearCache(); schedule(); });
      setInterval(() => { if (!video.paused) schedule(); }, 250);
      const open = $('ccMotion'); if (open) open.addEventListener('click', () => { if (!M.layers.length) addLayer(); else if (!selLayer()) select(M.layers[0].id); });   // tabs.js opens the sheet (data-tab)
      ensureFonts();
    },
    addLayer: addLayer, select: select, redraw: schedule, layers: layers, api: api, onRender: fn => { hooks.push(fn); }
  };
  Object.assign(api, { M: M, P: P, rec: rec, changed: changed, afterStructure: afterStructure, selLayer: selLayer, select: select, seek: seek, play: play, stopAfter: stopAfter,
    renderPane: renderPane, renderTrack: renderTrack, schedule: schedule, geometry: geometry, toast: toast, cur: cur, dur: dur, clamp: clamp, r1: r1, esc: esc,
    addQuestionTemplate: addQuestionTemplate, applyPreset: applyPreset, label: label, setSub: v => { sub = v; renderPane(); } });
})(window.SubEd);
