/* =====================================================================
 * UI: the MAIN video track as an editable timeline of scenes.
 *
 *   "จัดฉาก" cuts the timeline into scenes (S.state.project.arrange.scenes). Every scene is drawn here as a piece of the video
 *   track — numbered, with the thumbnail of the clip it shows. The pieces are what the preview plays and what the export renders.
 *
 *   Tap a piece      select it + play it. The bottom bar becomes the scene bar:
 *                    [↶ ย้อนกลับ] [แยก] [ลบ] [◂ เลื่อนซ้าย] [เลื่อนขวา ▸] [เลือกส่วน] [เปลี่ยนคลิป] [▶ เล่น] [⬇ ส่งออก]
 *   White handles    drag one to move the cut between this scene and its neighbour (snaps to the playhead).
 *   "วิดีโอ" tool     add videos straight onto the timeline (a new video takes an empty scene, or the scene under the playhead).
 *   The track is also cut at the scene boundaries (arrange.js syncCuts), so "ตัดวิดีโอ" pieces line up with the scenes.
 *
 * Reads: SubEd.state.project.arrange, SubEd.arrange.   Listens: arrange:changed, media:metadata, media:cleared, time:changed,
 *        cut:selected, cue:selected, audio:selected, cut:structure.
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, P = S.state.project, A = P.arrange, video = S.dom.video;
  const COLORS = ['#f5c518', '#33c9b6', '#ff7a59', '#9b8cff', '#6fd16f', '#ff6fa8'];   // same palette as the strip in the sheet
  let layer = null, addBtn = null, sig = '', picked = false, tlScroll = null, timeline = null;

  const D = () => P.media.duration || 0;
  const visible = () => !!(A.on && A.scenes.length && D());
  const toast = (m, ms) => { if (S.ui.toast) S.ui.toast(m, ms || 2400); };
  const esc = t => String(t == null ? '' : t).replace(/[<>"&]/g, '');

  function setPicked(on) {
    on = !!on && visible() && A.sel >= 0;
    if (picked === on) return;
    picked = on; sig = '';
    document.body.classList.toggle('scene-selected', on);
    render(); syncBar();
  }

  function render() {
    if (!layer) return;
    const show = visible();
    document.body.classList.toggle('arr-scn', show);
    if (addBtn) { addBtn.style.display = show ? '' : 'none'; if (show) addBtn.style.top = ($('videoTrack').offsetTop + 4) + 'px'; }
    if (!show) { if (picked) { picked = false; document.body.classList.remove('scene-selected'); } layer.innerHTML = ''; sig = ''; return; }
    const d = D(), n = A.scenes.length;
    // rebuild only when something that is drawn changed (cheap enough to run on every arrange:changed)
    const key = d + '|' + A.sel + '|' + picked + '|' + A.scenes.map(s => [s.id, s.start, s.end, s.clipId].join(',')).join(';') + '|' + A.clips.map(c => c.id + (c.thumb ? 1 : 0)).join(',');
    if (key === sig) { markCurrent(); return; }
    sig = key;
    layer.innerHTML = A.scenes.map((s, i) => {
      const c = S.arrange.clipOf(s), col = COLORS[i % COLORS.length], sel = i === A.sel, pk = sel && picked;
      return '<div class="scn-blk' + (c ? '' : ' empty') + (sel ? ' sel' : '') + (pk ? ' pick' : '') + (i === 0 ? ' first' : '') + (i === n - 1 ? ' last' : '') + '" data-i="' + i +
        '" style="left:' + (s.start / d * 100) + '%;width:' + ((s.end - s.start) / d * 100) + '%;--c:' + col + (c && c.thumb ? ';background-image:url(' + c.thumb + ')' : '') +
        '" title="' + (c ? esc(c.name) : 'ฉากนี้ยังไม่มีคลิป') + '"><b>' + (i + 1) + '</b>' + (pk ? '<div class="rh l"></div><div class="rh r"></div>' : '') + '</div>';
    }).join('');
    markCurrent(); syncBar();
  }
  /** Move the blocks while a handle is being dragged (a full rebuild would drop the handle under the finger). */
  function place() {
    const d = D(); if (!d || !layer) return;
    layer.querySelectorAll('.scn-blk').forEach(el => {
      const s = A.scenes[+el.dataset.i]; if (!s) return;
      el.style.left = (s.start / d * 100) + '%'; el.style.width = ((s.end - s.start) / d * 100) + '%';
    });
  }
  function markCurrent() {
    if (!layer || !visible()) return;
    const s = S.arrange.sceneAt(video.currentTime || 0), cur = s ? A.scenes.indexOf(s) : -1;
    layer.querySelectorAll('.scn-blk').forEach(el => el.classList.toggle('cur', +el.dataset.i === cur));
  }

  /* ------------------------------------------------------------ the bottom bar */
  function syncBar() {
    const i = A.sel, n = A.scenes.length, set = (id, dis) => { const b = $(id); if (b) b.disabled = !!dis; };
    const s = A.scenes[i], t = video.currentTime || 0, inside = !!s && t > s.start + 0.25 && t < s.end - 0.25;
    set('scSplit', !inside); set('scDel', n < 2); set('scMerge', i < 0 || i >= n - 1); set('scLeft', i <= 0); set('scRight', i < 0 || i >= n - 1);
    set('scUndo', !S.arrange.canUndo());
  }
  function initBar() {
    const on = (id, fn) => { const b = $(id); if (b) b.addEventListener('click', fn); };
    on('scBack', () => setPicked(false));
    on('scUndo', () => { if (S.arrange.undoScenes()) toast('ย้อนกลับแล้ว'); });
    on('scSplit', () => {
      const k = S.arrange.splitAtPlayhead();
      toast(k < 0 ? 'เลื่อนเส้นเล่นไปกลางฉากก่อน แล้วกด “แยก”' : 'แยกฉากแล้ว');
    });
    on('scDel', () => { if (S.arrange.removeScene(A.sel)) toast('ลบฉากแล้ว — ช่วงเวลาไปรวมกับฉากข้างๆ (กด ย้อนกลับ ได้)', 2800); else toast('ต้องเหลืออย่างน้อยหนึ่งฉาก'); });
    on('scLeft', () => S.arrange.moveScene(A.sel, -1));
    on('scRight', () => S.arrange.moveScene(A.sel, 1));
    on('scMerge', () => {
      if (A.sel < 0 || A.sel >= A.scenes.length - 1) { toast('ฉากสุดท้ายไม่มีฉากถัดไปให้รวม'); return; }
      S.arrange.pushUndo(); S.arrange.mergeWithNext(A.sel); S.arrange.commit(); toast('รวมกับฉากถัดไปแล้ว (กด ย้อนกลับ ได้)', 2400);
    });
    on('scSet', () => { setPicked(false); if (S.ui.tabs && S.ui.tabs.open) S.ui.tabs.open('arrange'); });
    on('scPick', () => { if (S.ui.clipPicker) S.ui.clipPicker.open(A.sel); });
    on('scReplace', () => S.arrange.replaceScene(A.sel, false));
    on('scPlay', () => { const s = A.scenes[A.sel]; if (s) S.ui.player.replay(s.start, s.end); });
    on('scExport', () => S.arrange.exportScene(A.sel));
    on('ccAddVideo', () => $('arrClipInput').click());
  }

  /* ------------------------------------------------------------ dragging a handle = moving the cut next to this scene */
  let drag = null;
  function initDrag() {
    const apply = x => {
      if (!drag) return;
      const w = timeline.getBoundingClientRect().width || 1;
      let t = drag.origT + ((x - drag.sx) + (tlScroll.scrollLeft - drag.sScroll)) / w * D();
      const reach = 6 / ((S.ui.timeline && S.ui.timeline.getZoom()) || 80), head = video.currentTime || 0;
      if (Math.abs(head - t) <= reach) t = head;                      // snap to the playhead
      S.arrange.moveCut(drag.bi, t); place();
    };
    const edge = () => {
      if (!drag) return; drag.raf = 0;
      const r = tlScroll.getBoundingClientRect(), EDGE = 36, lx = drag.lx;
      const v = lx > r.right - EDGE ? Math.min(18, (lx - (r.right - EDGE)) / 2 + 2) : lx < r.left + EDGE ? -Math.min(18, ((r.left + EDGE) - lx) / 2 + 2) : 0;
      if (v) { const b = tlScroll.scrollLeft; tlScroll.scrollLeft = b + v; if (tlScroll.scrollLeft !== b) apply(lx); }
      drag.raf = requestAnimationFrame(edge);
    };
    layer.addEventListener('pointerdown', e => {
      const h = e.target.closest('.rh'); if (!h) return;
      const blk = h.closest('.scn-blk'), i = +blk.dataset.i, bi = h.classList.contains('l') ? i - 1 : i;
      if (bi < 0 || bi >= A.scenes.length - 1) return;
      e.stopPropagation(); e.preventDefault();
      if (!video.paused) video.pause();
      drag = { bi: bi, id: e.pointerId, sx: e.clientX, lx: e.clientX, sScroll: tlScroll.scrollLeft, origT: A.scenes[bi].end, moved: false, raf: 0 };
      h.setPointerCapture(e.pointerId);
      drag.raf = requestAnimationFrame(edge);
    });
    layer.addEventListener('pointermove', e => {
      if (!drag || e.pointerId !== drag.id) return;
      drag.lx = e.clientX;
      if (!drag.moved) { if (Math.abs(e.clientX - drag.sx) < 2) return; drag.moved = true; S.arrange.pushUndo(); }
      apply(e.clientX);
    });
    const end = e => {
      if (!drag || (e && e.pointerId !== drag.id)) return;
      const d = drag; drag = null;
      if (d.raf) cancelAnimationFrame(d.raf);
      if (d.moved) { S.arrange.syncCuts(); S.arrange.renderAll(); }      // pieces of "ตัดวิดีโอ" follow the new cut; the sheet and the saved copy too
    };
    ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(ev => layer.addEventListener(ev, end));
  }

  S.ui.sceneTrack = {
    init() {
      tlScroll = $('tlScroll'); timeline = $('timeline');
      layer = document.createElement('div'); layer.className = 'scn-layer'; layer.id = 'scnLayer';
      const vt = $('videoTrack'), cutLayer = $('vsegLayer');
      vt.insertBefore(layer, cutLayer || $('dimLeft'));
      layer.addEventListener('click', e => {
        if (e.target.closest('.rh')) return;                                        // the click that ends a handle drag
        const el = e.target.closest('.scn-blk'); if (!el) return;
        if (S.ui.videoCut && S.ui.videoCut.clear) S.ui.videoCut.clear();            // a selected cut piece would otherwise keep the cut toolbar open
        if (S.ui.sel && S.ui.sel.clear) S.ui.sel.clear();
        const i = +el.dataset.i;
        A.sel = i; picked = false; sig = '';                                        // setPicked(true) below rebuilds with the handles
        setPicked(true);
        S.arrange.selectScene(i, true);
      });
      // CapCut's "+" after the last piece: add more clips (an empty scene takes one, otherwise the scene under the playhead)
      addBtn = document.createElement('button'); addBtn.type = 'button'; addBtn.className = 'scn-add'; addBtn.id = 'scnAdd';
      addBtn.title = 'เพิ่มวิดีโอ'; addBtn.innerHTML = '<b>+</b>'; addBtn.style.display = 'none';
      addBtn.addEventListener('click', () => $('arrClipInput').click());
      $('tlPadR').appendChild(addBtn);
      initBar(); initDrag();
      ['arrange:changed', 'media:metadata', 'cut:structure'].forEach(ev => bus.on(ev, render));
      bus.on('media:cleared', () => { picked = false; document.body.classList.remove('scene-selected'); sig = ''; render(); });
      bus.on('time:changed', () => { markCurrent(); syncBar(); });
      // picking something else on the timeline closes the scene bar
      bus.on('cut:selected', e => { if (e && e.id) setPicked(false); });
      bus.on('cue:selected', e => { if (e && e.id) setPicked(false); });
      bus.on('audio:selected', e => { if (e && e.id) setPicked(false); });
      $('ccCut').addEventListener('click', () => setPicked(false));
      $('ccAudio').addEventListener('click', () => setPicked(false));
      render();
    }
  };
})(window.SubEd);
