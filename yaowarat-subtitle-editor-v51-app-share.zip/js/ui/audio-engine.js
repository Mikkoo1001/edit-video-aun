/* =====================================================================
 * SubEd.audioTracks — the "เสียง" tracks: sounds laid on the timeline next to the video (music, voice-over, effects).
 *
 *   project.audio = { clips: [{ id, mid, name, start, in, len, vol, fadeIn, fadeOut }], sel }
 *     start   where the clip sits on the timeline (seconds, source-clip time — the same clock as the subtitle lines)
 *     in      where in the sound file it begins   len  how long it plays (so trimming either edge = changing in / start / len)
 *     vol     0..2 (1 = as recorded)   fadeIn / fadeOut  seconds
 *     mid     the sound file it plays (runtime store `media`: decoded AudioBuffer + waveform peaks + the original Blob)
 *   Splitting a clip makes two clips that share one `mid`, so nothing is decoded twice.
 *
 * This file has no timeline DOM: it is the model + three consumers of it —
 *   preview   hears the clips while the video plays (Web Audio, kept in step with the <video> clock)
 *   mixer     makeMixer(t0) -> mix(planes, n, firstSample)  ADDS the clips into the 48 kHz blocks an audio encoder is about to take
 *             (same hook the scene sound effects use, so MP4 and WebM exports both get it)
 *   realtime  scheduleInto(ctx, node, from, when) for the real-time recorder fallback
 * Emits: audio:structure (clips added / removed / replaced)  audio:timing (a clip moved or changed)  audio:changed (either of them)
 * ===================================================================== */
(function (S) {
  'use strict';
  const bus = S.bus, P = S.state.project, video = S.dom.video;
  const A = P.audio;
  const RATE = 48000, MIN_LEN = 0.1, PK = 50;                  // PK = waveform peaks per second
  const media = new Map();
  let ac = null, seq = 0;
  const uid = () => 'a' + (++seq).toString(36) + Math.random().toString(36).slice(2, 6);
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const dur = () => P.media.duration || 0;

  function ctx() {
    if (!ac) {
      const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return null;
      try { ac = new AC({ sampleRate: RATE }); } catch (e) { ac = new AC(); }
    }
    if (ac.state === 'suspended') ac.resume().catch(() => {});
    return ac;
  }
  function changed(structural) {
    bus.emit(structural ? 'audio:structure' : 'audio:timing');
    bus.emit('audio:changed');
  }

  /* ------------------------------------------------------------ sound files */
  function decode(blob) {
    const c = ctx(); if (!c) return Promise.reject(new Error('เบราว์เซอร์นี้เล่นเสียงไม่ได้'));
    return blob.arrayBuffer().then(ab => new Promise((res, rej) => {
      const p = c.decodeAudioData(ab, res, rej);
      if (p && p.catch) p.catch(rej);
    })).catch(e => { throw new Error(e && e.message && /memory/i.test(e.message) ? 'ไฟล์ใหญ่เกินกว่าเครื่องจะอ่านเสียงได้' : 'ถอดรหัสเสียงจากไฟล์นี้ไม่ได้'); });
  }
  /** 50 values per second (0-255): the loudest sample in each slice, square-rooted so quiet parts still show. */
  function peaksOf(buf) {
    const n = Math.max(1, Math.ceil(buf.duration * PK)), out = new Uint8Array(n), per = buf.sampleRate / PK, chs = [];
    for (let k = 0; k < Math.min(2, buf.numberOfChannels); k++) chs.push(buf.getChannelData(k));
    for (let i = 0; i < n; i++) {
      const a = Math.floor(i * per), b = Math.min(buf.length, Math.floor((i + 1) * per)), step = Math.max(1, Math.floor((b - a) / 64));
      let m = 0;
      for (let j = a; j < b; j += step) for (let k = 0; k < chs.length; k++) { const v = Math.abs(chs[k][j]); if (v > m) m = v; }
      out[i] = Math.min(255, Math.round(Math.sqrt(m) * 255));
    }
    return out;
  }
  function putMedia(id, name, kind, buf, blob, sfx) {
    media.set(id, { id: id, name: name, kind: kind, buf: buf, dur: buf.duration, peaks: peaksOf(buf), blob: blob || null, sfx: sfx || null });
    return id;
  }
  /** Decode a picked / recorded / extracted file into the store. Resolves with its media id. */
  async function addMedia(blob, name, kind, id) {
    const buf = await decode(blob);
    if (!(buf.duration > 0.05)) throw new Error('ไฟล์นี้ไม่มีเสียง');
    return putMedia(id || uid(), name || 'เสียง', kind || 'file', buf, blob, null);
  }
  /** A built-in sound effect (the same synthesised ones the scene effects use). */
  function addSfx(type, id) {
    const F = S.arrangeFx, s = F && F.synth(type), c = ctx(); if (!s || !c) return null;
    const buf = c.createBuffer(1, s.data.length, RATE); buf.copyToChannel(s.data, 0);
    return putMedia(id || uid(), F.SFX[type] || type, 'sfx', buf, null, type);
  }

  /* ------------------------------------------------------------ clips */
  const get = id => A.clips.find(c => c.id === id) || null;
  const end = c => c.start + c.len;
  function fitFades(c) {
    c.fadeIn = clamp(c.fadeIn || 0, 0, c.len); c.fadeOut = clamp(c.fadeOut || 0, 0, c.len);
    if (c.fadeIn + c.fadeOut > c.len) { const k = c.len / (c.fadeIn + c.fadeOut); c.fadeIn *= k; c.fadeOut *= k; }
  }
  /** Put a sound on the timeline at `at` (clamped so it stays inside the video; shortened when it would run past the end). */
  function addClip(mid, at) {
    const m = media.get(mid), D = dur(); if (!m || !(D > 0)) return null;
    at = clamp(at || 0, 0, D);
    if (D - at < Math.min(m.dur, 0.5)) at = Math.max(0, D - m.dur);
    const len = Math.min(m.dur, D - at);
    if (len < MIN_LEN) return null;
    const c = { id: uid(), mid: mid, name: m.name, start: +at.toFixed(3), in: 0, len: +len.toFixed(3), vol: 1, fadeIn: 0, fadeOut: 0 };
    A.clips.push(c); changed(true);
    return c;
  }
  function split(id, t) {
    const c = get(id); if (!c || !(t > c.start + MIN_LEN && t < end(c) - MIN_LEN)) return null;
    const tail = Object.assign({}, c, { id: uid(), start: +t.toFixed(3), in: +(c.in + (t - c.start)).toFixed(3), len: +(end(c) - t).toFixed(3), fadeIn: 0 });
    c.len = +(t - c.start).toFixed(3); c.fadeOut = 0;
    fitFades(c); fitFades(tail);
    A.clips.splice(A.clips.indexOf(c) + 1, 0, tail); changed(true);
    return tail;
  }
  function duplicate(id) {
    const c = get(id), D = dur(); if (!c) return null;
    let at = end(c);
    if (at + c.len > D + 1e-6) at = Math.max(0, D - c.len);         // no room after it: lay the copy as far right as it fits (it may overlap, on its own lane)
    const copy = Object.assign({}, c, { id: uid(), start: +at.toFixed(3) });
    A.clips.splice(A.clips.indexOf(c) + 1, 0, copy); changed(true);
    return copy;
  }
  function remove(id) {
    const i = A.clips.findIndex(c => c.id === id); if (i < 0) return false;
    A.clips.splice(i, 1); changed(true); return true;
  }
  function clear() { A.clips = []; A.sel = null; media.clear(); changed(true); }

  /* ------------------------------------------------------------ playing the clips (preview and real-time export) */
  /** Gain of a clip `k` seconds after its start. */
  function gainAt(c, k) {
    let g = c.vol;
    if (c.fadeIn > 0 && k < c.fadeIn) g *= k / c.fadeIn;
    const r = c.len - k; if (c.fadeOut > 0 && r < c.fadeOut) g *= Math.max(0, r) / c.fadeOut;
    return g;
  }
  /** Schedule every clip that is still to be heard from timeline time `from`; the time `from` happens at audio-clock time `when`.
   *  Returns the nodes (stopNodes() silences them). `dest` is where they connect (speakers, or a MediaStreamDestination). */
  function scheduleInto(c, dest, from, when) {
    const out = [];
    A.clips.forEach(clip => {
      const m = media.get(clip.mid); if (!m || end(clip) <= from + 0.001) return;
      const k0 = Math.max(0, from - clip.start), at = when + Math.max(0, clip.start - from);
      const src = c.createBufferSource(), g = c.createGain();
      src.buffer = m.buf;
      const p = g.gain;
      p.setValueAtTime(gainAt(clip, k0), at);
      if (clip.fadeIn > 0 && k0 < clip.fadeIn) p.linearRampToValueAtTime(clip.vol, at + (clip.fadeIn - k0));
      if (clip.fadeOut > 0) {
        const kOut = clip.len - clip.fadeOut;
        if (k0 < kOut) { p.setValueAtTime(clip.vol, at + (kOut - k0)); p.linearRampToValueAtTime(0, at + (clip.len - k0)); }
        else p.linearRampToValueAtTime(0, at + (clip.len - k0));
      }
      src.connect(g); g.connect(dest);
      try { src.start(at, clip.in + k0, clip.len - k0); } catch (e) { return; }
      out.push({ src: src, g: g });
    });
    return out;
  }
  function stopNodes(list) {
    (list || []).forEach(n => { try { n.src.stop(); } catch (e) {} try { n.src.disconnect(); n.g.disconnect(); } catch (e) {} });
  }

  let nodes = [], playing = false, tv0 = 0, tc0 = 0, held = false, timer = 0;
  function stopPreview() { stopNodes(nodes); nodes = []; playing = false; clearInterval(timer); timer = 0; }
  function startPreview() {
    stopNodes(nodes); nodes = [];
    if (held || video.paused || !A.clips.length) { playing = false; return; }
    const c = ctx(); if (!c) return;
    tv0 = video.currentTime; tc0 = c.currentTime + 0.03; playing = true;
    nodes = scheduleInto(c, c.destination, tv0, tc0);
    if (!timer) timer = setInterval(() => {                       // the <video> clock and the audio clock drift apart (and the video stalls): re-sync
      if (!playing || video.paused) return;
      if (Math.abs(tv0 + (ac.currentTime - tc0) - video.currentTime) > 0.15) startPreview();
    }, 800);
  }
  video.addEventListener('playing', startPreview);
  video.addEventListener('seeked', () => { if (!video.paused) startPreview(); });
  ['pause', 'waiting', 'ended', 'emptied'].forEach(ev => video.addEventListener(ev, stopPreview));
  bus.on('audio:changed', () => { if (!video.paused) startPreview(); });

  /* ------------------------------------------------------------ export */
  /** mix(planes, n, firstSample) for an export that starts at timeline time t0, or null when there is nothing to add. */
  function makeMixer(t0) {
    const list = [];
    A.clips.forEach(c => {
      const m = media.get(c.mid); if (!m || !(c.len > 0)) return;
      const b = m.buf, chs = [];
      for (let k = 0; k < Math.min(2, b.numberOfChannels); k++) chs.push(b.getChannelData(k));
      list.push({ from: Math.round((c.start - t0) * RATE), n: Math.round(c.len * RATE), chs: chs, ratio: b.sampleRate / RATE, off: c.in * b.sampleRate,
        vol: c.vol, fi: Math.round((c.fadeIn || 0) * RATE), fo: Math.round((c.fadeOut || 0) * RATE), srcLen: b.length });
    });
    if (!list.length) return null;
    return function mix(planes, n, start) {
      for (const e of list) {
        const a = Math.max(start, e.from), z = Math.min(start + n, e.from + e.n);
        if (z <= a) continue;
        const nch = e.chs.length;
        for (let i = a; i < z; i++) {
          const k = i - e.from, pos = e.off + k * e.ratio, i0 = Math.floor(pos), f = pos - i0;
          if (i0 + 1 >= e.srcLen) break;
          let g = e.vol; if (e.fi && k < e.fi) g *= k / e.fi; const r = e.n - k; if (e.fo && r < e.fo) g *= r / e.fo;
          const o = i - start;
          if (planes.length === 1) { let s = 0; for (let q = 0; q < nch; q++) s += e.chs[q][i0] * (1 - f) + e.chs[q][i0 + 1] * f; planes[0][o] += s / nch * g; }
          else for (let q = 0; q < planes.length; q++) { const ch = e.chs[Math.min(q, nch - 1)]; planes[q][o] += (ch[i0] * (1 - f) + ch[i0 + 1] * f) * g; }
        }
      }
      for (let q = 0; q < planes.length; q++) { const pl = planes[q]; for (let i = 0; i < n; i++) { const v = pl[i]; if (v > 1) pl[i] = 1; else if (v < -1) pl[i] = -1; } }
    };
  }
  /** Run several mixers one after the other (scene effects + sound tracks); null entries are skipped, and null comes back when none is left. */
  function chain() {
    const fns = Array.prototype.filter.call(arguments, f => typeof f === 'function');
    if (!fns.length) return null;
    if (fns.length === 1) return fns[0];
    return (planes, n, start) => fns.forEach(f => f(planes, n, start));
  }

  S.audioTracks = {
    media: media, RATE: RATE, MIN_LEN: MIN_LEN, PK: PK,
    ctx: ctx, addMedia: addMedia, addSfx: addSfx, get: get, end: end, fitFades: fitFades,
    addClip: addClip, split: split, duplicate: duplicate, remove: remove, clear: clear, changed: changed,
    makeMixer: makeMixer, chain: chain, scheduleInto: scheduleInto, stopNodes: stopNodes,
    /** The real-time exporter plays the video itself: the preview must stay silent meanwhile. */
    hold(on) { held = !!on; if (held) stopPreview(); else if (!video.paused) startPreview(); },
    count: () => A.clips.length
  };
})(window.SubEd);
