/* =====================================================================
 * UI: custom video player controls. Owns the <video> element's behaviour:
 * play/pause, mute, fullscreen, trim-aware playback, and the time signal.
 * Emits  media:metadata  and  time:changed(t).
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, fmt = S.util.fmt, state = S.state, P = state.project;
  const video = S.dom.video, videoBox = S.dom.videoBox;

  function loop() {
    if (!video.paused) {
      bus.emit('time:changed', video.currentTime);
      state.ui.rafId = requestAnimationFrame(loop);
    }
  }

  function rawSeek(t) {
    video.currentTime = t;
    bus.emit('time:changed', video.currentTime);
  }

  /** A pending "play one sentence" must die when the user pauses or jumps elsewhere, or it would pause them later. */
  let stopReplay = null;
  function cancelReplay() { if (stopReplay) { stopReplay(); stopReplay = null; } }

  /** Seek and notify listeners immediately (captions + playhead + clock). */
  function seek(t) {
    cancelReplay();
    rawSeek(t);
  }

  /** Play exactly one sentence: start → end, then pause. Cancels any previous replay. */
  function replay(start, end) {
    if (!P.media.duration) return;
    cancelReplay();
    rawSeek(start + 0.01);
    const onTime = () => {
      if (video.currentTime >= end - 0.03) {
        const t = end;
        cancelReplay();
        video.pause();
        video.currentTime = t;
      }
    };
    const onPause = () => cancelReplay();
    video.addEventListener('timeupdate', onTime);
    video.addEventListener('pause', onPause);
    stopReplay = () => { video.removeEventListener('timeupdate', onTime); video.removeEventListener('pause', onPause); };
    video.play();
  }


  /* ---- Fullscreen. The normal controls sit OUTSIDE #videoBox, so in fullscreen (only #videoBox is shown) there was nothing to
   * press. This builds a small overlay INSIDE the box: tap the picture = play / pause, plus a bar with play, time, a seek slider and
   * an exit button. The overlay is hidden unless the box is fullscreen (css/app.css), auto-hides while playing, and the caption
   * is scaled up with the picture so it keeps the same size relative to the video as in the editor. */
  let fsBase = 0;
  const PLAY = '<path d="M8 5v14l11-7z"/>', PAUSE = '<path d="M6 5h4v14H6zM14 5h4v14h-4z"/>';

  function initFullscreen() {
    const ov = document.createElement('div');
    ov.className = 'fs-ctrl';
    ov.innerHTML =
      '<div class="fs-big" aria-hidden="true"><svg viewBox="0 0 24 24" fill="currentColor"><g id="fsBigIcon">' + PLAY + '</g></svg></div>' +
      '<div class="fs-bar">' +
        '<button type="button" class="fs-btn fs-play" title="เล่น / หยุด"><svg viewBox="0 0 24 24" fill="currentColor"><g class="fs-play-icon">' + PLAY + '</g></svg></button>' +
        '<span class="fs-time">0:00 / 0:00</span>' +
        '<input type="range" class="fs-seek" min="0" max="1000" value="0" step="1">' +
        '<button type="button" class="fs-btn fs-exit" title="ออกจากเต็มจอ"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 4v3a2 2 0 0 1-2 2H4m16 0h-3a2 2 0 0 1-2-2V4M4 15h3a2 2 0 0 1 2 2v3m6 0v-3a2 2 0 0 1 2-2h3"/></svg></button>' +
      '</div>';
    videoBox.appendChild(ov);
    const bar = ov.querySelector('.fs-bar'), playBtn = ov.querySelector('.fs-play'), playG = ov.querySelector('.fs-play-icon'),
          bigG = ov.querySelector('#fsBigIcon'), timeEl = ov.querySelector('.fs-time'), seek = ov.querySelector('.fs-seek'), exitBtn = ov.querySelector('.fs-exit');
    const fsElement = () => document.fullscreenElement || document.webkitFullscreenElement || null;
    const isFs = () => fsElement() === videoBox;
    let hideTimer = 0, dragging = false;

    function range() { const a = P.trim.start || 0, b = P.trim.end > a ? P.trim.end : (video.duration || a + 1); return [a, b]; }
    function sync() {
      const g = range(), t = Math.min(g[1], Math.max(g[0], video.currentTime || 0));
      if (!dragging) seek.value = String(Math.round((t - g[0]) / Math.max(0.001, g[1] - g[0]) * 1000));
      timeEl.textContent = fmt(t - g[0]) + ' / ' + fmt(g[1] - g[0]);
      const icon = video.paused ? PLAY : PAUSE;
      playG.innerHTML = icon; bigG.innerHTML = icon;
      ov.classList.toggle('paused', video.paused);
    }
    function showBar() {
      ov.classList.add('show'); clearTimeout(hideTimer);
      if (!video.paused && !dragging) hideTimer = setTimeout(() => ov.classList.remove('show'), 2800);
    }
    function toggle() {
      if (video.paused) {
        const g = range();
        if (video.currentTime >= g[1] - 0.05 || video.currentTime < g[0]) rawSeek(g[0]);     // at the end: play from the start again
        video.play();
      } else video.pause();
      sync(); showBar();
    }
    function exit() {
      if (document.exitFullscreen) document.exitFullscreen();
      else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
    }
    // tap the picture: first tap while the bar is hidden only shows it when playing; otherwise it toggles play / pause
    ov.addEventListener('click', e => {
      if (e.target.closest('.fs-bar')) return;
      if (!video.paused && !ov.classList.contains('show')) { showBar(); return; }
      toggle();
    });
    playBtn.addEventListener('click', e => { e.stopPropagation(); toggle(); });
    exitBtn.addEventListener('click', e => { e.stopPropagation(); exit(); });
    seek.addEventListener('input', () => {
      dragging = true; clearTimeout(hideTimer);
      const g = range(); rawSeek(g[0] + (+seek.value / 1000) * (g[1] - g[0]));
      sync();
    });
    const endDrag = () => { if (dragging) { dragging = false; showBar(); } };
    seek.addEventListener('change', endDrag); seek.addEventListener('pointerup', endDrag); seek.addEventListener('touchend', endDrag);
    ['play', 'pause', 'seeked', 'loadedmetadata'].forEach(ev => video.addEventListener(ev, () => { sync(); if (isFs()) showBar(); }));
    bus.on('time:changed', sync);

    // caption scale: same size relative to the picture as in the editor
    function scaleCaption() {
      const cap = S.dom.capText;
      if (!isFs() || !fsBase) { if (S.ui.preview.relayout) S.ui.preview.relayout(); else cap.style.zoom = ''; return; }   // not fullscreen: the preview's own zoom (relative to the main-screen picture) applies
      const r = S.ui.preview.contentRect();
      cap.style.zoom = r.w > 0 ? String(+(r.w / fsBase).toFixed(4)) : '';
    }
    function onFsChange() {
      const on = isFs();
      videoBox.classList.toggle('is-fs', on);
      document.documentElement.classList.toggle('fs-open', on);
      if (!on) { fsBase = 0; ov.classList.remove('show'); clearTimeout(hideTimer); }
      scaleCaption(); sync();
      if (on) showBar();
      // the box changes size a moment after the event: lay the caption out again once it has settled
      [60, 250, 600].forEach(ms => setTimeout(() => { scaleCaption(); window.dispatchEvent(new Event('resize')); }, ms));
    }
    document.addEventListener('fullscreenchange', onFsChange);
    document.addEventListener('webkitfullscreenchange', onFsChange);
    if (window.ResizeObserver) new ResizeObserver(scaleCaption).observe(videoBox);
    window.addEventListener('orientationchange', () => setTimeout(scaleCaption, 200));
    sync();
  }

  S.ui.player = {
    seek: seek,
    replay: replay,
    userMuted: () => (S.mainMute ? S.mainMute.userMuted() : !!video.muted),
    init() {
      const playBtn = $('playBtn'), playIcon = $('playIcon'), muteBtn = $('muteBtn'), muteIcon = $('muteIcon');
      const curTime = $('curTime'), durTime = $('durTime'), fsBtn = $('fsBtn');

      video.addEventListener('loadedmetadata', () => {
        if (S.ui.media && S.ui.media.swapping && S.ui.media.swapping()) return;      // the player was only pointed at the safe copy of the same clip (ui/media.js)
        durTime.textContent = fmt(video.duration);
        P.media.duration = video.duration || 0;
        const rt = P.media.resumeTrim; P.media.resumeTrim = null;      // set by ui/resume.js when a saved project is coming back
        P.trim.start = rt ? Math.max(0, Math.min(rt.start || 0, P.media.duration)) : 0;
        P.trim.end = rt && rt.end > P.trim.start ? Math.min(rt.end, P.media.duration) : P.media.duration;
        bus.emit('media:metadata');
      });
      playBtn.addEventListener('click', () => {
        if (!video.paused) { video.pause(); return; }
        // at (or past) the end of the cut, play() used to start and be stopped again by the trim check at once = a dead button: start from the cut's beginning
        if (P.media.duration && (video.currentTime >= P.trim.end - 0.05 || video.currentTime < P.trim.start)) rawSeek(P.trim.start);
        const pr = video.play();
        if (pr && pr.catch) pr.catch(e => {
          if (e && e.name === 'AbortError') return;                       // a new load replaced this play(): not an error
          if (S.ui.media && S.ui.media.recover && S.ui.media.recover(true)) return;   // the source went stale: point the player at the clip again
          if (S.ui.toast) S.ui.toast('เล่นวิดีโอไม่ได้' + (e && e.name ? ' [' + e.name + ']' : '') + ' — ลองกดอีกครั้ง หรือเลือกไฟล์ใหม่', 6000);
        });
      });
      video.addEventListener('play', () => {
        playIcon.innerHTML = '<path d="M6 5h4v14H6zM14 5h4v14h-4z"/>';
        if (video.currentTime < P.trim.start) video.currentTime = P.trim.start;
        loop();
      });
      video.addEventListener('pause', () => { playIcon.innerHTML = '<path d="M8 5v14l11-7z"/>'; cancelAnimationFrame(state.ui.rafId); });
      muteBtn.addEventListener('click', () => {
        const MM = S.mainMute, nowMuted = MM ? !MM.userMuted() : !video.muted;      // the speaker button is its own switch; "ปิดเสียงวิดีโอหลัก" (ui/main-mute.js) is another
        if (MM) MM.setUser(nowMuted); else video.muted = nowMuted;
        muteIcon.innerHTML = nowMuted
          ? '<path d="M16.5 12 20 8.5l-1-1-3.5 3.5L12 7.5V4L8 9H4v6h4l4 5v-3.5l3.5 3.5 1-1z"/>'
          : '<path d="M4 9v6h4l5 5V4L8 9H4z"/>';
      });
      fsBtn.addEventListener('click', () => {
        fsBase = (S.ui.preview.refWidth && S.ui.preview.refWidth()) || S.ui.preview.contentRect().w || 0;      // picture width before fullscreen: the caption is scaled by (new width / this)
        if (videoBox.requestFullscreen) videoBox.requestFullscreen();
        else if (videoBox.webkitRequestFullscreen) videoBox.webkitRequestFullscreen();
      });
      initFullscreen();
      video.addEventListener('timeupdate', () => {
        bus.emit('time:changed', video.currentTime);
        if (P.media.duration && video.currentTime >= P.trim.end - 0.02 && !video.paused) {
          video.pause(); video.currentTime = P.trim.end;
        }
      });
      video.addEventListener('seeked', () => bus.emit('time:changed', video.currentTime));

      // clock label follows the time signal
      let last = '';
      bus.on('time:changed', () => {
        const s = fmt(video.currentTime);
        if (s !== last) { last = s; curTime.textContent = s; }
      });
    }
  };
})(window.SubEd);
