/* =====================================================================
 * "ตัดวิดีโอ" — cut the loaded clip into pieces, delete / restore any piece, move the cut points (CapCut's Split + Delete).
 *
 *   project.cut = { segs: [{ id, start, end, del }], sel }
 *     segs tile the whole clip (first.start = 0, last.end = duration) in SOURCE time — the same clock as the subtitle lines,
 *     the sound tracks and the scenes, so nothing else has to be re-timed when a piece is cut: a deleted piece is simply
 *     SKIPPED, by the preview while it plays and by every exporter. (The timeline keeps the gap, drawn as a hatched block, so a
 *     deleted piece can be brought back or its edges moved at any time.)
 *
 *   SubEd.videoCut   model: split / remove / restore / moveBound / cutBefore / cutAfter, keptRanges(a,b), skipInfo(t), keptLength(a,b)
 *   UI               pieces are drawn over the video strip. Tap a piece to select it; the bottom bar becomes
 *                    « [แยก] [ตัดก่อนหน้า] [ตัดหลังจากนี้] [ลบ | กู้คืน]; the white handles of the selected piece move its cut points.
 * Emits: cut:structure (pieces added / removed / deleted / restored)  cut:timing (a cut point moved)  cut:selected
 * ===================================================================== */
(function (S) {
  'use strict';
  const bus = S.bus, P = S.state.project, C = P.cut, video = S.dom.video, $ = S.$;
  const MIN = 0.1, EPS = 1e-6;
  let seq = 0;
  const uid = () => 'v' + (++seq).toString(36) + Math.random().toString(36).slice(2, 5);
  const D = () => P.media.duration || 0;

  /* ------------------------------------------------------------ model */
  /** Make sure the pieces tile [0, duration]; anything else (new clip, bad saved data) becomes one kept piece. */
  function ensure() {
    const d = D(), s = C.segs;
    if (!(d > 0)) { C.segs = []; C.sel = null; return; }
    const ok = s.length && Math.abs(s[0].start) < 1e-3 && Math.abs(s[s.length - 1].end - d) < 0.06 &&
      s.every((x, i) => x.end > x.start && (i === 0 || Math.abs(x.start - s[i - 1].end) < 1e-3) && typeof x.id === 'string');
    if (!ok) { C.segs = [{ id: uid(), start: 0, end: d, del: false }]; C.sel = null; return; }
    s[s.length - 1].end = d;
    if (C.sel && !s.some(x => x.id === C.sel)) C.sel = null;
  }
  const get = id => C.segs.find(s => s.id === id) || null;
  const indexOf = id => C.segs.findIndex(s => s.id === id);
  function segAt(t) {
    const s = C.segs; if (!s.length) return null;
    for (let i = 0; i < s.length; i++) if (t < s[i].end - EPS) return s[i];
    return s[s.length - 1];
  }
  const changed = timing => { bus.emit(timing ? 'cut:timing' : 'cut:structure'); };
  const keptCount = () => C.segs.filter(s => !s.del).length;

  /** Cut the piece under time t in two. Returns the new (right) piece, or null when t is too close to an edge. */
  function split(t) {
    const s = segAt(t); if (!s || !(t > s.start + MIN && t < s.end - MIN)) return null;
    const tail = { id: uid(), start: +t.toFixed(3), end: s.end, del: s.del };
    s.end = tail.start;
    C.segs.splice(C.segs.indexOf(s) + 1, 0, tail); changed(false);
    return tail;
  }
  /** Delete a piece (it is skipped from now on). The last kept piece cannot be deleted. */
  function remove(id) {
    const s = get(id); if (!s || s.del) return false;
    if (keptCount() <= 1) return false;
    s.del = true; changed(false); return true;
  }
  function restore(id) { const s = get(id); if (!s || !s.del) return false; s.del = false; changed(false); return true; }
  /** Move the cut point between piece i and piece i+1. */
  function moveBound(i, t) {
    const a = C.segs[i], b = C.segs[i + 1]; if (!a || !b) return;
    t = Math.min(b.end - MIN, Math.max(a.start + MIN, t));
    a.end = b.start = +t.toFixed(3);
  }
  /** Delete the part of the piece under t that comes before t / after t. Returns false when there is nothing to delete. */
  function cutSide(t, side) {
    const s = segAt(t); if (!s || s.del) return false;
    if (side === 'before' ? t <= s.start + MIN : t >= s.end - MIN) return false;
    const tail = split(t); if (!tail) return false;
    const gone = side === 'before' ? s : tail;
    gone.del = true; changed(false);
    return gone;
  }
  /** Kept parts of [a, b] in source time, adjacent parts merged: [[from, to], ...]. */
  function keptRanges(a, b) {
    const out = [];
    C.segs.forEach(s => {
      if (s.del) return;
      const x = Math.max(a, s.start), y = Math.min(b, s.end);
      if (y - x <= 0.02) return;
      const last = out[out.length - 1];
      if (last && Math.abs(last[1] - x) < 1e-3) last[1] = y; else out.push([x, y]);
    });
    return out.length ? out : [[a, b]];
  }
  const keptLength = (a, b) => keptRanges(a, b).reduce((n, r) => n + (r[1] - r[0]), 0);
  /** When time t is inside a deleted run: { from, to } (the whole run of deleted pieces around it), else null. */
  function skipInfo(t) {
    const s = C.segs; let i = s.findIndex(x => t >= x.start - EPS && t < x.end - EPS);
    if (i < 0 || !s[i].del) return null;
    let a = i, b = i;
    while (a > 0 && s[a - 1].del) a--;
    while (b < s.length - 1 && s[b + 1].del) b++;
    return { from: s[a].start, to: s[b].end };
  }
  /** Cut the clip into pieces at these times (the scene boundaries from "จัดฉาก"). With nothing deleted yet the cut points are
   *  REPLACED, so planning again does not pile old splits on top of new ones; once a piece has been deleted the new points are only
   *  ADDED (a deleted piece stays deleted, and keeps its flag when it is split). */
  function setBounds(times) {
    const d = D(); if (!(d > 0)) return;
    ensure();
    const sorted = (times || []).map(t => +(+t).toFixed(3)).filter(t => t > MIN && t < d - MIN).sort((a, b) => a - b), cuts = [];
    sorted.forEach(t => { if (!cuts.length || t - cuts[cuts.length - 1] >= MIN) cuts.push(t); });
    if (!C.segs.some(s => s.del)) {
      const pts = [0].concat(cuts, [d]), segs = [];
      for (let i = 0; i + 1 < pts.length; i++) segs.push({ id: uid(), start: pts[i], end: pts[i + 1], del: false });
      C.segs = segs;
    } else {
      cuts.forEach(t => {
        const s = segAt(t);
        if (s && t > s.start + MIN && t < s.end - MIN) { const tail = { id: uid(), start: t, end: s.end, del: s.del }; s.end = t; C.segs.splice(C.segs.indexOf(s) + 1, 0, tail); }
      });
    }
    C.sel = null; document.body.classList.remove('vseg-selected');
    changed(false);
  }
  S.videoCut = { MIN: MIN, get: get, segAt: segAt, split: split, setBounds: setBounds, remove: remove, restore: restore, moveBound: moveBound, cutSide: cutSide,
    hold: on => { held = !!on; if (held && raf) { cancelAnimationFrame(raf); raf = 0; } else if (!held && !video.paused) kick(); },
    keptRanges: keptRanges, keptLength: keptLength, skipInfo: skipInfo, ensure: ensure, hasCuts: () => C.segs.some(s => s.del) };

  /* ------------------------------------------------------------ playing: skip what was deleted */
  let raf = 0, held = false;
  function tick() {
    raf = 0;
    if (video.paused || held) return;
    const info = skipInfo(video.currentTime);
    if (info) {
      const end = P.trim.end || D();
      if (info.to >= end - 0.03) { video.pause(); try { video.currentTime = Math.max(P.trim.start, Math.min(info.from, end)); } catch (e) {} }
      else video.currentTime = Math.max(info.to, P.trim.start);
    }
    raf = requestAnimationFrame(tick);
  }
  const kick = () => { if (!raf && !held && C.segs.length) raf = requestAnimationFrame(tick); };
  video.addEventListener('playing', kick);
  video.addEventListener('play', kick);
  video.addEventListener('pause', () => { if (raf) { cancelAnimationFrame(raf); raf = 0; } });

  /* ------------------------------------------------------------ UI */
  let layer = null, tlScroll, timeline, tip = null;
  const pct = t => (t / D() * 100) + '%';
  const sel = () => (C.sel && get(C.sel)) || null;
  const PPS = () => (S.ui.timeline && S.ui.timeline.getZoom()) || 80;
  const record = () => { if (S.history) S.history.record('cut'); };
  const toast = (m, ms) => { if (S.ui.toast) S.ui.toast(m, ms); };
  const fmt2 = S.util.fmt2;

  function setSel(id) {
    if (id && !get(id)) id = null;
    if (C.sel === id) { placeAll(); syncBar(); return; }
    C.sel = id;
    document.body.classList.toggle('vseg-selected', !!id);
    placeAll(); syncBar();
    bus.emit('cut:selected', { id: id });
  }
  function render() {
    if (!layer) return;
    layer.innerHTML = '';
    if (!D()) return;
    C.segs.forEach(s => {
      const el = document.createElement('div');
      el.className = 'vseg'; el.dataset.id = s.id;
      el.innerHTML = '<span class="vs-lbl">ลบแล้ว</span><div class="rh l"></div><div class="rh r"></div>';
      layer.appendChild(el);
      attach(el, s);
    });
    placeAll();
  }
  function placeAll() {
    if (!layer) return;
    const els = layer.querySelectorAll('.vseg');
    if (els.length !== C.segs.length) return;
    C.segs.forEach((s, i) => {
      const el = els[i]; if (el.dataset.id !== s.id) return;
      el.style.left = pct(s.start); el.style.width = pct(s.end - s.start);
      el.classList.toggle('del', !!s.del); el.classList.toggle('sel', C.sel === s.id);
      el.classList.toggle('first', i === 0); el.classList.toggle('last', i === C.segs.length - 1);
    });
  }
  function showTip(s) {
    if (!tip) { tip = document.createElement('div'); tip.className = 'cap-tip vs-tip'; }
    if (!tip.parentNode) layer.parentNode.appendChild(tip);
    tip.textContent = fmt2(s.start) + ' → ' + fmt2(s.end) + '  (' + (s.end - s.start).toFixed(2) + ' วิ)';
    tip.style.left = pct(s.start); tip.style.top = '-20px';
  }
  function hideTip() { if (tip && tip.parentNode) tip.parentNode.removeChild(tip); }

  /** A handle moves the cut point shared with the neighbour piece: side 'l' = the point before the piece, 'r' = the one after it. */
  function attach(el, s) {
    el.addEventListener('click', e => { if (!e.target.closest('.rh')) setSel(s.id); });
    ['l', 'r'].forEach(side => {
      const h = el.querySelector('.rh.' + side);
      let on = false, sx = 0, sScroll = 0, origT = 0, bi = 0, raf2 = 0, lx = 0, recorded = false;
      const apply = x => {
        const dt = ((x - sx) + (tlScroll.scrollLeft - sScroll)) / (timeline.getBoundingClientRect().width || 1) * D();
        let t = origT + dt;
        const reach = 6 / PPS(), head = video.currentTime || 0;
        if (Math.abs(head - t) <= reach) t = head;                      // snap to the playhead
        moveBound(bi, t);
        placeAll(); showTip(C.segs[bi]);
      };
      const edge = () => {
        raf2 = 0; if (!on) return;
        const r = tlScroll.getBoundingClientRect(), EDGE = 36;
        const v = lx > r.right - EDGE ? Math.min(18, (lx - (r.right - EDGE)) / 2 + 2) : lx < r.left + EDGE ? -Math.min(18, ((r.left + EDGE) - lx) / 2 + 2) : 0;
        if (v) { const b = tlScroll.scrollLeft; tlScroll.scrollLeft = b + v; if (tlScroll.scrollLeft !== b) apply(lx); }
        raf2 = requestAnimationFrame(edge);
      };
      h.addEventListener('pointerdown', e => {
        e.stopPropagation(); e.preventDefault();
        const i = indexOf(s.id); bi = side === 'l' ? i - 1 : i;
        if (bi < 0 || bi >= C.segs.length - 1) return;
        on = true; recorded = false; sx = lx = e.clientX; sScroll = tlScroll.scrollLeft;
        origT = side === 'l' ? C.segs[i].start : C.segs[i].end;
        if (!video.paused) video.pause();
        h.setPointerCapture(e.pointerId);
        if (!raf2) raf2 = requestAnimationFrame(edge);
      });
      h.addEventListener('pointermove', e => {
        if (!on) return; lx = e.clientX;
        if (!recorded) { if (Math.abs(e.clientX - sx) < 2) return; recorded = true; record(); }
        apply(e.clientX);
      });
      const end = () => { if (!on) return; on = false; hideTip(); if (raf2) { cancelAnimationFrame(raf2); raf2 = 0; } if (recorded) changed(true); };
      ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(ev => h.addEventListener(ev, end));
    });
  }

  function syncBar() {
    const s = sel(), t = video.currentTime || 0;
    const inside = s && t > s.start + MIN && t < s.end - MIN;
    const set = (id, dis) => { const b = $(id); if (b) b.disabled = !!dis; };
    set('vsSplit', !inside); set('vsCutL', !inside || s.del); set('vsCutR', !inside || s.del);
    const del = !!(s && s.del);
    const d = $('vsDel'), r = $('vsRestore');
    if (d) d.style.display = del ? 'none' : ''; if (r) r.style.display = del ? '' : 'none';
  }
  function afterEdit(msg) {
    syncBar(); placeAll();
    if (msg) toast(msg, 2400);
  }
  function initBar() {
    $('ccCut').addEventListener('click', () => {
      if (S.ui.sel && S.ui.sel.clear) S.ui.sel.clear();
      const s = segAt(video.currentTime || 0); if (s) setSel(s.id);
    });
    $('vsBack').addEventListener('click', () => setSel(null));
    $('vsSplit').addEventListener('click', () => {
      const t = video.currentTime || 0; if (!(segAt(t) && t > segAt(t).start + MIN && t < segAt(t).end - MIN)) { toast('เลื่อนเส้นเล่นไปกลางชิ้นก่อน แล้วกด “แยก”'); return; }
      record(); const tail = split(t); if (tail) { setSel(tail.id); afterEdit('แยกวิดีโอแล้ว'); }
    });
    const side = which => () => {
      const t = video.currentTime || 0, s = segAt(t);
      if (!s || s.del || (which === 'before' ? t <= s.start + MIN : t >= s.end - MIN)) { toast('เลื่อนเส้นเล่นไปกลางชิ้นก่อน'); return; }
      record(); const g = cutSide(t, which);
      if (g) { const keep = which === 'before' ? segAt(t + MIN) : segAt(t - MIN); setSel(keep ? keep.id : null); afterEdit('ลบแล้ว (กด “กู้คืน” ที่ช่องสีเทาเพื่อเอากลับ)'); }
    };
    $('vsCutL').addEventListener('click', side('before'));
    $('vsCutR').addEventListener('click', side('after'));
    $('vsDel').addEventListener('click', () => {
      const s = sel(); if (!s) return;
      if (keptCount() <= 1) { toast('ต้องเหลือวิดีโออย่างน้อยหนึ่งชิ้น'); return; }
      record(); if (remove(s.id)) afterEdit('ลบชิ้นนี้แล้ว — เล่นและส่งออกจะข้ามไป');
    });
    $('vsRestore').addEventListener('click', () => { const s = sel(); if (!s) return; record(); if (restore(s.id)) afterEdit('กู้คืนแล้ว'); });
    video.addEventListener('timeupdate', syncBar);
  }

  S.ui.videoCut = {
    clear: () => setSel(null),
    init() {
      layer = document.createElement('div'); layer.className = 'vseg-layer'; layer.id = 'vsegLayer';
      const vt = $('videoTrack'); vt.insertBefore(layer, $('dimLeft'));
      tlScroll = $('tlScroll'); timeline = $('timeline');
      initBar();
      bus.on('media:selected', () => { C.segs = []; C.sel = null; document.body.classList.remove('vseg-selected'); });
      bus.on('media:cleared', () => { C.segs = []; C.sel = null; document.body.classList.remove('vseg-selected'); if (layer) layer.innerHTML = ''; });
      bus.on('media:metadata', () => { ensure(); render(); document.body.classList.toggle('vseg-selected', !!C.sel); syncBar(); });
      bus.on('cut:structure', () => {
        ensure(); render(); document.body.classList.toggle('vseg-selected', !!C.sel); syncBar();
      });
      bus.on('cut:timing', () => { placeAll(); syncBar(); });
      bus.on('time:changed', syncBar);
      bus.on('audio:selected', e => { if (e && e.id && C.sel) setSel(null); });
      bus.on('cue:selected', e => { if (e && e.id && C.sel) setSel(null); });
      $('ccAudio').addEventListener('click', () => setSel(null));
      bus.on('timeline:zoom', () => placeAll());
    }
  };
})(window.SubEd);
