/* =====================================================================
 * UI: ค่าทศนิยมของขนาด (%) และตำแหน่ง. Turns the little number beside a slider into a field you can TYPE in
 * (e.g. 97.1 or 46.5) and gives the slider a 0.1 step, so size / position can be set to one decimal place.
 *
 * The old code writes the readout with `el.textContent = ...`; the field defines its own textContent so that code keeps
 * working unchanged (and never overwrites a value while you are typing in it).
 * Typing a value moves the slider and fires the slider's own `input` + `change` events, so every listener that
 * already reacts to the slider (preview, undo step, export) reacts to the typed value too.
 *
 * Also exposes S.ui.precise.f1(v) = one-decimal text, and S.ui.precise.r1(v) = value rounded to 0.1.
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$;

  // [slider id, readout id, unit shown after the field]
  const PAIRS = [
    ['sizeR', 'sizeNum', '%'],            // main caption size (100% = the default 32)
    ['csScale', 'csScaleNum', '%'],       // size of the chosen lines (100% = the main size)
    ['scPosY', 'scPosYNum', ''],          // main position, up-down (% of picture height)
    ['cuePosY', 'cuePosYNum', ''],        // this line, up-down
    ['cpPosY', 'cpPosYNum', ''],          // chosen lines, up-down
    ['cpPosX', 'cpPosXNum', '']           // chosen lines, left-right (% of picture width)
  ];

  const r1 = v => Math.round(v * 10) / 10;
  const f1 = v => (Math.round(v * 10) / 10).toFixed(1);

  function upgrade(sliderId, numId, unit) {
    const slider = $(sliderId), span = $(numId);
    if (!slider || !span || span.tagName === 'INPUT') return;
    slider.step = '0.1';
    const inp = document.createElement('input');
    inp.type = 'number'; inp.id = numId; inp.className = 'num-in';
    inp.step = '0.1'; inp.min = slider.min; inp.max = slider.max;
    inp.inputMode = 'decimal'; inp.autocomplete = 'off';
    inp.setAttribute('aria-label', (span.closest('.row') && span.closest('.row').querySelector('label') || { textContent: sliderId }).textContent.trim());
    inp.value = f1(parseFloat(slider.value));
    // legacy `el.textContent = v` keeps working, but never while the person is typing in the field
    Object.defineProperty(inp, 'textContent', {
      get() { return inp.value; },
      set(v) { if (document.activeElement !== inp) inp.value = String(v).replace('%', '').trim(); }
    });
    span.replaceWith(inp);
    if (unit) { const u = document.createElement('span'); u.className = 'num-unit'; u.textContent = unit; inp.after(u); }

    const commit = () => {
      let v = parseFloat(inp.value);
      if (!isFinite(v)) { inp.value = f1(parseFloat(slider.value)); return; }
      v = Math.min(parseFloat(slider.max), Math.max(parseFloat(slider.min), r1(v)));
      slider.value = String(v);
      slider.dispatchEvent(new Event('input', { bubbles: true }));
      slider.dispatchEvent(new Event('change', { bubbles: true }));
      inp.value = f1(parseFloat(slider.value));
    };
    inp.addEventListener('change', commit);
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); commit(); inp.blur(); } });
    inp.addEventListener('focus', () => { try { inp.select(); } catch (e) {} });
  }

  S.ui.precise = {
    f1: f1, r1: r1,
    init() { PAIRS.forEach(p => upgrade(p[0], p[1], p[2])); }
  };
})(window.SubEd);
