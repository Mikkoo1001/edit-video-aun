/* =====================================================================
 * UI: the CapCut-style colour row, shared by every place that colours something:
 *   [ eyedropper ] [ colour wheel ] [ the full tone palette, hue by hue, light -> dark, scroll sideways ]
 * Used by the ข้อความ tab (ui/cc-color.js), the สีเฉพาะคำ / เรืองแสง tabs (ui/extras.js) and the palette on the picture (ui/word-color.js),
 * so a word gets exactly the same colours to choose from as a whole line.
 * S.ui.palette.mount(host, pick, opts) -> { mark(color), list, wheel, eye }
 *   pick(color, first, drag): first = record an undo step (false while the wheel is being dragged); drag = a wheel drag in progress
 * ===================================================================== */
(function (S) {
  'use strict';
  // CapCut's own order: the 11 quick colours first, then the palette hue by hue (light -> dark):
  // pink, red, orange, yellow, lime / olive, green, cyan / teal, blue, purple, brown.
  const PAL = [
    '#ffffff', '#b3b3b3', '#808080', '#3f3f3f', '#000000', '#f3c70e', '#ff7f00', '#ff0856', '#cc00ff', '#0090ff', '#01b20a',
    '#ffd6f4', '#ff87ce', '#ff6ebd', '#ff3ea9', '#dc0c88', '#ba007b', '#950066',
    '#ffb7cd', '#ff88ae', '#ff6d80', '#ff4a60', '#eb1d1d', '#b51b1b', '#a20032',
    '#feb7a5', '#ffa77f', '#ff8c55', '#ff802f', '#ff6801', '#c74c00', '#a74100',
    '#f7e4bc', '#f6dc92', '#ffe473', '#fedc00', '#f6c90e', '#d29600', '#c47f00',
    '#fff9af', '#f8f284', '#efff00', '#99e000', '#80920a', '#777403',
    '#bbffb4', '#8ffb84', '#00ff18', '#00e300', '#009d00', '#007701', '#014e0a',
    '#b8ffff', '#6afffb', '#00faf0', '#00ffff', '#00cfc5', '#007876', '#00504f',
    '#caf6ff', '#a6deff', '#64bbfe', '#008efe', '#0066c5', '#0045c7', '#003287',
    '#c3b7ff', '#a387fe', '#8c6cfe', '#8f47ff', '#8200ff', '#7700b2', '#67008d',
    '#e2dacd', '#c5ab94', '#ae9471', '#927442', '#785619', '#543500', '#3e2600'
  ];

  function mount(host, pick, opts) {
    opts = opts || {};
    host.classList.add('cc-colors');
    host.innerHTML = '';
    const eye = document.createElement('button'); eye.type = 'button'; eye.className = 'cc-eye'; eye.title = 'ดูดสี';
    eye.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m14 7 3 3M4 20l1-4 9-9a2 2 0 0 1 3 0l1 1a2 2 0 0 1 0 3l-9 9-4 1zM16 5l3 3"/></svg>';
    if (!window.EyeDropper) eye.style.opacity = '.35';
    eye.addEventListener('click', () => { if (window.EyeDropper) new window.EyeDropper().open().then(r => pick(r.sRGBHex, true)).catch(() => {}); });
    const wheel = document.createElement('label'); wheel.className = 'cc-wheel'; wheel.title = 'เลือกสีเอง';
    const inp = document.createElement('input'); inp.type = 'color'; if (opts.value) inp.value = opts.value; wheel.appendChild(inp);
    let rec = false;                                           // dragging the wheel = ONE undo step, and no heavy refresh per move
    inp.addEventListener('input', () => { pick(inp.value, !rec, true); rec = true; });
    inp.addEventListener('change', () => { rec = false; pick(inp.value, false); });
    const list = document.createElement('div'); list.className = 'cc-swlist';
    PAL.forEach(c => {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'tx-sw big'; b.style.background = c; b.title = c;
      b.addEventListener('click', () => pick(c, true)); list.appendChild(b);
    });
    host.appendChild(eye); host.appendChild(wheel); host.appendChild(list);
    // a tap on a button must not take the focus (and the text selection) away from the text box / the picture
    ['pointerdown', 'mousedown'].forEach(ev => host.addEventListener(ev, e => { if (e.target.closest('button')) e.preventDefault(); }));
    return {
      list: list, wheel: inp, eye: eye,
      mark(color) {
        const cur = String(color || '').toLowerCase();
        list.querySelectorAll('.tx-sw').forEach(b => b.classList.toggle('on', b.title.toLowerCase() === cur));
        if (/^#[0-9a-f]{6}$/i.test(cur)) inp.value = cur;
      },
      setDisabled(off) { host.classList.toggle('off', !!off); eye.disabled = !!off; list.querySelectorAll('button').forEach(b => { b.disabled = !!off; }); inp.disabled = !!off; }
    };
  }

  S.ui.palette = { PAL: PAL, mount: mount };
})(window.SubEd);
