/* =====================================================================
 * UI: the start screen lists.
 *   "งานที่บันทึกไว้"  — SubEd.drafts: every clip opened for editing, with its cuts / subtitles. Tap a row (or [ทำต่อ]) to go back into it.
 *                        The one that was open when the page died / was refreshed is first, with a "ค้างไว้ล่าสุด" badge. Only [ลบ] removes one.
 *   "ประวัติการตัด"    — SubEd.clipHistory: the exported (cut) videos — the exported (cut) videos kept by SubEd.clipHistory.
 * Each row: [เปิดแก้ต่อ] loads the saved video as the clip again · [ดาวน์โหลด] · [ลบ]. Header: storage meter + [ล้างทั้งหมด].
 * Hidden while the editor is open (body.editing) and when the history is empty.
 * Listens: history:saved, media:cleared (the start screen is back).
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus;
  const MB = 1048576, GB = 1024 * MB;
  const size = n => n >= GB ? (n / GB).toFixed(2) + ' GB' : (n / MB).toFixed(1) + ' MB';
  const dur = s => { s = Math.round(s || 0); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
  const when = t => { const d = new Date(t); return d.toLocaleDateString('th-TH', { day: 'numeric', month: 'short' }) + ' ' + d.toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' }); };
  let root, listEl, meterEl, countEl, busy = false, dRoot, dList, dCount;

  const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };

  async function refresh() {
    if (!root) return;
    const H = S.clipHistory;
    const items = H ? await H.list() : [];
    root.hidden = !items.length;
    listEl.textContent = '';
    countEl.textContent = items.length ? '(' + items.length + ')' : '';
    if (!items.length) return;
    items.forEach(e => {
      const row = el('div', 'hist-row');
      const info = el('div', 'hist-info');
      info.appendChild(el('div', 'hist-name', e.name));
      info.appendChild(el('div', 'hist-meta', [when(e.savedAt), e.duration ? 'ยาว ' + dur(e.duration) : '', size(e.size), '.' + e.ext].filter(Boolean).join(' · ')));
      const btns = el('div', 'hist-btns');
      const open = el('button', 'hist-btn primary', 'เปิดแก้ต่อ'), dl = el('button', 'hist-btn', 'ดาวน์โหลด'), del = el('button', 'hist-btn danger', 'ลบ');
      [open, dl, del].forEach(b => { b.type = 'button'; btns.appendChild(b); });
      open.addEventListener('click', async e2 => {
        e2.stopPropagation(); if (busy) return; busy = true; open.disabled = true;
        const f = await H.file(e.id);
        busy = false; open.disabled = false;
        if (!f) { note('ไฟล์นี้หายไปจากเบราว์เซอร์แล้ว — ลบออกจากประวัติ'); await H.remove(e.id); return; }
        if (S.ui.media && S.ui.media.loadFiles) S.ui.media.loadFiles([f]);
      });
      dl.addEventListener('click', async e2 => {
        e2.stopPropagation();
        const f = await H.file(e.id);
        if (!f) { note('ไฟล์นี้หายไปจากเบราว์เซอร์แล้ว — ลบออกจากประวัติ'); await H.remove(e.id); return; }
        const url = URL.createObjectURL(f), a = document.createElement('a');
        a.href = url; a.download = e.name; document.body.appendChild(a); a.click(); document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 60000);
      });
      del.addEventListener('click', async e2 => { e2.stopPropagation(); del.disabled = true; await H.remove(e.id); });
      row.appendChild(info); row.appendChild(btns); listEl.appendChild(row);
    });
    meter();
  }

  async function meter() {
    const u = await S.clipHistory.usage();
    let kept = null; try { kept = navigator.storage && navigator.storage.persisted && await navigator.storage.persisted(); } catch (e) {}
    const dm = $('draftMeter');
    meterEl.textContent = dm.textContent = 'ที่เก็บในเบราว์เซอร์ใช้ไป ' + size(u.used) + (u.quota ? ' จากที่ให้ใช้ได้ ~' + size(u.quota) : '') + ' · ระบบไม่ลบอะไรให้เอง ต้องกดลบเองเท่านั้น' +
      (kept === false ? ' · เบราว์เซอร์ยังไม่รับรองการเก็บถาวร: ถ้าเครื่องเหลือพื้นที่น้อยหรือล้างข้อมูลเว็บไซต์ งานอาจหาย (แนะนำเพิ่มเว็บนี้ลงหน้าจอหลักเป็นแอป)' : '');
  }

  /** The saved drafts ("งานที่บันทึกไว้"). */
  async function refreshDrafts() {
    if (!dRoot) return;
    const items = S.drafts ? await S.drafts.list() : [];
    dRoot.hidden = !items.length;
    dList.textContent = '';
    dCount.textContent = items.length ? '(' + items.length + ')' : '';
    items.sort((a, b) => (b.open ? 1 : 0) - (a.open ? 1 : 0) || b.savedAt - a.savedAt);     // the interrupted one first
    items.forEach(r => {
      const row = el('div', 'hist-row tap'), info = el('div', 'hist-info'), name = el('div', 'hist-name', r.name || 'วิดีโอ');
      if (r.open) name.appendChild(el('span', 'hist-badge', 'ค้างไว้ล่าสุด'));
      info.appendChild(name);
      info.appendChild(el('div', 'hist-meta', ['แก้ล่าสุด ' + when(r.savedAt), r.duration ? 'ยาว ' + dur(r.duration) : '', r.cues ? 'ซับ ' + r.cues + ' ประโยค' : '', r.size ? size(r.size) : '',
        r.store === 'none' ? 'ต้องเลือกไฟล์เดิมอีกครั้ง' : ''].filter(Boolean).join(' · ')));
      const btns = el('div', 'hist-btns'), go = el('button', 'hist-btn primary', 'ทำต่อ'), del = el('button', 'hist-btn danger', 'ลบ');
      [go, del].forEach(b => { b.type = 'button'; btns.appendChild(b); });
      const enter = async ev => {
        ev.stopPropagation(); if (busy) return; busy = true; go.disabled = true; const old = go.textContent; go.textContent = 'กำลังเปิด…';
        try { await S.ui.resume.open(r.id); } finally { busy = false; go.disabled = false; go.textContent = old; }
      };
      row.addEventListener('click', enter); go.addEventListener('click', enter);
      del.addEventListener('click', async ev => {
        ev.stopPropagation();
        if (!confirm('ลบ "' + (r.name || 'วิดีโอ') + '" ออกจากงานที่บันทึกไว้? (ลบแล้วกู้คืนไม่ได้)')) return;
        del.disabled = true; await S.drafts.remove(r.id);
      });
      row.appendChild(info); row.appendChild(btns); dList.appendChild(row);
    });
    meter();
  }
  function note(msg) { meterEl.textContent = msg; }

  S.ui.historyPanel = {
    refresh: function () { refresh(); refreshDrafts(); },
    init() {
      root = $('hist'); listEl = $('histList'); meterEl = $('histMeter'); countEl = $('histCount');
      dRoot = $('drafts'); dList = $('draftList'); dCount = $('draftCount');
      if (S.clipHistory) S.clipHistory.ask();                       // ask the browser to keep our storage for good (once is enough)
      if (dRoot && S.drafts) { bus.on('drafts:changed', refreshDrafts); refreshDrafts(); }
      if (!root || !S.clipHistory) return;
      $('histClear').addEventListener('click', async () => {
        if (!confirm('ลบวิดีโอทั้งหมดในประวัติการตัด?')) return;
        await S.clipHistory.clear();
      });
      bus.on('history:saved', refresh);
      bus.on('media:cleared', () => { refresh(); refreshDrafts(); });
      refresh();
    }
  };
})(window.SubEd);
