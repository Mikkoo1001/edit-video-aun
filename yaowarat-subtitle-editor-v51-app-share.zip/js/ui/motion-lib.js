/* =====================================================================
 * UI: คลังของโมชันข้อความ (library) + แท็บ "ท่า" + ตัวควบคุมของรูปภาพ / ปุ่ม / ตัวพิกเซล / กลิตช์.
 *
 *   "คลัง" (the + button of the sheet) offers, each with a "ใช้กับ: ..." line telling what it is good for:
 *     ต้นแบบพร้อมใช้   item slides in and swings · character rises from the bottom · logo / panel spins in · queue of buttons · pixel words · "?"
 *     ไอเท็มในตัว       built-in vector stickers (phone, arrow, star, heart, fire ...)
 *     อัปโหลดรูป       your own item / character / logo picture (PNG with a see-through background is best; plain backgrounds can be keyed out)
 *     ปุ่ม              glossy 3D buttons (the red "Keyframe / Graph" buttons of the example clip) in 6 colours
 *     ข้อความพิเศษ     pixel text: white, glowing yellow, glowing red with glitch
 *   แท็บ "ท่า": pick the IN move, the LOOP move and the OUT move of the layer (like CapCut Animations: เข้า / คอมโบ / ออก); the keyframes are
 *   built from them, and the layer can still be dragged / resized (its resting pose) without breaking the entrance.
 *
 * The layer data and the drawing are in js/render/motion-text.js; the sheet / timeline in js/ui/motion-text.js (this file uses its `api`).
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, P = S.state.project, M = P.motion, MT = () => S.motionText, A = S.ui.motionText.api;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const r1 = (v, d) => +(+v).toFixed(d == null ? 3 : d);

  /* =============================================================== built-in items (vector, drawn here — free of any brand artwork) */
  const svg = inner => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="512" height="512">' + inner + '</svg>';
  const ST = 'stroke="#1a1a1a" stroke-width="5" stroke-linejoin="round" stroke-linecap="round"';
  const keys = (() => { let s = ''; for (let r = 0; r < 4; r++) for (let c = 0; c < 3; c++) s += '<circle cx="' + (40 + c * 10) + '" cy="' + (46 + r * 10) + '" r="3.6" fill="#e4e8f5"/>'; return s; })();
  const NEW_ITEM = { frac: 0.22, x: 0.5, y: 0.42, anim: { inId: 'pop', loopId: 'bob', outId: 'shrink' } };
  const ICONS = [
    { id: 'phone', th: 'โทรศัพท์', use: 'ไอเท็มสิ่งของ ของสะสม มือถือรุ่นเก่า', d: { frac: 0.24, x: 0.26, y: 0.42, anim: { inId: 'slideLtilt', loopId: 'swing', outId: 'outL' } },
      svg: svg('<rect x="30" y="4" width="40" height="92" rx="9" fill="#3d4f7a" stroke="#1b2540" stroke-width="3"/><rect x="36" y="12" width="28" height="20" rx="3" fill="#b8e089" stroke="#1b2540" stroke-width="2"/>' + keys) },
    { id: 'arrow', th: 'ลูกศรชี้', use: 'ชี้จุดสำคัญ ชี้ปุ่ม ชี้ของในภาพ', d: { frac: 0.22, x: 0.35, y: 0.5, anim: { inId: 'slideL', loopId: 'pulse', outId: 'fadeOut' } }, svg: svg('<path d="M8 38h50V16l34 34-34 34V62H8z" fill="#ffd400" ' + ST + '/>') },
    { id: 'star', th: 'ดาว', use: 'ให้คะแนน เน้นความเจ๋ง ตกแต่งมุมภาพ', d: { frac: 0.18, x: 0.5, y: 0.4, anim: { inId: 'spin', loopId: 'pulse', outId: 'shrink' } }, svg: svg('<polygon points="50,6 62,36 94,38 69,58 78,90 50,72 22,90 31,58 6,38 38,36" fill="#ffd400" ' + ST + '/>') },
    { id: 'sparkle', th: 'ประกาย', use: 'ของวิเศษ ของมีค่า ฉากสวยๆ แวววาว', d: { frac: 0.18, x: 0.55, y: 0.38, anim: { inId: 'spin', loopId: 'pulse', outId: 'shrink' } }, svg: svg('<path d="M50 4 Q54 46 96 50 Q54 54 50 96 Q46 54 4 50 Q46 46 50 4Z" fill="#ffffff" stroke="#59d3ff" stroke-width="4"/>') },
    { id: 'heart', th: 'หัวใจ', use: 'ความรัก ถูกใจ ชีวิต (เลือด) ในเกม', d: NEW_ITEM, svg: svg('<path d="M50 88C10 58 6 30 24 18 38 9 50 20 50 28 50 20 62 9 76 18 94 30 90 58 50 88Z" fill="#ff3b5c" ' + ST + '/><path d="M26 30c4-6 10-7 14-4" stroke="#fff" stroke-width="5" fill="none" stroke-linecap="round" opacity=".7"/>') },
    { id: 'fire', th: 'ไฟ', use: 'ของร้อนแรง ไวรัล ความดุเดือด', d: NEW_ITEM, svg: svg('<path d="M52 4C56 26 80 36 80 62 80 82 66 94 50 94 32 94 20 82 20 64 20 50 30 42 34 30 40 40 44 42 46 46 50 34 48 18 52 4Z" fill="#ff7a1a" ' + ST + '/><path d="M50 94C40 94 34 86 34 76 34 66 44 62 48 50 54 60 66 66 66 78 66 88 58 94 50 94Z" fill="#ffd23f"/>') },
    { id: 'bolt', th: 'สายฟ้า', use: 'พลัง ความเร็ว ไฟฟ้า การโจมตี', d: { frac: 0.2, x: 0.5, y: 0.4, anim: { inId: 'slam', loopId: 'shake', outId: 'fadeOut' } }, svg: svg('<polygon points="58,4 20,56 46,56 38,96 82,40 54,40" fill="#ffe21a" ' + ST + '/>') },
    { id: 'bomb', th: 'ระเบิด', use: 'อันตราย ปิดท้ายแรงๆ มุกระเบิดตูม', d: { frac: 0.22, x: 0.5, y: 0.45, anim: { inId: 'drop', loopId: 'shake', outId: 'shrink' } }, svg: svg('<circle cx="46" cy="58" r="34" fill="#2b2b33" stroke="#000" stroke-width="5"/><path d="M62 28 74 14" stroke="#8a6a3a" stroke-width="7" stroke-linecap="round"/><path d="M74 4v14M66 11h16M68 5l12 12M80 5 68 17" stroke="#ffb020" stroke-width="4" stroke-linecap="round"/><ellipse cx="34" cy="46" rx="8" ry="5" fill="#fff" opacity=".35" transform="rotate(-30 34 46)"/>') },
    { id: 'bulb', th: 'หลอดไฟ', use: 'ไอเดีย เคล็ดลับ ข้อสรุป', d: { frac: 0.2, x: 0.5, y: 0.4, anim: { inId: 'pop', loopId: 'blink', outId: 'shrink' } }, svg: svg('<circle cx="50" cy="40" r="30" fill="#ffe66b" ' + ST + '/><rect x="38" y="68" width="24" height="16" rx="4" fill="#bfc5d0" ' + ST + '/><rect x="42" y="84" width="16" height="9" rx="4" fill="#8a909c" ' + ST + '/><path d="M42 40c0-6 4-10 8-10" stroke="#fff" stroke-width="5" fill="none" stroke-linecap="round" opacity=".8"/>') },
    { id: 'crown', th: 'มงกุฎ', use: 'อันดับ 1 ราชา/ราชินี ของที่ดีที่สุด', d: { frac: 0.22, x: 0.5, y: 0.35, anim: { inId: 'drop', loopId: 'bob', outId: 'fadeOut' } }, svg: svg('<path d="M10 74 6 28 30 48 50 16 70 48 94 28 90 74Z" fill="#ffd400" ' + ST + '/><rect x="10" y="74" width="80" height="12" rx="3" fill="#f2a900" ' + ST + '/>') },
    { id: 'play', th: 'ปุ่มเล่น', use: 'ชวนดูคลิป ลิงก์วิดีโอ ช่องยูทูบ', d: NEW_ITEM, svg: svg('<rect x="4" y="18" width="92" height="64" rx="18" fill="#ff1f1f" stroke="#1a1a1a" stroke-width="4"/><polygon points="40,34 40,66 68,50" fill="#fff"/>') },
    { id: 'gift', th: 'ของขวัญ', use: 'รางวัล แจกของ โปรโมชัน', d: { frac: 0.22, x: 0.5, y: 0.45, anim: { inId: 'drop', loopId: 'wobble', outId: 'shrink' } }, svg: svg('<rect x="12" y="40" width="76" height="52" rx="5" fill="#ff4d6d" ' + ST + '/><rect x="8" y="28" width="84" height="18" rx="4" fill="#ff7a93" ' + ST + '/><rect x="44" y="28" width="12" height="64" fill="#ffd400" stroke="#1a1a1a" stroke-width="4"/><path d="M50 28C40 8 20 12 28 24 34 32 50 28 50 28ZM50 28C60 8 80 12 72 24 66 32 50 28 50 28Z" fill="#ffd400" ' + ST + '/>') },
    { id: 'coin', th: 'เหรียญ', use: 'เงิน ราคา คะแนนสะสม ในเกม', d: { frac: 0.18, x: 0.5, y: 0.42, anim: { inId: 'spin', loopId: 'bob', outId: 'shrink' } }, svg: svg('<circle cx="50" cy="50" r="42" fill="#ffd400" ' + ST + '/><circle cx="50" cy="50" r="30" fill="none" stroke="#f2a900" stroke-width="5"/><polygon points="50,28 55,43 71,43 58,52 63,67 50,58 37,67 42,52 29,43 45,43" fill="#f2a900"/>') },
    { id: 'target', th: 'เป้าเล็ง', use: 'จุดโฟกัส เล็งเป้า หาตัว', d: { frac: 0.24, x: 0.5, y: 0.4, anim: { inId: 'slam', loopId: 'pulse', outId: 'fadeOut' } }, svg: svg('<circle cx="50" cy="50" r="42" fill="#fff" stroke="#e11" stroke-width="7"/><circle cx="50" cy="50" r="26" fill="none" stroke="#e11" stroke-width="7"/><circle cx="50" cy="50" r="8" fill="#e11"/><path d="M50 2v22M50 76v22M2 50h22M76 50h22" stroke="#1a1a1a" stroke-width="5" stroke-linecap="round"/>') },
    { id: 'bubble', th: 'ฟองคำพูด', use: 'บทพูด ความคิด คำเตือนสั้นๆ', d: { frac: 0.26, x: 0.5, y: 0.35, anim: { inId: 'pop', loopId: 'wobble', outId: 'shrink' } }, svg: svg('<path d="M12 14H88Q96 14 96 22V60Q96 68 88 68H48L28 90V68H12Q4 68 4 60V22Q4 14 12 14Z" fill="#fff" ' + ST + '/><g fill="#1a1a1a"><circle cx="30" cy="41" r="5"/><circle cx="50" cy="41" r="5"/><circle cx="70" cy="41" r="5"/></g>') },
    { id: 'alert', th: 'เครื่องหมายตกใจ', use: 'คำเตือน ตกใจ จุดสำคัญ', d: { frac: 0.18, x: 0.5, y: 0.4, anim: { inId: 'slam', loopId: 'shake', outId: 'shrink' } }, svg: svg('<circle cx="50" cy="50" r="44" fill="#ff2a2a" ' + ST + '/><rect x="44" y="20" width="12" height="38" rx="5" fill="#fff"/><circle cx="50" cy="73" r="7" fill="#fff"/>') },
    { id: 'question', th: 'เครื่องหมายคำถาม', use: 'สงสัย ปริศนา ใครกันนะ', d: { frac: 0.18, x: 0.5, y: 0.4, anim: { inId: 'pop', loopId: 'wobble', outId: 'floatUp' } }, svg: svg('<circle cx="50" cy="50" r="44" fill="#2f6bff" ' + ST + '/><text x="50" y="72" font-size="66" font-weight="900" text-anchor="middle" fill="#fff" font-family="Arial Black,Impact,Arial,sans-serif">?</text>') },
    { id: 'check', th: 'ถูกต้อง', use: 'ผ่าน/ใช่ ทำสำเร็จ เลือกข้อนี้', d: NEW_ITEM, svg: svg('<circle cx="50" cy="50" r="44" fill="#2fbf5a" ' + ST + '/><path d="M26 52 43 68 76 34" stroke="#fff" stroke-width="10" fill="none" stroke-linecap="round" stroke-linejoin="round"/>') },
    { id: 'cross', th: 'ผิด', use: 'ไม่ผ่าน/ไม่ใช่ ห้าม อย่าทำ', d: NEW_ITEM, svg: svg('<circle cx="50" cy="50" r="44" fill="#e53935" ' + ST + '/><path d="M30 30 70 70M70 30 30 70" stroke="#fff" stroke-width="10" stroke-linecap="round"/>') }
  ];
  const svgUrl = x => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(x);

  /* =============================================================== presets for picture layers and styles */
  const PURPOSE = {
    item: { frac: 0.34, x: 0.27, y: 0.42, len: 4, anim: { inId: 'slideLtilt', loopId: 'swing', outId: 'outL' }, shadow: { on: true, color: '#000000', opacity: 55, dx: 6, dy: 8, blur: 8 } },
    char: { frac: 0.9, x: 0.5, y: 0.7, bottom: true, len: 4, anim: { inId: 'slideB', loopId: 'breathe', outId: 'outB' }, shadow: { on: false, color: '#000000', opacity: 60, dx: 0, dy: 6, blur: 10 } },
    logo: { frac: 0.7, x: 0.5, y: 0.45, len: 3.5, anim: { inId: 'spinzoom', loopId: 'none', outId: 'spinOut' }, shadow: { on: true, color: '#000000', opacity: 55, dx: 0, dy: 10, blur: 14 } },
    sticker: { frac: 0.22, x: 0.5, y: 0.42, len: 3, anim: { inId: 'pop', loopId: 'bob', outId: 'shrink' }, shadow: { on: true, color: '#000000', opacity: 45, dx: 5, dy: 7, blur: 6 } }
  };
  const BTN_COLORS = [['red', 'แดง', '#d81212', '#ffffff'], ['blue', 'น้ำเงิน', '#1f5fe0', '#ffffff'], ['green', 'เขียว', '#1fa24a', '#ffffff'], ['yellow', 'เหลือง', '#f2b705', '#2a1a00'], ['black', 'ดำ', '#26262b', '#ffffff'], ['white', 'ขาว', '#eeeeee', '#202020']];
  const TXT_STYLES = {
    plain: { th: 'ข้อความธรรมดา', use: 'ซับพิเศษ คำเน้น หัวข้อ', p: { color: '#ffffff', outline: { on: true, color: '#000000', width: 3 }, shadow: { on: false }, glow: { on: false }, pixel: 0 } },
    pxwhite: { th: 'พิกเซลขาว', use: 'ข้อความสไตล์เกม/เรโทร ทีละคำ', p: { color: '#ffffff', outline: { on: false }, shadow: { on: true, color: '#000000', opacity: 90, dx: 7, dy: 7, blur: 0 }, glow: { on: false }, pixel: 3 } },
    pxyellow: { th: 'พิกเซลเหลืองเรืองแสง', use: 'คำพูดตัวละคร คำถาม คำที่เล่นมุก', p: { color: '#ffe14a', outline: { on: false }, shadow: { on: false }, glow: { on: true, color: '#ffc800', intensity: 75, range: 12 }, pixel: 3 } },
    pxred: { th: 'พิกเซลแดงเรืองแสง+กลิตช์', use: 'คำเด็ดปิดประโยค คำขู่ คำว่า “สุด”', p: { color: '#ff3030', outline: { on: false }, shadow: { on: false }, glow: { on: true, color: '#ff0000', intensity: 85, range: 14 }, pixel: 3, glitch: { inD: 0.35, outD: 0 } } }
  };

  /* =============================================================== helpers: pictures */
  const refW = () => S.ui.preview.refWidth() || A.geometry().r.w || 360;
  function newAssetId(p) { return (p || 'u') + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36); }
  /** a picture file -> { url, w, h, name }: shrunk to 1024px on the long side so the project (and the saved copy) stays small */
  function readImage(file) {
    return new Promise((res, rej) => {
      const fr = new FileReader();
      fr.onerror = () => rej(new Error('อ่านไฟล์ไม่ได้')); fr.onload = () => {
        const im = new Image(); im.onerror = () => rej(new Error('ไฟล์นี้ไม่ใช่รูปที่เปิดได้'));
        im.onload = () => {
          let w = im.naturalWidth, h = im.naturalHeight, url = fr.result; const f = Math.min(1, 1024 / Math.max(w, h));
          if (f < 1 || file.size > 1.6e6) {
            w = Math.max(1, Math.round(w * f)); h = Math.max(1, Math.round(h * f));
            const c = document.createElement('canvas'); c.width = w; c.height = h; c.getContext('2d').drawImage(im, 0, 0, w, h);
            url = c.toDataURL(file.type === 'image/jpeg' ? 'image/jpeg' : 'image/png', 0.9);
          }
          res({ url: url, w: w, h: h, name: file.name || 'รูป' });
        };
        im.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  }
  function storeAsset(a, prefix) {
    const id = newAssetId(prefix); M.assets[id] = { name: a.name, url: a.url, w: a.w, h: a.h };
    return MT().registerAsset({ id: id, name: a.name, url: a.url, w: a.w, h: a.h }).then(() => id);
  }

  /** push ready-made layers as ONE undo step, select the last, and play them once */
  function pushLayers(list, o) {
    o = o || {}; if (!list.length) return;
    A.rec('motion'); list.forEach(L => M.layers.push(L));
    const last = list[list.length - 1]; M.sel = last.id; M.kfSel = 0; A.afterStructure();
    const first = list[0], endAll = Math.max.apply(null, list.map(l => l.end));
    A.seek(first.start + 0.01); A.play(); A.stopAfter(Math.min(endAll, first.start + (o.watch || 3.2)) + 0.3);
  }
  function span(len) { const d = A.dur(), t0 = clamp(A.cur(), 0, Math.max(0, d - 0.5)); return { start: t0, end: Math.min(d, t0 + len) }; }

  /** a picture layer built from a purpose preset (item / character / logo / sticker) */
  function pictureLayer(id, cfg, time) {
    const a = MT().getAsset(id); if (!a || !a.w) return null;
    const g = A.geometry(), rw = refW(), picH = rw * g.r.h / Math.max(1, g.r.w), t = time || span(cfg.len);
    let w = Math.round(rw * cfg.frac), hImg = w * a.h / a.w;
    if (hImg > picH * 0.96) { w = Math.round(w * picH * 0.96 / hImg); hImg = w * a.h / a.w; }
    let y = cfg.y; if (cfg.bottom) y = clamp(1 - (hImg / 2) / picH + 0.04, 0.3, 0.75);
    const L = MT().makeLayer({ kind: 'image', img: id, text: '', w: w, z: 'front', start: t.start, end: t.end, shadow: Object.assign({}, cfg.shadow),
      glow: { on: false, color: '#ffffff', intensity: 45, range: 10 }, kf: [{ t: 0, x: cfg.x, y: y, scale: 1, rot: 0, alpha: 1, ease: 'linear' }] });
    L.rest = { x: cfg.x, y: y, scale: 1, rot: 0 };
    MT().setAnim(L, Object.assign({ inD: null, outD: null }, cfg.anim));
    return L;
  }
  /** a text layer for the library (plain text, pixel styles, buttons) */
  function textLayer(o) {
    const st = P.style, t = o.time || span(o.len || 3);
    const L = MT().makeLayer(Object.assign({ kind: 'text', z: 'front', start: t.start, end: t.end, font: st.font || undefined, weight: st.weight || 700,
      size: Math.round((st.size || 32) * (o.sizeK || 1.3)),
      kf: [{ t: 0, x: o.x == null ? 0.5 : o.x, y: o.y == null ? 0.3 : o.y, scale: 1, rot: 0, alpha: 1, ease: 'linear' }] }, o.props));
    L.rest = { x: o.x == null ? 0.5 : o.x, y: o.y == null ? 0.3 : o.y, scale: 1, rot: 0 };
    MT().setAnim(L, Object.assign({ inD: null, outD: null }, o.anim || { inId: 'pop', outId: 'none' }));
    return L;
  }
  function buttonProps(key, label, pixelOn) {
    const c = BTN_COLORS.find(x => x[0] === key) || BTN_COLORS[0];
    return { text: label, color: c[3], plate: { on: true, color: c[2], radius: pixelOn ? 0.16 : 0.32, padX: 0.9, padY: 0.42 }, outline: { on: false }, shadow: { on: false }, glow: { on: false }, pixel: pixelOn ? 2 : 0 };
  }

  /* =============================================================== file picking */
  let fileEl = null, pendingPurpose = null;
  function pick(purpose) {
    if (!A.dur()) { A.toast('เพิ่มวิดีโอก่อนครับ'); return; }
    if (!fileEl) {
      fileEl = document.createElement('input'); fileEl.type = 'file'; fileEl.accept = 'image/*'; fileEl.style.display = 'none'; document.body.appendChild(fileEl);
      fileEl.addEventListener('change', async () => {
        const f = fileEl.files && fileEl.files[0], purpose2 = pendingPurpose; fileEl.value = ''; if (!f || !purpose2) return;
        try {
          const a = await readImage(f), id = await storeAsset(a, 'u');
          if (purpose2 === 'replace') {
            const L = A.selLayer(); if (!L || L.kind !== 'image') return;
            A.rec('motion'); L.img = id; MT().clearCache(); A.afterStructure(); return;
          }
          const L = pictureLayer(id, PURPOSE[purpose2]); if (!L) { A.toast('เปิดรูปนี้ไม่ได้'); return; }
          closeLib(); pushLayers([L]);
        } catch (e) { A.toast(e && e.message ? e.message : 'เพิ่มรูปไม่สำเร็จ'); }
      });
    }
    pendingPurpose = purpose; fileEl.click();
  }

  /* =============================================================== the library panel */
  let formKind = null, formColor = 'red', formStyle = 'pxyellow', btnPixel = true;
  const libEl = () => $('mgLib');
  function openLib(on) { const el = libEl(); if (!el) return; el.hidden = !on; if (on && !el.dataset.built) buildLib(); document.body.classList.toggle('mg-lib-open', !!on); }
  function toggleLib() { const el = libEl(); openLib(el.hidden); if (!el.hidden) el.scrollIntoView({ block: 'nearest' }); }
  function closeLib() { openLib(false); formKind = null; const f = $('mgForm'); if (f) f.hidden = true; }

  const card = (act, ico, title, use) => '<button type="button" class="mg-card" data-act="' + act + '"><span class="mg-cico">' + ico + '</span><span class="mg-ctx"><b>' + title + '</b><em>ใช้กับ: ' + use + '</em></span></button>';
  function buildLib() {
    const el = libEl(); el.dataset.built = '1';
    el.innerHTML =
      '<div class="mg-libhead"><b>คลังโมชัน</b><button type="button" class="tx-tbtn" data-act="close">ปิด</button></div>' +
      '<div class="mg-libsec"><b>ต้นแบบพร้อมใช้</b><small>แตะแล้วได้ทั้งหน้าตาและท่าเคลื่อนไหว</small></div>' +
      '<div class="mg-cards">' +
        card('tpl-item', '📱', 'ไอเท็มสไลด์เข้า + แกว่ง', 'ไอเท็ม/สิ่งของ โทรศัพท์ อาวุธ ของวิเศษ (อัปโหลดรูป)') +
        card('tpl-char', '🧍', 'ภาพตัวละครผุดจากล่าง', 'ภาพตัวละคร คน มาสคอต การ์ตูน (อัปโหลดรูป)') +
        card('tpl-logo', '🖼️', 'แผง/โลโก้หมุนซูมเข้า', 'โลโก้ การ์ด แผงเกม ภาพหน้าจอ (อัปโหลดรูป)') +
        card('tpl-btns', '🔴', 'รายการปุ่มโผล่ต่อคิว', 'สรุปเมนู ขั้นตอน ฟีเจอร์ หัวข้อทีละข้อ') +
        card('tpl-words', '🔤', 'ข้อความพิกเซลทีละคำ', 'ประโยคเด็ด คำพูดสั้นๆ เรียงทีละคำ') +
        card('tpl-q', '❓', '“?” เอียงหน้า ต่อท้ายซับ', 'ท้ายประโยคคำถาม ท่าทีสงสัย') +
      '</div>' +
      '<div class="mg-form" id="mgForm" hidden></div>' +
      '<div class="mg-libsec"><b>ไอเท็มในตัว</b><small>ใช้กับ: ไอคอนประกอบ ชี้จุด เสริมอารมณ์ ตกแต่งมุมภาพ — แต่ละชิ้นตั้งท่าเข้า/ท่าค้างมาให้แล้ว</small></div>' +
      '<div class="mg-icons">' + ICONS.map(ic => '<button type="button" class="mg-ic" data-ico="' + ic.id + '" title="ใช้กับ: ' + ic.use + '"><img alt="" src="' + svgUrl(ic.svg) + '"><span>' + ic.th + '</span></button>').join('') + '</div>' +
      '<div class="mg-libsec"><b>อัปโหลดรูปของคุณ</b><small>PNG พื้นโปร่งดีที่สุด · รูปที่พื้นเรียบสีเดียวให้เปิด “ตัดพื้นหลัง” ที่แท็บสไตล์</small></div>' +
      '<div class="mg-ups"><button type="button" class="chip" data-act="up-item">📦 ไอเท็ม/สิ่งของ</button><button type="button" class="chip" data-act="up-char">🧑 ภาพตัวละคร</button><button type="button" class="chip" data-act="up-logo">🏷️ โลโก้/แผง</button></div>' +
      '<div class="mg-libsec"><b>ปุ่ม</b><small>ใช้กับ: ป้ายเมนู ป้ายราคา หัวข้อ ปุ่มกดในเกม — แก้ข้อความได้</small></div>' +
      '<label class="mg-chk"><input type="checkbox" id="mgBtnPix" ' + (btnPixel ? 'checked' : '') + '> ตัวอักษรพิกเซล</label>' +
      '<div class="mg-btns">' + BTN_COLORS.map(c => '<button type="button" class="mg-btn3d" data-btn="' + c[0] + '" style="--c:' + c[2] + ';color:' + c[3] + '">' + c[1] + '</button>').join('') + '</div>' +
      '<div class="mg-libsec"><b>ข้อความสไตล์พิเศษ</b><small>ตัวพิกเซล เรืองแสง กลิตช์</small></div>' +
      '<div class="mg-cards">' + Object.keys(TXT_STYLES).map(k => card('txt-' + k, 'Aa', TXT_STYLES[k].th, TXT_STYLES[k].use)).join('') + '</div>';
    el.querySelectorAll('.mg-card,.mg-ic,.mg-btn3d').forEach((n, i) => n.style.setProperty('--k', Math.min(i, 14)));
    el.addEventListener('click', onLibClick);
    el.addEventListener('change', e => { if (e.target.id === 'mgBtnPix') btnPixel = e.target.checked; });
  }

  function onLibClick(e) {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.ico) { addIcon(b.dataset.ico); return; }
    if (b.dataset.btn) { const L = textLayer({ props: buttonProps(b.dataset.btn, 'ปุ่ม', btnPixel), y: 0.3, anim: { inId: 'fade', outId: 'fadeOut' }, sizeK: 1.1, len: 3 }); closeLib(); pushLayers([L]); return; }
    if (b.dataset.fcolor) { formColor = b.dataset.fcolor; renderForm(); return; }
    if (b.dataset.fstyle) { formStyle = b.dataset.fstyle; renderForm(); return; }
    const act = b.dataset.act; if (!act) return;
    if (act === 'close') { closeLib(); return; }
    if (act === 'tpl-item' || act === 'up-item') return pick('item');
    if (act === 'tpl-char' || act === 'up-char') return pick('char');
    if (act === 'tpl-logo' || act === 'up-logo') return pick('logo');
    if (act === 'tpl-btns') { showForm('btns'); return; }
    if (act === 'tpl-words') { showForm('words'); return; }
    if (act === 'tpl-q') { closeLib(); const n = A.addQuestionTemplate(); if (n) { A.play(); A.stopAfter(n.end + 0.3); } return; }
    if (act.indexOf('txt-') === 0) {
      const k = act.slice(4), ts = TXT_STYLES[k]; const L = textLayer({ props: Object.assign({ text: 'ข้อความ' }, ts.p), y: 0.3, sizeK: 1.5, anim: { inId: 'pop', outId: 'none' } });
      closeLib(); pushLayers([L]); return;
    }
    if (act === 'form-ok') { makeForm(); return; }
    if (act === 'form-cancel') { formKind = null; $('mgForm').hidden = true; return; }
  }

  function addIcon(id) {
    const ic = ICONS.find(x => x.id === id); if (!ic || !A.dur()) { if (!A.dur()) A.toast('เพิ่มวิดีโอก่อนครับ'); return; }
    const aid = 'b-' + ic.id;
    if (!M.assets[aid]) M.assets[aid] = { name: ic.th, url: svgUrl(ic.svg), w: 512, h: 512 };
    MT().registerAsset({ id: aid, name: M.assets[aid].name, url: M.assets[aid].url, w: 512, h: 512 }).then(() => {
      const cfg = Object.assign({}, PURPOSE.sticker, ic.d, { len: 3 }), L = pictureLayer(aid, cfg); if (!L) return;
      closeLib(); pushLayers([L]);
    });
  }

  /* ---- forms for the two queue templates */
  function showForm(kind) {
    formKind = kind; const f = $('mgForm'); f.hidden = false; renderForm(); f.scrollIntoView({ block: 'nearest' });
  }
  function renderForm() {
    const f = $('mgForm'); if (!f || !formKind) return;
    const keepTxt = f.querySelector('#mgFormTxt') ? f.querySelector('#mgFormTxt').value : null, keepGap = f.querySelector('#mgFormGap') ? f.querySelector('#mgFormGap').value : null;
    if (formKind === 'btns') {
      f.innerHTML = '<div class="mg-ft">รายการปุ่มโผล่ต่อคิว <small>1 บรรทัด = 1 ปุ่ม · เรียงลงมาจากบน</small></div>' +
        '<textarea id="mgFormTxt" rows="4" spellcheck="false">' + (keepTxt != null ? keepTxt : 'Keyframe\nGraph\nTransition\nEffects') + '</textarea>' +
        '<div class="mg-frow"><span>ห่างกัน</span><input type="range" id="mgFormGap" min="0.15" max="1.5" step="0.05" value="' + (keepGap || 0.5) + '"><b id="mgFormGapNum">' + (+(keepGap || 0.5)).toFixed(2) + ' วิ</b></div>' +
        '<div class="mg-frow"><span>สีปุ่ม</span><div class="mg-sw">' + BTN_COLORS.map(c => '<button type="button" class="' + (c[0] === formColor ? 'on' : '') + '" data-fcolor="' + c[0] + '" style="background:' + c[2] + '" title="' + c[1] + '"></button>').join('') + '</div></div>' +
        '<div class="mg-fbtns"><button type="button" class="tx-tbtn" data-act="form-ok">สร้างปุ่ม</button><button type="button" class="tx-tbtn" data-act="form-cancel">ยกเลิก</button></div>';
    } else {
      f.innerHTML = '<div class="mg-ft">ข้อความพิกเซลทีละคำ <small>คั่นคำด้วยเว้นวรรคหรือขึ้นบรรทัดใหม่ · เรียงลงมาจากบน</small></div>' +
        '<textarea id="mgFormTxt" rows="2" spellcheck="false">' + (keepTxt != null ? keepTxt : 'ง่าย ที่ สุด') + '</textarea>' +
        '<div class="mg-frow"><span>ห่างกัน</span><input type="range" id="mgFormGap" min="0.1" max="1" step="0.05" value="' + (keepGap || 0.3) + '"><b id="mgFormGapNum">' + (+(keepGap || 0.3)).toFixed(2) + ' วิ</b></div>' +
        '<div class="mg-frow"><span>สไตล์</span><div class="mg-sw wide">' + ['pxwhite', 'pxyellow', 'pxred'].map(k => '<button type="button" class="' + (k === formStyle ? 'on' : '') + '" data-fstyle="' + k + '">' + TXT_STYLES[k].th + '</button>').join('') + '</div></div>' +
        '<div class="mg-fbtns"><button type="button" class="tx-tbtn" data-act="form-ok">สร้างข้อความ</button><button type="button" class="tx-tbtn" data-act="form-cancel">ยกเลิก</button></div>';
    }
    const g = f.querySelector('#mgFormGap'); g.addEventListener('input', () => { f.querySelector('#mgFormGapNum').textContent = (+g.value).toFixed(2) + ' วิ'; });
  }
  function makeForm() {
    const f = $('mgForm'), txt = f.querySelector('#mgFormTxt').value, gap = +f.querySelector('#mgFormGap').value || 0.4;
    if (!A.dur()) { A.toast('เพิ่มวิดีโอก่อนครับ'); return; }
    const t0 = clamp(A.cur(), 0, Math.max(0, A.dur() - 0.5)), list = [];
    if (formKind === 'btns') {
      const labels = txt.split('\n').map(s => s.trim()).filter(Boolean).slice(0, 12); if (!labels.length) { A.toast('พิมพ์ข้อความปุ่มก่อนครับ'); return; }
      const n = labels.length, y0 = 0.2, step = n > 1 ? Math.min(0.115, 0.68 / (n - 1)) : 0, endAll = Math.min(A.dur(), t0 + (n - 1) * gap + 3.4);
      labels.forEach((lb, i) => { const s = Math.min(t0 + i * gap, endAll - 0.6); list.push(textLayer({ props: buttonProps(formColor, lb, btnPixel), x: 0.5, y: y0 + i * step, sizeK: 1.1, anim: { inId: 'fade', outId: 'fadeOut' }, time: { start: s, end: endAll } })); });
    } else {
      const words = txt.split(/\s+/).map(s => s.trim()).filter(Boolean).slice(0, 12); if (!words.length) { A.toast('พิมพ์ข้อความก่อนครับ'); return; }
      const n = words.length, y0 = 0.16, step = n > 1 ? Math.min(0.13, 0.62 / (n - 1)) : 0, endAll = Math.min(A.dur(), t0 + (n - 1) * gap + 2.8);
      words.forEach((w, i) => { const s = Math.min(t0 + i * gap, endAll - 0.6); list.push(textLayer({ props: Object.assign({ text: w, glitch: { inD: 0.25, outD: 0 } }, TXT_STYLES[formStyle].p, { glitch: { inD: 0.25, outD: 0 } }), x: 0.5, y: y0 + i * step, sizeK: 1.8, anim: { inId: 'pop', outId: 'fadeOut' }, time: { start: s, end: endAll } })); });
    }
    closeLib(); pushLayers(list, { watch: (list.length - 1) * gap + 2.4 });
  }

  /* =============================================================== "ท่า" tab: in / loop / out */
  let lastUse = '';
  const mvChip = (part, m) => '<button type="button" class="chip mg-mv" data-part="' + part + '" data-id="' + m.id + '" title="' + (m.use || '') + '">' + m.th + '</button>';
  function buildAnimTab() {
    $('mgInRow').innerHTML = MT().IN_MOVES.map(m => mvChip('in', m)).join('');
    $('mgLoopRow').innerHTML = MT().LOOP_MOVES.map(m => mvChip('loop', m)).join('');
    $('mgOutRow').innerHTML = MT().OUT_MOVES.map(m => mvChip('out', m)).join('');
    const root = document.querySelector('.tab-pane[data-pane="motion"]');
    root.addEventListener('click', e => {
      const b = e.target.closest('.mg-mv'); if (!b) return;
      const L = A.selLayer(); if (!L) return;
      const list = b.dataset.part === 'in' ? MT().IN_MOVES : b.dataset.part === 'loop' ? MT().LOOP_MOVES : MT().OUT_MOVES, m = list.find(x => x.id === b.dataset.id); if (!m) return;
      A.rec('motion');
      const part = b.dataset.part === 'in' ? { inId: m.id, inD: null } : b.dataset.part === 'loop' ? { loopId: m.id } : { outId: m.id, outD: null };
      MT().setAnim(L, part); lastUse = m.th + ' — ใช้กับ: ' + (m.use || '');
      MT().clearCache(); A.renderPane(); A.changed();
      const len = L.end - L.start;                                                          // show the move once
      if (b.dataset.part === 'out') { const od = (L.anim && L.anim.outId !== 'none') ? Math.min(len * 0.5, m.dur || 0.4) : 0.4; A.seek(Math.max(L.start, L.end - od - 0.7)); A.play(); A.stopAfter(L.end + 0.15); }
      else { A.seek(L.start + 0.01); A.play(); A.stopAfter(L.start + Math.min(len, b.dataset.part === 'in' ? 1.6 : 2.6) + 0.1); }
    });
  }
  const setv = (id, val, txt) => { const el = $(id); if (!el) return; if (el.type === 'checkbox') el.checked = !!val; else if (document.activeElement !== el) el.value = val; const n = $(id + 'Num'); if (n && txt != null) n.textContent = txt; };
  function syncAnim(L) {
    const a = L.anim, root = document.querySelector('.tab-pane[data-pane="motion"]');
    root.querySelectorAll('.mg-mv').forEach(b => { const id = a ? (b.dataset.part === 'in' ? a.inId : b.dataset.part === 'loop' ? a.loopId : a.outId) : null; b.classList.toggle('on', !!a && id === b.dataset.id); });
    const inM = a && MT().IN_MOVES.find(x => x.id === a.inId), outM = a && MT().OUT_MOVES.find(x => x.id === a.outId);
    const id = a && a.inD != null ? a.inD : (inM && inM.dur) || 0.4, od = a && a.outD != null ? a.outD : (outM && outM.dur) || 0.3;
    setv('mgInD', id, r1(id, 2) + 's'); setv('mgOutD', od, r1(od, 2) + 's');
    $('mgInD').disabled = !inM || !inM.make; $('mgOutD').disabled = !outM || !outM.make;
    $('mgUse').textContent = a ? (lastUse || '') : 'ท่าของเลเยอร์นี้ถูกปรับเองในแท็บคีย์เฟรม — เลือกท่าด้านบนเพื่อสร้างใหม่ (แก้ไขย้อนกลับได้ด้วยปุ่มเลิกทำ)';
    syncRest(L); syncExtras(L);
  }
  function syncRest(L) {
    L = L || A.selLayer(); if (!L) return;
    setv('mgRX', r1(L.rest.x * 100, 1), r1(L.rest.x * 100, 1) + '%'); setv('mgRY', r1(L.rest.y * 100, 1), r1(L.rest.y * 100, 1) + '%');
    setv('mgRS', Math.round(L.rest.scale * 100), Math.round(L.rest.scale * 100) + '%'); setv('mgRR', Math.round(L.rest.rot), Math.round(L.rest.rot) + '°');
  }
  function syncExtras(L) {
    setv('mgPlOn', L.plate.on); setv('mgPlColor', L.plate.color); setv('mgPlRad', Math.round(L.plate.radius * 100), Math.round(L.plate.radius * 100));
    setv('mgPixel', L.pixel, L.pixel > 0 ? L.pixel + 'px' : 'ปิด');
    setv('mgGlitIn', L.glitch.inD, L.glitch.inD > 0 ? r1(L.glitch.inD, 2) + 's' : 'ปิด'); setv('mgGlitOut', L.glitch.outD, L.glitch.outD > 0 ? r1(L.glitch.outD, 2) + 's' : 'ปิด');
    if (L.kind === 'image') { const pct = r1(L.w / refW() * 100, 1); setv('mgImgW', pct, pct + '%'); setv('mgKeyOn', L.key.on); setv('mgKeyTol', L.key.tol, L.key.tol); $('mgKeyTol').disabled = !L.key.on; }
  }

  function bindControls() {
    const bind = A.bind, mt = MT();
    bind('mgInD', L => (L.anim && L.anim.inD) || 0.4, (L, k, v) => { mt.setAnim(L, { inD: v }); }, v => r1(v, 2) + 's');
    bind('mgOutD', L => (L.anim && L.anim.outD) || 0.3, (L, k, v) => { mt.setAnim(L, { outD: v }); }, v => r1(v, 2) + 's');
    bind('mgRX', L => L.rest.x * 100, (L, k, v) => { mt.setRest(L, 'x', v / 100); }, v => r1(v, 1) + '%');
    bind('mgRY', L => L.rest.y * 100, (L, k, v) => { mt.setRest(L, 'y', v / 100); }, v => r1(v, 1) + '%');
    bind('mgRS', L => L.rest.scale * 100, (L, k, v) => { mt.setRest(L, 'scale', Math.max(0.05, v / 100)); }, v => Math.round(v) + '%');
    bind('mgRR', L => L.rest.rot, (L, k, v) => { mt.setRest(L, 'rot', v); }, v => Math.round(v) + '°');
    bind('mgPlOn', L => L.plate.on, (L, k, v) => { L.plate.on = !!v; });
    bind('mgPlColor', L => L.plate.color, (L, k, v) => { L.plate.color = v; });
    bind('mgPlRad', L => L.plate.radius * 100, (L, k, v) => { L.plate.radius = v / 100; }, v => Math.round(v));
    bind('mgPixel', L => L.pixel, (L, k, v) => { L.pixel = v; }, v => (v > 0 ? v + 'px' : 'ปิด'));
    bind('mgGlitIn', L => L.glitch.inD, (L, k, v) => { L.glitch.inD = v; }, v => (v > 0 ? r1(v, 2) + 's' : 'ปิด'));
    bind('mgGlitOut', L => L.glitch.outD, (L, k, v) => { L.glitch.outD = v; }, v => (v > 0 ? r1(v, 2) + 's' : 'ปิด'));
    bind('mgImgW', L => L.w / refW() * 100, (L, k, v) => { L.w = Math.max(4, v / 100 * refW()); }, v => r1(v, 1) + '%');
    bind('mgKeyOn', L => L.key.on, (L, k, v) => { L.key.on = !!v; $('mgKeyTol').disabled = !v; });
    bind('mgKeyTol', L => L.key.tol, (L, k, v) => { L.key.tol = v; }, v => Math.round(v));
    $('mgImgReplace').addEventListener('click', () => pick('replace'));
  }

  S.ui.motionLib = {
    init() {
      if (!$('mgLib')) return;
      bindControls(); buildAnimTab();
      // presets row (whole sets): same chips as before, now inside the "ท่า" tab
      const pre = $('mgPresets');
      if (pre && !pre.children.length) pre.innerHTML = MT().PRESETS.map(p => '<button type="button" class="chip" data-mgpre="' + p.id + '">' + p.th + '</button>').join('');
      $('mgLibBtn').addEventListener('click', toggleLib);
      S.ui.motionText.onRender(syncAnim);
      bus.on('motion:changed', () => { const L = A.selLayer(), p = document.querySelector('.tab-pane.active[data-pane="motion"]'); if (L && p) syncRest(L); });
      bus.on('motion:asset', () => { MT().clearCache(); A.schedule(); });
      bus.on('motion:structure', () => { if (!M.layers.length && libEl() && !libEl().dataset.built) { /* library opens on demand */ } });
      // restore: pictures saved with the project are decoded again
      MT().loadAssets(M.assets);
    },
    open: () => openLib(true), close: closeLib, pick: pick, ICONS: ICONS
  };
})(window.SubEd);
