/* =====================================================================
 * UI: "เสียง" — sound tracks on the timeline (CapCut style).
 *
 *   bottom bar  เสียง  ->  [ดึงเสียงจากวิดีโอ] [เสียง/เพลง] [เสียงเอฟเฟกต์] [อัดเสียง]          (add sub-bar, « goes back)
 *   a sound lands on the timeline as a teal block with its waveform and is selected at once; the bar then becomes
 *               « [แยก] [ระดับเสียง] [เฟด] [ทำซ้ำ] [ลบ]
 *   block       drag the body to move it (snaps to the playhead and to other blocks), drag the white handles to trim / stretch
 *               either end (it can only grow back as far as the sound file goes). Blocks that overlap in time stack on lanes.
 *   sound file  kept in IndexedDB together with the clip list, so a refresh brings the tracks back (same video only).
 * Model + playback + export mixing: audio-engine.js (SubEd.audioTracks).
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, state = S.state, P = state.project, A = P.audio, video = S.dom.video;
  const fmt2 = S.util.fmt2;
  const LANE_H = 28, GAP = 3, SNAP_PX = 6;
  let E, track, tlScroll, timeline;
  const dur = () => P.media.duration || 0;
  const PPS = () => (S.ui.timeline && S.ui.timeline.getZoom()) || 80;
  const pct = t => (t / dur() * 100) + '%';
  const blockOf = id => track.querySelector('.aud-block[data-id="' + id + '"]');
  const selClip = () => (A.sel && E.get(A.sel)) || null;

  /* ---------------------------------------------------------------- small helpers */
  let toastT = 0;
  function toast(msg, ms) {
    const el = $('audToast'); if (!el) return;
    el.textContent = msg; el.classList.add('show'); clearTimeout(toastT);
    if (ms !== 0) toastT = setTimeout(() => el.classList.remove('show'), ms || 3200);
  }
  S.ui.toast = toast;
  const record = () => { if (S.history) S.history.record('audio'); };
  const timeFromX = x => { const r = timeline.getBoundingClientRect(); return Math.min(dur(), Math.max(0, (x - r.left) / (r.width || 1) * dur())); };

  /* ---------------------------------------------------------------- selection + the two bars */
  function setBodyMode() {
    document.body.classList.toggle('aud-selected', !!A.sel);
    document.body.classList.toggle('aud-add', addOpen && !A.sel);
  }
  let addOpen = false;
  function select(id) {
    if (!id || !E.get(id)) id = null;
    const was = A.sel; A.sel = id;
    if (id) { addOpen = false; if (S.ui.sel && S.ui.sel.is && S.ui.sel.is()) S.ui.sel.clear(); }
    if (was !== id) closePop();
    setBodyMode(); placeAll(); syncBar();
    bus.emit('audio:selected', { id: id });
  }
  function openAdd(on) { addOpen = !!on; if (on) { if (S.ui.sel && S.ui.sel.clear) S.ui.sel.clear(); A.sel = null; } closePop(); setBodyMode(); placeAll(); }

  /* ---------------------------------------------------------------- the pop-over (volume / fade / effects / recording) */
  let popMode = null, popRecorded = false;
  function closePop() { popMode = null; document.body.classList.remove('aud-pop-open'); }
  function openPop(mode) {
    popMode = mode; popRecorded = false;
    const el = $('audPop'), c = selClip();
    let h = '<div class="ap-head"><b></b><button type="button" class="ap-ok" id="apOk" title="เสร็จ"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 5 5 9-10"/></svg></button></div>';
    if (mode === 'vol' && c) {
      h += '<div class="ap-row"><input type="range" id="apVol" min="0" max="200" step="1" value="' + Math.round(c.vol * 100) + '"><span class="ap-num" id="apVolN">' + Math.round(c.vol * 100) + '%</span></div>' +
        '<div class="ap-note">100% = ดังเท่าไฟล์เดิม · ลากไปทางขวาเพื่อเพิ่มเสียง · 0% = ปิดเสียง</div>';
    } else if (mode === 'fade' && c) {
      const mx = Math.max(0.1, Math.min(10, c.len)).toFixed(1);
      h += '<div class="ap-row"><label>เฟดเข้า</label><input type="range" id="apFi" min="0" max="' + mx + '" step="0.1" value="' + c.fadeIn.toFixed(1) + '"><span class="ap-num" id="apFiN">' + c.fadeIn.toFixed(1) + ' วิ</span></div>' +
        '<div class="ap-row"><label>เฟดออก</label><input type="range" id="apFo" min="0" max="' + mx + '" step="0.1" value="' + c.fadeOut.toFixed(1) + '"><span class="ap-num" id="apFoN">' + c.fadeOut.toFixed(1) + ' วิ</span></div>';
    } else if (mode === 'sfx') {
      const F = S.arrangeFx;
      h += '<div class="ap-grid">' + Object.keys(F.SFX).map(k => '<button type="button" class="ap-fx" data-fx="' + k + '">' + F.SFX[k] + '</button>').join('') + '</div>' +
        '<div class="ap-note">แตะเพื่อวางเสียงตรงตำแหน่งเล่นปัจจุบัน แล้วลากไปวางที่ที่ต้องการ</div>';
    } else if (mode === 'rec') {
      h += '<div class="ap-rec"><i class="ap-dot"></i><span id="apRecT">0:00</span><button type="button" class="tx-tbtn" id="apRecStop">หยุดอัด</button></div>' +
        '<div class="ap-note">วิดีโอจะเล่นไปด้วยระหว่างอัด · แนะนำให้ใช้หูฟังเพื่อไม่ให้เสียงลำโพงเข้าไมค์</div>';
    } else { closePop(); return; }
    el.innerHTML = h;
    el.querySelector('.ap-head b').textContent = { vol: 'ระดับเสียง', fade: 'เฟดเสียง', sfx: 'เสียงเอฟเฟกต์', rec: 'กำลังอัดเสียง' }[mode];
    document.body.classList.add('aud-pop-open');
  }
  function initPop() {
    const el = $('audPop');
    el.addEventListener('click', e => {
      if (e.target.closest('#apOk')) { if (popMode === 'rec') stopRec(); else closePop(); return; }
      if (e.target.closest('#apRecStop')) { stopRec(); return; }
      const fx = e.target.closest('[data-fx]');
      if (fx) addSfx(fx.dataset.fx);
    });
    el.addEventListener('input', e => {
      const c = selClip(); if (!c) return;
      if (!popRecorded) { popRecorded = true; record(); }               // one undo step per time the pop-over is opened
      if (e.target.id === 'apVol') { c.vol = +e.target.value / 100; $('apVolN').textContent = e.target.value + '%'; }
      else if (e.target.id === 'apFi') { c.fadeIn = +e.target.value; E.fitFades(c); $('apFiN').textContent = c.fadeIn.toFixed(1) + ' วิ'; $('apFi').value = c.fadeIn; $('apFo').value = c.fadeOut; $('apFoN').textContent = c.fadeOut.toFixed(1) + ' วิ'; }
      else if (e.target.id === 'apFo') { c.fadeOut = +e.target.value; E.fitFades(c); $('apFoN').textContent = c.fadeOut.toFixed(1) + ' วิ'; $('apFi').value = c.fadeIn; $('apFiN').textContent = c.fadeIn.toFixed(1) + ' วิ'; }
      else return;
      E.changed(false);
    });
  }

  /* ---------------------------------------------------------------- adding sounds */
  let busy = false;
  /** Decode picked files and lay them end to end from the playhead. */
  async function addFiles(list, kind) {
    const files = Array.from(list || []).filter(f => f && (kind === 'extract' ? (/^video\//.test(f.type) || /\.(mp4|m4v|mov|webm|mkv)$/i.test(f.name)) : (/^audio\//.test(f.type) || /\.(mp3|m4a|aac|wav|ogg|opus|flac|weba|amr)$/i.test(f.name) || /^video\//.test(f.type))));
    if (!files.length) { if (list && list.length) toast('เลือกได้เฉพาะไฟล์' + (kind === 'extract' ? 'วิดีโอ' : 'เสียง')); return; }
    if (busy) { toast('กำลังอ่านเสียงชุดก่อนหน้าอยู่ รอสักครู่'); return; }
    busy = true; E.ctx();
    let at = video.currentTime || 0, last = null, bad = [], cut = 0; const added = [];
    try {
      for (let i = 0; i < files.length; i++) {
        const f = files[i], lim = kind === 'extract' ? 300 : 200;
        if (f.size > lim * 1048576) { bad.push('“' + f.name + '” ใหญ่เกิน ' + lim + ' MB'); continue; }
        toast('กำลังอ่านเสียง ' + (i + 1) + '/' + files.length + ' · ' + f.name, 0);
        try {
          const mid = await E.addMedia(f, f.name.replace(/\.[^.]+$/, ''), kind === 'extract' ? 'extract' : 'file');
          record();
          const c = E.addClip(mid, at);
          if (!c) { bad.push('ไม่มีที่ว่างบนไทม์ไลน์ให้ “' + f.name + '”'); continue; }
          if (c.len < E.media.get(mid).dur - 0.01) cut++;
          last = c; at = E.end(c); added.push(c.id);
        } catch (err) { bad.push('“' + f.name + '” — ' + (kind === 'extract' ? 'ไม่พบเสียงที่ถอดรหัสได้ในวิดีโอนี้' : err.message)); }
      }
    } finally { busy = false; }
    if (last) select(last.id);
    const parts = [];
    if (last) parts.push('เพิ่มเสียงแล้ว' + (cut ? ' (ตัดส่วนที่เกินท้ายวิดีโอออก — ลากขอบขวาเพื่อปรับ)' : ''));
    if (bad.length) parts.push(bad.slice(0, 2).join(' · ') + (bad.length > 2 ? ' · และอีก ' + (bad.length - 2) + ' ไฟล์' : ''));
    toast(parts.join(' · '), 4200);
    if (added.length) bus.emit('audio:added', { ids: added, kind: kind === 'extract' ? 'extract' : 'file' });      // ui/voice-arrange.js listens: new narration -> scenes follow what it says
  }
  function addSfx(type) {
    E.ctx();
    const mid = E.addSfx(type); if (!mid) return;
    record();
    const c = E.addClip(mid, video.currentTime || 0);
    if (!c) { toast('ไม่มีที่ว่างบนไทม์ไลน์'); return; }
    select(c.id);
    const F = S.arrangeFx; if (F && F.player) F.player.play(type, 0.8, 0.0001);
  }

  /* ---------------------------------------------------------------- recording */
  let rec = null, recTick = 0;
  async function toggleRec() {
    if (rec) { stopRec(); return; }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) { toast('เบราว์เซอร์นี้อัดเสียงไม่ได้'); return; }
    let stream;
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
    catch (e) { toast('ไม่ได้รับอนุญาตให้ใช้ไมโครโฟน — เปิดสิทธิ์ไมโครโฟนให้เว็บนี้ในเบราว์เซอร์แล้วลองใหม่'); return; }
    E.ctx();
    const chunks = [], mr = new MediaRecorder(stream);
    rec = { mr: mr, stream: stream, at: video.currentTime || 0, t0: performance.now(), chunks: chunks };
    mr.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
    mr.onstop = async () => {
      clearInterval(recTick); stream.getTracks().forEach(t => t.stop());
      try { video.pause(); } catch (e) {}
      const r = rec; rec = null; document.body.classList.remove('aud-recording'); closePop();
      const blob = new Blob(chunks, { type: mr.mimeType || 'audio/webm' });
      if (!blob.size) { toast('ไม่ได้บันทึกเสียง'); return; }
      try {
        const n = A.clips.filter(c => (E.media.get(c.mid) || {}).kind === 'rec').length + 1;
        const mid = await E.addMedia(blob, 'อัดเสียง ' + n, 'rec');
        record();
        const c = E.addClip(mid, r.at);
        if (c) { select(c.id); toast('เพิ่มเสียงที่อัดแล้ว'); bus.emit('audio:added', { ids: [c.id], kind: 'rec' }); } else toast('ไม่มีที่ว่างบนไทม์ไลน์');
      } catch (err) { toast(err.message); }
    };
    openAdd(false); openPop('rec'); document.body.classList.add('aud-recording');
    mr.start();
    video.play().catch(() => {});
    recTick = setInterval(() => { const t = (performance.now() - rec.t0) / 1000, el = $('apRecT'); if (el) el.textContent = Math.floor(t / 60) + ':' + String(Math.floor(t % 60)).padStart(2, '0'); }, 250);
  }
  function stopRec() { if (rec && rec.mr.state !== 'inactive') rec.mr.stop(); }
  video.addEventListener('pause', () => { if (rec && !video.seeking && video.currentTime >= (P.trim.end || dur()) - 0.05) stopRec(); });

  /* ---------------------------------------------------------------- the lanes on the timeline */
  function layout() {
    const cl = A.clips, idx = cl.map((c, i) => i).sort((a, b) => cl[a].start - cl[b].start), ends = [], lane = new Array(cl.length).fill(0);
    idx.forEach(i => {
      const c = cl[i]; let l = 0;
      while (l < ends.length && ends[l] > c.start + 0.001) l++;
      ends[l] = c.start + c.len; lane[i] = l;
    });
    return { lane: lane, count: ends.length };
  }
  function waveHtml(c) {
    const m = E.media.get(c.mid); if (!m) return { pts: '', n: 1, fi: '', fo: '' };
    const i0 = Math.floor(c.in * E.PK), count = Math.max(1, Math.ceil(c.len * E.PK)), n = Math.max(12, Math.min(900, Math.round(c.len * PPS() / 2)));
    const top = [], bot = [];
    for (let k = 0; k < n; k++) {
      const a = i0 + Math.floor(k * count / n), z = Math.min(m.peaks.length, i0 + Math.max(Math.floor(k * count / n) + 1, Math.floor((k + 1) * count / n)));
      let mx = 0; for (let j = a; j < z; j++) if (m.peaks[j] > mx) mx = m.peaks[j];
      const h = Math.max(0.05, mx / 255 * Math.min(1.6, c.vol * 1.0 + 0.0)) * 44;
      top.push((k + 0.5).toFixed(1) + ',' + (50 - Math.min(48, h)).toFixed(1)); bot.unshift((k + 0.5).toFixed(1) + ',' + (50 + Math.min(48, h)).toFixed(1));
    }
    const fi = c.fadeIn > 0 ? '0,100 ' + (c.fadeIn / c.len * n).toFixed(1) + ',2' : '', fo = c.fadeOut > 0 ? ((1 - c.fadeOut / c.len) * n).toFixed(1) + ',2 ' + n + ',100' : '';
    return { pts: top.concat(bot).join(' '), n: n, fi: fi, fo: fo };
  }
  function paintWave(b, c) {
    const key = [c.mid, c.in.toFixed(2), c.len.toFixed(2), c.vol.toFixed(2), c.fadeIn.toFixed(1), c.fadeOut.toFixed(1), Math.round(c.len * PPS() / 2)].join('|');
    if (b.dataset.wk === key) return;
    b.dataset.wk = key;
    const w = waveHtml(c), svg = b.querySelector('.aud-wave');
    svg.setAttribute('viewBox', '0 0 ' + w.n + ' 100');
    svg.querySelector('polygon').setAttribute('points', w.pts);
    const fi = svg.querySelector('.fi'), fo = svg.querySelector('.fo');
    fi.setAttribute('points', w.fi); fo.setAttribute('points', w.fo);
  }
  function placeAll() {
    if (!track) return;
    const els = track.querySelectorAll('.aud-block');
    if (!dur() || els.length !== A.clips.length) return;
    const lay = layout();
    track.style.height = (lay.count * (LANE_H + GAP) + 2) + 'px';
    A.clips.forEach((c, i) => {
      const b = els[i]; if (b.dataset.id !== c.id) return;
      b.style.left = pct(c.start); b.style.width = pct(Math.max(c.len, 0.02));
      b.style.top = (lay.lane[i] * (LANE_H + GAP) + 2) + 'px'; b.style.height = LANE_H + 'px';
      b.classList.toggle('sel', A.sel === c.id);
      paintWave(b, c);
    });
  }
  function render() {
    track.innerHTML = '';
    const has = A.clips.length > 0 && dur() > 0;
    track.classList.toggle('has', has);
    if (!has) { track.style.height = ''; return; }
    A.clips.forEach(c => {
      const b = document.createElement('div');
      b.className = 'aud-block'; b.dataset.id = c.id;
      b.innerHTML = '<svg class="aud-wave" viewBox="0 0 100 100" preserveAspectRatio="none"><polygon points=""/><polyline class="fi" points="" vector-effect="non-scaling-stroke"/><polyline class="fo" points="" vector-effect="non-scaling-stroke"/></svg>' +
        '<span class="aud-name"></span><div class="rh l"></div><div class="rh r"></div>';
      b.querySelector('.aud-name').textContent = c.name;
      track.appendChild(b);
      attach(b, c);
    });
    placeAll();
  }

  /* ---------------------------------------------------------------- dragging: move / trim from either end */
  let tip = null;
  function showTip(b, c) {
    if (!tip) { tip = document.createElement('div'); tip.className = 'cap-tip aud-tip'; }
    if (!tip.parentNode) track.appendChild(tip);
    tip.textContent = fmt2(c.start) + ' → ' + fmt2(c.start + c.len) + '  (' + c.len.toFixed(2) + ' วิ)';
    tip.style.left = b.style.left; tip.style.top = (parseFloat(b.style.top) - 20) + 'px';
  }
  function hideTip() { if (tip && tip.parentNode) tip.parentNode.removeChild(tip); }
  function snapTargets(except) {
    const t = [0, dur()];
    A.clips.forEach(o => { if (o !== except) { t.push(o.start); t.push(o.start + o.len); } });
    P.subtitle.cues.forEach(o => { t.push(o.start); t.push(o.end); });
    return t;
  }
  function snap(t, targets) {
    const reach = SNAP_PX / PPS(); let best = null, bd = Infinity;
    targets.concat([video.currentTime || 0]).forEach(x => { const d = Math.abs(x - t); if (d <= reach && d < bd) { bd = d; best = x; } });
    return best;
  }
  function attach(b, c) {
    let mode = null, moved = false, sx = 0, sy = 0, lx = 0, sScroll = 0, orig = null, raf = 0, targets = null, lastSnap = null;
    const down = (e, m) => {
      e.stopPropagation();
      mode = m; moved = false; sx = lx = e.clientX; sy = e.clientY; sScroll = tlScroll.scrollLeft;
      orig = { start: c.start, in: c.in, len: c.len, fi: c.fadeIn, fo: c.fadeOut };
      b.setPointerCapture(e.pointerId);
    };
    b.addEventListener('pointerdown', e => down(e, 'move'));
    b.querySelector('.rh.l').addEventListener('pointerdown', e => down(e, 'left'));
    b.querySelector('.rh.r').addEventListener('pointerdown', e => down(e, 'right'));

    function apply(clientX) {
      const D = dur(), m = E.media.get(c.mid);
      const dt = ((clientX - sx) + (tlScroll.scrollLeft - sScroll)) / (timeline.getBoundingClientRect().width || 1) * D;
      let hit = null;
      if (mode === 'move') {
        let ns = orig.start + dt;
        const a = snap(ns, targets), z = snap(ns + orig.len, targets);
        const da = a == null ? Infinity : Math.abs(a - ns), dz = z == null ? Infinity : Math.abs(z - (ns + orig.len));
        if (da <= dz && a != null) { ns = a; hit = a; } else if (z != null) { ns = z - orig.len; hit = z; }
        c.start = Math.min(Math.max(0, ns), D - orig.len);
      } else if (mode === 'left') {
        const s = snap(orig.start + dt, targets); if (s != null) hit = s;
        const lo = Math.max(0, orig.start - orig.in), hi = orig.start + orig.len - E.MIN_LEN;
        const ns = Math.min(Math.max(s != null ? s : orig.start + dt, lo), hi), d = ns - orig.start;
        c.start = ns; c.in = orig.in + d; c.len = orig.len - d;
      } else {
        const s = snap(orig.start + orig.len + dt, targets); if (s != null) hit = s;
        const maxLen = Math.min(m ? m.dur - orig.in : orig.len, D - orig.start);
        c.len = Math.min(Math.max((s != null ? s : orig.start + orig.len + dt) - orig.start, E.MIN_LEN), maxLen);
      }
      E.fitFades(c);
      if (hit !== lastSnap) { lastSnap = hit; if (hit != null && S.haptic) S.haptic.pulse('tick'); }
      placeAll(); showTip(b, c);
    }
    function edgeScroll() {
      raf = 0;
      if (!mode || !moved) return;
      const r = tlScroll.getBoundingClientRect(), EDGE = 36;
      const v = lx > r.right - EDGE ? Math.min(18, (lx - (r.right - EDGE)) / 2 + 2) : lx < r.left + EDGE ? -Math.min(18, ((r.left + EDGE) - lx) / 2 + 2) : 0;
      if (v) { const before = tlScroll.scrollLeft; tlScroll.scrollLeft = before + v; if (tlScroll.scrollLeft !== before) apply(lx); }
      raf = requestAnimationFrame(edgeScroll);
    }
    b.addEventListener('pointermove', e => {
      if (!mode || !dur()) return;
      lx = e.clientX;
      if (e.pointerType === 'touch' && !moved && A.sel !== c.id) return;       // an unselected block is panned by touch (the strip scrolls); only a selected one is dragged
      if (!moved) {
        if (Math.abs(e.clientX - sx) < 3 && Math.abs(e.clientY - sy) < 3) return;
        moved = true;
        if (!video.paused) video.pause();
        record();
        if (A.sel !== c.id) select(c.id);
        sScroll = tlScroll.scrollLeft; targets = snapTargets(c); lastSnap = null;
        b.classList.add('dragging');
        if (!raf) raf = requestAnimationFrame(edgeScroll);
      }
      apply(e.clientX);
    });
    function finish(cancelled) {
      if (!mode) return;
      const was = moved;
      mode = null; hideTip(); b.classList.remove('dragging');
      if (raf) { cancelAnimationFrame(raf); raf = 0; }
      if (was) { placeAll(); E.changed(false); return; }
      if (!cancelled) { select(c.id); }       // a tap selects (tap the empty part of the track, or «, to let go)
    }
    b.addEventListener('pointerup', () => finish(false));
    b.addEventListener('pointercancel', () => {
      if (moved) { c.start = orig.start; c.in = orig.in; c.len = orig.len; c.fadeIn = orig.fi; c.fadeOut = orig.fo; finish(true); E.changed(false); }
      else mode = null;
    });
  }

  /* ---------------------------------------------------------------- the bars' buttons */
  function syncBar() {
    const c = selClip(), t = video.currentTime || 0;
    const sp = $('audSplit'); if (sp) sp.disabled = !c || !(t > c.start + E.MIN_LEN && t < c.start + c.len - E.MIN_LEN);
  }
  function initBars() {
    $('ccAudio').addEventListener('click', () => openAdd(true));
    $('audAddBack').addEventListener('click', () => openAdd(false));
    $('audBack').addEventListener('click', () => select(null));
    $('audExtract').addEventListener('click', () => $('audVideo').click());
    $('audSounds').addEventListener('click', () => $('audFile').click());
    $('audSfx').addEventListener('click', () => { select(null); openPop('sfx'); });
    $('audRec').addEventListener('click', () => toggleRec());
    $('audFile').addEventListener('change', e => { const f = Array.from(e.target.files || []); e.target.value = ''; addFiles(f, 'file'); });
    $('audVideo').addEventListener('change', e => { const f = Array.from(e.target.files || []); e.target.value = ''; addFiles(f, 'extract'); });
    $('audSplit').addEventListener('click', () => {
      const c = selClip(); if (!c) return;
      const at = video.currentTime || 0;
      if (!(at > c.start + E.MIN_LEN && at < c.start + c.len - E.MIN_LEN)) { toast('เลื่อนเส้นเล่นไปกลางคลิปเสียงก่อน แล้วกด “แยก”'); return; }
      record(); const t = E.split(c.id, at);
      if (t) select(t.id);
    });
    $('audVol').addEventListener('click', () => { if (popMode === 'vol') closePop(); else openPop('vol'); });
    $('audFade').addEventListener('click', () => { if (popMode === 'fade') closePop(); else openPop('fade'); });
    $('audDup').addEventListener('click', () => { const c = selClip(); if (!c) return; record(); const d = E.duplicate(c.id); if (d) select(d.id); });
    $('audDel').addEventListener('click', () => { const c = selClip(); if (!c) return; record(); E.remove(c.id); select(null); });
    initPop();
    track.addEventListener('click', e => { if (e.target === track) select(null); });
  }

  /* ---------------------------------------------------------------- keep across a refresh */
  const stored = new Set();
  let saveT = 0, armed = false;       // armed: the live clip list is the one that should be saved (never while a restore is still to run)
  const keyOf = f => f ? f.name + '|' + f.size : '';
  function saveSoon() { clearTimeout(saveT); saveT = setTimeout(save, 700); }
  async function save() {
    const f = P.media.file; if (!f || !S.persist || !armed || restoring) return;
    const mids = Array.from(new Set(A.clips.map(c => c.mid))), metas = [];
    mids.forEach(id => { const m = E.media.get(id); if (m) metas.push({ id: id, name: m.name, kind: m.kind, sfx: m.sfx }); });
    try {
      for (const m of metas) {
        const mm = E.media.get(m.id);
        if (m.kind !== 'sfx' && mm.blob && !stored.has(m.id)) { await S.persist.put('aud:file:' + m.id, mm.blob); stored.add(m.id); }
      }
      await S.persist.put('audio', { key: keyOf(f), clips: JSON.parse(JSON.stringify(A.clips)), metas: metas });
      const gone = Array.from(stored).filter(id => !mids.includes(id));
      if (gone.length) { await S.persist.del(gone.map(id => 'aud:file:' + id)).catch(() => {}); gone.forEach(id => stored.delete(id)); }
    } catch (e) { console.warn('[audio] could not keep the sound tracks:', e); }
  }
  async function forget() {
    const ids = Array.from(stored); stored.clear();
    try { await S.persist.del(['audio'].concat(ids.map(id => 'aud:file:' + id))); } catch (e) {}
  }
  let restoring = false;
  async function restore() {
    if (!S.persist) { armed = true; return; }
    if (A.clips.length || restoring) { armed = true; return; }
    restoring = true;
    try {
      let rec; try { rec = await S.persist.get('audio'); } catch (e) { return; }
      const f = P.media.file;
      if (!rec || !f || rec.key !== keyOf(f)) { if (rec) forget(); return; }
      if (A.clips.length) return;
      for (const m of rec.metas || []) {
        try {
          if (m.kind === 'sfx') { E.addSfx(m.sfx, m.id); }
          else { const blob = await S.persist.get('aud:file:' + m.id); if (blob) { await E.addMedia(blob, m.name, m.kind, m.id); stored.add(m.id); } }
        } catch (e) { console.warn('[audio] could not bring back', m.name, e); }
      }
      A.clips = (rec.clips || []).filter(c => E.media.has(c.mid));
      A.clips.forEach(c => { c.len = Math.min(c.len, Math.max(0.1, dur() - c.start)); E.fitFades(c); });
      E.changed(true);
    } finally { restoring = false; armed = true; }
  }

  S.ui.audioTrack = {
    init() {
      E = S.audioTracks; track = $('audTrack'); tlScroll = $('tlScroll'); timeline = $('timeline');
      initBars();
      bus.on('media:metadata', () => { render(); restore(); });
      bus.on('audio:structure', () => { if (A.sel && !E.get(A.sel)) { A.sel = null; setBodyMode(); } render(); syncBar(); });
      bus.on('audio:timing', () => { placeAll(); syncBar(); });
      bus.on('audio:changed', saveSoon);
      bus.on('time:changed', syncBar);
      bus.on('cue:selected', e => { if (e && e.id) { if (A.sel) select(null); if (addOpen) openAdd(false); } });
      bus.on('sheet:toggle', () => { closePop(); });
      bus.on('media:selected', () => { armed = false; stopRec(); E.clear(); stored.clear(); setBodyMode(); closePop(); });      // a new video: the old video's sounds do not belong to it
      bus.on('media:cleared', () => { armed = false; stopRec(); E.clear(); setBodyMode(); closePop(); addOpen = false; forget(); });
      bus.on('timeline:zoom', () => { if (track) { track.querySelectorAll('.aud-block').forEach(b => delete b.dataset.wk); placeAll(); } });
      window.addEventListener('resize', () => { if (track) { track.querySelectorAll('.aud-block').forEach(b => delete b.dataset.wk); placeAll(); } });
      window.addEventListener('pagehide', () => { clearTimeout(saveT); save(); });
    }
  };
})(window.SubEd);
