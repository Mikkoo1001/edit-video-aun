/* =====================================================================
 * UI: clip loading — drop zone, file picker, "change clip".
 * Emits: media:selected(file), media:cleared. (media:metadata comes from player.js)
 *
 * N clips: the picker / drop accepts several videos at once.
 *   1 video            -> the main clip, exactly as before.
 *   2+ videos          -> one timeline: the clips' sounds are merged back to back into one main sound (ui/merge-clips.js) and the clips
 *                         are laid as pictures, each for its own length ("จัดฉาก" scenes, so cutting / effects / auto subtitles all work).
 *   a sound file first -> that sound is the main clip; the videos go into the clip pool (SubEd.arrange.addMany).
 *
 * Fast open (v40): a single picked clip opens the editor AT ONCE from the picked file. The safety copy (memory / private disk, see
 * snapshot() below) is made in the background; when it is done the file behind the project is swapped for the copy ('media:relinked')
 * and the player is pointed at the copy the next time it is paused. AI / export wait for the copy with SubEd.ui.media.settled().
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, P = S.state.project;
  const video = S.dom.video;
  const drop = $('drop'), fileInput = $('fileInput'), stageWrap = $('stageWrap'), panels = $('panels');

  // A picked File is only a reference. If it lives on a cloud drive or the picker's permission lapses, reading it
  // later (e.g. when extracting audio) fails with NotReadableError. So the bytes are copied right now, while the
  // reference is fresh: up to SNAPSHOT_MAX into memory; bigger clips onto the browser's private disk storage
  // (SubEd.localCopy, no RAM needed). Only when that is impossible (no OPFS, disk full) the reference is kept — after a
  // probe read, so an unreadable file is reported here instead of in the middle of the AI step.
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  // Can the browser itself open this file (through an object URL)? Some phones / cloud placeholders refuse arrayBuffer() / slice()
  // yet still stream the file fine to a <video>. -> Promise<boolean>
  function playable(file) {
    if (video.getAttribute('src') && !video.error && video.readyState >= 1) return Promise.resolve(true);      // the editor's own player already opened this clip: it IS playable (a second detached <video> is not reliable on phones)
    return new Promise(resolve => {
      const el = document.createElement(/^audio\//.test(file.type) || /\.(mp3|m4a|aac|wav|ogg|opus|flac)$/i.test(file.name || '') ? 'audio' : 'video');
      const url = URL.createObjectURL(file);
      let done = false;
      const onMain = () => end(true);
      video.addEventListener('loadedmetadata', onMain);
      const end = ok => { if (done) return; done = true; clearTimeout(timer); video.removeEventListener('loadedmetadata', onMain); el.removeAttribute('src'); try { el.load(); } catch (e) {} URL.revokeObjectURL(url); resolve(ok); };
      const timer = setTimeout(() => end(false), 10000);
      el.preload = 'metadata'; el.muted = true;
      el.onloadedmetadata = () => end(true);
      el.onerror = () => end(false);
      el.src = url;
    });
  }

  /** Copy the picked clip now (see above). opts.allowRef: when no copy can be made, fall back to the picked file itself as long as the
   *  browser can still play it (a clear warning is toasted) instead of refusing the clip. relink() does NOT set it: there a copy is the point. */
  async function snapshot(file, onProgress, cancelled, opts) {
    const L = S.localCopy;
    let firstErr = null;
    const gone = e => cancelled() || (e && e.cancelled);
    try {
      // A copy in RAM (the whole clip, up to 300-600 MB) is what made phones kill the page "out of the blue": the disk copy needs no RAM and is what a saved draft reuses
      if (L && L.supported() && file.size > 24 * 1048576 && file.size <= S.limits.SNAPSHOT_MAX) {
        try { const kept = await L.copy(file, { onProgress: onProgress, cancelled: cancelled }); if (kept) return kept; }
        catch (e) { if (gone(e)) throw e; }
      }
      if (file.size > S.limits.SNAPSHOT_MAX) {
        if (L) {
          const kept = await L.copy(file, { onProgress: onProgress, cancelled: cancelled });
          if (kept) return kept;
          await L.probe(file);
        }
        return file;
      }
      for (let attempt = 0; ; attempt++) {
        try {
          const buf = await file.arrayBuffer();
          return new File([buf], file.name, { type: file.type, lastModified: file.lastModified });
        } catch (e) {
          if (attempt >= 2) throw e;
          await sleep(400);
        }
      }
    } catch (e) {
      if (gone(e)) throw e;
      firstErr = e;
      console.warn('[media] could not copy the picked clip into memory / disk:', e);
    }
    // 2nd route: not enough memory for a copy (typical on phones) -> the browser's private disk storage, then the file as is
    if (L && file.size <= S.limits.SNAPSHOT_MAX) {
      try {
        const kept = await L.copy(file, { onProgress: onProgress, cancelled: cancelled });
        if (kept) return kept;
      } catch (e) { if (gone(e)) throw e; }
    }
    if (opts && opts.allowRef && await playable(file)) {
      if (gone()) { const c = new Error('cancelled'); c.cancelled = true; throw c; }
      console.warn('[media] using the picked file itself (no private copy was possible)');
      if (S.ui.toast) S.ui.toast('เปิดคลิปได้ปกติ แต่เบราว์เซอร์ไม่ยอมให้คัดลอกไฟล์ (มักเกิดกับคลิปที่เลือกจากแกลเลอรี/คลาวด์) — สร้างซับและส่งออกยังใช้ได้ แต่จะทำจากการเล่นคลิปแบบเรียลไทม์ จึงช้ากว่า อยากให้เร็วให้เลือกคลิปใหม่ผ่านปุ่ม “ไฟล์”', 10000);
      return file;
    }
    throw firstErr;
  }

  /** Short, honest reason for a failed read (the old text blamed the cloud drive for every error, e.g. running out of memory). */
  function readFailMessage(e, file) {
    const name = e && e.name || '', mb = file ? (file.size / 1048576).toFixed(0) : '?';
    if (name === 'RangeError' || /memory|allocation/i.test(e && e.message || '')) return 'หน่วยความจำเบราว์เซอร์ไม่พอสำหรับคลิปนี้ (' + mb + ' MB) — ปิดแท็บอื่นแล้วลองใหม่ หรือใช้ Chrome บนคอมพิวเตอร์ / ย่อขนาดคลิปก่อน';
    if (name === 'SecurityError') return 'เบราว์เซอร์ไม่อนุญาตให้อ่านไฟล์นี้ — ลองเลือกไฟล์ใหม่จากในเครื่อง';
    if (name === 'NotFoundError') return 'ไม่พบไฟล์นี้แล้ว (ถูกย้ายหรือลบ?) — เลือกใหม่อีกครั้ง';
    return 'เบราว์เซอร์อ่านไฟล์นี้ไม่ได้ — ถ้าไฟล์อยู่บนคลาวด์ (Drive / iCloud / OneDrive) ให้ดาวน์โหลดลงเครื่องก่อน แล้วเลือกใหม่' + (name ? ' [' + name + ']' : '');
  }

  const isMedia = f => !!f && (f.type.startsWith('video/') || f.type.startsWith('audio/') || /\.(mp4|m4v|mov|webm|mkv|mp3|m4a|aac|wav|ogg|opus|flac)$/i.test(f.name || ''));
  const isVideo = f => !!f && (f.type.startsWith('video/') || /\.(mp4|m4v|mov|webm|mkv)$/i.test(f.name || ''));
  let loadSeq = 0, dropHint = null;
  let copyJob = null;                   // { seq, promise } while the safety copy of the clip that is open is being made in the background
  let swapLeft = 0;                     // > 0 while the player is silently pointed at the safe copy (player.js ignores that loadedmetadata)
  let noteEl = null;
  const resetInputs = () => { fileInput.value = ''; $('fileInput2').value = ''; };

  /** Small pill under the top bar while the copy is made (the drop zone — where this text used to be — is hidden by then). */
  function showNote(text) {
    if (!noteEl) {
      noteEl = document.createElement('div');
      noteEl.setAttribute('role', 'status');
      noteEl.style.cssText = 'position:fixed;left:50%;transform:translateX(-50%);top:calc(var(--top-h,44px) + 6px);z-index:80;max-width:92vw;padding:6px 12px;border-radius:999px;' +
        'background:rgba(27,27,27,.92);border:1px solid var(--border,#333);color:var(--text-dim,#8f8f94);font-size:12px;line-height:1.3;text-align:center;pointer-events:none;box-shadow:0 2px 10px rgba(0,0,0,.4);';
      document.body.appendChild(noteEl);
    }
    noteEl.textContent = text; noteEl.style.display = '';
  }
  function hideNote() { if (noteEl) noteEl.style.display = 'none'; }

  /** Point the player at the safe copy WITHOUT resetting trim / subtitles (player.js skips its loadedmetadata work while swapLeft > 0).
   *  If the copy cannot be played the previous source comes back. Position is kept. */
  function swapSource(file) {
    const t = video.currentTime, oldUrl = video.src, newUrl = URL.createObjectURL(file);
    let over = false;
    const restoreTime = () => { try { video.currentTime = t; } catch (e) {} };
    const clean = () => { video.removeEventListener('loadedmetadata', onMeta); video.removeEventListener('error', onErr); };
    const onMeta = () => { if (over) return; over = true; clean(); swapLeft = 0; restoreTime(); try { URL.revokeObjectURL(oldUrl); } catch (e) {} };
    const onErr = () => {
      if (over) return; over = true; clean();
      const back = () => { video.removeEventListener('loadedmetadata', back); swapLeft = 0; restoreTime(); };
      video.addEventListener('loadedmetadata', back);
      setTimeout(() => { swapLeft = 0; }, 8000);                    // never stay "swapping": that silences the player's own loading and error handling
      swapLeft = 1; video.src = oldUrl;
      try { URL.revokeObjectURL(newUrl); } catch (e) {}
    };
    swapLeft = 1;
    video.addEventListener('loadedmetadata', onMeta);
    video.addEventListener('error', onErr);
    setTimeout(() => { if (!over) onErr(); }, 10000);              // the copy neither loaded nor failed: go back to the source that worked
    video.src = newUrl;
  }
  /** Swap now when the player is paused, else at its next pause (never interrupt playback). */
  function swapWhenPaused(file, seq) {
    const go = () => { if (seq === loadSeq && P.media.file === file && video.src) swapSource(file); };
    const whenPaused = () => { if (video.paused) go(); else video.addEventListener('pause', go, { once: true }); };
    if (P.media.duration) { whenPaused(); return; }
    const off = bus.on('media:metadata', () => { off(); setTimeout(whenPaused, 0); });      // the copy was faster than the first load: let the player finish reading the clip first
  }

  // How the open clip is held (for the error text): 'memory' | 'disk' (private copy) | 'reference' (only the picked file) + why no copy
  let hold = null;
  function noteHold(file, picked) {
    const L = S.localCopy;
    const mode = file !== picked ? (L && L.nameOf(file) ? 'disk' : 'memory') : 'reference';
    hold = { mode: mode, why: mode === 'reference' && L ? L.lastWhy : '', mb: Math.round((picked.size || 0) / 1048576) };
  }
  function holdInfo() {
    if (!hold) return '';
    return 'คลิป ' + hold.mb + ' MB · ' + (hold.mode === 'reference' ? 'ไม่มีสำเนา (ใช้ไฟล์ที่เลือกโดยตรง)' + (hold.why ? ' · สาเหตุ: ' + hold.why : '') : hold.mode === 'disk' ? 'มีสำเนาในที่เก็บของเบราว์เซอร์' : 'มีสำเนาในหน่วยความจำ');
  }
  /** No private copy of the clip could be made, so the picked file is all there is — and it may stop working later (gallery / cloud files).
   *  The SOUND is small: take it out now, while the file can be read, and let "สร้างซับ" use that (ai/audio-cache.js). */
  function keepSound(file, seq) {
    if (!S.audioCache) return;
    const label = f => 'ไม่มีสำเนาของคลิป — กำลังเก็บเสียงของคลิปไว้ก่อน' + (f != null ? ' · ' + Math.floor(f * 100) + '%' : '') + ' (ตัดต่อไปได้เลย)';
    showNote(label(0));
    S.audioCache.prepare(file, { durationHint: P.media.duration, onProgress: f => { if (seq === loadSeq) showNote(label(f)); } }).then(() => {
      if (seq !== loadSeq) return;
      hideNote();
      if (S.audioCache.status(file) === 'failed' && S.audioCache.failedUnreadable(file) && S.ui.toast) {
        S.ui.toast('เปิดและตัดต่อคลิปได้ปกติ แต่เบราว์เซอร์ไม่ให้อ่านไฟล์ตรงๆ (มักเป็นคลิปจากแกลเลอรี/Google Photos) — สร้างซับกับส่งออกยังใช้ได้โดยฟังเสียงแบบเรียลไทม์ (ช้ากว่า) และหลังรีเฟรชต้องเลือกไฟล์ซ้ำ · ถ้าอยากให้เร็วและเปิดคืนเองหลังรีเฟรช ให้ติดตั้งแอป “ซับทันคำ” แล้วกดแชร์คลิปจากแกลเลอรีมาที่แอป (หรือดาวน์โหลดคลิปลงเครื่องแล้วเลือกผ่านปุ่ม “ไฟล์”)', 14000);
      }
    });
  }

  /** The safety copy of the clip that was just opened, made in the background. */
  function startCopy(picked, seq) {
    const mb = (picked.size / 1048576).toFixed(0);
    let lastPct = -1;
    const base = picked.size > S.limits.SNAPSHOT_MAX ? 'กำลังเก็บสำเนาคลิป (' + mb + ' MB) ไว้ในเบราว์เซอร์ — ตัดต่อไปได้เลย' : 'กำลังเก็บสำเนาคลิป — ตัดต่อไปได้เลย';
    showNote(base);
    const progress = f => {
      const pct = Math.floor(f * 100);
      if (seq === loadSeq && pct !== lastPct) { lastPct = pct; showNote(base + ' · ' + pct + '%'); }
    };
    const job = { seq: seq, promise: null };
    job.promise = (async () => {
      let file;
      try { file = await snapshot(picked, progress, () => seq !== loadSeq, { allowRef: true }); }
      catch (e) {
        if (seq !== loadSeq || (e && e.cancelled)) return;
        console.error('[media] cannot read the picked file:', e);
        hideNote();
        const msg = readFailMessage(e, picked);
        if (video.error || (video.readyState === 0 && !P.media.duration)) {      // nothing can be shown either: back to the picker with the reason
          closeClip();
          const hintEl = drop.querySelector('span');
          if (hintEl) { hintEl.style.color = 'var(--danger)'; hintEl.textContent = msg; }
        } else if (S.ui.toast) S.ui.toast(msg, 9000);
        return;
      }
      if (seq !== loadSeq) return;
      hideNote();
      noteHold(file, picked);
      if (file === picked) keepSound(file, seq);                      // no copy: at least keep the sound while the file still reads
      if (file !== picked) { P.media.file = file; swapWhenPaused(file, seq); }
      if (S.localCopy) S.localCopy.keepOnly(file);                    // drop the private copy of the previous clip (if any)
      bus.emit('media:relinked', file);                               // ui/resume.js stores the clip now (it waited for this copy)
    })().catch(e => { console.warn('[media] background copy failed:', e); hideNote(); })
        .then(() => { if (copyJob === job) copyJob = null; });
    copyJob = job;
  }

  /** Load one file as the main clip. Resolves to the file that was opened (null when nothing was opened).
   *  Default: the editor opens at once and the safety copy is made in the background (the resolved file is then the picked one; the project
   *  switches to the copy later). opts.wait: copy first, open after (callers that need the copy right away). opts.local: the file is already
   *  held in memory (e.g. the merged sound of several clips) — nothing to copy. */
  async function loadFile(picked, opts) {
    opts = opts || {};
    // some systems report an empty MIME type for .mov / .mkv, so the extension counts too
    if (!isMedia(picked)) return null;
    const hintEl = drop.querySelector('span');
    if (dropHint === null) dropHint = hintEl.textContent;
    const seq = ++loadSeq;
    if (picked.size > S.limits.MAX_VIDEO_BYTES) {     // 8 GB is the supported ceiling (S.limits.MAX_VIDEO_BYTES)
      hintEl.style.color = 'var(--danger)';
      hintEl.textContent = 'ไฟล์ใหญ่เกินไป (' + (picked.size / 1048576).toFixed(0) + ' MB) — รองรับสูงสุด ' + (S.limits.MAX_VIDEO_BYTES / 1048576).toFixed(0) + ' MB';
      fileInput.value = '';
      return null;
    }
    if (!opts.wait) {
      hintEl.style.color = ''; hintEl.textContent = dropHint;
      resetInputs();
      hideNote(); copyJob = null; swapLeft = 0;
      if (P.media.file) bus.emit('media:closing');          // another clip replaces the open one: ui/resume.js saves the old one a last time
      openClip(picked);
      if (S.localCopy) S.localCopy.keepOnly(picked);
      if (!opts.local) startCopy(picked, seq);                 // BEFORE the event: ui/resume.js asks copying() to know it must wait for the copy before storing the clip
      bus.emit('media:selected', picked);
      return picked;
    }
    hintEl.style.color = ''; hintEl.textContent = 'กำลังอ่านไฟล์...';
    let file, lastPct = -1;
    const mb = (picked.size / 1048576).toFixed(0);
    const progress = f => {                              // only big clips report (copy onto disk)
      const pct = Math.floor(f * 100);
      if (seq === loadSeq && pct !== lastPct) { lastPct = pct; hintEl.textContent = 'กำลังคัดลอกคลิปใหญ่ (' + mb + ' MB) เก็บไว้ในเบราว์เซอร์ ' + pct + '% — ทำครั้งเดียว ช่วยให้ถอดซับ/ส่งออกไม่พัง'; }
    };
    try { file = await snapshot(picked, progress, () => seq !== loadSeq, { allowRef: true }); }
    catch (e) {
      if (seq !== loadSeq || (e && e.cancelled)) return null;
      console.error('[media] cannot read the picked file:', e);
      hintEl.style.color = 'var(--danger)';
      hintEl.textContent = readFailMessage(e, picked);
      resetInputs();
      return null;
    }
    if (seq !== loadSeq) return null;
    hintEl.style.color = ''; hintEl.textContent = dropHint;
    resetInputs();
    hideNote(); copyJob = null; swapLeft = 0;
    if (P.media.file) bus.emit('media:closing');          // another clip replaces the open one: ui/resume.js saves the old one a last time
    openClip(file);
    if (S.localCopy) S.localCopy.keepOnly(file);         // drop the private copy of the previous clip (if any)
    noteHold(file, picked);
    bus.emit('media:selected', file);
    if (file === picked && !opts.local) keepSound(file, seq);
    return file;
  }
  /** n videos picked together: put every sound one after another into ONE main sound (ui/merge-clips.js) and lay the pictures
   *  (the clips themselves) along it, each for its own length. Resolves true when that worked, false when the caller should fall back. */
  async function mergeAndLoad(videos) {
    const hintEl = drop.querySelector('span');
    if (dropHint === null) dropHint = hintEl.textContent;
    const seq = ++loadSeq, fail = msg => { hintEl.style.color = 'var(--danger)'; hintEl.textContent = msg; };
    const clips = [], bad = [];
    try {
      for (let i = 0; i < videos.length; i++) {
        hintEl.style.color = ''; hintEl.textContent = 'กำลังอ่านคลิป ' + (i + 1) + '/' + videos.length + ' · ' + videos[i].name;
        const f = videos[i], known = S.arrange.clips().find(c => c.sig === S.arrange.sigOf(f));
        if (known) { if (!clips.includes(known)) clips.push(known); continue; }
        try { clips.push(await S.arrange.addClipFile(f)); } catch (e) { bad.push(e.message); }
        if (seq !== loadSeq) return true;
      }
      if (!clips.length) { fail(bad[0] || 'อ่านคลิปไม่ได้'); return true; }
      const built = await S.ui.mergeClips.build(clips, (i, n, name) => { if (seq === loadSeq) { hintEl.style.color = ''; hintEl.textContent = 'กำลังรวมเสียง ' + (i + 1) + '/' + n + ' · ' + name; } });
      if (seq !== loadSeq) return true;
      hintEl.textContent = dropHint;
      const main = await loadFile(built.file, { local: true });      // the merged sound is built in memory: no safety copy to wait for
      if (!main) return true;
      const off = bus.on('media:metadata', () => {
        off();
        if (P.media.file !== main) return;
        S.arrange.layMerged(clips);
        const notes = [];
        if (built.silent.length) notes.push(built.silent.length + ' คลิปไม่มีเสียงที่อ่านได้ (ใส่เป็นช่วงเงียบ)');
        if (bad.length) notes.push('ข้าม ' + bad.length + ' ไฟล์ที่เปิดไม่ได้');
        if (S.ui.toast) S.ui.toast('รวม ' + clips.length + ' คลิปต่อกันแล้ว' + (notes.length ? ' · ' + notes.join(' · ') : ''));
      });
      const offClear = bus.on('media:cleared', () => { off(); offClear(); });
      return true;
    } catch (e) {
      console.warn('[media] could not merge the clips:', e);
      hintEl.textContent = dropHint; hintEl.style.color = '';
      if (S.ui.toast) S.ui.toast('รวมคลิปไม่สำเร็จ (' + (e && e.message || e) + ') — โหลดเป็นคลิปแรกก่อน แล้วใส่คลิปที่เหลือในจัดฉาก', 7000);   // was silent: it looked like "only one video loads"
      return false;
    }
  }

  /** Several files picked at once. 2+ videos: they become one timeline, one after another. */
  async function loadFiles(list) {
    list = (list || []).filter(isMedia);
    if (!list.length) return;
    const videos = list.filter(isVideo);
    if (videos.length >= 2 && isVideo(list[0]) && S.arrange && S.arrange.addClipFile && S.ui.mergeClips) {
      if (await mergeAndLoad(videos)) return;
    }
    const main = await loadFile(list[0], { wait: list.length > 1 });      // several files: the others are laid against the main clip's copy, so it is made first
    if (!main) return;
    if (videos.length < 2 && !(videos.length === 1 && !isVideo(list[0]))) return;      // one video as the main clip: nothing more to add (a sound file as main + 1 video still adds it)
    const all = videos.map(f => f === list[0] ? main : f);                 // the main clip is used from its in-memory copy
    const off = bus.on('media:metadata', () => {
      off();
      if (P.media.file !== main || !S.arrange || !S.arrange.addMany) return;
      S.arrange.addMany(all, { even: isVideo(list[0]) });      // sound file first: each video for its own length; merge fell back: equal shares
    });
    const offClear = bus.on('media:cleared', () => { off(); offClear(); });
  }

  /** Put a clip into the player and show the editor (no events: callers decide whether this is a new clip or a resume). */
  function openClip(file) {
    recovered = 0;
    if (video.src) URL.revokeObjectURL(video.src);
    video.src = URL.createObjectURL(file);
    P.media.file = file;
    stageWrap.classList.add('show');
    panels.classList.add('show');
    document.body.classList.add('editing');
    drop.style.display = 'none';
  }

  /** The loaded clip can no longer be read (access lapsed, file on a cloud drive ...): take the SAME file again and swap it in
   *  WITHOUT touching subtitles / style / trim. Only the file that AI + export read from changes; the player keeps playing.
   *  -> Promise<{ ok, msg }> */
  async function relink(picked) {
    const cur = P.media.file;
    if (!cur || !picked) return { ok: false, msg: 'ไม่มีคลิปที่เปิดอยู่' };
    if (picked.name !== (cur.name || picked.name) && cur.name && !/^รวม \d+ คลิป/.test(cur.name)) return { ok: false, msg: 'ชื่อไฟล์ไม่ตรงกับคลิปเดิม (“' + cur.name + '”) — เลือกไฟล์เดิม' };
    if (picked.size !== cur.size) return { ok: false, msg: 'ขนาดไฟล์ไม่ตรงกับคลิปเดิม — เลือกไฟล์เดิมอันเดียวกัน' };
    let file;
    try { file = await snapshot(picked, () => {}, () => false); }
    catch (e) { return { ok: false, msg: 'เบราว์เซอร์ยังอ่านไฟล์นี้ไม่ได้ — ถ้าอยู่บนคลาวด์ให้ดาวน์โหลดลงเครื่องก่อน' }; }
    if (P.media.file !== cur) return { ok: false, msg: 'คลิปเปลี่ยนไปแล้ว' };
    P.media.file = file;
    if (S.localCopy) S.localCopy.keepOnly(file);
    noteHold(file, picked);
    if (file === picked) keepSound(file, loadSeq);
    bus.emit('media:relinked', file);
    return { ok: true, msg: '' };
  }

  /** The player's source went stale (revoked URL, file behind it replaced): point the <video> at the open clip again, keeping the position.
   *  Tried once per source (`force` = the play button just failed). -> true when it started. */
  let recovered = 0;
  function recover(force) {
    const f = P.media.file;
    if (!f || swapLeft > 0 || (recovered >= 2 && !force) || recovered >= 4) return false;
    recovered++;
    const t = video.currentTime || 0, old = video.src;
    swapLeft = 1;
    const fin = () => { video.removeEventListener('loadedmetadata', fin); swapLeft = 0; try { video.currentTime = t; } catch (e) {} };
    video.addEventListener('loadedmetadata', fin);
    setTimeout(() => { swapLeft = 0; }, 8000);
    video.src = URL.createObjectURL(f);
    if (old) { try { URL.revokeObjectURL(old); } catch (e) {} }
    return true;
  }

  /** Close the editor and go back to the picker (✕). Also stops a safety copy that is still being made. */
  function closeClip() {
    loadSeq++; copyJob = null; swapLeft = 0; hideNote();
    stageWrap.classList.remove('show'); panels.classList.remove('show'); document.body.classList.remove('editing'); S.ui.tabs.close();
    drop.style.display = ''; video.pause(); if (video.src) URL.revokeObjectURL(video.src); video.removeAttribute('src'); video.load();
    S.project.resetMedia();
    hold = null; if (S.audioCache) S.audioCache.clear();
    if (S.localCopy) S.localCopy.keepOnly(null);
    bus.emit('media:cleared');
  }

  S.ui.media = {
    open: openClip,
    /** Promise that resolves once the background safety copy of the open clip is finished (at once when there is none). AI / export await it. */
    settled: () => copyJob ? copyJob.promise.then(() => {}, () => {}) : Promise.resolve(),
    copying: () => !!copyJob,
    swapping: () => swapLeft > 0,
    recover: recover,
    relink: relink,
    holdInfo: holdInfo,
    pick: () => fileInput.click(),    // ui/resume.js asks for the original file again (a draft whose video could not be kept)
    loadFiles: loadFiles,          // ui/history-panel.js re-opens a saved video through the normal loading route
    init() {
      // The video picker accepts video/* only: on Android that opens the phone's gallery (thumbnails + durations) after the
      // one-time permission, instead of the plain file manager that extensions / audio types would force.
      drop.addEventListener('click', e => { if (e.target.closest('#dropAudio, .drop-btn')) return; fileInput.click(); });
      // เลือกจากแกลเลอรี: accept="video/*" only -> the phone's gallery / photo picker (thumbnails + durations). เลือกจากไฟล์: the extensions are listed too,
      // so Android / desktop open the file manager (cloud drives, Downloads ...). A browser can never read the gallery behind the user's back: this picker IS the direct route.
      const fileInput2 = $('fileInput2');
      $('dropGallery').addEventListener('click', e => { e.stopPropagation(); fileInput.click(); });
      $('dropFiles').addEventListener('click', e => { e.stopPropagation(); fileInput2.click(); });
      [fileInput, fileInput2].forEach(inp => inp.addEventListener('change', e => { const files = Array.from(e.target.files || []); loadFiles(files); }));
      // a clip the browser cannot decode (codec / damaged file): say so, instead of leaving a black editor with a 0:00 length
      video.addEventListener('error', () => {
        if (swapLeft > 0 || !video.getAttribute('src') || !P.media.file) return;
        if (recover(false)) return;                                    // first try: take the clip from its file again, silently
        if (S.ui.toast) S.ui.toast('เบราว์เซอร์เปิดวิดีโอนี้ไม่ได้ (ไฟล์เสียหายหรือโคเดกที่เครื่องไม่รองรับ เช่น HEVC บางเครื่อง) — ลองแปลงเป็น MP4 (H.264) หรือเลือกไฟล์อื่น', 9000);
      });
      const audioInput = $('audioInput');
      $('dropAudio').addEventListener('click', e => { e.stopPropagation(); audioInput.click(); });
      audioInput.addEventListener('change', e => { const f = e.target.files[0]; e.target.value = ''; loadFile(f); });
      ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('drag'); }));
      ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('drag'); }));
      drop.addEventListener('drop', e => loadFiles(Array.from(e.dataTransfer.files || [])));
      $('changeClip').addEventListener('click', () => { bus.emit('media:closing'); closeClip(); });      // ui/resume.js saves the clip as a draft a last time, then the editor is reset
    }
  };
})(window.SubEd);
