/* =====================================================================
 * "เสียงใหม่" — when a sound is added on the เสียง track, the จัดฉาก scenes are cut and filled to match what it SAYS.
 *
 *   1. Listen   the sound that was added (narration / recording / sound pulled from a video) is turned into words with the same
 *               transcriber the subtitles use (Groq Whisper / Gemini, keys from the ซับอัตโนมัติ sheet). No speech found (music):
 *               with "ตัดตามจังหวะเสียง" on the scenes are still cut on its rhythm (clips in order), with it off nothing is changed.
 *   2. Cut      the stretch the sound covers is cut on ITS RHYTHM ("ตัดตามจังหวะเสียง", default): the beats / syllable onsets of the sound, pulled
 *               toward its pauses and sentence edges, every scene between the min and max length of the จัดฉาก sheet. With the switch off
 *               the จัดฉาก mode is used instead (ตามซับ · ตามช่วงเงียบ · ทุก N วินาที). Scenes outside that stretch stay as they were.
 *   3. Look     (needs a Gemini key) time-stamped frames of every video in the pool (one picture for a still) go to Gemini ONCE: what happens in it, which
 *               characters / animals / objects / places are in it (named when recognised), and which parts are usable. Kept on the clip (clip.ai) and reused.
 *               Gemini never names a real person from a face, so the names come from what the user supplies: the cast list (A.cast), a note on a clip (clip.names ✎),
 *               the narration, the file name. With A.webSearch Gemini may also search the web (Google Search grounding) to find what a character / item / place is called.
 *               Looking is redone when the cast list or the web switch changed since a clip was looked at (clip.aiKey).
 *   4. Match    Gemini reads the words of each scene against those descriptions and names the video, the second inside a usable part, and why.
 *               No Gemini key / a failed call -> the videos are laid in order (the sound still decides where the cuts are).
 *   5. Fit      with "ตัดความยาวตามเสียง" on, the export range (trim) becomes the stretch of the new sound. Subtitle lines are only
 *               written when there are none yet (existing lines are never replaced).
 *
 *   Runs by itself on the bus event  audio:added { ids, kind }  (switch: จัดฉากตามเสียงที่เพิ่ม), or from the button
 *   "วิเคราะห์เสียงแล้วจัดฉาก" for the selected / last sound.   Undo: the scene undo of จัดฉาก (and the cut history).
 *   Pure helpers for tests: SubEd.voiceArrange.snapEdge / freeSpot / ensureTiling / onsetsOf / planRhythm / fitUsable.
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, P = S.state.project, A = P.arrange, AU = P.audio, video = S.dom.video;
  const MIN_SCENE = 0.2, FRAME_BUDGET = 40;
  let busy = false, hinted = false;
  const dur = () => P.media.duration || 0;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const val = id => { const el = $(id); return el && el.value ? String(el.value).trim() : ''; };
  const ft = t => { t = Math.max(0, t || 0); const m = Math.floor(t / 60); return m + ':' + (t - m * 60).toFixed(1).padStart(4, '0'); };
  const msgOf = e => (e && e.message) || String(e);
  const say = (m, kind) => { const el = $('arrVoiceInfo'); if (el) { el.textContent = m || ''; el.className = 'status' + (kind ? ' ' + kind : ''); } };
  const toast = (m, ms) => { if (S.ui.toast) S.ui.toast(m, ms); };
  const hideToast = () => { const el = $('audToast'); if (el) el.classList.remove('show'); };
  const media = id => (S.audioTracks && S.audioTracks.media.get(id)) || null;
  const kindOf = c => { const m = media(c.mid); return m ? m.kind : ''; };
  const EXT = { 'audio/mpeg': '.mp3', 'audio/mp3': '.mp3', 'audio/wav': '.wav', 'audio/x-wav': '.wav', 'audio/webm': '.webm', 'video/webm': '.webm', 'audio/ogg': '.ogg', 'audio/mp4': '.m4a', 'audio/x-m4a': '.m4a', 'audio/aac': '.aac', 'video/mp4': '.mp4' };

  /* ------------------------------------------------------------ pure helpers */
  /** A span edge that lies within MIN_SCENE of an existing scene boundary (or of 0 / the end) is moved onto it, so no sliver is left behind. */
  function snapEdge(t, scenes, D) {
    if (t < MIN_SCENE) return 0;
    if (D - t < MIN_SCENE) return D;
    for (let i = 0; i < scenes.length; i++) {
      if (Math.abs(t - scenes[i].start) < MIN_SCENE) return scenes[i].start;
      if (Math.abs(t - scenes[i].end) < MIN_SCENE) return scenes[i].end;
    }
    return t;
  }
  /** Where in clip `c` (length d) can a scene of `len` seconds start, as close to `at` as possible, without overlapping a part already used? */
  function freeSpot(d, at, len, list) {
    const L = Math.min(len, d), clash = x => list.some(u => x < u[1] - 0.05 && x + L > u[0] + 0.05);
    if (!clash(at)) return at;
    let best = null;
    [0].concat(list.map(u => u[1])).forEach(x => { if (x + L <= d + 0.01 && !clash(x)) { const k = Math.abs(x - at); if (!best || k < best.k) best = { x: x, k: k }; } });
    return best ? best.x : at;
  }
  /** Scenes sorted and tiling [0, D]: a hole is closed by stretching the scene before it (or, at the very start, the first scene backwards). */
  function ensureTiling(list, D) {
    list.sort((a, b) => a.start - b.start);
    for (let i = 0; i < list.length; i++) {
      const s = list[i], prev = list[i - 1];
      if (i === 0) { if (s.start > 0) { const g = s.start; if (s.clipId) s.offset = +Math.max(0, (s.offset || 0) - g).toFixed(3); s.start = 0; } }
      else if (s.start > prev.end + 1e-3) prev.end = s.start;
      else if (s.start < prev.end - 1e-3) s.start = prev.end;
    }
    if (list.length && list[list.length - 1].end < D) list[list.length - 1].end = D;
    return list;
  }
  /** Loudness per 20 ms straight from a decoded AudioBuffer (the sound is already decoded in the เสียง store, no second decode). */
  function envOf(buf) {
    const HOP = 0.02, n = Math.max(2, Math.round(buf.sampleRate * HOP)), chs = [], rms = [];
    for (let k = 0; k < Math.min(2, buf.numberOfChannels); k++) chs.push(buf.getChannelData(k));
    for (let i = 0; i + n <= buf.length; i += n) {
      let s = 0, cnt = 0;
      for (let j = 0; j < n; j += 2) { let v = 0; for (let k = 0; k < chs.length; k++) v += chs[k][i + j]; v /= chs.length; s += v * v; cnt++; }
      rms.push(Math.sqrt(s / cnt));
    }
    return { hop: HOP, rms: rms };
  }

  /** Rhythm of a decoded sound: where the energy jumps (a beat, a syllable, speech starting again after a pause). -> [{ t: seconds in the file, s: strength 0..1 }] */
  function onsetsOf(buf) {
    const env = envOf(buf), n = env.rms.length, hop = env.hop; if (n < 10) return [];
    const db = new Float32Array(n), sm = new Float32Array(n), flux = new Float32Array(n), back = 5;
    for (let i = 0; i < n; i++) db[i] = 20 * Math.log10(Math.max(env.rms[i], 1e-5));
    for (let i = 0; i < n; i++) sm[i] = (db[Math.max(0, i - 1)] + db[i] + db[Math.min(n - 1, i + 1)]) / 3;
    for (let i = back; i < n; i++) { let m = 0; for (let k = 1; k <= back; k++) m += sm[i - k]; flux[i] = Math.max(0, sm[i] - m / back); }
    let mean = 0, sq = 0; for (let i = 0; i < n; i++) mean += flux[i]; mean /= n;
    for (let i = 0; i < n; i++) sq += (flux[i] - mean) * (flux[i] - mean);
    const thr = Math.max(3, mean + Math.sqrt(sq / n)), win = Math.max(1, Math.round(0.12 / hop)), out = []; let mx = 0;
    for (let i = back; i < n; i++) {
      if (flux[i] < thr) continue;
      let top = true;
      for (let k = Math.max(0, i - win); k <= Math.min(n - 1, i + win); k++) if (flux[k] > flux[i] || (flux[k] === flux[i] && k < i)) { top = false; break; }
      if (top) { out.push({ t: +(i * hop).toFixed(3), s: flux[i] }); if (flux[i] > mx) mx = flux[i]; }
    }
    out.forEach(o => { o.s = mx ? o.s / mx : 0; });
    return out;
  }
  /** Cut points for [a, b] on the rhythm: in every window (min..max scene length after the last cut) take the strongest onset, helped by `soft` hints
   *  (sentence edges, pauses: [{t, w}]) and by being near a comfortable length. Returns [a, ..., b]. */
  function planRhythm(a, b, ons, soft, minLen, maxLen) {
    const minL = Math.max(0.5, minLen), maxL = Math.max(minL * 1.3, maxLen), pref = Math.min(maxL, minL * 1.8);
    const hint = t => { let w = 0; for (let i = 0; i < soft.length; i++) if (Math.abs(soft[i].t - t) <= 0.25 && soft[i].w > w) w = soft[i].w; return w; };
    const out = [a]; let last = a;
    for (let g = 0; g < 100000 && b - last > minL * 1.6; g++) {
      let best = null, bs = -1e9;
      ons.forEach(o => {
        if (o.t < last + minL || o.t > last + maxL || b - o.t < minL * 0.6) return;
        const sc = o.s + hint(o.t) - 0.35 * Math.abs(o.t - last - pref) / maxL;
        if (sc > bs) { bs = sc; best = o.t; }
      });
      const cut = best != null ? best : clamp(last + maxL, last + minL, Math.max(last + minL, b - minL * 0.6));
      if (cut >= b - 0.05) break;
      out.push(+cut.toFixed(3)); last = cut;
    }
    out.push(+b.toFixed(3));
    return out;
  }
  /** Start `at` of a scene (len s) moved into a part of the clip Gemini marked usable, as late as needed for the scene to fit inside it. */
  function fitUsable(c, at, len) {
    const I = c.ai; if (!I || !I.segments || !I.segments.length) return at;
    const L = Math.min(len, c.duration || len), m = [];
    I.segments.filter(g => g.usable).forEach(g => { const l = m[m.length - 1]; if (l && g.from <= l[1] + 0.05) l[1] = Math.max(l[1], g.to); else m.push([g.from, g.to]); });
    if (!m.length) return at;
    for (let i = 0; i < m.length; i++) if (at >= m[i][0] - 0.01 && at < m[i][1] - 0.2) return Math.max(m[i][0], Math.min(at, m[i][1] - L));
    let best = m[0], bd = 1e9;
    m.forEach(r => { const d = Math.min(Math.abs(at - r[0]), Math.abs(at - r[1])); if (d < bd) { bd = d; best = r; } });
    return at < best[0] ? best[0] : Math.max(best[0], best[1] - L);
  }
  /** The rhythm of one sound clip on the TIMELINE clock (only the part of the file that is on the timeline). */
  function onsetsOfClip(c) {
    const m = media(c.mid); if (!m || !m.buf) return [];
    try { return onsetsOf(m.buf).filter(o => o.t >= c.in && o.t <= c.in + c.len).map(o => ({ t: +(o.t - c.in + c.start).toFixed(3), s: o.s })); } catch (e) { return []; }
  }

  /* ------------------------------------------------------------ listening */
  function setup() {
    const groq = val('apiKey'), gem = val('geminiKey'), mode = val('aiMode') || 'groq-gemini';
    const provider = (mode === 'groq-gemini' && !gem) ? 'groq-whisper' : mode;
    return { groq: groq, gem: gem, mode: mode, provider: provider, canListen: provider === 'gemini' ? !!gem : !!groq };
  }
  /** Words of one sound clip on the TIMELINE clock (only the part of the file that is actually on the timeline). */
  async function transcribeSound(c, st, onPct) {
    const m = media(c.mid); if (!m || !m.blob) return [];
    const blob = m.blob, file = (blob instanceof File) ? blob : new File([blob], (m.name || 'voice') + (EXT[String(blob.type || '').split(';')[0]] || '.webm'), { type: blob.type || 'audio/webm' });
    const r = await S.ai.transcribe({
      provider: st.provider, file: file, language: val('langSel') || 'th', apiKey: st.groq, geminiKey: st.gem, geminiModel: val('geminiModel'),
      maxChars: P.subtitle.segmentation.maxChars, onStatus: m2 => say(m2), onProgress: onPct
    });
    const shift = c.start - c.in, a = c.start, b = c.start + c.len;
    return (r.words || []).filter(w => w.end > c.in + 0.01 && w.start < c.in + c.len - 0.01)
      .map(w => Object.assign({}, w, { start: clamp(w.start + shift, a, b), end: clamp(w.end + shift, a, b) }));
  }
  function pausesOf(c) {
    const m = media(c.mid); if (!m || !m.buf) return [];
    try {
      return S.arrange.pauseRanges(envOf(m.buf), A.silMin)
        .map(r => [r[0] - c.in + c.start, r[1] - c.in + c.start]).filter(r => r[1] > c.start && r[0] < c.start + c.len)
        .map(r => [Math.max(c.start, r[0]), Math.min(c.start + c.len, r[1])]);
    } catch (e) { return []; }
  }

  /* ------------------------------------------------------------ looking */
  /** `n` small time-stamped JPEG frames of one pool clip, spread over its length. */
  /** The one picture of a still clip (wider than a video frame so the text in it stays readable). */
  async function stillFrame(c) {
    const el = S.arrange.hiddenMedia(c.url, true);
    try {
      await new Promise(res => { if (el.readyState >= 1) res(); else { el.addEventListener('loadedmetadata', res, { once: true }); el.addEventListener('error', res, { once: true }); setTimeout(res, 5000); } });
      if (!el.videoWidth) return [];
      const w = Math.min(640, el.videoWidth), h = Math.max(2, Math.round(w * el.videoHeight / el.videoWidth)), cv = document.createElement('canvas'); cv.width = w; cv.height = h;
      cv.getContext('2d').drawImage(el, 0, 0, w, h);
      return [{ t: 0, b64: cv.toDataURL('image/jpeg', 0.7).split(',')[1] }];
    } finally { try { el.removeAttribute('src'); el.remove(); } catch (e) {} }
  }
  async function sampleFrames(c, n) {
    if (c.still) return stillFrame(c);
    const el = S.arrange.hiddenVideo(c.url), out = [];
    try {
      await new Promise(res => { if (el.readyState >= 1) res(); else { el.onloadedmetadata = res; el.onerror = res; setTimeout(res, 4000); } });
      const d = c.duration || el.duration || 1, cnt = Math.max(1, Math.min(n, Math.ceil(d / 3)));
      for (let k = 0; k < cnt; k++) {
        const t = clamp(d * (k + 0.5) / cnt, 0, Math.max(0, d - 0.1));
        await new Promise(res => { const tm = setTimeout(res, 2500); el.addEventListener('seeked', () => { clearTimeout(tm); res(); }, { once: true }); el.currentTime = t; });
        if (!el.videoWidth) continue;
        const w = 256, h = Math.max(2, Math.round(w * el.videoHeight / el.videoWidth)), cv = document.createElement('canvas'); cv.width = w; cv.height = h;
        cv.getContext('2d').drawImage(el, 0, 0, w, h);
        out.push({ t: +t.toFixed(2), b64: cv.toDataURL('image/jpeg', 0.6).split(',')[1] });
      }
    } finally { try { el.removeAttribute('src'); el.load(); el.remove(); } catch (e) {} }
    return out;
  }

  /* ------------------------------------------------------------ cutting */
  const MODE_LABEL = { cue: 'ตามประโยคของเสียงนี้', silence: 'ตามช่วงเงียบ' };
  /** Boundaries [a .. b] for the stretch, following the จัดฉาก mode: cue = sentences of the new speech, silence = its pauses, fixed = a grid. */
  function planOver(a, b, cues, pauses) {
    const len = b - a; let mode = A.mode, cands = [];
    if (mode === 'cue' && !cues.length) mode = 'silence';
    if (mode === 'cue') for (let i = 1; i < cues.length; i++) cands.push(cues[i].start > cues[i - 1].end ? (cues[i - 1].end + cues[i].start) / 2 : cues[i].start);
    else if (mode === 'fixed') for (let t = A.fixedLen; t < len; t += A.fixedLen) cands.push(t + a);
    else { mode = 'silence'; cands = pauses.map(r => (r[0] + r[1]) / 2); }
    const rel = cands.map(t => t - a), PB = S.arrange.planBounds;
    const rb = mode === 'fixed' ? PB(rel, len, Math.min(A.minLen, A.fixedLen), A.fixedLen + 0.5) : PB(rel, len, A.minLen, A.maxLen);
    return { bounds: rb.map(t => +(t + a).toFixed(3)), mode: mode };
  }

  /* ------------------------------------------------------------ the whole job */
  const runBtn = () => $('arrVoiceRun');
  async function run(ids, opts) {
    opts = opts || {};
    if (busy) { if (opts.manual) say('กำลังวิเคราะห์เสียงชุดก่อนหน้าอยู่ รอสักครู่', 'err'); return; }
    const D = dur(), f0 = P.media.file; if (!D || !f0) return;
    const sounds = (ids || []).map(id => AU.clips.find(c => c.id === id)).filter(c => c && kindOf(c) !== 'sfx').sort((x, y) => x.start - y.start);
    if (!sounds.length) { if (opts.manual) say('ยังไม่มีเสียงให้วิเคราะห์ — เพิ่มเสียงบรรยายในแทร็ก “เสียง” ก่อน', 'err'); return; }
    if (opts.auto && sounds.every(c => c.len < 1.5)) return;                             // a click / a short effect is no narration
    if (!A.clips.length) { if (opts.manual) say('ยังไม่มีคลิปวิดีโอในจัดฉาก — เพิ่มคลิปก่อน แล้วค่อยให้จัดฉากตามเสียง', 'err'); return; }
    const st = setup(), rhythm = A.voiceRhythm !== false;
    if (!st.canListen && !opts.manual && !rhythm) {
      const need = st.provider === 'gemini' ? 'Gemini' : 'Groq';
      say('ใส่ ' + need + ' API Key (ในแท็บซับอัตโนมัติ) เพื่อให้ถอดคำพูดของเสียงที่เพิ่มแล้วจัดฉากตามเอง', '');
      if (!hinted) { hinted = true; toast('ใส่ ' + need + ' API Key ในแท็บซับอัตโนมัติ เพื่อให้จัดฉากตามคำพูดของเสียงที่เพิ่มอัตโนมัติ', 5200); }
      return;
    }
    busy = true; if (runBtn()) runBtn().disabled = true;
    const prog = m => { say(m); toast(m, 0); };
    let final = '', kind = 'ok', detailText = '';
    try {
      /* 1 — listen */
      let words = [], note = '';
      if (st.canListen) {
        for (let i = 0; i < sounds.length; i++) {
          const tag = sounds.length > 1 ? ' ' + (i + 1) + '/' + sounds.length : '';
          prog('กำลังถอดคำพูดของเสียงที่เพิ่ม' + tag + '...');
          try { words = words.concat(await transcribeSound(sounds[i], st, p => prog('กำลังถอดคำพูดของเสียงที่เพิ่ม' + tag + '... ' + Math.round(p) + '%'))); }
          catch (e) { note += ' · ถอดเสียงไม่สำเร็จ (' + msgOf(e) + ')'; }
        }
      } else note += rhythm ? ' · ไม่มี API Key ถอดเสียง จึงตัดตามจังหวะเสียงอย่างเดียว' : ' · ไม่มี API Key ถอดเสียง จึงตัดตามช่วงเงียบแทน';
      if (f0 !== P.media.file) return;                                                    // another clip was loaded meanwhile
      if (!words.length && !opts.manual && !rhythm) {
        final = 'ไม่พบคำพูดในเสียงที่เพิ่ม (เพลง / เสียงประกอบ?) — ไม่ได้จัดฉากใหม่' + note; kind = note ? 'err' : ''; return;
      }
      if (!words.length && st.canListen && rhythm) note += ' · ไม่พบคำพูด จึงตัดตามจังหวะเสียงอย่างเดียว';
      words.sort((x, y) => x.start - y.start);
      let cues = [];
      if (words.length) {
        try { const seg = P.subtitle.segmentation; cues = S.segmenters.get(seg.strategy).run(words, Object.assign({}, seg)).sort((x, y) => x.start - y.start); } catch (e) { cues = []; }
      }

      /* 2 — cut */
      const old = S.arrange.scenes().map(s => Object.assign({}, s));
      let a = Math.max(0, Math.min.apply(null, sounds.map(c => c.start))), b = Math.min(D, Math.max.apply(null, sounds.map(c => c.start + c.len)));
      a = snapEdge(a, old, D); b = snapEdge(b, old, D);
      if (b - a < MIN_SCENE) throw new Error('เสียงที่เพิ่มสั้นเกินไป');
      const pauses = []; sounds.forEach(c => pauses.push.apply(pauses, pausesOf(c)));
      let plan = null;
      if (rhythm) {
        const ons = []; sounds.forEach(c => ons.push.apply(ons, onsetsOfClip(c)));
        if (ons.length >= 3) {
          const soft = []; cues.forEach((c, i) => { if (i) soft.push({ t: c.start, w: 0.35 }); });
          pauses.forEach(r => { soft.push({ t: r[0], w: 0.45 }); soft.push({ t: r[1], w: 0.45 }); });
          plan = { bounds: planRhythm(a, b, ons, soft, A.minLen, A.maxLen), mode: 'rhythm' };
        }
      }
      if (!plan) plan = planOver(a, b, cues, pauses);
      if (plan.bounds.length < 2) throw new Error('แบ่งฉากไม่ได้');
      const fresh = [], texts = [];
      for (let i = 0; i + 1 < plan.bounds.length; i++) {
        const s = S.arrange.newScene(plan.bounds[i], plan.bounds[i + 1]); fresh.push(s);
        texts.push(cues.filter(c => { const m = (c.start + c.end) / 2; return m >= s.start && m < s.end; }).map(c => c.text).join(' ').trim());
      }

      /* 3 — look + match */
      const clips = A.clips.slice(), used = new Map();
      const useOf = id => { if (!used.has(id)) used.set(id, []); return used.get(id); };
      old.forEach(s => { if (s.clipId && (s.end <= a + 1e-3 || s.start >= b - 1e-3)) useOf(s.clipId).push([s.offset || 0, (s.offset || 0) + s.end - s.start]); });
      let matched = 0; const matchLines = [], webQ = []; let webOff = '';
      const castTxt = String(A.cast || '').trim(), useWeb = A.webSearch !== false, lookKey = (useWeb ? 'w' : 'n') + '|' + castTxt, narration = texts.join(' ').trim();
      if (st.gem && words.length) {
        try {
          /* look: what is in each clip (once per clip — kept in clip.ai) */
          const need = clips.filter(c => !c.ai || c.aiKey !== lookKey), G = 8;
          for (let g = 0; g < need.length; g += G) {
            const grp = need.slice(g, g + G), per = clamp(Math.floor(48 / grp.length), 3, 12), cl = [];
            for (let i = 0; i < grp.length; i++) {
              prog('กำลังดูภาพของคลิป ' + (g + i + 1) + '/' + need.length + '...');
              cl.push({ name: grp[i].name, sec: grp[i].duration || 0, still: !!grp[i].still, names: grp[i].names || [], frames: await sampleFrames(grp[i], per) });
            }
            if (f0 !== P.media.file) return;
            prog(useWeb ? 'Gemini กำลังดูคลิปและค้นเว็บหาชื่อตัวละคร / สิ่งของ...' : 'Gemini กำลังดูว่าในคลิปมีตัวละคร / สิ่งของอะไร และส่วนไหนใช้ได้...');
            try {
              const res = await S.ai.describeClips({ geminiKey: st.gem, geminiModel: val('geminiModel'), onStatus: m => say(m), clips: cl, search: useWeb, cast: castTxt, context: narration });
              grp.forEach((c, i) => { if (res[i]) { c.ai = res[i]; c.aiKey = lookKey; } });
              if (res.search) { res.search.queries.forEach(q => { if (webQ.indexOf(q) < 0) webQ.push(q); }); if (res.search.off && !webOff) webOff = res.search.note || 'ไม่ทราบสาเหตุ'; }
            }
            catch (e) { note += ' · วิเคราะห์ภาพในคลิปไม่สำเร็จ (' + msgOf(e) + ')'; }
            S.arrange.save();
          }
          /* match: the words of each scene against what is in the clips */
          const cl = [];
          for (let i = 0; i < clips.length; i++) cl.push(clips[i].ai ? { name: clips[i].name, sec: clips[i].duration || 0, still: !!clips[i].still, names: clips[i].names || [], info: clips[i].ai } : { name: clips[i].name, sec: clips[i].duration || 0, still: !!clips[i].still, names: clips[i].names || [], frames: await sampleFrames(clips[i], 4) });
          if (f0 !== P.media.file) return;
          prog('Gemini กำลังจับคู่ภาพกับคำพูด...');
          const picks = await S.ai.matchVoice({ geminiKey: st.gem, geminiModel: val('geminiModel'), onStatus: m => say(m), clips: cl, cast: castTxt, scenes: fresh.map((s, i) => ({ text: texts[i], sec: s.end - s.start })) });
          fresh.forEach((s, i) => {
            const pk = picks[i], c = pk && clips[pk.clip]; if (!c) return;
            const len = s.end - s.start, d = c.duration || 0;
            let at = d > 0 && !c.still ? clamp(pk.at, 0, Math.max(0, d - Math.min(len, d))) : 0;        // a still picture has no "moment" in it
            if (d > 0 && !c.still) { at = fitUsable(c, at, len); at = freeSpot(d, at, len, useOf(c.id)); at = clamp(fitUsable(c, at, len), 0, Math.max(0, d - Math.min(len, d))); }
            s.clipId = c.id; s.offset = +at.toFixed(3); s.note = pk.why || ''; if (!c.still) useOf(c.id).push([at, at + Math.min(len, d || len)]); matched++;
            if (matchLines.length < 8) matchLines.push(' ' + (i + 1) + ') ' + ft(s.start) + '–' + ft(s.end) + ' → คลิป ' + (clips.indexOf(c) + 1) + ' @' + ft(at) + (pk.why ? ' · ' + pk.why : ''));
          });
          if (useWeb && webQ.length) note += ' · Gemini ค้นเว็บ ' + webQ.length + ' ครั้ง (เช่น “' + webQ.slice(0, 2).join('” · “') + '”)';
          if (webOff) note += ' · ค้นเว็บไม่ได้ (' + webOff + ') จึงใช้เฉพาะสิ่งที่เห็นในภาพ';
        } catch (e) { note += ' · AI จับคู่ภาพไม่สำเร็จ (' + msgOf(e) + ') จึงเรียงคลิปตามลำดับแทน'; }
      } else if (words.length) note += ' · ไม่มี Gemini Key จึงเรียงคลิปตามลำดับ (ใส่ Key เพื่อให้ AI ดูภาพ รู้ว่าตัวละครคือตัวอะไร และเลือกส่วนที่ตรงคำพูด)';
      const detail = [];
      const seen = clips.map((c, i) => c.ai ? ' ' + (i + 1) + ') ' + (c.still ? '🖼 ' : '') + c.ai.summary + (c.ai.subjects.length || (c.names || []).length ? ' [' + (c.names || []).concat(c.ai.subjects.filter(t => (c.names || []).indexOf(t) < 0)).slice(0, 5).join(', ') + ']' : '') : null).filter(Boolean);
      if (seen.length) { detail.push('AI เห็นในคลิป:'); seen.slice(0, 8).forEach(l => detail.push(l)); if (seen.length > 8) detail.push(' … และอีก ' + (seen.length - 8) + ' คลิป'); }
      if (matchLines.length) { detail.push('ฉากที่จับคู่:'); matchLines.forEach(l => detail.push(l)); }
      if (f0 !== P.media.file) return;

      /* 4 — put them on the timeline */
      const before = [], after = [];
      old.forEach(s => {
        if (s.end <= a + 1e-3) before.push(s);
        else if (s.start >= b - 1e-3) after.push(s);
        else {                                                                           // a scene that crosses an edge of the stretch keeps its outside part
          if (s.start < a - 1e-3) before.push(Object.assign({}, s, { end: a }));
          if (s.end > b + 1e-3) { const t = S.arrange.newScene(b, s.end); Object.assign(t, { clipId: s.clipId, offset: +((s.offset || 0) + (b - s.start)).toFixed(3), fit: s.fit }); after.push(t); }
        }
      });
      S.arrange.pushUndo();
      const list = ensureTiling(before.concat(fresh, after), D), first = list.indexOf(fresh[0]);
      S.arrange.putScenes(list, first);
      if (!A.on) S.arrange.setOn(true);
      S.arrange.autoAssign(true);                                                        // scenes the AI left empty (or no AI): the videos in order, each one continuing where the last stopped
      S.arrange.commit();

      let tail = '';
      if (words.length && A.voiceTrim && (a > 0.05 || b < D - 0.05)) {
        P.trim.start = a; P.trim.end = b;
        if (S.ui.timeline && S.ui.timeline.refreshTrim) S.ui.timeline.refreshTrim(); else bus.emit('trim:changed');
        const t = video.currentTime || 0; if (t < a || t > b) S.ui.player.seek(a);
        tail += ' · ตัดความยาวส่งออกให้พอดีเสียง (' + ft(a) + '–' + ft(b) + ')';
      }
      if (words.length && !P.subtitle.cues.length) {
        try { P.subtitle.words = words; S.subtitle.regroup(); tail += ' · สร้างซับจากเสียงนี้ให้แล้ว ' + P.subtitle.cues.length + ' บรรทัด'; } catch (e) { /* subtitles are a bonus */ }
      }
      detailText = detail.join('\n');
      const modeTxt = plan.mode === 'rhythm' ? 'ตามจังหวะเสียง' : plan.mode === 'cue' ? MODE_LABEL.cue : plan.mode === 'silence' ? MODE_LABEL.silence : 'ทุก ' + A.fixedLen + ' วิ';
      final = 'จัดฉากตามเสียงแล้ว ' + fresh.length + ' ฉาก (' + ft(a) + '–' + ft(b) + ' · ตัด' + modeTxt + ')' +
        (matched ? ' · AI เลือกภาพตรงกับคำพูด ' + matched + '/' + fresh.length + ' ฉาก' : '') + tail + note + ' · กดเลิกทำฉากได้';
      if (words.length && P.subtitle.cues.length && !tail.includes('สร้างซับ')) final += ' · ซับเดิมยังเป็นของเสียงเดิม';
      if (note) kind = '';
    } catch (e) {
      final = 'จัดฉากตามเสียงไม่สำเร็จ: ' + msgOf(e); kind = 'err';
    } finally {
      busy = false; if (runBtn()) runBtn().disabled = false;
      if (final) { say(final + (detailText ? '\n' + detailText : ''), kind); toast(final, 7000); } else hideToast();
    }
  }

  /** The sound the button works on: the selected one, else the last narration-like sound on the timeline. */
  function targetIds() {
    const sel = AU.sel && AU.clips.find(c => c.id === AU.sel);
    if (sel && kindOf(sel) !== 'sfx') return [sel.id];
    for (let i = AU.clips.length - 1; i >= 0; i--) if (kindOf(AU.clips[i]) !== 'sfx') return [AU.clips[i].id];
    return [];
  }

  S.voiceArrange = { run: run, snapEdge: snapEdge, freeSpot: freeSpot, ensureTiling: ensureTiling, onsetsOf: onsetsOf, planRhythm: planRhythm, fitUsable: fitUsable };
  S.ui.voiceArrange = {
    init() {
      const autoEl = $('arrAutoVoice'), trimEl = $('arrVoiceTrim'), rhEl = $('arrVoiceRhythm'), btn = runBtn();
      if (!autoEl || !trimEl || !rhEl || !btn) return;
      const webEl = $('arrWebSearch'), zoomEl = $('arrStillZoom'), castEl = $('arrCast');
      const paint = () => {
        autoEl.classList.toggle('active', !!A.autoVoice); trimEl.classList.toggle('active', !!A.voiceTrim); rhEl.classList.toggle('active', A.voiceRhythm !== false);
        if (webEl) webEl.classList.toggle('active', A.webSearch !== false);
        if (zoomEl) zoomEl.classList.toggle('active', A.stillZoom !== false);
        if (castEl && document.activeElement !== castEl && castEl.value !== (A.cast || '')) castEl.value = A.cast || '';          // the saved list comes back after a refresh
      };
      if (webEl) webEl.addEventListener('click', () => { A.webSearch = A.webSearch === false; paint(); S.arrange.save(); });
      if (zoomEl) zoomEl.addEventListener('click', () => { A.stillZoom = A.stillZoom === false; paint(); S.arrange.save(); S.arrange.renderAll(); });
      if (castEl) castEl.addEventListener('input', () => { A.cast = castEl.value.slice(0, 1500); S.arrange.save(); });
      rhEl.addEventListener('click', () => { A.voiceRhythm = A.voiceRhythm === false; paint(); S.arrange.save(); });
      autoEl.addEventListener('click', () => { A.autoVoice = !A.autoVoice; paint(); S.arrange.save(); });
      trimEl.addEventListener('click', () => { A.voiceTrim = !A.voiceTrim; paint(); S.arrange.save(); });
      btn.addEventListener('click', () => run(targetIds(), { manual: true }));
      paint();
      bus.on('arrange:changed', paint);                                                  // the saved settings come back after a refresh
      bus.on('audio:added', e => { if (A.autoVoice && e && e.ids && e.ids.length) run(e.ids, { auto: true }); });
      bus.on('media:selected', () => { say('', ''); hinted = false; });
      bus.on('media:cleared', () => { say('', ''); });
    }
  };
})(window.SubEd);
