/* =====================================================================
 * UI: "สไตล์" tab. The controls are the INITIAL source of the style (so the
 * HTML defaults stay the single place to tune them); after boot,
 * project.style is the truth. Use SubEd.style.apply(patch) to change style
 * from code (AI style analysis, presets, ...): it updates the state and emits
 * style:changed; the panel re-syncs its controls and the preview refreshes.
 * Emits: style:changed.
 *
 * Scope (state.ui.styleScope): 'all' = every control edits project.style (the original behaviour);
 * 'cue' = the LOOK controls (colour, thickness, sharpness, italic, glow, shadow, animation) edit the active
 * line's own override (cue.style, see SubEd.subtitle.setCueLook); size/font/outline/background/position stay global.
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, P = S.state.project;

  const SIZE_BASE = 32;                                // main caption size is shown as a % of this (100% = 32 px on the main preview)
  let sizePctShown = 100;                              // the % the size slider last showed, so a control that only re-reads the slider never rewrites the size
  let cueRec = false;                                  // a drag in 'cue' scope = ONE undo step (reset on the control's change event)
  let shadowEm = false;                                // the shadow offset is set by the X / Y sliders (% of the font size) instead of angle + distance
  const firstFam = f => String(f || '').split(',')[0].replace(/["']/g, '').trim();
  const inCueScope = () => S.state.ui.styleScope === 'cue';
  const activeCue = () => P.subtitle.cues[S.state.ui.activeCue];

  /** The look controls as plain values (the part that can differ per line). */
  function readLook() {
    return {
      weight: parseInt($('weightR').value, 10) || 700,   // thickness slider is the truth; Bold switch just jumps it to 700 / 400
      thick: parseFloat($('thickR').value) || 0,
      sharp: parseInt($('sharpR').value, 10) || 0,
      italic: $('italicChk').checked,
      color: $('colorPick').value,
      bgColor: $('bgColor').value,
      glow: { on: $('glowChk').checked, type: $('glowType').value === 'burst' ? 'burst' : 'halo', color: $('glowColor').value, follow: $('glowFollow').checked, intensity: parseFloat($('glowInt').value), range: parseFloat($('glowRange').value) },
      shadow: { on: $('shadowChk').checked, color: $('shadowColor').value, opacity: parseFloat($('shadowOpacity').value), blur: parseFloat($('shadowBlur').value), dist: parseFloat($('shadowDist').value), angle: parseFloat($('shadowAngle').value),
        dx: shadowEm ? parseFloat($('shadowX').value) : null, dy: shadowEm ? parseFloat($('shadowY').value) : null }
    };
  }

  /** 'cue' scope: store only what DIFFERS from the global style on the active line (equal = inherit). */
  function writeCueLook(look) {
    const i = S.state.ui.activeCue, c = activeCue();
    if (!c) return;                                      // no line on screen: nothing to edit (controls snap back on the next sync)
    const g = P.style, patch = {};
    const diff = (k, v, base) => { patch[k] = v !== base ? v : null; };
    diff('weight', look.weight, g.weight || (g.bold ? 700 : 400));
    diff('thick', look.thick, g.thick || 0);
    diff('sharp', look.sharp, g.sharp || 0);
    diff('italic', look.italic, !!g.italic);
    diff('color', look.color, g.color);
    diff('bgColor', look.bgColor, g.bg.color);
    const same = (a, b) => !!b && Object.keys(a).every(k => a[k] === b[k]);
    patch.glow = same(look.glow, g.glow) ? null : look.glow;
    patch.shadow = same(look.shadow, g.shadow) ? null : look.shadow;
    if (!cueRec && S.history) { S.history.record('style'); cueRec = true; }
    S.subtitle.setCueLook(i, patch, { history: false });
  }

  function readControls() {
    const st = P.style, look = readLook();
    st.font = $('fontSel').value;
    st.opacity = parseInt($('opacityR').value, 10);
    { const pct = parseFloat($('sizeR').value);                         // main size is shown as % (100% = SIZE_BASE px) and kept as a real decimal
      if (isFinite(pct) && Math.abs(pct - sizePctShown) > 1e-6) st.size = +(pct * SIZE_BASE / 100).toFixed(3); }
    st.autoWrap = $('wrapChk').checked;
    st.outline.on = $('outlineChk').checked;
    st.outline.color = $('outlineColor').value;
    st.outline.width = parseFloat($('outlineW').value);
    st.bg.on = $('bgChk').checked;
    st.bg.opacity = $('bgOpacity').value / 100;
    st.halo = Object.assign(st.halo || {}, { on: $('haloChk').checked, blur: parseFloat($('haloBlur').value), alpha: parseFloat($('haloAlpha').value), layers: parseInt($('haloLayers').value, 10) });
    if (inCueScope()) { writeCueLook(look); return; }
    st.weight = look.weight; st.bold = look.weight >= 600;
    st.sharp = look.sharp; st.thick = look.thick; st.italic = look.italic;
    st.color = look.color; st.bg.color = look.bgColor;
    st.glow = Object.assign(st.glow || {}, look.glow);
    st.shadow = Object.assign(st.shadow || {}, look.shadow);
  }

  function syncChips(attr, value) {
    document.querySelectorAll('[' + attr + ']').forEach(c => c.classList.toggle('active', c.getAttribute(attr) === value));
  }
  /** Projects saved before the shadow had opacity / angle: fill in the values that reproduce their old look (full opacity, down-right). */
  function normShadow() {
    const sh = P.style.shadow;
    if (sh.opacity == null) sh.opacity = 100;
    if (sh.angle == null) sh.angle = -45;
    if (sh.dx === undefined) sh.dx = null;
    if (sh.dy === undefined) sh.dy = null;
    if (!P.style.halo) P.style.halo = { on: false, blur: 22, alpha: 85, layers: 2 };
    if (P.style.fxStep == null) P.style.fxStep = 350;
    if (!P.style.fxOut) P.style.fxOut = 'none';
    if (!(P.style.fxOutDur > 0)) P.style.fxOutDur = 0.4;
  }
  function syncControls() {
    normShadow();
    const st = inCueScope() ? S.subtitle.effectiveStyle(activeCue(), P.style) : P.style;   // cue scope: show the line's own look
    const sel = $('fontSel');
    // keep the option the user picked when it still describes the state (two entries can share one family, e.g. Prompt / Prompt Bd);
    // otherwise find the entry that matches family + weight, then any entry of that family
    const cur = sel.selectedOptions[0];
    const curOk = cur && cur.value === st.font && (!cur.dataset.weight || +cur.dataset.weight === (st.weight || 0));
    if (!curOk) {
      const hit = Array.from(sel.options).find(o => o.value === st.font && (parseInt(o.dataset.weight, 10) || 0) === (st.weight || 0));
      if (hit) hit.selected = true; else sel.value = st.font;
    }
    const w = st.weight || (st.bold ? 700 : 400);
    $('weightR').value = w; $('weightNum').textContent = w;
    const op = st.opacity == null ? 100 : st.opacity; $('opacityR').value = op; $('opacityNum').textContent = op;
    $('thickR').value = st.thick || 0; $('thickNum').textContent = st.thick || 0;
    $('sharpR').value = st.sharp || 0; $('sharpNum').textContent = st.sharp || 0;
    sizePctShown = S.ui.precise.r1(P.style.size / SIZE_BASE * 100); $('sizeR').value = sizePctShown; sizePctShown = parseFloat($('sizeR').value); $('sizeNum').textContent = S.ui.precise.f1(sizePctShown);
    $('boldChk').checked = w >= 600;
    $('italicChk').checked = !!st.italic;
    $('wrapChk').checked = !!P.style.autoWrap;
    $('colorPick').value = st.color;
    $('outlineChk').checked = st.outline.on; $('outlineColor').value = st.outline.color; $('outlineW').value = st.outline.width;
    st.glow = st.glow || { on: false, type: 'halo', color: '#00e5ff', follow: true, intensity: 60, range: 12 };
    if (!st.glow.type) st.glow.type = 'halo';                  // projects saved before glow types existed
    $('glowType').value = st.glow.type === 'burst' ? 'burst' : 'halo'; syncChips('data-gt', $('glowType').value);
    $('glowChk').checked = st.glow.on; $('glowColor').value = st.glow.color; $('glowFollow').checked = !!st.glow.follow;
    $('glowInt').value = st.glow.intensity; $('glowIntNum').textContent = Math.round(st.glow.intensity);
    $('glowRange').value = st.glow.range; $('glowRangeNum').textContent = Math.round(st.glow.range);
    $('outlineWNum').textContent = st.outline.width; $('shadowBlurNum').textContent = st.shadow.blur; $('bgOpacityNum').textContent = Math.round(st.bg.opacity * 100);
    $('shadowChk').checked = st.shadow.on; $('shadowColor').value = st.shadow.color; $('shadowBlur').value = st.shadow.blur;
    $('shadowDist').value = st.shadow.dist; $('shadowDistNum').textContent = st.shadow.dist;
    const shOp = st.shadow.opacity == null ? 100 : st.shadow.opacity, shAng = st.shadow.angle == null ? -45 : st.shadow.angle;
    $('shadowOpacity').value = shOp; $('shadowOpacityNum').textContent = Math.round(shOp);
    $('shadowAngle').value = shAng; $('shadowAngleNum').textContent = Math.round(shAng);
    {                                                          // เงาเหลื่อม: X / Y in % of the font size (derived from angle + distance while those are in charge)
      const sh = st.shadow; shadowEm = sh.dx != null && sh.dy != null;
      const so = S.render.shadowOffset(sh), sz = st.size || 32, q = v => Math.round(Math.min(20, Math.max(-20, v)) * 2) / 2;
      const gx = q(shadowEm ? +sh.dx : so.dx / sz * 100), gy = q(shadowEm ? +sh.dy : so.dy / sz * 100);
      $('shadowX').value = gx; $('shadowXNum').textContent = gx; $('shadowY').value = gy; $('shadowYNum').textContent = gy;
      const hl = P.style.halo;                                 // ขอบมืดรอบตัวอักษร (the same for every line)
      $('haloChk').checked = !!hl.on; $('haloBlur').value = hl.blur; $('haloBlurNum').textContent = Math.round(hl.blur);
      $('haloAlpha').value = hl.alpha; $('haloAlphaNum').textContent = Math.round(hl.alpha); $('haloLayers').value = hl.layers; $('haloLayersNum').textContent = Math.round(hl.layers);
    }
    $('bgChk').checked = st.bg.on; $('bgColor').value = st.bg.color; $('bgOpacity').value = Math.round(st.bg.opacity * 100);
    st.karaokeMode = st.karaokeMode || (st.karaoke === false ? 'off' : 'custom'); st.karaoke = st.karaokeMode !== 'off';
    syncChips('data-km', st.karaokeMode);
    syncChips('data-pos', P.style.pos); syncChips('data-fx', st.fx);
    const fd = st.fxDur > 0 ? st.fxDur : 0.22;
    if (String($('fxDur').value) !== String(fd)) $('fxDur').value = fd;
    $('fxDurNum').textContent = fd.toFixed(2) + ' วิ';
    const fs = st.fxStep > 0 ? st.fxStep : 350, fo = st.fxOut || 'none', fod = st.fxOutDur > 0 ? st.fxOutDur : 0.4;
    if (String($('fxStep').value) !== String(fs)) $('fxStep').value = fs;
    $('fxStepNum').textContent = Math.round(fs) + ' ms';
    syncChips('data-fxo', fo);
    if (String($('fxOutDur').value) !== String(fod)) $('fxOutDur').value = fod;
    $('fxOutDurNum').textContent = fod.toFixed(2) + ' วิ';
    if ($('fxHl').value !== st.highlight && /^#[0-9a-f]{6}$/i.test(st.highlight || '')) $('fxHl').value = st.highlight;
    const show = (id, on) => { const r = $(id).closest('.row'); if (r) r.style.display = on ? '' : 'none'; };
    show('fxDur', S.fx.usesLength(st.fx));                     // per-word / per-letter / continuous animations have their own length
    show('fxStep', S.fx.usesStep(st.fx));
    show('fxOutDur', fo !== 'none');
    // a font that is not in the list (e.g. an uploaded one that has not loaded yet): add a stand-in so reading the controls never overwrites it
    if (st.font && sel.value !== st.font) {
      const o = document.createElement('option'); o.value = st.font; o.textContent = firstFam(st.font) + ' (ไม่พบไฟล์ฟอนต์)'; o.dataset.cat = 'custom'; o.dataset.temp = '1';
      sel.appendChild(o); o.selected = true;
    }
  }

  /** Make sure the chosen face is downloaded: canvas (export) can only draw a web font that is already loaded. */
  function ensureFont() {
    // everything (weights, italics, used characters, font stack) is handled by js/render/font-kit.js
    if (S.fontKit) return S.fontKit.ensure(P);
    return Promise.resolve();
  }

  S.style = {
    ensureFont: ensureFont,
    /** Merge a partial style (nested objects merge one level deep) and refresh everything. */
    apply(patch) {
      const st = P.style;
      Object.keys(patch).forEach(k => {
        if (patch[k] && typeof patch[k] === 'object') Object.assign(st[k], patch[k]); else st[k] = patch[k];
      });
      // keep state inside the ranges the controls declare, so state and what is shown never disagree
      const clamp = (v, id, scale) => { const el = $(id), lo = parseFloat(el.min) / scale, hi = parseFloat(el.max) / scale; return Math.min(hi, Math.max(lo, v)); };
      st.size = clamp(st.size, 'sizeR', 100 / SIZE_BASE);
      st.weight = clamp(st.weight || 700, 'weightR', 1); st.sharp = clamp(st.sharp || 0, 'sharpR', 1); st.thick = clamp(st.thick || 0, 'thickR', 1); st.opacity = clamp(st.opacity == null ? 100 : st.opacity, 'opacityR', 1);
      st.outline.width = clamp(st.outline.width, 'outlineW', 1);
      st.bg.opacity = clamp(st.bg.opacity, 'bgOpacity', 100);
      st.glow = st.glow || {}; st.glow.intensity = clamp(st.glow.intensity || 0, 'glowInt', 1); st.glow.range = clamp(st.glow.range || 1, 'glowRange', 1);
      st.shadow.blur = clamp(st.shadow.blur, 'shadowBlur', 1);
      st.shadow.dist = clamp(st.shadow.dist, 'shadowDist', 1);
      st.shadow.opacity = clamp(st.shadow.opacity == null ? 100 : st.shadow.opacity, 'shadowOpacity', 1);
      st.shadow.angle = clamp(st.shadow.angle == null ? -45 : st.shadow.angle, 'shadowAngle', 1);
      if (patch.shadow && ('dist' in patch.shadow || 'angle' in patch.shadow) && !('dx' in patch.shadow)) { st.shadow.dx = null; st.shadow.dy = null; }   // a preset / copied style that sets angle + distance takes the offset back
      if (st.shadow.dx != null && st.shadow.dy != null) { st.shadow.dx = clamp(+st.shadow.dx, 'shadowX', 1); st.shadow.dy = clamp(+st.shadow.dy, 'shadowY', 1); } else { st.shadow.dx = null; st.shadow.dy = null; }
      st.halo = Object.assign({ on: false, blur: 22, alpha: 85, layers: 2 }, st.halo || {});
      st.halo.blur = clamp(+st.halo.blur || 0, 'haloBlur', 1); st.halo.alpha = clamp(+st.halo.alpha || 0, 'haloAlpha', 1); st.halo.layers = Math.round(clamp(+st.halo.layers || 0, 'haloLayers', 1));
      if (st.fxStep != null) st.fxStep = clamp(+st.fxStep || 350, 'fxStep', 1);
      if (st.fxOutDur != null) st.fxOutDur = clamp(+st.fxOutDur || 0.4, 'fxOutDur', 1);
      bus.emit('style:changed');          // the panel re-syncs its controls from state on this event
    }
  };

  const TARGET = { text: 'colorPick', stroke: 'outlineColor', glow: 'glowColor', bg: 'bgColor', shadow: 'shadowColor' };
  const COLORS = ['#ffffff', '#b3b3b3', '#808080', '#3a3a3a', '#000000', '#f5c518', '#ff8a00', '#ff0a5c', '#b100ff', '#1e88ff', '#00e5ff', '#16e04a'];
  // each preset: text colour, stroke, glow, drop shadow, box (a cue-independent global style patch). Row order follows CapCut's Styles row:
  // white with a heavy black edge (x4), yellow / red / orange / blue / green lettering, a grey box, then glow + extras. 14 = "no style".
  const SH = (blur, dist, opacity, angle) => ({ on: true, color: '#000000', opacity: opacity == null ? 100 : opacity, blur: blur, dist: dist, angle: angle == null ? -45 : angle });
  const NOSH = { on: false }, NOGL = { on: false }, NOBG = { on: false };
  const PRESETS = [
    { color: '#ffffff', outline: { on: true, color: '#000000', width: 3 }, glow: NOGL, shadow: SH(4, 3), bg: NOBG },
    { color: '#ffffff', outline: { on: true, color: '#000000', width: 5 }, glow: NOGL, shadow: SH(5, 4), bg: NOBG },
    { color: '#ffffff', outline: { on: true, color: '#000000', width: 2 }, glow: NOGL, shadow: SH(8, 5), bg: NOBG },
    { color: '#ffffff', outline: { on: true, color: '#000000', width: 2 }, glow: NOGL, shadow: NOSH, bg: { on: true, color: '#000000', opacity: 0.55 } },
    { color: '#ffe600', outline: { on: true, color: '#000000', width: 3 }, glow: NOGL, shadow: SH(4, 3), bg: NOBG },
    { color: '#e25050', outline: { on: true, color: '#ffffff', width: 2 }, glow: NOGL, shadow: SH(4, 3), bg: NOBG },   // red = the red CapCut really shows (#E25050, measured from its export)
    { color: '#ff8a00', outline: { on: true, color: '#ffffff', width: 2 }, glow: NOGL, shadow: SH(4, 3), bg: NOBG },
    { color: '#1e88ff', outline: { on: true, color: '#ffffff', width: 2 }, glow: NOGL, shadow: SH(4, 3), bg: NOBG },
    { color: '#ffffff', outline: { on: false }, glow: { on: true, type: 'halo', follow: false, color: '#00e5ff', intensity: 70, range: 14 }, shadow: NOSH, bg: NOBG },
    { color: '#ffe9ff', outline: { on: false }, glow: { on: true, type: 'halo', follow: false, color: '#ff0a9c', intensity: 85, range: 20 }, shadow: NOSH, bg: NOBG },
    { color: '#111111', outline: { on: false }, glow: NOGL, shadow: NOSH, bg: { on: true, color: '#b3b3b3', opacity: 0.95 } },
    { color: '#ffffff', outline: { on: false }, glow: NOGL, shadow: NOSH, bg: { on: true, color: '#e53935', opacity: 0.95 } },
    { color: '#16e04a', outline: { on: true, color: '#000000', width: 3 }, glow: NOGL, shadow: SH(4, 3), bg: NOBG },
    { color: '#ffffff', outline: { on: true, color: '#8a2be2', width: 4 }, glow: { on: true, type: 'burst', follow: false, color: '#ffffff', intensity: 80, range: 18 }, shadow: NOSH, bg: NOBG },
    { color: '#ffffff', outline: { on: false }, glow: NOGL, shadow: NOSH, bg: NOBG },
    // 15 = the CapCut "Aa" in อนุพันธ์ Bold: white letters, no outline, hard black shadow (65% opacity, blur 0, down-right -45°) PLUS a soft
    // light around the letters. The glow FOLLOWS each word's own colour (follow: true): white words glow white, a recoloured word glows in its colour.
    { font: "'Anuphan',sans-serif", weight: 700, bold: true, color: '#ffffff', outline: { on: false }, glow: { on: true, type: 'halo', follow: true, color: '#ffffff', intensity: 35, range: 8 }, shadow: SH(0, 3, 65, -45), bg: NOBG },
    // 16 = template from the "ทุกคน" reference picture: Anuphan Bold, pure white, razor-sharp edges (sharp 100 = mitred corners + a hard,
    // un-blurred shadow), no outline / glow. The shadow is a solid black drop shadow, 60% opacity, ~12% of the letter height, down-right.
    { font: "'Anuphan',sans-serif", weight: 700, bold: true, sharp: 100, thick: 0, italic: false, color: '#ffffff', outline: { on: false }, glow: NOGL, shadow: SH(0, 3, 60, -45), bg: NOBG },
    // 17 = template from video 1 (VID_20260928…): heavy ITALIC Prompt Bold, white, no outline, soft dark halo shadow (blur 6, short offset, 80% opacity).
    { font: "'Prompt',sans-serif", weight: 700, bold: true, italic: true, sharp: 60, thick: 0, color: '#ffffff', outline: { on: false }, glow: NOGL, shadow: SH(6, 2, 80, -45), bg: NOBG },
    // 18 = template from video 2 (VID_20261001…): upright Prompt Bold, white, crisp edges, hard un-blurred black shadow down-right (70% opacity).
    { font: "'Prompt',sans-serif", weight: 700, bold: true, italic: false, sharp: 100, thick: 0, color: '#ffffff', outline: { on: false }, glow: NOGL, shadow: SH(0, 3, 70, -45), bg: NOBG },
    // 19 = the CapCut "Aa" (3rd in its Styles row), measured on its export:
    //   font  Anuphan SemiBold 600 (glyph overlap 91% with the picture; Bold 700 only 81%) -> the bundled 'Anuphan Local' so it needs no network
    //   size  8.85% of the frame width (63.7 px on a 720 px wide frame) = sizeFrac, turned into px for the current preview when the style is applied
    //   fill  white, no outline, no glow; coloured words get NO glow either (wgOff) - the reference has none
    //   shadow black 65%, offset 7.5% of the letter size right AND down (4.7 px at 720), edge ~1 px soft (blur 5 x (1 - sharp 80%))
    { font: "'Anuphan Local',sans-serif", weight: 600, bold: true, italic: false, sharp: 80, thick: 0, color: '#ffffff', outline: { on: false }, glow: NOGL, shadow: { on: true, color: '#000000', opacity: 65, blur: 5, dist: 3, angle: -45, dx: 7.5, dy: 7.5 }, bg: NOBG, sizeFrac: 0.0885, wgOff: true }
  ];
  /** A preset: colour + glow follow the scope (this line only, or everything); outline / background stay global. */
  // Templates (presets that carry their own sharp/italic/font, i.e. 16-18) change the look of the LETTERS, which the older colour/glow presets
  // never touch. So that a template does not leak into the next preset you tap, remember what the letters were before the first template and put
  // those values back when a non-template preset is applied -- but only the keys that still hold the template's own value (a manual tweak wins).
  let tplUndo = null;
  const TPL_KEYS = ['font', 'weight', 'bold', 'italic', 'sharp', 'thick'];
  function applyPreset(p) {
    const patch = JSON.parse(JSON.stringify(p));
    if (patch.shadow && patch.shadow.on && patch.shadow.dist != null && !('dx' in patch.shadow)) { patch.shadow.dx = null; patch.shadow.dy = null; }   // the preset's offset is angle + distance
    const isTpl = patch.sharp != null;
    const gs = P.style || {};
    if (isTpl) {
      if (!tplUndo) { tplUndo = { prev: {}, set: {} }; TPL_KEYS.forEach(k => { tplUndo.prev[k] = gs[k]; }); }
      TPL_KEYS.forEach(k => { if (patch[k] != null) tplUndo.set[k] = patch[k]; });
    } else if (tplUndo) {
      TPL_KEYS.forEach(k => { if (patch[k] == null && k in tplUndo.set && gs[k] === tplUndo.set[k] && tplUndo.prev[k] != null) patch[k] = tplUndo.prev[k]; });
      tplUndo = null;
    }
    if (inCueScope()) {
      const c = activeCue();
      if (!c) return;
      const g = P.style, eff = S.subtitle.effectiveStyle(c, g), glow = Object.assign({}, eff.glow, patch.glow);
      const same = Object.keys(glow).every(k => glow[k] === g.glow[k]);
      const shadow = Object.assign({}, eff.shadow, patch.shadow), sameSh = Object.keys(shadow).every(k => shadow[k] === g.shadow[k]);
      if (S.history) S.history.record('style');
      S.subtitle.setCueLook(S.state.ui.activeCue, { color: patch.color !== g.color ? patch.color : null, glow: same ? null : glow, shadow: sameSh ? null : shadow }, { history: false });
      delete patch.color; delete patch.glow; delete patch.shadow;
    }
    if (inCueScope()) { delete patch.sizeFrac; delete patch.wgOff; }
    else {
      if (patch.sizeFrac) { const pw = (S.ui.preview && (S.ui.preview.refWidth ? S.ui.preview.refWidth() : S.ui.preview.contentRect().w)) || 0; if (pw > 0) patch.size = Math.max(8, Math.min(120, Math.round(patch.sizeFrac * pw * 10) / 10)); }
      delete patch.sizeFrac;
      if (patch.wgOff == null) patch.wgOff = false;          // every other style: coloured words glow in their colour again
    }
    S.style.apply(patch);
    if (patch.font) ensureFont().then(() => bus.emit('style:changed'));      // the canvas can only draw a web font that is already loaded
  }

  /** "แก้สไตล์ให้: ทุกประโยค | เฉพาะประโยคนี้" */
  function initScope() {
    const row = $('scopeRow'), hint = $('scopeHint');
    const paint = () => {
      const cueMode = inCueScope();
      row.querySelectorAll('[data-scope]').forEach(c => c.classList.toggle('active', c.dataset.scope === S.state.ui.styleScope));
      hint.hidden = !cueMode;
      hint.textContent = !cueMode ? '' : (activeCue()
        ? 'แก้เฉพาะประโยคที่ขึ้นอยู่ตอนนี้: สี ความหนา ความคม ความเอียง เรืองแสง เงา และเอฟเฟค · ส่วนอื่น (ฟอนต์ ขนาด ขอบ พื้นหลัง) ยังใช้ร่วมกันทุกประโยค · ตำแหน่งเฉพาะประโยคปรับได้ที่แท็บ "จัดวาง"'
        : 'เลื่อนวิดีโอไปที่ประโยคที่ต้องการก่อน');
    };
    row.querySelectorAll('[data-scope]').forEach(chip => chip.addEventListener('click', () => {
      S.state.ui.styleScope = chip.dataset.scope; cueRec = false;
      paint(); bus.emit('style:changed');
    }));
    ['cue:active', 'cue:style', 'cues:structure'].forEach(e => bus.on(e, () => { paint(); if (inCueScope()) syncControls(); }));
    paint();
  }

  function initSubUi() {
    let sub = 'text';
    const sw = $('swatches');
    function drawSwatches() {
      const tgt = TARGET[sub]; sw.style.display = tgt ? '' : 'none';
      if (!tgt) return;
      sw.innerHTML = '';
      COLORS.forEach(c => {
        const b = document.createElement('button'); b.type = 'button'; b.className = 'tx-sw big'; b.style.background = c; b.title = c;
        b.addEventListener('click', () => { const el = $(TARGET[sub]); el.value = c; el.dispatchEvent(new Event('input', { bubbles: true })); });
        sw.appendChild(b);
      });
    }
    // sliding underline under the active sub-tab
    const subTabs = $('subTabs'), ind = document.createElement('i');
    ind.className = 'sub-ind'; subTabs.appendChild(ind);
    let indPlaced = false;
    function moveInd() {
      const on = subTabs.querySelector('button.on');
      if (!on || !on.offsetWidth) return;                         // pane is hidden right now; the resize observer calls again when it shows
      if (!indPlaced) ind.style.transition = 'none';              // first placement: jump, don't slide in from the corner
      ind.style.width = on.offsetWidth + 'px';
      ind.style.transform = 'translate(' + on.offsetLeft + 'px,' + (on.offsetTop + on.offsetHeight) + 'px)';
      if (!indPlaced) { void ind.offsetWidth; ind.style.transition = ''; indPlaced = true; }
    }
    if (window.ResizeObserver) new ResizeObserver(() => moveInd()).observe(subTabs);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(moveInd);
    window.addEventListener('resize', moveInd);
    document.querySelectorAll('#subTabs button').forEach(b => b.addEventListener('click', () => {
      sub = b.dataset.sub;
      document.querySelectorAll('#subTabs button').forEach(x => x.classList.toggle('on', x === b));
      document.querySelectorAll('.sub-pane').forEach(p => p.hidden = p.dataset.subpane !== sub);
      drawSwatches();
      moveInd();
      subTabs.scrollTo({ left: Math.max(0, b.offsetLeft - (subTabs.clientWidth - b.offsetWidth) / 2), behavior: 'smooth' });
    }));
    moveInd();
    drawSwatches();
    document.querySelectorAll('#preRow .pre').forEach(b => {
      const p = PRESETS[+b.dataset.pre], span = b.firstChild, g = p.glow.on ? p.glow : null, sh = p.shadow && p.shadow.on ? p.shadow : null;
      span.style.color = p.color;
      span.style.webkitTextStroke = p.outline.on ? Math.min(2.6, 1 + p.outline.width * 0.3) + 'px ' + p.outline.color : '0';
      span.style.paintOrder = 'stroke fill';
      const lay = [];
      if (g) { const gc = g.follow ? p.color : g.color; lay.push('0 0 ' + g.range / 2 + 'px ' + gc, '0 0 ' + g.range + 'px ' + gc); }
      if (p.font) span.style.fontFamily = p.font;
      if (sh) { const so = S.render.shadowOffset(sh); lay.push(Math.max(1, so.dx * 0.5) + 'px ' + Math.max(1, so.dy * 0.5) + 'px ' + Math.max(0, sh.blur / 4) + 'px ' + S.render.shadowColorCss(sh)); }
      span.style.textShadow = lay.length ? lay.join(', ') : 'none';
      span.style.background = p.bg.on ? p.bg.color : 'none';
      span.style.borderRadius = p.bg.on ? '4px' : '';
      b.addEventListener('click', () => {
        document.querySelectorAll('#preRow .pre').forEach(x => x.classList.toggle('on', x === b));
        applyPreset(p);
      });
    });
  }

  S.ui.stylePanel = {
    init() {
      // registered first so they run before the generic handler below reads the controls
      $('fontSel').addEventListener('input', () => { const o = $('fontSel').selectedOptions[0]; if (o && o.dataset.weight) $('weightR').value = o.dataset.weight; });
      $('boldChk').addEventListener('input', () => { $('weightR').value = $('boldChk').checked ? 700 : 400; readControls(); ensureFont().then(() => bus.emit('style:changed')); });
      $('weightR').addEventListener('input', () => { $('weightNum').textContent = $('weightR').value; ensureFont(); });
      $('thickR').addEventListener('input', () => { $('thickNum').textContent = $('thickR').value; });
      $('sharpR').addEventListener('input', () => { $('sharpNum').textContent = $('sharpR').value; });
      ['fontSel', 'weightR', 'sharpR', 'thickR', 'opacityR', 'italicChk', 'wrapChk', 'colorPick', 'outlineChk', 'outlineColor', 'outlineW', 'glowChk', 'glowFollow', 'glowType', 'glowColor', 'glowInt', 'glowRange', 'shadowChk', 'shadowColor', 'shadowOpacity', 'shadowBlur', 'shadowDist', 'shadowAngle', 'shadowX', 'shadowY', 'haloChk', 'haloBlur', 'haloAlpha', 'haloLayers', 'bgChk', 'bgColor', 'bgOpacity'].forEach(id => {
        $(id).addEventListener('input', () => {
          if (id === 'shadowX' || id === 'shadowY') shadowEm = true;                         // the offset is now the X / Y sliders ...
          else if (id === 'shadowDist' || id === 'shadowAngle') shadowEm = false;              // ... or angle + distance, whichever was touched last
          if (id === 'shadowX') $('shadowXNum').textContent = $('shadowX').value;
          if (id === 'shadowY') $('shadowYNum').textContent = $('shadowY').value;
          if (/^halo/.test(id)) { $('haloBlurNum').textContent = $('haloBlur').value; $('haloAlphaNum').textContent = $('haloAlpha').value; $('haloLayersNum').textContent = $('haloLayers').value; if (id !== 'haloChk') $('haloChk').checked = true; }
          if (id === 'glowColor') $('glowFollow').checked = false;      // choosing a glow colour = stop following the text colour
          if (/^shadow(Color|Opacity|Blur|Dist|Angle|X|Y)$/.test(id)) $('shadowChk').checked = true;   // touching a shadow control turns the shadow on (like CapCut)
          readControls(); bus.emit('style:changed');
        });
      });
      ['weightR', 'thickR', 'sharpR', 'italicChk', 'boldChk', 'colorPick', 'bgColor', 'glowChk', 'glowFollow', 'glowType', 'glowColor', 'glowInt', 'glowRange', 'shadowChk', 'shadowColor', 'shadowOpacity', 'shadowBlur', 'shadowDist', 'shadowAngle', 'shadowX', 'shadowY'].forEach(id => $(id).addEventListener('change', () => { cueRec = false; }));
      $('sizeR').addEventListener('input', () => { $('sizeNum').textContent = S.ui.precise.f1(parseFloat($('sizeR').value)); readControls(); bus.emit('style:changed'); });
      document.querySelectorAll('[data-pos]').forEach(chip => {
        chip.addEventListener('click', () => {
          S.subtitle.clearCuePositions();                  // every line follows the main position (one undo step)
          syncChips('data-pos', chip.dataset.pos);
          P.style.pos = chip.dataset.pos;
          bus.emit('style:changed');
        });
      });
      document.querySelectorAll('[data-gt]').forEach(chip => {      // glow type: picking one also switches the glow on (like CapCut)
        chip.addEventListener('click', () => {
          $('glowType').value = chip.dataset.gt; $('glowChk').checked = true;
          $('glowType').dispatchEvent(new Event('input')); $('glowType').dispatchEvent(new Event('change'));
        });
      });
      document.querySelectorAll('[data-km]').forEach(chip => {
        chip.addEventListener('click', () => { P.style.karaokeMode = chip.dataset.km; P.style.karaoke = chip.dataset.km !== 'off'; bus.emit('style:changed'); });
      });
      let fxRec = false;                                  // dragging the length slider = ONE undo step
      $('fxDur').addEventListener('input', () => {
        const v = Math.min(3, Math.max(0.01, Math.round(parseFloat($('fxDur').value) * 100) / 100)) || 0.22;
        $('fxDurNum').textContent = v.toFixed(2) + ' วิ';
        if (inCueScope()) {                               // this line's own length (equal to the global one = inherit)
          const i = S.state.ui.activeCue;
          if (!activeCue()) return;
          if (!fxRec && S.history) S.history.record('style');
          fxRec = true;
          S.subtitle.setCueLook(i, { fxDur: v !== P.style.fxDur ? v : null }, { history: false });
        } else {
          P.style.fxDur = v;
          bus.emit('style:changed');                      // saved with the project
        }
        bus.emit('fx:replay');
      });
      $('fxDur').addEventListener('change', () => { fxRec = false; });
      document.querySelectorAll('[data-fx]').forEach(chip => {
        chip.addEventListener('click', () => {
          const v = chip.dataset.fx, meta = S.fx.get(v), nat = meta && meta.lab ? meta.lab : null;   // nat = natural length of a newly added animation
          if (inCueScope()) {                                // this line's own animation (equal to the global one = inherit)
            const i = S.state.ui.activeCue;
            if (!activeCue()) return;
            if (S.history) S.history.record('style');
            const patch = { fx: v !== P.style.fx ? v : null };
            if (nat) patch.fxDur = nat !== P.style.fxDur ? nat : null;
            S.subtitle.setCueLook(i, patch, { history: false });
            syncChips('data-fx', v);
            bus.emit('style:changed');
            bus.emit('fx:replay');
            return;
          }
          syncChips('data-fx', v);
          P.style.fx = v;
          if (nat) P.style.fxDur = nat;
          bus.emit('style:changed');
          bus.emit('fx:replay');
        });
      });
      // ending animation (none | fade | zoom | down | shrink | blur): global, or this line only in 'cue' scope
      document.querySelectorAll('[data-fxo]').forEach(chip => {
        chip.addEventListener('click', () => {
          const v = chip.dataset.fxo;
          if (inCueScope()) {
            if (!activeCue()) return;
            if (S.history) S.history.record('style');
            S.subtitle.setCueLook(S.state.ui.activeCue, { fxOut: v !== (P.style.fxOut || 'none') ? v : null }, { history: false });
          } else P.style.fxOut = v;
          bus.emit('style:changed');
          bus.emit('fx:replay-out');
        });
      });
      // numeric animation controls (stagger ms, ending length s): ONE undo step per drag, like the intro length
      const numFx = { fxStep: ['fxStep', 350, 1, v => Math.round(v)], fxOutDur: ['fxOutDur', 0.4, 100, v => Math.round(v * 100) / 100] };
      const numRec = {};
      Object.keys(numFx).forEach(id => {
        const key = numFx[id][0], dflt = numFx[id][1], q = numFx[id][3];
        $(id).addEventListener('input', () => {
          const v = q(parseFloat($(id).value)) || dflt;
          if (inCueScope()) {
            if (!activeCue()) return;
            if (!numRec[id] && S.history) S.history.record('style');
            numRec[id] = true;
            const patch = {}; patch[key] = v !== P.style[key] ? v : null;
            S.subtitle.setCueLook(S.state.ui.activeCue, patch, { history: false });
          } else P[ 'style' ][key] = v;
          bus.emit('style:changed');
          bus.emit(id === 'fxOutDur' ? 'fx:replay-out' : 'fx:replay');
        });
        $(id).addEventListener('change', () => { numRec[id] = false; });
      });
      $('fxHl').addEventListener('input', () => {                // highlight colour used by ไฮไลต์ทีละคำ / สีวิ่งทีละตัว (and the word highlight while speaking)
        const v = $('fxHl').value;
        if (inCueScope()) {
          if (!activeCue()) return;
          S.subtitle.setCueLook(S.state.ui.activeCue, { highlight: v !== P.style.highlight ? v : null }, { history: false });
        } else P.style.highlight = v;
        bus.emit('style:changed');
        bus.emit('fx:replay');
      });
      bus.on('style:changed', syncControls);   // state is the truth; controls are a view of it
      $('fontSel').addEventListener('input', () => { ensureFont().then(() => bus.emit('style:changed')); });
      initSubUi();
      initScope();
      readControls();
      P.style.pos = (document.querySelector('[data-pos].active') || {dataset:{pos:'bottom'}}).dataset.pos;
      P.style.fx = (document.querySelector('[data-fx].active') || {dataset:{fx:'pop'}}).dataset.fx;
      if (!(P.style.fxDur > 0)) P.style.fxDur = 0.22;
      bus.emit('style:changed');
    }
  };
})(window.SubEd);
