/* =====================================================================
 * UI extras for the CapCut-style editor:
 *   - text bar at the top of the สไตล์ sheet (edit the line on screen, ✓ closes, ⤢ enlarges)
 *   - timeline zoom (two-finger pinch, Ctrl+wheel)
 *   - subtitle search (🔍 in the top bar): type, Enter / ▶ jumps to the next match
 *   - "apply this line's style to all lines" button at the top of the สไตล์ sheet
 * Emits: cue:select (via search), history through S.history.record.
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, P = S.state.project, state = S.state;

  function initTextBar() {
    const ta = $('teInput'); let editing = false, recorded = false;
    const idx = () => state.ui.activeCue;
    function pull() {
      if (editing) return;
      const c = P.subtitle.cues[idx()];
      ta.value = c ? c.text : ''; ta.disabled = !c;
      ta.placeholder = c ? '' : 'เล่นวิดีโอไปที่ประโยคที่ต้องการ แล้วแก้ข้อความที่นี่';
    }
    ta.addEventListener('focus', () => { recorded = false; });
    ta.addEventListener('input', () => {
      const i = idx(); if (i < 0) return;
      editing = true;
      if (!recorded && S.history) { S.history.record('text'); recorded = true; }   // one undo step per typing session
      S.subtitle.setCueText(i, ta.value, { history: false });
      editing = false;
    });
    ta.addEventListener('blur', pull);
    $('teOk').addEventListener('click', () => S.ui.tabs.close());
    ['cue:active', 'cue:text', 'cues:structure', 'sheet:toggle'].forEach(e => bus.on(e, pull));
  }

  function initZoom() {
    const el = $('tlScroll'); let d0 = 0, z0 = 80;
    const dist = t => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
    el.addEventListener('touchstart', e => { if (e.touches.length === 2) { d0 = dist(e.touches); z0 = S.ui.timeline.getZoom(); } }, { passive: true });
    el.addEventListener('touchmove', e => {
      if (e.touches.length !== 2 || !d0) return;
      if (e.cancelable) e.preventDefault();
      S.ui.timeline.setZoom(z0 * dist(e.touches) / d0);
    }, { passive: false });
    el.addEventListener('touchend', () => { d0 = 0; }, { passive: true });
    el.addEventListener('wheel', e => { if (!e.ctrlKey) return; e.preventDefault(); S.ui.timeline.setZoom(S.ui.timeline.getZoom() * (e.deltaY < 0 ? 1.15 : 1 / 1.15)); }, { passive: false });
  }

  function initSearch() {
    const bar = $('searchBar'), inp = $('searchInput'), cnt = $('searchCount');
    let hits = [], pos = -1;
    const norm = s => (s || '').toLowerCase().replace(/\s+/g, '');
    function find() {
      const q = norm(inp.value); hits = [];
      if (q) P.subtitle.cues.forEach((c, i) => { if (norm(c.text).indexOf(q) !== -1) hits.push(i); });
      pos = -1; cnt.textContent = q ? hits.length + ' รายการ' : '';
    }
    function next(dir) {
      if (!hits.length) { find(); if (!hits.length) return; }
      pos = (pos + (dir || 1) + hits.length) % hits.length;
      const i = hits[pos], c = P.subtitle.cues[i];
      S.ui.player.seek(Math.min(c.end - 0.01, c.start + 0.01));
      bus.emit('cue:active', { idx: i }); bus.emit('cue:select', { idx: i });
      cnt.textContent = (pos + 1) + '/' + hits.length;
    }
    const show = on => { bar.classList.toggle('show', on); if (on) { inp.focus(); inp.select(); } else inp.blur(); };
    $('ccSearch').addEventListener('click', () => show(!bar.classList.contains('show')));
    $('searchClose').addEventListener('click', () => show(false));
    $('searchNext').addEventListener('click', () => next(1));
    $('searchPrev').addEventListener('click', () => next(-1));
    inp.addEventListener('input', find);
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); next(e.shiftKey ? -1 : 1); } else if (e.key === 'Escape') show(false); });
    bus.on('cues:structure', find);
    bus.on('media:cleared', () => show(false));
  }

  /**
   * สีเฉพาะคำ tab: the line's text is shown in a box — press and hold in it and drag to select words (the same way as selecting text
   * anywhere on the phone), or do it on the picture. A colour then applies to every selected word, and each of them also glows in it.
   */
  function initWordColors() {
    const WS = S.ui.wordSel, sw = $('wdSwatches');
    const own = c => !!c && c.words.some(w => w.color || w.glow);
    WS.makePicker($('wdPick'), {
      info: (g, c) => !c ? '' : g ? 'กำลังแก้เฉพาะ: ' + WS.labelOf(60) : 'ยังไม่ได้เลือกคำ — แตะคำด้านบน (แตะอีกคำเพื่อเลือกเป็นช่วง) หรือกดค้างที่ข้อความแล้วลาก'
    });
    // the same full tone palette as the ข้อความ tab (eyedropper + colour wheel + every hue, light -> dark)
    const pal = S.ui.palette.mount(sw, (c, first) => { if (WS.get()) WS.color(c, first); });
    function curColor() { const g = WS.get(), c = P.subtitle.cues[state.ui.activeCue]; return g && c && c.words[g.a] ? (c.words[g.a].color || '') : ''; }
    function sync() {
      const has = !!WS.get(), c = P.subtitle.cues[state.ui.activeCue];
      pal.setDisabled(!has);
      $('wdClear').disabled = !has;
      pal.mark(curColor());
      $('wdClearAll').disabled = !own(c);
    }
    // a tap on a button must not take the focus (and the selection) away from the text box
    [$('wdClear').parentNode].forEach(el => ['pointerdown', 'mousedown'].forEach(ev => el.addEventListener(ev, e => { if (e.target.closest('button')) e.preventDefault(); })));
    $('wdClear').addEventListener('click', () => WS.clearStyle());
    $('wdClearAll').addEventListener('click', () => WS.clearLine());
    ['wordsel:changed', 'cue:active', 'cue:text', 'cues:structure', 'sheet:toggle'].forEach(e => bus.on(e, sync));
    sync();
  }

  /**
   * เรืองแสงเฉพาะคำ (glow tab): the words are the ones SELECTED (press and hold + drag in the text box here, in the text bar, or on the
   * picture). The colour row / switch / sliders then change ONLY those words' glow (word.glow); other words keep the line's glow.
   * Nothing selected = the glow controls above edit the whole line as before.
   */
  function initWordGlow() {
    const WS = S.ui.wordSel, on = $('wgOn'), col = $('wgColor'), inte = $('wgInt'), rng = $('wgRange');
    let rec = false;
    const cue = () => P.subtitle.cues[state.ui.activeCue];
    const picked = () => WS.words();
    const setVal = (el, v) => { if (String(el.value) !== String(v)) el.value = v; };
    const picker = WS.makePicker($('wgPick'), {
      info: (g, c) => !c ? '' : g ? 'กำลังแก้เฉพาะ: ' + WS.labelOf(60) : 'ยังไม่ได้เลือกคำ — แตะคำด้านบน (แตะอีกคำเพื่อเลือกเป็นช่วง) หรือกดค้างที่ข้อความแล้วลาก'
    });

    function sync() {
      const c = cue(), sel = picked(), has = !!c && sel.length > 0;
      [on, col, inte, rng, $('wgClear')].forEach(el => { el.disabled = !has; });
      $('wgClearAll').disabled = !c;
      if (!c) return;
      const base = S.subtitle.effectiveStyle(c, P.style).glow || {};
      const g = has ? S.subtitle.wordGlow(c.words[Math.min.apply(null, sel)], base) : base;   // the first picked word's glow (nothing picked: the line's, greyed out)
      on.checked = !!g.on;
      setVal(col, g.color || '#00e5ff');
      setVal(inte, g.intensity == null ? 60 : g.intensity); $('wgIntNum').textContent = Math.round(+inte.value);
      setVal(rng, g.range == null ? 12 : g.range); $('wgRangeNum').textContent = Math.round(+rng.value);
    }

    /** patch -> every selected word. `once` = a single click (one undo step); sliders / the colour wheel record once per drag. */
    function apply(patch, once) {
      if (!picked().length) return false;
      WS.glow(patch, once || !rec);
      rec = !once;
      return true;
    }

    const gpal = S.ui.palette.mount($('wgSwatches'), (c, first) => { if (!picked().length) return; WS.glow({ on: true, color: c, follow: false }, first); });
    const gsync = () => { const sel = picked(), c = cue(); gpal.setDisabled(!sel.length); const w = c && sel.length ? c.words[Math.min.apply(null, sel)] : null; gpal.mark(w && w.glow && w.glow.color ? w.glow.color : ''); };
    on.addEventListener('change', () => { const p = { on: on.checked }; if (on.checked && +inte.value <= 0) p.intensity = 60; apply(p, true); });
    col.addEventListener('input', () => apply({ on: true, color: col.value, follow: false }));
    inte.addEventListener('input', () => apply({ intensity: parseFloat(inte.value) }));
    rng.addEventListener('input', () => apply({ range: parseFloat(rng.value) }));
    [col, inte, rng].forEach(el => el.addEventListener('change', () => { rec = false; }));
    $('wgClear').addEventListener('click', () => apply(null, true));
    $('wgClearAll').addEventListener('click', () => {
      const c = cue(); if (!c) return;
      if (S.history) S.history.record('wordglow');
      c.words.forEach((_, wi) => S.subtitle.setWordGlow(state.ui.activeCue, wi, null, { history: false }));
    });
    ['cue:active', 'cue:text', 'cues:structure', 'sheet:toggle', 'wordsel:changed'].forEach(e => bus.on(e, () => { sync(); gsync(); }));
    sync(); gsync();
  }

  /**
   * "ใช้สไตล์ประโยคนี้กับทุกประโยค" — the button opens a small checklist (what to apply); "ใช้กับทุกประโยค" applies it.
   * The line is fixed when the list opens (by id), so a playing video cannot switch it under the user's finger.
   */
  function initApplyAll() {
    const btn = $('applyAllBtn'), pop = $('applyAllPop'), label = btn.textContent;
    let timer = 0, cueId = null;
    const cur = () => P.subtitle.cues.find(c => c.id === cueId);
    const close = () => { pop.hidden = true; cueId = null; };
    const sync = () => { btn.disabled = !P.subtitle.cues[state.ui.activeCue]; };

    function open() {
      const i = state.ui.activeCue, c = P.subtitle.cues[i];
      if (!c) return;
      cueId = c.id;
      const eff = S.subtitle.effectiveStyle(c, P.style);
      const coloured = P.subtitle.cues.reduce((n, x) => n + x.words.filter(w => w.color || w.glow).length, 0);
      const FX = new Proxy({}, { get: (_, k) => S.fx.label(k) });
      const onOff = g => (g && g.on ? 'เปิด' : 'ปิด');
      const opts = [
        { k: 'color', text: 'สีตัวอักษร', sw: eff.color },
        { k: 'highlight', text: 'สีไฮไลต์คำ', sw: eff.highlight },
        { k: 'bg', text: 'สีพื้นหลัง', sw: eff.bg.color },
        { k: 'fx', text: 'อนิเมชั่น', n: (FX[eff.fx] || eff.fx) + (S.fx.usesLength(eff.fx) && eff.fx !== 'none' && eff.fxDur > 0 ? ' · ' + (+eff.fxDur).toFixed(2) + ' วิ' : '') + (S.fx.usesStep(eff.fx) ? ' · ทุก ' + Math.round(eff.fxStep || 350) + ' ms' : '') + (eff.fxOut && eff.fxOut !== 'none' ? ' · ตอนจบ: ' + S.fx.outLabel(eff.fxOut) : '') },
        { k: 'weight', text: 'ความหนา', n: (eff.weight || (eff.bold ? 700 : 400)) + (eff.thick ? ' +' + eff.thick : '') },
        { k: 'sharp', text: 'ความคม', n: String(eff.sharp || 0) },
        { k: 'italic', text: 'ความเอียง', n: eff.italic ? 'เอียง' : 'ปกติ' },
        { k: 'glow', text: 'เรืองแสง', n: onOff(eff.glow), sw: eff.glow && eff.glow.on ? eff.glow.color : null },
        { k: 'shadow', text: 'เงา', n: onOff(eff.shadow), sw: eff.shadow && eff.shadow.on ? eff.shadow.color : null },
        { k: 'words', text: 'ล้างสี/เรืองแสงเฉพาะคำทุกประโยค', n: coloured ? coloured + ' คำ' : 'ไม่มี' }
      ];
      pop.innerHTML = '';
      const boxes = {};
      opts.forEach(o => {
        const row = document.createElement('label'); row.className = 'ap-opt';
        const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = true; boxes[o.k] = cb;
        row.appendChild(cb);
        if (o.sw) { const d = document.createElement('span'); d.className = 'ap-sw'; d.style.background = o.sw; row.appendChild(d); }
        const t = document.createElement('span'); t.textContent = o.text; row.appendChild(t);
        if (o.n) { const n = document.createElement('span'); n.className = 'ap-n'; n.textContent = o.n; row.appendChild(n); }
        pop.appendChild(row);
      });
      const note = document.createElement('p'); note.className = 'ap-note';
      note.textContent = 'ค่าที่ติ๊กจะกลายเป็นค่าหลักของทุกประโยคและทุกคำ ส่วนที่ไม่ติ๊กจะไม่ถูกแตะ · ข้อความและเวลาไม่เปลี่ยน · เลิกทำได้';
      pop.appendChild(note);
      const row = document.createElement('div'); row.className = 'ap-btns';
      const go = document.createElement('button'); go.type = 'button'; go.className = 'tx-tbtn ap-go'; go.textContent = 'ใช้กับทุกประโยค';
      const no = document.createElement('button'); no.type = 'button'; no.className = 'tx-tbtn'; no.textContent = 'ยกเลิก';
      const refresh = () => { go.disabled = !Object.keys(boxes).some(k => boxes[k].checked); };
      Object.keys(boxes).forEach(k => boxes[k].addEventListener('change', refresh));
      no.addEventListener('click', close);
      go.addEventListener('click', () => {
        const c2 = cur();
        if (!c2) { close(); return; }
        const parts = {}; Object.keys(boxes).forEach(k => { parts[k] = boxes[k].checked; });
        const ok = S.subtitle.applyCueStyleToAll(P.subtitle.cues.indexOf(c2), parts);
        close();
        if (!ok) return;
        btn.textContent = '✓ ใช้กับทุกประโยคแล้ว';
        clearTimeout(timer); timer = setTimeout(() => { btn.textContent = label; }, 2200);
      });
      row.appendChild(go); row.appendChild(no); pop.appendChild(row);
      pop.hidden = false;
    }

    btn.addEventListener('click', () => { if (pop.hidden) open(); else close(); });
    bus.on('sheet:toggle', close);
    bus.on('cues:structure', () => { close(); sync(); });
    ['cue:active', 'sheet:toggle'].forEach(e => bus.on(e, sync));
    sync();
  }

  S.ui.extras = { init() { initWordColors(); initWordGlow(); initTextBar(); initApplyAll(); initZoom(); initSearch(); } };
})(window.SubEd);
