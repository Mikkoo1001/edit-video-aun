/* =====================================================================
 * UI: "ปิดเสียงวิดีโอหลัก" — silence the sound of the main video (every clip on the main track) in one tap.
 *
 *   The main sound is the loaded file / the merged sound of all the clips (see ui/merge-clips.js); the "เสียง" tracks, the
 *   scene sound effects and the narration added on top are NOT part of it and keep playing. So this is the CapCut
 *   "mute clip audio" switch: the original sound off, everything you laid over it on.
 *
 *   Preview : the <video> element is muted (together with the speaker button: video.muted = mainMuted || userMuted).
 *   Export  : S.mainMute.get() is read by export/exporters.js and export/arrange-export.js — the main sound is left out of the
 *             file (the "เสียง" tracks and effects are still mixed in).
 *   Kept    : in localStorage across a refresh; a newly picked video starts with its sound on again.
 *
 *   SubEd.mainMute  { get(), set(bool), toggle(), userMuted(), setUser(bool) }      Emits: mainmute:changed (bool)
 * ===================================================================== */
(function (S) {
  'use strict';
  const bus = S.bus, video = S.dom.video, KEY = 'subed.mainMute';
  let main = false, user = false;
  try { main = localStorage.getItem(KEY) === '1'; } catch (e) { /* private window / blocked storage: starts un-muted */ }

  const ICON_ON = '<rect x="2.5" y="5" width="19" height="14" rx="3"/><path d="M8 10.5v3h2l2.5 2v-7l-2.5 2H8z" fill="currentColor"/><path d="M15.5 10.5a2.5 2.5 0 0 1 0 3"/>';
  const ICON_OFF = '<rect x="2.5" y="5" width="19" height="14" rx="3"/><path d="M8 10.5v3h2l2.5 2v-7l-2.5 2H8z" fill="currentColor"/><path d="m15 10.2 3.2 3.6M18.2 10.2 15 13.8"/>';

  function apply() { video.muted = main || user; }
  function paint() {
    document.body.classList.toggle('main-muted', main);
    const t = main ? 'เปิดเสียงวิดีโอหลัก (ตอนนี้ปิดอยู่)' : 'ปิดเสียงวิดีโอหลักทั้งหมด';
    const b = document.getElementById('mainMuteBtn'), ic = document.getElementById('mainMuteIcon');
    if (b) { b.classList.toggle('mm-on', main); b.title = t; b.setAttribute('aria-pressed', main ? 'true' : 'false'); }
    if (ic) ic.innerHTML = main ? ICON_OFF : ICON_ON;
    const a = document.getElementById('audMainMute');
    if (a) {
      a.classList.toggle('mm-on', main); a.setAttribute('aria-pressed', main ? 'true' : 'false');
      const sp = a.querySelector('span'); if (sp) sp.textContent = main ? 'เปิดเสียงวิดีโอหลัก' : 'ปิดเสียงวิดีโอหลัก';
      const svg = a.querySelector('svg'); if (svg) svg.innerHTML = main ? ICON_OFF : ICON_ON;
    }
  }
  function set(v, quiet) {
    v = !!v; if (v === main) { paint(); return; }
    main = v;
    try { localStorage.setItem(KEY, v ? '1' : '0'); } catch (e) {}
    apply(); paint();
    bus.emit('mainmute:changed', main);
    if (!quiet && S.ui.toast) S.ui.toast(main ? 'ปิดเสียงวิดีโอหลักแล้ว — เสียงที่เพิ่มในแทร็ก “เสียง” ยังดังอยู่ (ส่งออกก็ไม่มีเสียงวิดีโอหลัก)' : 'เปิดเสียงวิดีโอหลักแล้ว', 3200);
  }

  S.mainMute = {
    get: () => main,
    set: set,
    toggle: () => set(!main),
    userMuted: () => user,
    setUser(v) { user = !!v; apply(); }
  };
  S.ui.mainMute = {
    init() {
      ['mainMuteBtn', 'audMainMute'].forEach(id => { const el = document.getElementById(id); if (el) el.addEventListener('click', () => S.mainMute.toggle()); });
      apply(); paint();
      // a new video starts with its sound on: a silent export of a freshly picked clip would be a nasty surprise
      bus.on('media:selected', () => set(false, true));
      bus.on('media:cleared', () => set(false, true));
      bus.on('media:metadata', () => { apply(); paint(); });
    }
  };
})(window.SubEd);
