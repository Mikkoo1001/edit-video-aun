/* =====================================================================
 * UI: "ตำแหน่งเฉพาะประโยคนี้" (สไตล์ sheet -> จัดวาง). Moves ONLY the line on screen: the value is stored in that
 * cue's own override (cue.style.pos / posY, see SubEd.subtitle.effectiveStyle). Every other line has no override,
 * so it keeps following the global position (the chips + slider above).
 * Listens: cue:active, cue:style, cues:structure, style:changed. Calls: S.subtitle.setCueLook().
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, P = S.state.project;
  const ANCHOR = { top: 0.1, mid: 0.5, bottom: 0.85 };      // rough block centres for the 3 presets (same values the style copy uses)
  const STEP = 0.02;
  let rec = false;                                            // a slider drag = ONE undo step
  const idx = () => S.state.ui.activeCue;
  const cue = () => P.subtitle.cues[idx()];
  const clamp = v => Math.min(0.97, Math.max(0.05, v));
  const frac = v => +(Math.round(parseFloat(v) * 10) / 1000).toFixed(4);          // slider text 46.5 -> 0.465

  /** Where the line is now (centre, 0..1): its own posY, else its preset anchor, else the global position. */
  function currentY(c) {
    const es = S.subtitle.effectiveStyle(c, P.style);
    if (es.pos === 'custom') return es.posY == null ? 0.62 : es.posY;
    return ANCHOR[es.pos] != null ? ANCHOR[es.pos] : 0.62;
  }

  function sync() {
    const c = cue(), box = $('posCue');
    box.classList.toggle('off', !c);
    $('cuePosHint').textContent = !c ? 'เลื่อนวิดีโอไปที่ประโยคที่ต้องการก่อน'
      : (c.style && (c.style.pos || c.style.posY != null) ? 'ประโยคนี้ใช้ตำแหน่งของตัวเอง · ประโยคอื่นยังอยู่ตามตำแหน่งหลัก' : 'ประโยคนี้ยังใช้ตำแหน่งหลัก · ปรับด้านล่างเพื่อย้ายเฉพาะประโยคนี้');
    if (!c) return;
    const own = !!(c.style && (c.style.pos || c.style.posY != null)), es = S.subtitle.effectiveStyle(c, P.style);
    const v = S.ui.precise.r1(currentY(c) * 100);
    $('cuePosY').value = v; $('cuePosYNum').textContent = S.ui.precise.f1(v);
    document.querySelectorAll('[data-cpos]').forEach(ch => { ch.classList.toggle('active', own && es.pos === ch.dataset.cpos); ch.classList.toggle('own', own); });
    $('cuePosReset').style.display = own ? '' : 'none';
    $('cuePosAll').style.display = '';
  }

  function set(patch, record) {
    const c = cue(); if (!c) return;
    if (record && S.history) S.history.record('style');
    S.subtitle.setCueLook(idx(), patch, { history: false });
  }

  S.ui.cuePosition = {
    init() {
      $('cuePosY').addEventListener('input', () => {
        if (!cue()) return;
        const first = !rec; rec = true;
        $('cuePosYNum').textContent = S.ui.precise.f1(parseFloat($('cuePosY').value));
        set({ pos: 'custom', posY: clamp(frac($('cuePosY').value)) }, first);
      });
      $('cuePosY').addEventListener('change', () => { rec = false; });
      document.querySelectorAll('[data-cpos]').forEach(ch => ch.addEventListener('click', () => set({ pos: ch.dataset.cpos, posY: null }, true)));
      const nudge = d => { const c = cue(); if (c) set({ pos: 'custom', posY: clamp(Math.round((currentY(c) + d) * 1000) / 1000) }, true); };
      $('cuePosUp').addEventListener('click', () => nudge(-STEP));
      $('cuePosDown').addEventListener('click', () => nudge(STEP));
      $('cuePosReset').addEventListener('click', () => set({ pos: null, posY: null }, true));
      $('cuePosAll').addEventListener('click', () => { if (cue()) S.subtitle.applyCuePositionToAll(idx()); });
      ['cue:active', 'cue:style', 'cues:structure', 'style:changed'].forEach(e => bus.on(e, sync));
      sync();
    }
  };
})(window.SubEd);
