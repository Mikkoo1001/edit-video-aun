/* =====================================================================
 * UI: "เลือกประโยคแล้วปรับตำแหน่ง" (สไตล์ sheet -> จัดวาง) — the same pick-lines-from-a-list idea as "ปรับขนาดเฉพาะบางประโยค".
 * Lists every line; tap lines to choose them, then the position controls (ล่าง / กลาง / บน, สูง-ต่ำ, ซ้าย-ขวา, ▲ ▼) move ONLY the chosen
 * ones. The values are stored in each chosen cue's own override (cue.style.pos / posY / posX — the same keys "ประโยคนี้" and the frame on the
 * preview write), so the preview and the burned-in export already agree. Lines that are not chosen keep following the main position.
 * Listens: cue:style, cues:structure, cue:text, style:changed. Calls: S.subtitle.setCueLook(), S.history.record().
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, P = S.state.project;
  const ANCHOR = { top: 0.1, mid: 0.5, bottom: 0.85 };       // rough block centres of the 3 presets (same values as ui/cue-position.js)
  const NAME = { top: 'บน', mid: 'กลาง', bottom: 'ล่าง', custom: 'กำหนดเอง' };
  const STEP = 0.02;
  const picked = new Set();                                    // cue ids chosen in the list
  let rec = false;                                             // one slider drag = ONE undo step
  let open = false;

  const fmt = t => { t = Math.max(0, t || 0); const m = Math.floor(t / 60), s = t - m * 60; return m + ':' + (s < 10 ? '0' : '') + s.toFixed(1); };
  const clampY = v => Math.min(0.97, Math.max(0.05, v));
  const clampX = v => Math.min(0.95, Math.max(0.05, v));
  const frac = v => +(Math.round(parseFloat(v) * 10) / 1000).toFixed(4);                // slider text 46.5 -> 0.465
  const pc = f => Math.round(f * 1000) / 10;                                              // fraction -> % with one decimal
  const f1 = v => S.ui.precise.f1(v);
  const ownPos = c => !!(c.style && (c.style.pos || c.style.posY != null || c.style.posX != null));
  const chosen = () => { const out = []; P.subtitle.cues.forEach((c, i) => { if (picked.has(c.id)) out.push(i); }); return out; };
  function prune() { const ids = new Set(P.subtitle.cues.map(c => c.id)); picked.forEach(id => { if (!ids.has(id)) picked.delete(id); }); }

  function currentY(c) {
    const es = S.subtitle.effectiveStyle(c, P.style);
    if (es.pos === 'custom') return es.posY == null ? 0.62 : es.posY;
    return ANCHOR[es.pos] != null ? ANCHOR[es.pos] : 0.62;
  }
  const currentX = c => { const es = S.subtitle.effectiveStyle(c, P.style); return es.posX != null ? clampX(es.posX) : 0.5; };

  function renderList() {
    const list = $('cpList'), cues = P.subtitle.cues;
    list.innerHTML = '';
    if (!cues.length) { const e = document.createElement('div'); e.className = 'cs-empty'; e.textContent = 'ยังไม่มีประโยค — สร้างซับก่อน'; list.appendChild(e); return; }
    cues.forEach(c => {
      const row = document.createElement('button'); row.type = 'button'; row.className = 'cs-item' + (picked.has(c.id) ? ' on' : ''); row.dataset.id = c.id;
      const box = document.createElement('i'); box.className = 'cs-box';
      const tm = document.createElement('span'); tm.className = 'cs-time'; tm.textContent = fmt(c.start);
      const tx = document.createElement('span'); tx.className = 'cs-text'; tx.textContent = c.text || (c.words || []).map(w => w.word).join('') || '(ว่าง)';
      row.append(box, tm, tx);
      if (ownPos(c)) {
        const es = S.subtitle.effectiveStyle(c, P.style), b = document.createElement('b'); b.className = 'cs-badge';
        b.textContent = es.pos === 'custom' ? 'Y ' + f1(pc(currentY(c))) + (c.style && c.style.posX != null ? ' · X ' + f1(pc(currentX(c))) : '') : (NAME[es.pos] || 'เอง'); row.appendChild(b);
      }
      list.appendChild(row);
    });
  }

  function syncControls() {
    const idxs = chosen(), cues = P.subtitle.cues, has = idxs.length > 0;
    $('cpCount').textContent = has ? 'เลือก ' + idxs.length + ' ประโยค' : 'ยังไม่ได้เลือก';
    $('cpCtl').classList.toggle('off', !has);
    $('cpReset').disabled = !idxs.some(i => ownPos(cues[i]));
    const y = has ? pc(currentY(cues[idxs[0]])) : 62, x = has ? pc(currentX(cues[idxs[0]])) : 50;
    $('cpPosY').value = y; $('cpPosYNum').textContent = f1(y);
    $('cpPosX').value = x; $('cpPosXNum').textContent = f1(x);
    const mixed = idxs.length > 1 && idxs.some(i => Math.abs(pc(currentY(cues[i])) - y) > 0.05 || Math.abs(pc(currentX(cues[i])) - x) > 0.05);
    $('cpMixed').hidden = !mixed;
    document.querySelectorAll('[data-cppos]').forEach(ch => {
      ch.classList.toggle('active', has && idxs.every(i => ownPos(cues[i]) && S.subtitle.effectiveStyle(cues[i], P.style).pos === ch.dataset.cppos));
    });
  }

  function refresh() { if (!open) return; prune(); renderList(); syncControls(); }

  /** patch (or fn(cueIndex) -> patch) -> every chosen line. `record` = one undo step for the whole change. */
  function apply(make, record) {
    const idxs = chosen(); if (!idxs.length) return;
    if (record && S.history) S.history.record('style');
    idxs.forEach(i => S.subtitle.setCueLook(i, typeof make === 'function' ? make(i) : make, { history: false }));
  }

  S.ui.cueLayout = {
    init() {
      const toggle = $('cpToggle'), pop = $('cpPop'), video = S.dom.video;
      toggle.addEventListener('click', () => {
        open = !open; pop.hidden = !open; toggle.setAttribute('aria-pressed', open ? 'true' : 'false');
        if (open) { const a = P.subtitle.cues[S.state.ui.activeCue]; if (a && !picked.size) picked.add(a.id); }   // the line on screen starts chosen
        refresh();
      });
      $('cpList').addEventListener('click', e => {
        const it = e.target.closest('.cs-item'); if (!it) return;
        const id = it.dataset.id, i = P.subtitle.cues.findIndex(c => c.id === id); if (i < 0) return;
        if (picked.has(id)) picked.delete(id); else picked.add(id);
        if (picked.has(id) && video) { video.currentTime = P.subtitle.cues[i].start + 0.01; bus.emit('time:changed', video.currentTime); }   // show the line you just chose
        rec = false; renderList(); syncControls();
      });
      $('cpAll').addEventListener('click', () => { P.subtitle.cues.forEach(c => picked.add(c.id)); rec = false; renderList(); syncControls(); });
      $('cpNone').addEventListener('click', () => { picked.clear(); rec = false; renderList(); syncControls(); });
      document.querySelectorAll('[data-cppos]').forEach(ch => ch.addEventListener('click', () => { rec = false; apply({ pos: ch.dataset.cppos, posY: null }, true); }));
      $('cpPosY').addEventListener('input', () => {
        const first = !rec; rec = true; const y = clampY(frac($('cpPosY').value));
        $('cpPosYNum').textContent = f1(pc(y));
        apply({ pos: 'custom', posY: y }, first);
      });
      $('cpPosX').addEventListener('input', () => {
        const first = !rec; rec = true; const x = clampX(frac($('cpPosX').value));
        $('cpPosXNum').textContent = f1(pc(x));
        apply({ posX: Math.abs(x - 0.5) < 0.0005 ? null : +x.toFixed(4) }, first);               // exactly centre = no sideways override
      });
      ['cpPosY', 'cpPosX'].forEach(id => $(id).addEventListener('change', () => { rec = false; }));
      const nudge = d => { rec = false; apply(i => ({ pos: 'custom', posY: clampY(Math.round((currentY(P.subtitle.cues[i]) + d) * 1000) / 1000) }), true); };
      $('cpUp').addEventListener('click', () => nudge(-STEP));
      $('cpDown').addEventListener('click', () => nudge(STEP));
      $('cpReset').addEventListener('click', () => { rec = false; apply({ pos: null, posY: null, posX: null }, true); });
      ['cue:style', 'cues:structure', 'cue:text', 'style:changed'].forEach(ev => bus.on(ev, refresh));
    }
  };
})(window.SubEd);
