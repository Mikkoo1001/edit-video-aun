/* =====================================================================
 * UI: live caption overlay on the preview (HTML/CSS). Draws from
 * project.style + the cue active at the current time.
 * Listens: time:changed, cues:structure, cue:text, style:changed.
 * Emits: cue:active.
 * (The burned-in export uses render/caption-canvas.js with the SAME style data and the same
 * picture-relative anchors; see contentRect().)
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, state = S.state, P = state.project;
  const video = S.dom.video, videoBox = S.dom.videoBox, capLayer = S.dom.capLayer, capText = S.dom.capText;

  function escapeHtml(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

  /**
   * Where the picture really is inside the preview box. The <video> element can be taller than the
   * picture (letterboxing, e.g. portrait clips capped at 70vh), so caption position, side margins and
   * the export font scale must all be measured against THIS rectangle, not the element.
   */
  function contentRect() {
    const ar = S.arrange && S.arrange.aspectSize();                  // "จัดฉาก" on: the picture is the arranged frame (9:16 / 7:12), not the loaded clip
    const bw = videoBox.clientWidth, bh = videoBox.clientHeight, vw = ar ? ar[0] : video.videoWidth, vh = ar ? ar[1] : video.videoHeight;
    if (!vw || !vh || !bw || !bh) return { x: 0, y: 0, w: bw, h: bh };
    const k = Math.min(bw / vw, bh / vh), w = vw * k, h = vh * k;
    return { x: (bw - w) / 2, y: (bh - h) / 2, w: w, h: h };
  }

  /**
   * Reference picture width = the picture as it is on the MAIN screen (sheet closed, not fullscreen). Caption sizes (style.size, px) mean
   * "this big on the main screen"; the export scales them by (export width / this). While a sheet is open the preview shrinks, so the
   * caption is zoomed by (picture width / reference) there: it keeps the same size relative to the picture everywhere, and the export
   * matches what the main screen shows (measuring the shrunk preview at export time made the burned-in text too big).
   */
  /** The main preview is drawn smaller than the room it has (CSS: --pv). Caption sizes and the export keep meaning "this big on the FULL-size
   *  preview" (the reference below is the box divided by PV), so the smaller picture shows the caption proportionally smaller and the exported
   *  clip comes out exactly as before: the same resolution and the same caption size relative to the picture. */
  const PV = 0.8;
  document.documentElement.style.setProperty('--pv', String(PV));
  let refBox = null;                                   // the preview box on the main screen { w, h } (remembered while nothing is open), at full size (/ PV)
  const isFsNow = () => !!(document.fullscreenElement || document.webkitFullscreenElement) || videoBox.classList.contains('is-fs');
  const BUSY = ['sheet-open', 'sheet-closing', 'cue-selected', 'aud-selected', 'aud-add', 'aud-pop-open', 'scene-selected', 'vseg-selected'];
  const layoutBusy = () => BUSY.some(c => document.body.classList.contains(c));
  /** The picture width the preview box on the main screen gives the CURRENT picture shape (clip, or the 9:16 / 7:12 arranged frame). */
  function refWidth() {
    const ar = S.arrange && S.arrange.aspectSize(), vw = ar ? ar[0] : video.videoWidth, vh = ar ? ar[1] : video.videoHeight;
    if (!refBox || !vw || !vh) return contentRect().w || 0;
    return vw * Math.min(refBox.w / vw, refBox.h / vh);
  }
  function trackRef() {
    if (isFsNow() || layoutBusy() || !document.body.classList.contains('editing')) return;
    const bw = videoBox.clientWidth, bh = videoBox.clientHeight;
    if (bw > 0 && bh > 0 && video.videoWidth) refBox = { w: bw / PV, h: bh / PV };
  }

  function layoutOverlay() {
    trackRef();
    // the line on screen may carry its own position (cue.style.pos / posY); every other line uses the global one
    const es = S.subtitle.effectiveStyle(P.subtitle.cues[state.ui.activeCue], P.style);
    const r = contentRect(), bw = videoBox.clientWidth, bh = videoBox.clientHeight, pos = es.pos;
    capLayer.style.left = r.x + 'px';
    capLayer.style.right = (bw - r.x - r.w) + 'px';
    capLayer.style.padding = '0 ' + (r.w * 0.06) + 'px';
    { const rw = refWidth(), z = rw > 0 && r.w > 0 ? r.w / rw : 1; capText.style.zoom = Math.abs(z - 1) < 0.004 ? '' : String(+z.toFixed(4)); }
    // same anchors the canvas renderer uses: bottom edge at 91%, top at 6% / 44% of the picture height
    capLayer.style.transform = '';
    const shiftX = es.posX != null ? 'translateX(' + ((Math.min(0.95, Math.max(0.05, es.posX)) - 0.5) * r.w) + 'px) ' : '';
    if (pos === 'custom') {                       // posY = centre of the caption block, same as the canvas renderer
      const py = Math.min(0.97, Math.max(0.05, es.posY == null ? 0.62 : es.posY));
      capLayer.style.bottom = 'auto'; capLayer.style.top = (r.y + r.h * py) + 'px'; capLayer.style.transform = shiftX + 'translateY(-50%)';
    }
    else if (pos === 'bottom') { capLayer.style.top = 'auto'; capLayer.style.bottom = (bh - (r.y + r.h * 0.91)) + 'px'; }
    else { capLayer.style.bottom = 'auto'; capLayer.style.top = (r.y + r.h * (pos === 'top' ? 0.06 : 0.44)) + 'px'; }
    if (shiftX && pos !== 'custom') capLayer.style.transform = shiftX;
    const sx = es.posX != null ? (Math.min(0.95, Math.max(0.05, es.posX)) - 0.5) * r.w : 0;
    capLayer.style.transformOrigin = (r.w / 2 + sx) + 'px ' + (pos === 'custom' ? '0px' : '50%');
    bus.emit('caption:laidout');
  }

  /** text-shadow list: thickness rings in colour `c` (the colour of the word actually drawn), outline ring, glow, drop shadow. */
  function shadowCss(st, c) {
    const layers = [], T = st.thick || 0, g = S.subtitle.glowFor(st.glow, c[0] === '#' ? c : st.color);
    // extra thickness = rings of copies painted in the word's own colour (currentcolor) with the outline ring behind them
    const ring = (r, c) => { for (let i = 0; i < 16; i++) { const a = i * Math.PI / 8; layers.push((r * Math.cos(a)).toFixed(2) + 'px ' + (r * Math.sin(a)).toFixed(2) + 'px 0 ' + c); } };
    if (T > 0) { ring(T, c); if (st.outline.on) ring(T + st.outline.width, st.outline.color); }
    if (g && g.on && g.intensity > 0) S.render.glowLayers(g).forEach(l => layers.push(l.dx + 'px ' + l.dy + 'px ' + l.blur + 'px ' + (l.a >= 1 ? g.color : S.util.hexToRgba(g.color, l.a))));
    if (st.shadow && st.shadow.on) { const so = S.render.shadowOffset(st.shadow, st.size); layers.push(so.dx + 'px ' + so.dy + 'px ' + (st.shadow.blur * (1 - (st.sharp || 0) / 100)) + 'px ' + S.render.shadowColorCss(st.shadow)); }
    S.render.haloLayers(st.halo, st.size).forEach(l => layers.push('0 0 ' + l.blur + 'px ' + S.util.hexToRgba('#000000', l.a)));      // ขอบมืดรอบตัวอักษร
    return layers.length ? layers.join(',') : 'none';
  }

  /** CSS variables for the caption box. `st` is the EFFECTIVE style (global + the cue's own colours). */
  function applyCaptionVars(st) {
    capText.style.setProperty('--cap-font', st.font);
    capText.style.setProperty('--cap-size', st.size + 'px');
    capText.style.setProperty('--cap-weight', st.weight || (st.bold ? 700 : 400));
    capText.style.setProperty('--cap-style', st.italic ? 'italic' : 'normal');
    capText.style.setProperty('--cap-shadow', shadowCss(st, st.glow && st.glow.follow ? st.color : 'currentcolor'));
    capText.style.opacity = (st.opacity == null ? 100 : st.opacity) / 100;
    capText.style.setProperty('--cap-join', (st.sharp || 0) >= 50 ? 'miter' : 'round');
    capText.style.setProperty('--cap-color', st.color);
    capText.style.setProperty('--cap-hl', st.highlight);
    capText.style.setProperty('--cap-stroke', st.outline.on && !(st.thick > 0) ? st.outline.width + 'px ' + st.outline.color : '0px transparent');
    capText.style.setProperty('--cap-bg', st.bg.on ? S.util.hexToRgba(st.bg.color, st.bg.opacity) : 'transparent');
    capText.style.setProperty('--cap-ws', st.autoWrap ? 'normal' : 'nowrap');
    capText.style.setProperty('--cap-mw', st.autoWrap ? '100%' : 'none');
    capText.style.setProperty('--cap-wb', st.autoWrap ? 'break-word' : 'normal');
    capText.style.setProperty('--cap-pad', st.bg.on ? '5px 14px' : '0');
    capText.style.visibility = st.textOff ? 'hidden' : '';         // ข้อความ switched off: the line keeps its place, nothing is drawn
  }

  function applyStyleVars() {
    applyCaptionVars(S.subtitle.effectiveStyle(P.subtitle.cues[state.ui.activeCue], P.style));
    layoutOverlay();
    capLayer.className = 'cap-layer pos-' + S.subtitle.effectiveStyle(P.subtitle.cues[state.ui.activeCue], P.style).pos;
    const ac = P.subtitle.cues[state.ui.activeCue];
    if (ac) updateWordHighlight(ac, video.currentTime);
  }

  /**
   * Highlight modes (style.karaokeMode):
   *   custom (default) — only words that have their own colour light up (in that colour) while being read; other words keep the base colour
   *   all              — every word lights up while read: its own colour, else the highlight colour
   *   stay             — สีค้าง: words with their own colour turn that colour when read and keep it until the line ends
   *   stayAll          — สีค้าง for every word (own colour, else the highlight colour)
   *   off              — no timing; words with their own colour always show it
   */
  function updateWordHighlight(cue, t) {
    const spans = capText.querySelectorAll('.w'), st = S.subtitle.effectiveStyle(cue, P.style);
    const hlOff = !!st.hlOff;                                        // ไฮไลท์สี switched off: no word colour, no word glow, no highlight colour
    const mode = hlOff ? 'off' : (st.karaokeMode || (st.karaoke ? 'all' : 'off')), thick = (st.thick || 0) > 0;
    const peekOn = !!peek && peek.cue === cue && performance.now() < peek.until && video.paused;     // just recoloured, playhead elsewhere: show it anyway
    cue.words.forEach((w, i) => {
      const el = spans[i];
      if (!el) return;
      const wcol = hlOff ? '' : w.color, wglow = (hlOff || (st.wgOff && w.glow && w.glow.auto)) ? null : w.glow;     // what this word is allowed to show right now
      const peeked = !hlOff && peekOn && peek.wis.has(i) && !!w.color;
      const inRange = mode !== 'off' && ((t >= w.start && t < w.end) || peeked);
      const stay = mode === 'stay' || mode === 'stayAll';           // สีค้าง: lights up when the word is reached and STAYS until the line ends
      const active = inRange && (mode === 'all' || mode === 'stayAll' || !!wcol);
      el.classList.toggle('active', active);
      // `shown` = the colour as the stored #hex string (el.style.color reads back as rgb(...), which neither compares with w.color nor
      // lets a "follow the text" glow take the word's colour)
      const shown = ((wcol && w.hold) ? wcol : (mode === 'off' ? wcol : stay ? ((t >= w.start || peeked) && (wcol || (mode === 'stayAll' ? st.highlight : ''))) : (inRange && wcol))) || '';
      el.style.color = shown;
      // currentcolor does not reach a child span reliably, so the thickness rings get the word's colour explicitly
      // a word with its own glow gets its own full text-shadow list (it replaces the one inherited from the caption box)
      const idle = !!(wglow && wglow.auto && wcol && shown !== wcol);     // karaoke: the word's colour is not showing yet -> no glow either
      const wg = wglow && !idle ? wglow : null;
      const own = wg ? Object.assign({}, st, { glow: S.subtitle.wordGlow(w, st.glow) }) : st;
      el.style.textShadow = (thick || wg || (st.glow && st.glow.on && st.glow.follow)) ? shadowCss(own, shown || (active ? st.highlight : st.color)) : '';
    });
  }

  /** Words were just given a colour: for 2.5 s (clip paused) show them in that colour with their glow, whatever karaoke mode / playhead says.
   *  Several words coloured in one go (a selection) are all kept, not just the last one. */
  let peek = null, peekTimer = 0;
  bus.on('word:colored', e => {
    const cue = P.subtitle.cues[e.idx];
    if (!cue) return;
    const now = performance.now();
    if (peek && peek.cue === cue && now < peek.until) { peek.wis.add(e.wi); peek.until = now + 2500; }
    else peek = { cue: cue, wis: new Set([e.wi]), until: now + 2500 };
    clearTimeout(peekTimer);
    peekTimer = setTimeout(() => { peek = null; const c = P.subtitle.cues[state.ui.activeCue]; if (c) updateWordHighlight(c, video.currentTime); }, 2550);
  });

  function renderActiveCaption(idx, animate) {
    const cue = P.subtitle.cues[idx];
    layoutOverlay();                          // a different line may sit at a different height
    if (idx === -1 || !cue) { capText.textContent = ''; capText.className = 'cap-text'; return; }
    applyCaptionVars(S.subtitle.effectiveStyle(cue, P.style));
    const est = S.subtitle.effectiveStyle(cue, P.style), fx = est.fx;
    const anim = S.render.animOf(est), unit = anim && anim.unit ? anim.unit : 'all';
    // letter animations: every letter (a Thai consonant with its vowel / tone marks counts as one) is its own span.c inside its word
    let letter = 0;
    capText.innerHTML = cue.words.map((w, i) => {
      const txt = w.word.trim();
      const inner = unit === 'char' ? S.render.graphemes(txt).map(g => '<span class="c" style="--i:' + (letter++) + '">' + escapeHtml(g) + '</span>').join('') : escapeHtml(txt);
      return (i ? (w.nl ? '<br>' : (w.joined ? '' : ' ')) : '') + '<span class="w' + (unit === 'char' ? ' wc' : '') + '" data-wi="' + i + '"' + (unit === 'word' ? ' style="--i:' + i + '"' : '') + '>' + inner + '</span>';
    }).join('');
    const dur = S.render.animLength(anim || { duration: 0.22 }, est);
    capText.style.setProperty('--fx-dur', dur + 's');
    if (unit !== 'all') capText.style.setProperty('--step', S.render.unitTiming(cue, est, anim, S.render.unitCount(cue, anim)).step + 's');
    capText.querySelectorAll('.w').forEach((el, i, all) => { el.style.animationDelay = fx === 'typing' ? (i * dur / all.length).toFixed(3) + 's' : ''; });   // typing: word i appears at i/n of the length
    if (animate !== false) {                 // a new line appears: play the entrance. Editing text/colour must not replay it.
      capText.className = 'cap-text' + (fx !== 'none' ? ' fx-' + fx : '');
      void capText.offsetWidth;
      if (fx !== 'none') { capText.classList.remove('fx-' + fx); void capText.offsetWidth; capText.classList.add('fx-' + fx); }
    } else if (unit !== 'all' && !(anim && anim.inf)) {      // the spans were just rebuilt: a word / letter intro would start over on every edit, so leave it off
      capText.classList.remove('fx-' + fx);
    }
    updateWordHighlight(cue, video.currentTime);
    slowZoomTo(idx, video.currentTime);
  }

  /** Ending animation: in the last fxOutDur seconds of the line the caption layer fades / zooms / slides / shrinks / blurs away.
   *  It lives on the layer (not on .cap-text, whose own animations would override it) and follows the playhead, like the export. */
  const OUT_PROPS = ['opacity', 'scale', 'translate', 'filter'];
  function clearOutro() { OUT_PROPS.forEach(k => capLayer.style.removeProperty(k)); }
  function outroStyle(o) {
    return { opacity: String(+o.alpha.toFixed(3)), scale: String(+o.scale.toFixed(3)), translate: '0px ' + o.dy.toFixed(2) + 'px', filter: o.blur > 0.05 ? 'blur(' + o.blur.toFixed(2) + 'px)' : 'none' };
  }
  function applyOutro(idx, t) {
    const cue = P.subtitle.cues[idx];
    if (!cue || idx === -1) { clearOutro(); return; }
    const est = S.subtitle.effectiveStyle(cue, P.style), od = S.render.outLength(est, cue);
    if (!(od > 0) || t < cue.end - od) { clearOutro(); return; }
    const st = outroStyle(S.render.outAt(est.fxOut, (t - (cue.end - od)) / od, est.size));
    OUT_PROPS.forEach(k => { capLayer.style[k] = st[k]; });
  }
  /** Picking an ending animation: play it once on the line on screen (does not move the playhead). */
  function playOutDemo() {
    const idx = state.ui.activeCue, cue = P.subtitle.cues[idx];
    if (!cue || !capLayer.animate) return;
    const est = S.subtitle.effectiveStyle(cue, P.style), od = S.render.outLength(est, cue);
    if (!(od > 0)) return;
    const frames = [0, 0.25, 0.5, 0.75, 1].map(p => Object.assign({ offset: p }, outroStyle(S.render.outAt(est.fxOut, p, est.size))));
    try { capLayer.animate(frames, { duration: Math.max(200, od * 1000), easing: 'linear' }); } catch (e) { /* older browser: no demo */ }
  }
  bus.on('fx:replay-out', playOutDemo);

  /** Play the intro of the line on screen again (used while choosing an animation / dragging its length). */
  function replayCaption() { const i = state.ui.activeCue; if (i >= 0 && P.subtitle.cues[i]) renderActiveCaption(i, true); }
  bus.on('fx:replay', replayCaption);

  function updateCaption(t) {
    const idx = S.subtitle.indexAt(P.subtitle.cues, t);
    if (idx !== state.ui.activeCue) {
      state.ui.activeCue = idx;
      renderActiveCaption(idx);
      bus.emit('cue:active', { idx: idx });
    } else if (idx !== -1 && P.style.karaoke) {
      updateWordHighlight(P.subtitle.cues[idx], t);
    }
    if (idx !== -1) slowZoomTo(idx, t);
    applyOutro(idx, t);
  }

  /** "ซูมช้าๆ": the whole line pushes in slowly; its size follows the playhead (so seeking / pausing stay in step with the export). */
  function slowZoomTo(idx, t) {
    const cue = P.subtitle.cues[idx];
    const slow = !!cue && S.subtitle.effectiveStyle(cue, P.style).fx === 'slowzoom';
    capText.classList.toggle('fx-slowzoom', slow);
    if (!slow) { capText.style.removeProperty('--sz'); return; }
    const p = Math.min(1, Math.max(0, (t - cue.start) / Math.max(0.2, cue.end - cue.start)));
    capText.style.setProperty('--sz', (1 + 0.12 * p).toFixed(4));
  }

  /** The cue list or a cue's timing changed: find the active line again and redraw it without replaying the entrance. */
  function resync() {
    const idx = S.subtitle.indexAt(P.subtitle.cues, video.currentTime);
    state.ui.activeCue = idx;
    renderActiveCaption(idx, false);
    applyOutro(idx, video.currentTime);
    bus.emit('cue:active', { idx: idx });
  }

  S.ui.preview = {
    contentRect: contentRect,
    refWidth: refWidth,
    relayout: layoutOverlay,
    peekInfo: function () { return peek && performance.now() < peek.until && peek.cue ? peek : null; },
    init() {
      if (window.ResizeObserver) new ResizeObserver(layoutOverlay).observe(videoBox);
      window.addEventListener('resize', layoutOverlay);
      bus.on('media:metadata', () => { refBox = null; layoutOverlay(); });
      bus.on('sheet:toggle', e => { if (e && e.settled) layoutOverlay(); });
      bus.on('time:changed', updateCaption);
      bus.on('style:changed', applyStyleVars);
      bus.on('cue:text', e => { if (state.ui.activeCue === e.idx) renderActiveCaption(e.idx, false); });
      bus.on('cue:style', e => { if (state.ui.activeCue === e.idx) applyStyleVars(); });
      bus.on('cue:timing', resync);
      bus.on('cues:structure', resync);
    }
  };
})(window.SubEd);
