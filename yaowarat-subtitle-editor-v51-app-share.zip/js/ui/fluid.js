/* =====================================================================
 * UI: fluid feel — the few things CSS cannot do alone.
 *   · ripple on the big buttons (genbtn, ส่งออก, ยกเลิก ...) and the library cards
 *   · a small "pop" on the play / pause icon
 *   · the export percentage glides to its next number instead of jumping (the exporters write "37%" in steps)
 * Everything is skipped when the device asks for reduced motion. CSS part: css/fluid.css
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, video = S.dom.video;
  const reduced = () => !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);

  function pop(el) { if (!el || reduced()) return; el.classList.remove('flu-pop'); void el.offsetWidth; el.classList.add('flu-pop'); }

  const RIP = '.genbtn,.cc-export,.xo-cancel,.xo-close,.tx-tbtn,.mg-tplbtn,.mg-btn3d,.mg-card,.drop-audio';
  function ripple(e) {
    if (reduced()) return;
    const b = e.target.closest && e.target.closest(RIP); if (!b || b.disabled) return;
    if (getComputedStyle(b).position === 'static') b.style.position = 'relative';
    const r = b.getBoundingClientRect(), d = Math.max(r.width, r.height) * 2.1;
    const wrap = document.createElement('span'); wrap.className = 'flu-rip';
    const dot = document.createElement('i'); dot.style.width = dot.style.height = d + 'px';
    dot.style.left = (e.clientX - r.left - d / 2) + 'px'; dot.style.top = (e.clientY - r.top - d / 2) + 'px';
    wrap.appendChild(dot); b.appendChild(wrap); setTimeout(() => wrap.remove(), 650);
  }

  /** "37%" written by the exporter -> the shown number eases there (ignores text that is not a plain percentage) */
  function glidePercent() {
    const el = $('xoPct'); if (!el || !window.MutationObserver) return;
    let shown = 0, target = 0, raf = 0, last = '';
    const parse = t => { const m = /^\s*(\d+(?:\.\d+)?)\s*%\s*$/.exec(t); return m ? +m[1] : null; };
    const put = v => { last = Math.round(v) + '%'; el.textContent = last; };
    const step = () => {
      raf = 0; const gap = target - shown;
      if (Math.abs(gap) < 0.45) shown = target; else shown += gap * 0.2;
      put(shown); if (shown !== target) raf = requestAnimationFrame(step);
    };
    new MutationObserver(() => {
      const t = el.textContent; if (t === last) return;
      const v = parse(t); if (v == null || reduced()) { shown = v == null ? shown : v; target = shown; last = t; return; }
      target = v;
      if (v < shown - 0.5 || v === 0) { shown = v; put(v); return; }                  // a new run starts over: no glide backwards
      put(shown);                                                                        // undo the jump now (before paint), then glide
      if (!raf) raf = requestAnimationFrame(step);
    }).observe(el, { childList: true, characterData: true, subtree: true });
  }

  S.ui.fluid = {
    pop: pop,
    init() {
      document.addEventListener('pointerdown', ripple, { passive: true });
      const pi = $('playIcon'); if (pi) ['play', 'pause'].forEach(ev => video.addEventListener(ev, () => pop(pi)));
      ['mainMuteBtn', 'muteBtn', 'ccUndo', 'ccRedo'].forEach(id => { const b = $(id); if (b) b.addEventListener('click', () => pop(b.querySelector('svg'))); });
      glidePercent();
      // library cards arrive in a short cascade (index -> --k)
      S.bus.on('sheet:toggle', () => { document.querySelectorAll('#mgLib .mg-card,#mgLib .mg-ic,#mgLib .mg-btn3d').forEach((n, i) => { if (!n.style.getPropertyValue('--k')) n.style.setProperty('--k', Math.min(i, 14)); }); });
    }
  };
})(window.SubEd);
