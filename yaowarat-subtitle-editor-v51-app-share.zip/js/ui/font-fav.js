/* =====================================================================
 * UI: ฟอนต์โปรด (CapCut "Brand fonts") on top of the font grid that ui/cc-color.js builds.
 *   - a filter row  [🔖 ฟอนต์โปรด | ทั้งหมด]  above the grid; ฟอนต์โปรด is the default view, like in CapCut
 *   - press and HOLD a font (or tap its bookmark) to add / remove it from the favourites
 *   - the first time, the favourites are the faces of the reference video that really exist in the app:
 *     SYSTEM, มหานคร, BEBAS NEUE, อนุพันธ์ Bd, อนุพันธ์ SB, Prompt Bd, BANGERS
 *     (Prohibition / WarGod were removed: their font files were never in /fonts)
 *   - a face listed in LOCAL_FACES whose file is missing from /fonts gets an "ไม่มีไฟล์" badge (none at the moment)
 * It only reads / writes the #fontSel select through the existing grid chips, so the style state, undo, resume and export
 * keep working exactly as before. Favourites are a per-device preference (localStorage), not part of the project.
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus;
  const KEY_FAV = 'yaowarat.fontFav.v1', KEY_VIEW = 'yaowarat.fontFavView.v1';
  const DEFAULT_FAV = ['ค่าเริ่มต้นระบบ', 'มหานคร', 'มหานคร Flat', 'Bebas Neue', 'อนุพันธ์ Bd', 'อนุพันธ์ SB', 'Prompt Bd', 'Bangers'];
  const REMOVED = ['Prohibition', 'WarGod'];            // fonts taken out (no file): drop them from favourites saved earlier
  const LOCAL_FACES = [];                                          // families that must have a file in /fonts (add the name here to get the "ไม่มีไฟล์" badge)
  const HOLD_MS = 450, MOVE_PX = 8;
  const MARK_SVG = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4h10a1 1 0 0 1 1 1v15l-6-4-6 4V5a1 1 0 0 1 1-1z"/></svg>';

  let favs = [], view = 'fav', grid = null, filter = null, hint = null, empty = null, suppressClick = false;
  const missing = {};                                            // family -> true when its file could not be loaded

  const store = {
    get(k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { window.localStorage.setItem(k, v); } catch (e) { /* private mode / full: favourites live for this visit only */ } }
  };
  const labelOf = o => o.textContent.replace(/\s*\(.*\)/, '').trim();
  const familyOf = v => String(v || '').split(',')[0].replace(/["']/g, '').trim();

  function loadFavs() {
    let list = null;
    try { list = JSON.parse(store.get(KEY_FAV)); } catch (e) { list = null; }
    favs = Array.isArray(list) ? list.filter(x => typeof x === 'string' && REMOVED.indexOf(x) < 0) : DEFAULT_FAV.slice();
    view = store.get(KEY_VIEW) === 'all' ? 'all' : 'fav';
  }
  const saveFavs = () => store.set(KEY_FAV, JSON.stringify(favs));

  function chips() { return Array.from(grid.querySelectorAll('.font-chip')); }
  function optOf(chip) { return $('fontSel').options[+chip.dataset.i]; }

  /** show / hide / reorder the tiles for the current view and paint the bookmarks */
  function paint() {
    let shown = 0;
    chips().forEach((chip, n) => {
      const key = chip.dataset.label, at = favs.indexOf(key), isFav = at >= 0;
      chip.classList.toggle('fav', isFav);
      chip.setAttribute('aria-pressed', isFav ? 'true' : 'false');
      const hide = (view === 'fav' && !isFav && chip.dataset.fsearch !== '1') || chip.dataset.fhide === '1';      // a font search / category shows matches from every font
      chip.hidden = hide;
      chip.style.order = view === 'fav' ? String(at) : String(n);     // favourites keep the order they were added in
      if (!hide) shown++;
    });
    filter.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.v === view));
    empty.hidden = !(view === 'fav' && shown === 0);
    hint.textContent = view === 'fav' ? 'กดค้างที่ฟอนต์เพื่อเพิ่ม / ลบจากฟอนต์โปรด' : 'กดค้างที่ฟอนต์เพื่อเพิ่มในฟอนต์โปรด · แตะ 🔖 ก็ได้';
    paintMissing();
  }

  function toggleFav(chip) {
    const key = chip.dataset.label, at = favs.indexOf(key);
    if (at >= 0) favs.splice(at, 1); else favs.push(key);
    saveFavs();
    chip.classList.remove('pulse'); void chip.offsetWidth; chip.classList.add('pulse');
    if (navigator.vibrate) { try { navigator.vibrate(18); } catch (e) { /* not allowed */ } }
    paint();
  }

  /** press-and-hold on a tile = toggle favourite; moving the finger (scrolling) or lifting early cancels it */
  function initHold() {
    let timer = 0, start = null, target = null;
    const cancel = () => { if (timer) { clearTimeout(timer); timer = 0; } start = null; target = null; };
    grid.addEventListener('pointerdown', e => {
      const chip = e.target.closest('.font-chip');
      if (!chip || e.target.closest('.fav-mark') || (e.pointerType === 'mouse' && e.button !== 0)) return;
      cancel(); start = { x: e.clientX, y: e.clientY }; target = chip;
      timer = setTimeout(() => { timer = 0; suppressClick = true; toggleFav(target); setTimeout(() => { suppressClick = false; }, 600); }, HOLD_MS);
    });
    grid.addEventListener('pointermove', e => { if (start && Math.hypot(e.clientX - start.x, e.clientY - start.y) > MOVE_PX) cancel(); });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => grid.addEventListener(ev, cancel));
    grid.addEventListener('scroll', cancel, true);
    grid.addEventListener('contextmenu', e => { if (e.target.closest('.font-chip')) e.preventDefault(); });     // no text-selection / long-press menu on a tile
    // capture phase: swallow the click that follows a long-press BEFORE the tile's own handler picks the font
    grid.addEventListener('click', e => {
      const chip = e.target.closest('.font-chip');
      if (!chip) return;
      if (suppressClick) { e.stopImmediatePropagation(); e.preventDefault(); suppressClick = false; return; }
      if (e.target.closest('.fav-mark')) { e.stopImmediatePropagation(); e.preventDefault(); toggleFav(chip); }
    }, true);
  }

  // ---- faces whose file is not in /fonts ----------------------------------------------------------------------------
  /** read what the browser already knows: every @font-face of the family failed = file missing, any loaded = fine, still unloaded = unknown */
  function refreshStatus() {
    if (!document.fonts) return;
    LOCAL_FACES.forEach(fam => {
      const faces = Array.from(document.fonts).filter(f => f.family.replace(/["']/g, '') === fam);
      if (!faces.length) return;
      if (faces.some(f => f.status === 'loaded')) missing[fam] = false;
      else if (faces.every(f => f.status === 'error')) missing[fam] = true;
    });
  }
  function paintMissing() {
    refreshStatus();
    chips().forEach(chip => {
      const o = optOf(chip), fam = familyOf(o && o.value);
      const gone = LOCAL_FACES.indexOf(fam) >= 0 && !!missing[fam];
      chip.classList.toggle('missing', gone);
      const small = chip.querySelector('small');
      if (small) small.textContent = gone ? labelOf(o) + ' · ไม่มีไฟล์' : labelOf(o);
    });
    const sel = $('fontSel').selectedOptions[0], fam = sel ? familyOf(sel.value) : '';
    const gone = LOCAL_FACES.indexOf(fam) >= 0 && !!missing[fam];
    const box = $('fontGridHint');
    box.hidden = !gone;
    if (gone) box.textContent = 'ยังไม่พบไฟล์ฟอนต์ ' + fam + ' — วาง ' + fam + '.woff2 (หรือ .ttf/.otf) ในโฟลเดอร์ fonts/ แล้วอัปโหลดใหม่ ตอนนี้จะแสดงเป็นฟอนต์สำรองแทน';
  }
  /** Ask the browser for each local face (only when the font tab is opened, so a project that never opens it makes no request). */
  function scanMissing() {
    if (!document.fonts || !document.fonts.load) return;
    LOCAL_FACES.forEach(fam => {
      if (!Array.from(document.fonts).some(f => f.family.replace(/["']/g, '') === fam)) return;     // no @font-face for it: nothing to check
      document.fonts.load('400 20px "' + fam + '"').then(paintMissing, paintMissing);
    });
  }

  S.ui.fontFav = {
    init() {
      grid = $('fontGrid');
      if (!grid) return;                                         // the grid is built by ui/cc-color.js; without it there is nothing to extend
      loadFavs();
      filter = document.createElement('div'); filter.id = 'fontFilter'; filter.className = 'font-filter';
      filter.innerHTML = '<button type="button" data-v="fav">' + MARK_SVG + '<span>ฟอนต์โปรด</span></button><button type="button" data-v="all"><span>ทั้งหมด</span></button>';
      grid.parentNode.insertBefore(filter, grid);
      empty = document.createElement('p'); empty.id = 'fontFavEmpty'; empty.className = 'hint font-empty'; empty.hidden = true;
      empty.textContent = 'ยังไม่มีฟอนต์โปรด — เปิดแท็บ "ทั้งหมด" แล้วกดค้างที่ฟอนต์ที่ชอบ';
      hint = document.createElement('p'); hint.id = 'fontFavHint'; hint.className = 'hint font-hint';
      const warn = document.createElement('p'); warn.id = 'fontGridHint'; warn.className = 'hint font-warn'; warn.hidden = true;
      grid.parentNode.insertBefore(empty, grid.nextSibling);
      grid.parentNode.insertBefore(hint, empty.nextSibling);
      grid.parentNode.insertBefore(warn, hint.nextSibling);

      chips().forEach(chip => {
        const o = optOf(chip);
        chip.dataset.label = labelOf(o);
        const m = document.createElement('i'); m.className = 'fav-mark'; m.innerHTML = MARK_SVG; m.title = 'ฟอนต์โปรด';
        chip.insertBefore(m, chip.firstChild);
      });

      filter.addEventListener('click', e => {
        const b = e.target.closest('button'); if (!b) return;
        view = b.dataset.v === 'all' ? 'all' : 'fav'; store.set(KEY_VIEW, view); paint();
      });
      initHold();
      document.querySelector('#subTabs').addEventListener('click', e => { const b = e.target.closest('button'); if (b && b.dataset.sub === 'font') { paint(); scanMissing(); } });
      bus.on('style:changed', paintMissing);
      paint();
    },
    /** a tile added while the app runs (uploaded / custom font): give it the bookmark like the others */
    decorate(chip) {
      if (!chip || chip.querySelector('.fav-mark')) return;
      chip.dataset.label = labelOf(optOf(chip));
      const m = document.createElement('i'); m.className = 'fav-mark'; m.innerHTML = MARK_SVG; m.title = 'ฟอนต์โปรด';
      chip.insertBefore(m, chip.firstChild);
      paint();
    },
    repaint() { if (grid) paint(); },
    /** for tests / other modules */
    list() { return favs.slice(); }
  };
})(window.SubEd);
