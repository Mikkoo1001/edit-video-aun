/* =====================================================================
 * UI layer — shared element handles. Everything under js/ui/ may touch the
 * DOM; nothing outside js/ui/ (and the media-level bits of export/) may.
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$ = id => document.getElementById(id);
  S.dom = { video: $('video'), videoBox: $('videoBox'), capLayer: $('capLayer'), capText: $('capText') };
  S.ui = S.ui || {};
})(window.SubEd);
