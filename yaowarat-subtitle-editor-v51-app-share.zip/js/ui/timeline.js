/* =====================================================================
 * UI: timeline — scrub, trim handles, thumbnails, ruler, playhead, and the
 * subtitle lane (draggable cue blocks).
 *
 * Reads: project.media.duration, project.trim, project.subtitle.cues.
 * Emits: trim:changed, cue:timing, cue:active, time:changed (via player.seek).
 * Listens: media:metadata, media:cleared, cues:structure, cue:text, cue:active, time:changed.
 *
 * One video lane + several subtitle lanes (blocks that overlap in time go on separate rows). When a second kind of
 * lane is needed (B-roll, music, SFX) split the "subtitle lane" section below
 * into its own file and give each lane a render(project) function.
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, fmt = S.util.fmt, state = S.state, P = state.project;
  const video = S.dom.video;
  const timeline = $('timeline'), tlThumbs = $('tlThumbs'), tlRuler = $('tlRuler');
  const dimLeft = $('dimLeft'), dimRight = $('dimRight'), trimLeftEl = $('trimLeft'), trimRightEl = $('trimRight');
  const capTrack = $('capTrack'), tlPlayhead = $('tlPlayhead'), trimInfo = $('trimInfo');
  const tlScroll = $('tlScroll'), padL = $('tlPadL'), padR = $('tlPadR');
  let PPS = 80;            // pixels per second: the strip scrolls under a fixed centre playhead (CapCut style)
  let lastSet = -99;

  // ---------- scrub / trim / playhead ----------
  function timeFromClientX(x) {
    if (!P.media.duration) return 0;
    const rect = timeline.getBoundingClientRect();
    const frac = Math.min(1, Math.max(0, (x - rect.left) / rect.width));
    return frac * P.media.duration;
  }
  function layoutScroll() {
    const half = Math.max(0, tlScroll.clientWidth / 2);
    padL.style.width = padR.style.width = half + 'px';
    timeline.style.width = Math.max(1, (P.media.duration || 0) * PPS) + 'px';
  }
  const trimDragging = () => String(state.ui.dragging || '').indexOf('trim-') === 0;
  function syncScroll(force) {
    if (!P.media.duration || !tlScroll.clientWidth) return;
    if (trimDragging() && !force) return;      // a trim handle is under the finger: the strip must stand still (it used to chase the playhead, which moved the picture under the finger and threw the cut somewhere else)
    const x = video.currentTime * PPS;
    if (force || Math.abs(tlScroll.scrollLeft - x) > 1.5) { lastSet = x; tlScroll.scrollLeft = x; }
  }
  function updatePlayhead() { syncScroll(false); }
  function updateTrimUI() {
    if (!P.media.duration) return;
    const lp = P.trim.start / P.media.duration * 100, rp = P.trim.end / P.media.duration * 100;
    trimLeftEl.style.left = lp + '%';
    trimRightEl.style.left = rp + '%';
    dimLeft.style.width = lp + '%';
    dimRight.style.width = (100 - rp) + '%';
    trimInfo.textContent = 'ความยาวที่ตัด: ' + fmt(P.trim.end - P.trim.start) + ' (' + fmt(P.trim.start) + '–' + fmt(P.trim.end) + ')';
    bus.emit('trim:changed');
  }
  /** Drag a trim handle. The cut is simply "the time under the finger": the strip does NOT follow the playhead meanwhile (see
   *  syncScroll) and the playhead is not dragged along either — it is only brought back inside the cut when the finger lifts.
   *  Holding the handle near the left / right edge of the strip scrolls it (like carrying a caption block), so a long clip can
   *  be cut in one drag. */
  function setupTrimHandle(el, side) {
    let lastX = 0, raf = 0;
    const mine = () => state.ui.dragging === 'trim-' + side;
    function place(clientX) {
      const t = timeFromClientX(clientX);
      if (side === 'left') P.trim.start = Math.max(0, Math.min(t, P.trim.end - 0.2));
      else P.trim.end = Math.min(P.media.duration, Math.max(t, P.trim.start + 0.2));
      updateTrimUI();
    }
    function edgeScroll() {
      raf = 0;
      if (!mine()) return;
      const r = tlScroll.getBoundingClientRect(), EDGE = 36;
      const v = lastX > r.right - EDGE ? Math.min(18, (lastX - (r.right - EDGE)) / 2 + 2) : lastX < r.left + EDGE ? -Math.min(18, ((r.left + EDGE) - lastX) / 2 + 2) : 0;
      if (v) {
        const before = tlScroll.scrollLeft;
        tlScroll.scrollLeft = before + v;
        if (tlScroll.scrollLeft !== before) place(lastX);          // the picture slid under the finger: the time under it changed
      }
      raf = requestAnimationFrame(edgeScroll);
    }
    function finish() {
      if (!mine()) return;
      state.ui.dragging = null;
      if (raf) { cancelAnimationFrame(raf); raf = 0; }
      const t = video.currentTime, c = Math.min(P.trim.end, Math.max(P.trim.start, t));
      if (Math.abs(c - t) > 1e-3) S.ui.player.seek(c);              // the playhead was cut off: put it on the new edge (the strip follows once, now)
      bus.emit('trim:changed');
    }
    el.addEventListener('pointerdown', e => {
      e.stopPropagation();
      if (!video.paused) video.pause();                             // playback scrolls the strip: not while cutting
      state.ui.dragging = 'trim-' + side;
      lastX = e.clientX;
      el.setPointerCapture(e.pointerId);
      if (!raf) raf = requestAnimationFrame(edgeScroll);
    });
    el.addEventListener('pointermove', e => {
      if (!mine()) return;
      e.stopPropagation();
      lastX = e.clientX;
      place(e.clientX);
    });
    ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(ev => el.addEventListener(ev, e => { e.stopPropagation(); finish(); }));
  }

  function buildRuler() {
    tlRuler.innerHTML = '';
    const d = P.media.duration; if (!d) return;
    const step = [1, 2, 5, 10, 15, 30, 60, 120, 300].find(x => x * PPS >= 52) || 600, pad = S.util.pad;
    for (let t = 0; t <= d; t += step) {
      const sp = document.createElement('span');
      sp.style.left = (t / d * 100) + '%';
      sp.textContent = pad(Math.floor(t / 60)) + ':' + pad(Math.floor(t % 60));
      tlRuler.appendChild(sp);
    }
  }

  let thumbSeq = 0;                                   // a newer clip (or a re-run) makes the older generator stop instead of mixing its pictures in
  function generateThumbnails(file, duration) {
    const mine = ++thumbSeq;
    tlThumbs.innerHTML = '';
    if (!file || !duration) return;
    const N = Math.max(4, Math.min(80, Math.round(duration * PPS / 52)));
    const tvid = document.createElement('video');
    tvid.muted = true; tvid.playsInline = true;
    const tUrl = URL.createObjectURL(file);
    tvid.src = tUrl;
    const stop = () => { URL.revokeObjectURL(tUrl); tvid.removeAttribute('src'); try { tvid.load(); } catch (e) {} };   // always give the blob URL back
    tvid.addEventListener('error', stop, { once: true });
    const canvas = document.createElement('canvas');
    canvas.width = 96; canvas.height = 54;
    const ctx = canvas.getContext('2d');
    let i = 0;
    tvid.addEventListener('loadeddata', () => { tvid.currentTime = Math.min(duration - 0.05, 0.05); });
    tvid.addEventListener('seeked', () => {
      if (mine !== thumbSeq) { stop(); return; }
      try {
        ctx.drawImage(tvid, 0, 0, 96, 54);
        const img = document.createElement('img');
        img.src = canvas.toDataURL('image/jpeg', 0.6);
        tlThumbs.appendChild(img);
      } catch (e) {}
      i++;
      if (i < N) tvid.currentTime = Math.min(duration - 0.05, (duration / N) * i);
      else stop();
    });
  }

  // ---------- subtitle lanes (free text blocks, CapCut style) ----------
  // Every cue is a block that can be dragged anywhere in time (overlapping others is fine), stretched / shrunk from either
  // edge, and dropped on any lane. Blocks that overlap in time never sit on the same lane (S.subtitle.layoutLanes).
  const LANE_H = 30, LANE_GAP = 3, MIN_LANES = 2, MIN_LEN = 0.1, SNAP_PX = 6;
  let spareLane = false;                                // while dragging: one extra empty lane to drop a block on
  const blockEls = () => Array.prototype.slice.call(capTrack.querySelectorAll('.cap-block'));
  const pct = t => (t / P.media.duration * 100) + '%';

  // Text that does not fit inside its block is written NEXT to it instead (in the free part of the same lane), so a line is never
  // cut to "…" or hidden: .cap-spill. The label inside a block also follows the visible part of it (position: sticky), so a block
  // that is half scrolled off the left edge still shows its words.
  const spillEls = () => Array.prototype.slice.call(capTrack.querySelectorAll('.cap-spill'));
  const widthCache = {};
  let measureCtx = null;
  function textW(txt) {
    if (!measureCtx) measureCtx = document.createElement('canvas').getContext('2d');
    const fam = getComputedStyle(capTrack).fontFamily || 'sans-serif';
    measureCtx.font = '600 11px ' + fam;
    const key = fam + '|' + txt;
    return widthCache[key] || (widthCache[key] = measureCtx.measureText(txt).width);
  }
  const SPILL_MIN = 56;
  // The selected line whose words fit neither inside its block nor beside it gets a small name tag above the block with ALL its words.
  let tag = null, tagFor = null;
  function clampTag() {
    if (!tag || !tagFor || tag.style.display === 'none') return;
    const vw = tlScroll.clientWidth, sl = tlScroll.scrollLeft, lo = sl - vw / 2 + 8, w = tag.offsetWidth;
    tag.style.left = Math.max(lo, Math.min(tagFor.c.start * PPS, sl + vw / 2 - 8 - w)) + 'px';
  }

  // ---------- guide: where the speech says the selected line should start / end ----------
  // Only the line that is selected gets one (the green dashed box + the flag at its end). It appears when that spot is clearly
  // different from where the block sits now - e.g. right after the words were edited - and the green box vanishes once the block is there.
  let guideEl = null, guideMemo = null;
  /** The suggestion for line c. `fresh` recomputes it (pointer down, text edit); otherwise the last one for the same line is reused. */
  function currentGuide(c, fresh) {
    if (!c || !S.subtitle.suggestSpan) return null;
    if (!fresh && guideMemo && guideMemo.id === c.id && guideMemo.text === c.text) return guideMemo.g;
    const g = S.subtitle.suggestSpan(c);
    guideMemo = { id: c.id, text: c.text, g: g };
    return g;
  }
  const GUIDE_MIN = 0.08;                                    // closer than this to the block: nothing to show
  function placeGuide(c, top) {
    const g = c && !state.ui.dragging ? currentGuide(c, false) : (guideMemo && c && guideMemo.id === c.id ? guideMemo.g : null);
    const off = g && (Math.abs(g.start - c.start) > GUIDE_MIN || Math.abs(g.end - c.end) > GUIDE_MIN);
    if (!off) { if (guideEl && guideEl.parentNode) guideEl.style.display = 'none'; bus.emit('guide:changed', { cue: c || null, guide: g || null, off: false }); return; }
    if (!guideEl) { guideEl = document.createElement('div'); guideEl.className = 'cap-guide'; guideEl.innerHTML = '<i class="gd-flag"></i>'; }
    if (!guideEl.parentNode) capTrack.appendChild(guideEl);
    guideEl.style.display = '';
    guideEl.classList.toggle('est', g.source !== 'speech');
    guideEl.style.left = pct(g.start); guideEl.style.width = pct(Math.max(g.end - g.start, 0.02));
    guideEl.style.top = top; guideEl.style.height = LANE_H + 'px';
    bus.emit('guide:changed', { cue: c, guide: g, off: true });
  }

  /** Position every block from the model (no DOM rebuild): time -> left/width, lane -> top. */
  function placeAll() {
    const cues = P.subtitle.cues, els = blockEls(), sp = spillEls();
    if (!P.media.duration || els.length !== cues.length) return;
    const dur = P.media.duration, lay = S.subtitle.layoutLanes(cues);
    const n = Math.max(MIN_LANES, lay.count) + (spareLane ? 1 : 0);
    capTrack.style.height = (n * (LANE_H + LANE_GAP) + 2) + 'px';
    // the next block that starts in the same lane = how far the words may run on to the right
    const byLane = [];
    cues.forEach((c, i) => { (byLane[lay.lanes[i]] = byLane[lay.lanes[i]] || []).push(i); });
    const nextStart = new Array(cues.length).fill(dur);
    byLane.forEach(list => {
      if (!list) return;
      list.sort((a, b) => cues[a].start - cues[b].start);
      list.forEach((ci, k) => { if (k + 1 < list.length) nextStart[ci] = cues[list[k + 1]].start; });
    });
    tagFor = null;
    cues.forEach((c, i) => {
      const b = els[i], top = (lay.lanes[i] * (LANE_H + LANE_GAP) + 2) + 'px';
      b.style.left = pct(c.start);
      b.style.width = pct(Math.max(c.end - c.start, 0.02));
      b.style.top = top;
      b.style.height = LANE_H + 'px';
      b.dataset.lane = lay.lanes[i];
      const wpx = Math.max(c.end - c.start, 0.02) * PPS;
      const need = textW(c.text) + (b.classList.contains('active-block') ? 66 : 18);     // the active block keeps 26px handles on both sides
      const room = (nextStart[i] - c.end) * PPS - 10;
      const out = need > wpx && room >= SPILL_MIN;                     // does not fit inside, but there is free lane to its right
      b.classList.toggle('spilled', out);
      if (b.classList.contains('active-block') && need > wpx && !out) tagFor = { c: c, top: top };
      const s = sp[i];
      if (s) {
        s.style.display = out ? '' : 'none';
        if (out) { s.style.left = 'calc(' + pct(c.end) + ' + 5px)'; s.style.top = top; s.style.height = LANE_H + 'px'; s.style.maxWidth = Math.floor(room) + 'px'; }
      }
    });
    const act = cues[state.ui.activeCue], ai = state.ui.activeCue;
    placeGuide(ai >= 0 ? act : null, ai >= 0 ? (lay.lanes[ai] * (LANE_H + LANE_GAP) + 2) + 'px' : '0px');
    if (!tag) { tag = document.createElement('div'); tag.className = 'cap-tag'; }
    if (tagFor) {
      if (!tag.parentNode) capTrack.appendChild(tag);
      tag.textContent = tagFor.c.text; tag.style.display = ''; tag.style.top = (parseFloat(tagFor.top) - 4) + 'px';
      clampTag();
    } else if (tag.parentNode) tag.style.display = 'none';
  }
  function renderCapTrack() {
    capTrack.innerHTML = ''; tag = null; tagFor = null; guideEl = null; guideMemo = null;
    capTrack.style.height = '';
    const cues = P.subtitle.cues;
    if (!P.media.duration || !cues.length) return;
    cues.forEach((c, i) => {
      const spill = document.createElement('div'); spill.className = 'cap-spill'; spill.textContent = c.text; spill.style.display = 'none';
      capTrack.appendChild(spill);
      const block = document.createElement('div');
      block.className = 'cap-block';
      block.dataset.id = c.id;
      const label = document.createElement('span'); label.className = 'blk-label'; label.textContent = c.text;
      block.appendChild(label);
      const rl = document.createElement('div'); rl.className = 'rh l';
      const rr = document.createElement('div'); rr.className = 'rh r';
      block.appendChild(rl); block.appendChild(rr);
      capTrack.appendChild(block);
      attachBlockDrag(block, rl, rr, c);
    });
    const a = P.subtitle.cues[state.ui.activeCue];
    if (a) { const el = capTrack.querySelector('.cap-block[data-id="' + a.id + '"]'); if (el) el.classList.add('active-block'); }
    placeAll();
  }

  let tip = null;
  function showTip(block, c) {
    if (!tip) { tip = document.createElement('div'); tip.className = 'cap-tip'; }
    if (!tip.parentNode) capTrack.appendChild(tip);
    tip.textContent = S.util.fmt2(c.start) + ' → ' + S.util.fmt2(c.end) + '  (' + (c.end - c.start).toFixed(2) + ' วิ)';
    tip.style.left = block.style.left; tip.style.top = (parseFloat(block.style.top) - 20) + 'px';
  }
  function hideTip() { if (tip && tip.parentNode) tip.parentNode.removeChild(tip); }

  /** Places the dragged edge may snap to. Each has a kind:
   *   edge  an edge of another line ('s' its start / 'e' its end; a start meeting an end = the two lines are joined)
   *   guide where the speech says THIS line should start / end (see S.subtitle.suggestSpan)
   *   clip  the ends of the clip       head  the playhead (read live: the strip may be scrolling) */
  function snapTargets(except, guide) {
    const t = [{ t: 0, k: 'clip' }, { t: P.media.duration, k: 'clip' }];
    P.subtitle.cues.forEach(o => { if (o !== except) { t.push({ t: o.start, k: 'edge', e: 's', id: o.id }); t.push({ t: o.end, k: 'edge', e: 'e', id: o.id }); } });
    if (guide) { t.push({ t: guide.start, k: 'guide', e: 's' }); t.push({ t: guide.end, k: 'guide', e: 'e' }); }
    return t;
  }
  const JOIN_PX = 10, GUIDE_PX = 10;                       // joining a line to a neighbour / reaching the guide pulls from a little further away
  /** Nearest target within reach of time t. `role` = which edge of the dragged line is being placed ('s' start / 'e' end).
   *  Returns { t, hit } (hit = the target, or null when nothing is in reach); hit.join is true when a start meets an end. */
  function snapTo(t, targets, role) {
    let best = null, bd = Infinity;
    targets.concat([{ t: video.currentTime, k: 'head' }]).forEach(x => {
      const join = x.k === 'edge' && x.e !== role, reach = ((join ? JOIN_PX : x.k === 'guide' ? GUIDE_PX : SNAP_PX)) / PPS;
      const d = Math.abs(x.t - t);
      if (d <= reach && (join || x.k === 'guide' ? d * 0.6 : d) < bd) { bd = (join || x.k === 'guide' ? d * 0.6 : d); best = Object.assign({ join: join }, x); }
    });
    return { t: best ? best.t : t, hit: best };
  }

  /** A tap on a block selects it, and a line is only selected while the playhead is ON it. So:
   *   - playhead already on the line  -> do not move it at all (the strip stays put, nothing "warps");
   *   - playhead elsewhere            -> move it the shortest way onto the line: to the spot that was tapped (clamped inside),
   *                                      not always to the line's start (tapping the END of a line used to fly to its start). */
  function landOn(i, tapT) {
    const all = P.subtitle.cues, c = all[i];
    if (!c || S.subtitle.indexAt(all, video.currentTime) === i) return;
    const lo = c.start + 0.01, hi = Math.max(lo, c.end - 0.05);
    const want = Math.min(hi, Math.max(lo, tapT));
    for (let k = 0; k < 200; k++) {                                   // when lines overlap, only some times belong to this line: search outward from the tap
      const tries = k ? [want - 0.02 * k, want + 0.02 * k] : [want];
      for (let j = 0; j < tries.length; j++) {
        const t = tries[j];
        if (t >= c.start && t < c.end && S.subtitle.indexAt(all, t) === i) { S.ui.player.seek(t); return; }
      }
    }
    S.ui.player.seek(c.start);                                        // (old behaviour, only as a last resort)
  }

  function attachBlockDrag(block, rl, rr, c) {
    let mode = null, snapKey = '', joinedEl = null, guide = null, origLane, startX = 0, startY = 0, startScroll = 0, lastX = 0, lastY = 0, origStart = 0, origEnd = 0, origWords = null, moved = false, targets = null, raf = 0;
    function down(e, m) {
      e.stopPropagation();
      mode = m; startX = lastX = e.clientX; startY = lastY = e.clientY; moved = false;
      startScroll = tlScroll.scrollLeft;
      origStart = c.start; origEnd = c.end; origLane = c.lane;
      origWords = c.words.map(w => ({ s: w.start, e: w.end }));
      guide = block.classList.contains('active-block') ? currentGuide(c, true) : null;    // where the speech says the SELECTED line belongs (the one that shows the green box): frozen for the whole drag
      snapKey = '';
      block.setPointerCapture(e.pointerId);
    }
    /** feel + see what the edge caught: another line (join), the guide, or just an alignment */
    function feedback(hit, role) {
      const key = hit ? hit.k + ':' + (hit.id || '') + ':' + (hit.e || '') + ':' + role : '';
      if (key === snapKey) return;
      snapKey = key;
      if (joinedEl) { joinedEl.classList.remove('snap-join'); joinedEl = null; }
      block.classList.toggle('snap-join', !!(hit && hit.join));
      if (!hit) return;
      if (hit.join) { const el = capTrack.querySelector('.cap-block[data-id="' + hit.id + '"]'); if (el) { el.classList.add('snap-join'); joinedEl = el; } }
      if (S.haptic) S.haptic.pulse(hit.join ? 'join' : hit.k === 'guide' ? 'guide' : 'tick');
    }
    block.addEventListener('pointerdown', e => down(e, 'move'));
    rl.addEventListener('pointerdown', e => down(e, 'left'));
    rr.addEventListener('pointerdown', e => down(e, 'right'));

    /** Apply the pointer position to the cue. The strip may have scrolled since the press (edge auto-scroll): count that too. */
    function apply(clientX, clientY) {
      const dur = P.media.duration;
      const dt = ((clientX - startX) + (tlScroll.scrollLeft - startScroll)) / (timeline.getBoundingClientRect().width || 1) * dur;
      if (mode === 'move') {
        const len = origEnd - origStart;
        let ns = origStart + dt;
        const a = snapTo(ns, targets, 's'), b = snapTo(ns + len, targets, 'e');       // snap whichever edge is nearer to a target
        const da = a.hit ? Math.abs(a.t - ns) : Infinity, db = b.hit ? Math.abs(b.t - (ns + len)) : Infinity;
        let hit = null, role = 's';
        if (da < Infinity || db < Infinity) { if (da <= db) { ns = a.t; hit = a.hit; } else { ns = b.t - len; hit = b.hit; role = 'e'; } }
        ns = Math.min(Math.max(0, ns), dur - len);
        feedback(hit, role);
        c.start = ns; c.end = ns + len;
        // vertical: the lane under the pointer (the empty lane below is a valid target)
        const y = clientY - capTrack.getBoundingClientRect().top;
        const others = S.subtitle.layoutLanes(P.subtitle.cues.filter(o => o !== c)).count;      // lanes the OTHER blocks use: only the first empty one below them is offered
        const lane = Math.max(0, Math.min(Math.floor(y / (LANE_H + LANE_GAP)), Math.max(MIN_LANES - 1, others)));
        if (lane !== c.lane) c.lane = lane;
      } else if (mode === 'left') {
        const sn = snapTo(origStart + dt, targets, 's');
        c.start = Math.min(Math.max(0, sn.t), origEnd - MIN_LEN);
        feedback(sn.hit, 's');
      } else {
        const sn = snapTo(origEnd + dt, targets, 'e');
        c.end = Math.max(Math.min(dur, sn.t), origStart + MIN_LEN);
        feedback(sn.hit, 'e');
      }
      const ol = origEnd - origStart, k = ol > 0.001 ? (c.end - c.start) / ol : 1;      // karaoke words follow the block live
      c.words.forEach((w, i) => { w.start = c.start + (origWords[i].s - origStart) * k; w.end = c.start + (origWords[i].e - origStart) * k; });
      placeAll();
      showTip(block, c);
    }
    /** Holding a block at the left / right edge of the strip scrolls it, so a block can be carried as far as you like. */
    function edgeScroll() {
      raf = 0;
      if (!mode || !moved) return;
      const r = tlScroll.getBoundingClientRect(), EDGE = 36;
      const v = lastX > r.right - EDGE ? Math.min(18, (lastX - (r.right - EDGE)) / 2 + 2) : lastX < r.left + EDGE ? -Math.min(18, ((r.left + EDGE) - lastX) / 2 + 2) : 0;
      if (v) {
        const before = tlScroll.scrollLeft;
        tlScroll.scrollLeft = before + v;
        if (tlScroll.scrollLeft !== before) apply(lastX, lastY);
      }
      raf = requestAnimationFrame(edgeScroll);
    }
    block.addEventListener('pointermove', e => {
      if (!mode || !P.media.duration) return;
      lastX = e.clientX; lastY = e.clientY;
      // a finger on a block that is not selected yet scrolls the strip (touch-action: pan-x); only a selected block is dragged by touch
      if (e.pointerType === 'touch' && !moved && !block.classList.contains('active-block')) return;
      if (!moved) {
        if (Math.abs(e.clientX - startX) < 3 && Math.abs(e.clientY - startY) < 3) return;
        moved = true;
        if (!video.paused) video.pause();                               // playback scrolls the strip: it must not move under the block being dragged
        startScroll = tlScroll.scrollLeft;
        if (S.history) S.history.record('timing');                      // one undo step per drag
        const lane = +block.dataset.lane;
        if (!(typeof c.lane === 'number')) c.lane = isNaN(lane) ? 0 : lane;   // the block keeps its row while it is dragged in time
        targets = snapTargets(c, guide);
        spareLane = true; block.classList.add('dragging');
        if (!raf) raf = requestAnimationFrame(edgeScroll);
      }
      apply(e.clientX, e.clientY);
    });
    function finish(cancelled) {
      if (!mode) return;
      const wasMoved = moved;
      mode = null; spareLane = false; hideTip(); block.classList.remove('dragging', 'snap-join');
      if (joinedEl) { joinedEl.classList.remove('snap-join'); joinedEl = null; } snapKey = '';
      if (raf) { cancelAnimationFrame(raf); raf = 0; }
      if (wasMoved) {
        const reordered = S.subtitle.sortCues();                  // the list stays in time order
        placeAll();
        if (reordered) S.bus.emit('cues:structure', { reason: 'timing-sort' });
        else bus.emit('cue:timing', { idx: P.subtitle.cues.indexOf(c) });
      }
      if (cancelled) return;
      const idx = P.subtitle.cues.indexOf(c);
      if (!wasMoved) landOn(idx, timeFromClientX(startX));
      bus.emit('cue:active', { idx: idx });
      bus.emit('cue:select', { idx: idx });
    }
    block.addEventListener('pointerup', () => finish(false));
    block.addEventListener('pointercancel', () => {        // the browser took the gesture (e.g. to scroll the strip): not a tap, not a drag
      if (moved) {                                           // put the block back exactly as it was
        c.start = origStart; c.end = origEnd;
        c.words.forEach((w, i) => { w.start = origWords[i].s; w.end = origWords[i].e; });
        if (origLane === undefined) delete c.lane; else c.lane = origLane;
        finish(true);
      } else mode = null;
    });
  }

  function resetDom() {
    tlThumbs.innerHTML = ''; tlRuler.innerHTML = '';
    dimLeft.style.width = '0%'; dimRight.style.width = '0%';
    trimLeftEl.style.left = '0%'; trimRightEl.style.left = '100%';
  }

  function setZoom(p) {
    const np = Math.min(400, Math.max(16, p));
    if (Math.abs(np - PPS) < 0.5) return;
    PPS = np; layoutScroll(); buildRuler(); syncScroll(true); bus.emit('timeline:zoom');
  }

  S.ui.timeline = {
    setZoom: setZoom, getZoom: () => PPS, refreshTrim: updateTrimUI,
    guideOf: c => currentGuide(c, false),
    init() {
      tlScroll.addEventListener('scroll', () => {          // dragging the strip IS scrubbing
        if (!P.media.duration) return;
        const x = tlScroll.scrollLeft;
        if (Math.abs(x - lastSet) < 1.5) return;       // our own programmatic scroll
        if (!video.paused) video.pause();
        const t = Math.min(P.trim.end, Math.max(P.trim.start, x / PPS));
        S.ui.player.seek(t);
      }, { passive: true });
      tlScroll.addEventListener('scroll', clampTag, { passive: true });
      window.addEventListener('resize', () => { layoutScroll(); syncScroll(true); });
      bus.on('sheet:toggle', () => { setTimeout(() => { layoutScroll(); syncScroll(true); }, 0); });
      setupTrimHandle(trimLeftEl, 'left');
      setupTrimHandle(trimRightEl, 'right');

      bus.on('media:metadata', () => {
        layoutScroll(); updateTrimUI(); buildRuler(); renderCapTrack(); syncScroll(true);
        // the strip of pictures is a luxury: wait until the main picture is on screen, so it never competes with opening the clip
        const thumbs = () => setTimeout(() => generateThumbnails(P.media.file, P.media.duration), 200);
        if (S.dom.video.readyState >= 2) thumbs(); else S.dom.video.addEventListener('loadeddata', thumbs, { once: true });
      });
      bus.on('media:cleared', resetDom);
      bus.on('time:changed', updatePlayhead);
      bus.on('cues:structure', renderCapTrack);
      bus.on('cue:text', e => {
        const c = P.subtitle.cues[e.idx], blk = c && capTrack.querySelector('.cap-block[data-id="' + c.id + '"]');
        if (blk) { const lbl = blk.querySelector('.blk-label'); if (lbl) lbl.textContent = c.text; }
        const sps = spillEls(); if (sps[e.idx]) sps[e.idx].textContent = c.text;
        currentGuide(c, true);                                  // new words -> where should the sentence end now?
        placeAll();
        if (guideEl) { guideEl.classList.remove('flash'); void guideEl.offsetWidth; guideEl.classList.add('flash'); }
      });
      bus.on('cue:timing', placeAll);                         // timing typed in the list / set by the AI: move the blocks
      bus.on('cue:active', e => {
        const a = P.subtitle.cues[e.idx];
        capTrack.querySelectorAll('.cap-block').forEach(b => b.classList.toggle('active-block', !!a && b.dataset.id === a.id));
        if (a) currentGuide(a, true);
        placeAll();                                            // the active block needs more room for its handles: re-decide what is written beside it
      });
    }
  };
})(window.SubEd);
