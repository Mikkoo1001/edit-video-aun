/* =====================================================================
 * UI: selecting a caption (CapCut style).
 *   select  = tap a block on the timeline, or tap the caption on the preview
 *   effect  = the bottom bar turns into the caption toolbar (back / edit text / split / style / animation / copy / delete)
 *             and the frame with the corner buttons appears on the preview
 *   clear   = « , tap the empty picture, or the playhead leaves the selected line
 * Emits: cue:selected ({id|null})
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, state = S.state, P = S.state.project, video = S.dom.video;
  let selId = null;
  const idxOf = id => P.subtitle.cues.findIndex(c => c.id === id);

  function set(id) {
    if (id === selId) return;
    selId = id;
    document.body.classList.toggle('cue-selected', !!id);
    bus.emit('cue:selected', { id: id });
  }
  function selectActive() { const c = P.subtitle.cues[state.ui.activeCue]; set(c ? c.id : null); }

  const api = S.ui.sel = S.ui.cueSelect = {
    get: () => idxOf(selId),
    is: () => !!selId && idxOf(selId) >= 0,
    select: set, clear: () => set(null),
    init() {
      const ok = () => api.is() && state.ui.activeCue === idxOf(selId);
      bus.on('cue:select', e => { const c = P.subtitle.cues[e.idx]; set(c ? c.id : null); });
      bus.on('cue:active', () => { if (selId && !ok() && !(S.ui.timeNudge && S.ui.timeNudge.busy)) set(null); });   // (the timing bar moves a line under the playhead for a moment)
      bus.on('cues:structure', () => { if (selId && idxOf(selId) < 0) set(null); });
      bus.on('media:cleared', () => set(null));
      S.dom.capText.addEventListener('click', () => { if (!document.getElementById('wcPop') || true) selectActive(); });
      S.dom.videoBox.addEventListener('click', e => {
        if (e.target.closest('.cap-frame') || e.target.closest('#capText') || e.target.closest('.wc-pop') || e.target.closest('.wh')) return;
        set(null);
      });

      const syncDel = () => { $('ccDel').disabled = !P.subtitle.cues[state.ui.activeCue]; };
      ['cue:active', 'cues:structure', 'time:changed'].forEach(e => bus.on(e, syncDel)); syncDel();
      $('ccDel').addEventListener('click', () => { const i = state.ui.activeCue; if (i < 0) return; S.subtitle.removeCue(i); set(null); syncDel(); });
      const act = (id, fn) => $(id).addEventListener('click', () => { const i = idxOf(selId); if (i >= 0) fn(i); });
      $('selBack').addEventListener('click', () => set(null));
      act('selEdit', () => { S.ui.tabs.open('style'); setTimeout(() => { const t = $('teInput'); if (t && !t.disabled) { t.focus(); try { t.setSelectionRange(t.value.length, t.value.length); } catch (e) {} } }, 300); });
      act('selSplit', i => { const c = P.subtitle.cues[i], t = video.currentTime; const at = S.subtitle.splitCue(i, (t > c.start && t < c.end) ? t : undefined); if (at >= 0) set(null); });
      act('selStyle', () => S.ui.tabs.open('style'));
      act('selAnim', () => { S.ui.tabs.open('style'); const b = document.querySelector('#subTabs button[data-sub="anim"]'); if (b) b.click(); });
      act('selDel', i => { S.subtitle.removeCue(i); set(null); });
      act('selDup', i => { const at = S.subtitle.duplicateCue(i); if (at >= 0) { video.currentTime = P.subtitle.cues[at].start; bus.emit('time:changed', video.currentTime); bus.emit('cue:active', { idx: at }); bus.emit('cue:select', { idx: at }); } });   // the copy becomes the selected line, like CapCut
    }
  };
})(window.SubEd);
