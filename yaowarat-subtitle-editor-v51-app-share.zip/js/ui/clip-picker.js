/* =====================================================================
 * UI: "เลือกส่วนของวิดีโอ" — choose WHICH PART of a video goes WHERE on the audio.
 *
 *   A video can be much longer than the audio. A scene on the timeline only shows as much of it as the scene is long, so for each
 *   scene you pick the part: drag the yellow window along the whole clip (it is as long as the scene) and the picture at its start
 *   shows in the little player. Cut the clip into pieces ("แยกที่นี่" / "ตัดเป็นชิ้นจากช่วงนี้" / "แบ่งตามความยาวฉากนี้"), then tap
 *   a piece to jump the window to it. "ใส่ในฉากนี้" keeps the scene's length; "ใส่ + ปรับความยาวฉาก" also makes the scene as long as
 *   the piece (as far as its neighbour allows). The same piece can be used in any number of scenes.
 *
 *   Writes: scene.clipId / scene.offset (and scene length via SubEd.arrange.setSceneLength), clip.cuts (saved with the clip).
 * Reads: SubEd.state.project.arrange, SubEd.arrange.
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, A = S.state.project.arrange, video = S.dom.video;
  const esc = t => String(t == null ? '' : t).replace(/[<>"&]/g, '');
  const ft = t => { t = Math.max(0, t || 0); const m = Math.floor(t / 60); return m + ':' + (t - m * 60).toFixed(1).padStart(4, '0'); };
  const toast = (m, ms) => { if (S.ui.toast) S.ui.toast(m, ms || 2400); };
  let ov = null, st = null, drag = null, seekRaf = 0, stopAt = 0;

  const clip = () => A.clips.find(c => c.id === st.clipId) || null;
  const scene = () => A.scenes[st.i] || null;
  const winLen = () => { const c = clip(), s = scene(); return c && s ? Math.min(s.end - s.start, c.duration) : 0; };
  const maxOff = () => { const c = clip(); return c ? Math.max(0, c.duration - winLen()) : 0; };
  function cutsOf(c) {
    const d = c.duration, out = [];
    (c.cuts || []).map(Number).filter(t => t > 0.1 && t < d - 0.1).sort((a, b) => a - b).forEach(t => { if (!out.length || t - out[out.length - 1] >= 0.1) out.push(+t.toFixed(2)); });
    c.cuts = out; return out;
  }
  function pieces() {
    const c = clip(); if (!c) return [];
    const pts = [0].concat(cutsOf(c), [c.duration]), out = [];
    for (let i = 0; i + 1 < pts.length; i++) out.push({ start: pts[i], end: pts[i + 1] });
    return out;
  }

  function build() {
    ov = document.createElement('div'); ov.className = 'cp-ov'; ov.id = 'cpOverlay';
    ov.innerHTML =
      '<div class="cp-box">' +
        '<div class="cp-head"><b id="cpTitle">เลือกส่วนของวิดีโอ</b><button type="button" class="cp-x" id="cpClose" aria-label="ปิด">✕</button></div>' +
        '<div class="cp-vwrap"><video id="cpVid" playsinline muted preload="auto"></video></div>' +
        '<div class="cp-row" id="cpClipRow"><label>วิดีโอ</label><select id="cpClip"></select></div>' +
        '<div class="cp-strip" id="cpStrip"><div id="cpCuts"></div><div class="cp-win" id="cpWin"></div></div>' +
        '<div class="cp-times"><span id="cpRange"></span><span id="cpDur"></span></div>' +
        '<div class="cp-row cp-btns">' +
          '<button type="button" class="tx-tbtn" id="cpBack">◂ 0.1</button><button type="button" class="tx-tbtn" id="cpFwd">0.1 ▸</button>' +
          '<button type="button" class="tx-tbtn" id="cpPlay">▶ ดูช่วงนี้</button>' +
        '</div>' +
        '<div class="cp-row cp-btns">' +
          '<button type="button" class="tx-tbtn" id="cpCutHere">✂ แยกที่นี่</button><button type="button" class="tx-tbtn" id="cpCutRange">ตัดเป็นชิ้นจากช่วงนี้</button>' +
          '<button type="button" class="tx-tbtn" id="cpChop">แบ่งตามความยาวฉากนี้</button><button type="button" class="tx-tbtn" id="cpClear">ล้างจุดตัด</button>' +
        '</div>' +
        '<div class="cp-label">ชิ้นวิดีโอ — แตะเพื่อเลือก</div><div class="cp-pieces" id="cpPieces"></div>' +
        '<div class="cp-foot"><button type="button" class="cp-ok" id="cpApply">ใส่ในฉากนี้</button><button type="button" class="cp-ok alt" id="cpApplyFit">ใส่ + ปรับความยาวฉากตามชิ้น</button></div>' +
      '</div>';
    document.body.appendChild(ov);
    const on = (id, fn) => $(id).addEventListener('click', fn);
    on('cpClose', close);
    ov.addEventListener('click', e => { if (e.target === ov) close(); });
    on('cpClip', () => {});
    $('cpClip').addEventListener('change', e => { st.clipId = e.target.value; st.piece = null; st.off = 0; loadClip(); });
    on('cpBack', () => nudge(-0.1)); on('cpFwd', () => nudge(0.1));
    on('cpPlay', togglePlay);
    on('cpCutHere', () => addCuts([st.off]));
    on('cpCutRange', () => addCuts([st.off, st.off + winLen()]));
    on('cpChop', () => {
      const c = clip(), w = winLen(); if (!c || w < 0.3) return;
      const t = []; for (let x = w; x < c.duration - 0.1; x += w) t.push(x);
      c.cuts = []; addCuts(t);
    });
    on('cpClear', () => { const c = clip(); if (c) { c.cuts = []; st.piece = null; changed(); } });
    on('cpApply', () => apply(false)); on('cpApplyFit', () => apply(true));
    $('cpPieces').addEventListener('click', e => {
      const x = e.target.closest('[data-del]');
      if (x) { const c = clip(), k = +x.dataset.del, p = pieces()[k]; if (c && p) { c.cuts = cutsOf(c).filter(t => Math.abs(t - p.start) > 0.01); st.piece = null; changed(); } return; }
      const el = e.target.closest('[data-k]'); if (!el) return;
      st.piece = +el.dataset.k; setOff(pieces()[st.piece].start, false);
    });
    // dragging the window (or tapping the strip to put the window there)
    const strip = $('cpStrip');
    strip.addEventListener('pointerdown', e => {
      const c = clip(); if (!c) return;
      const r = strip.getBoundingClientRect(), t = (e.clientX - r.left) / r.width * c.duration;
      if (t < st.off || t > st.off + winLen()) { setOff(t - winLen() / 2, true); }
      drag = { id: e.pointerId, x0: e.clientX, off0: st.off, w: r.width };
      strip.setPointerCapture(e.pointerId); e.preventDefault();
    });
    strip.addEventListener('pointermove', e => {
      if (!drag || e.pointerId !== drag.id) return;
      setOff(drag.off0 + (e.clientX - drag.x0) / drag.w * clip().duration, true);
    });
    ['pointerup', 'pointercancel'].forEach(ev => strip.addEventListener(ev, () => { drag = null; }));
    $('cpVid').addEventListener('timeupdate', () => { const v = $('cpVid'); if (stopAt && v.currentTime >= stopAt) { v.pause(); stopAt = 0; $('cpPlay').textContent = '▶ ดูช่วงนี้'; } });
    $('cpVid').addEventListener('pause', () => { $('cpPlay').textContent = '▶ ดูช่วงนี้'; });
  }

  function loadClip() {
    const c = clip(), v = $('cpVid'); if (!c) return;
    if (v.dataset.url !== c.url) { v.dataset.url = c.url; v.src = c.url; }
    st.off = Math.min(st.off, maxOff());
    seek(); layout();
  }
  function seek() {
    if (seekRaf) return;
    seekRaf = requestAnimationFrame(() => { seekRaf = 0; const v = $('cpVid'); try { v.currentTime = Math.min(st.off, Math.max(0, (clip() || {}).duration - 0.05 || 0)); } catch (e) {} });
  }
  function setOff(x, clearPiece) {
    st.off = +Math.min(maxOff(), Math.max(0, x)).toFixed(3);
    if (clearPiece) st.piece = null;
    const v = $('cpVid'); if (!v.paused) { v.pause(); stopAt = 0; }
    seek(); layout();
  }
  function nudge(d) { setOff(st.off + d, true); }
  function togglePlay() {
    const v = $('cpVid'); if (!v.paused) { v.pause(); return; }
    v.currentTime = st.off; stopAt = st.off + winLen() - 0.05;
    v.play().then(() => { $('cpPlay').textContent = '⏸ หยุด'; }).catch(() => {});
  }
  function addCuts(times) {
    const c = clip(); if (!c) return;
    c.cuts = (c.cuts || []).concat(times.filter(t => t > 0.1 && t < c.duration - 0.1));
    changed();
  }
  function changed() { layout(); if (S.arrange && S.arrange.renderAll) S.arrange.renderAll(); }      // renderAll also saves the cut marks with the clip

  function layout() {
    const c = clip(), s = scene(); if (!c || !s) return;
    const d = c.duration, w = winLen(), strip = $('cpStrip');
    strip.style.backgroundImage = c.thumb ? 'url(' + c.thumb + ')' : '';
    const win = $('cpWin'); win.style.left = (st.off / d * 100) + '%'; win.style.width = (w / d * 100) + '%';
    $('cpCuts').innerHTML = cutsOf(c).map(t => '<i style="left:' + (t / d * 100) + '%"></i>').join('');
    $('cpRange').textContent = 'ช่วงที่ใช้ ' + ft(st.off) + ' – ' + ft(st.off + w);
    $('cpDur').textContent = 'วิดีโอยาว ' + ft(d) + (d < s.end - s.start ? ' · สั้นกว่าฉาก จะเล่นวน' : '');
    const ps = pieces();
    $('cpPieces').innerHTML = ps.length < 2 ? '<div class="hint">ยังไม่ได้แบ่งชิ้น — เลื่อนหน้าต่างไปจุดที่ต้องการแล้วกด “แยกที่นี่”</div>' :
      ps.map((p, k) => '<div class="cp-pc' + (k === st.piece ? ' on' : '') + '" data-k="' + k + '"><b>' + (k + 1) + '</b> ' + ft(p.start) + ' – ' + ft(p.end) + ' <small>(' + (p.end - p.start).toFixed(1) + ' วิ)</small>' + (k > 0 ? '<span class="cp-del" data-del="' + k + '" title="ลบจุดตัดก่อนชิ้นนี้">✕</span>' : '') + '</div>').join('');
    $('cpApplyFit').disabled = st.piece == null;
  }

  function apply(fit) {
    const s = scene(), c = clip(); if (!s || !c) return;
    S.arrange.pushUndo();
    if (fit && st.piece != null) { const p = pieces()[st.piece]; if (p) S.arrange.setSceneLength(st.i, p.end - p.start); }
    s.clipId = c.id; s.offset = +Math.min(st.off, Math.max(0, c.duration - 0.05)).toFixed(3);
    const i = st.i; close();
    S.arrange.commit(); S.arrange.selectScene(i, true);
    toast('ใส่ส่วนที่เลือกลงฉาก ' + (i + 1) + ' แล้ว');
  }

  function open(i) {
    const s = A.scenes[i]; if (!s) return;
    if (!A.clips.length) { toast('เพิ่มวิดีโอก่อน'); if ($('arrClipInput')) $('arrClipInput').click(); return; }
    if (!ov) build();
    if (!video.paused) video.pause();
    st = { i: i, clipId: (A.clips.find(c => c.id === s.clipId) || A.clips[0]).id, off: s.offset || 0, piece: null };
    $('cpTitle').textContent = 'ฉาก ' + (i + 1) + ' · ใช้ ' + (s.end - s.start).toFixed(1) + ' วิ ของเสียง — เลือกส่วนวิดีโอ';
    $('cpClip').innerHTML = A.clips.map(k => '<option value="' + k.id + '"' + (k.id === st.clipId ? ' selected' : '') + '>' + esc(k.name) + '</option>').join('');
    $('cpClipRow').style.display = A.clips.length > 1 ? '' : 'none';
    ov.classList.add('open');
    $('cpVid').dataset.url = '';
    loadClip();
  }
  function close() {
    if (!ov) return;
    const v = $('cpVid'); v.pause(); stopAt = 0; drag = null;
    ov.classList.remove('open');
  }

  S.ui.clipPicker = { open: open, close: close, init() {} };
})(window.SubEd);
