/* =====================================================================
 * UI: pick words ON THE PICTURE and colour them — like selecting text on the phone.
 *   - press and hold a word  -> it is selected; keep the finger down and drag across the line to take more words
 *   - lift                   -> two handles appear on the ends of the selection (drag them to take more / fewer words)
 *                               and a small palette: tap a colour and every selected word takes it AND lights up in it
 *   - tap anywhere else      -> the selection goes away
 * The selection itself lives in ui/word-sel.js (shared with the text boxes in the สีเฉพาะคำ / เรืองแสง tabs), so a selection
 * made there is outlined here too and the other way round.
 * Listens: wordsel:changed, cue:text, caption:laidout. Paints through S.ui.wordSel.color() (one undo step per gesture).
 * ===================================================================== */
(function (S) {
  'use strict';
  const bus = S.bus, state = S.state, P = state.project, video = S.dom.video, capText = S.dom.capText, box = S.dom.videoBox;
  const HOLD_MS = 260, MOVE_PX = 16, HANDLE_LIFT = 30, DBL_MS = 380;   // a shorter hold and more finger wobble allowed: selecting is easier
  let pop, nameEl, pal, hS, hE;
  let timer = 0, startX = 0, startY = 0, pressId = null, pressWi = -1, pressCue = -1;
  let lastTap = { t: 0, wi: -1 };                            // a second tap on the same word within DBL_MS selects it at once
  let drag = null;                                           // { kind: 'range'|'handle', id, anchor, which? }
  let open = false;                                          // the palette + handles are showing (the selection was made on the picture)

  const WS = () => S.ui.wordSel;
  const cue = () => P.subtitle.cues[state.ui.activeCue] || null;
  const spanEls = () => Array.from(capText.querySelectorAll('.w'));

  /** the word nearest to a point (clientX / clientY); the same line wins over a nearer word on another line */
  function wordAt(x, y) {
    let best = -1, bd = Infinity;
    spanEls().forEach(el => {
      const r = el.getBoundingClientRect(); if (!r.width && !r.height) return;
      const dx = x < r.left ? r.left - x : x > r.right ? x - r.right : 0;
      const dy = y < r.top ? r.top - y : y > r.bottom ? y - r.bottom : 0;
      const d = dy * 3 + dx;
      if (d < bd) { bd = d; best = +el.dataset.wi; }
    });
    return best;
  }

  function mark() {
    const g = WS().get();
    capText.querySelectorAll('.w').forEach(el => { const i = +el.dataset.wi; el.classList.toggle('wsel', !!g && i >= g.a && i <= g.b); });
  }

  function hideUI() {
    pop.classList.remove('show'); hS.classList.remove('show'); hE.classList.remove('show');
    box.classList.remove('ws-open');
  }

  /** put the handles on the two ends of the selection and the palette above it */
  function placeUI() {
    const g = WS().get();
    const showHandles = !!g && (open || (drag && drag.kind === 'handle')), showPop = !!g && open && !drag;
    if (!g || (!showHandles && !showPop)) { hideUI(); return; }
    const els = spanEls(), f = els[g.a], l = els[g.b];
    if (!f || !l) { hideUI(); return; }
    const b = box.getBoundingClientRect(), fr = f.getBoundingClientRect(), lr = l.getBoundingClientRect();
    let top = Infinity, bottom = -Infinity, left = Infinity, right = -Infinity;
    for (let i = g.a; i <= g.b; i++) {
      const r = els[i] && els[i].getBoundingClientRect(); if (!r) continue;
      top = Math.min(top, r.top); bottom = Math.max(bottom, r.bottom); left = Math.min(left, r.left); right = Math.max(right, r.right);
    }
    const hy = h => Math.min(h - b.top, b.height - 14);       // keep the handles reachable at the bottom edge of the picture
    hS.style.left = (fr.left - b.left) + 'px'; hS.style.top = hy(fr.bottom) + 'px';
    hE.style.left = (lr.right - b.left) + 'px'; hE.style.top = hy(lr.bottom) + 'px';
    hS.classList.toggle('show', showHandles); hE.classList.toggle('show', showHandles);
    box.classList.toggle('ws-open', showHandles);               // the caption's move/resize frame would sit under the handles
    if (!showPop) { pop.classList.remove('show'); return; }
    refreshPop(g);
    pop.classList.add('show');
    const pw = pop.offsetWidth, ph = pop.offsetHeight;
    let x = (left + right) / 2 - b.left - pw / 2, y = top - b.top - ph - 10;
    if (y < 4) y = bottom - b.top + 40;                       // no room above: below the handles
    x = Math.max(6 - b.left, Math.min(x, window.innerWidth - 6 - b.left - pw));   // keep it on the screen (the picture is narrower than the palette now)
    pop.style.left = x + 'px'; pop.style.top = Math.max(4, y) + 'px';
  }

  function refreshPop(g) {
    const c = cue(); if (!c) return;
    nameEl.textContent = 'สีเฉพาะคำ: ' + WS().labelOf(40);
    const w0 = c.words[g.a], col = (w0 && w0.color) || S.subtitle.effectiveStyle(c, P.style).color;
    pal.mark(col);
  }

  function closeUI(clearSel) {
    open = false; drag = null;
    hideUI();
    if (clearSel) WS().clear('preview');
  }

  /* ---- selecting on the picture ----------------------------------------------------------------------------------------- */
  function cancelHold() { clearTimeout(timer); timer = 0; }

  function begin(wi) {                                         // the hold elapsed: this word starts a selection
    const c = cue(); if (!c || !c.words[wi] || state.ui.activeCue !== pressCue) return;   // (the clip was playing and moved on to another line meanwhile)
    if (!video.paused) video.pause();                          // the line must stay put while it is being coloured
    open = false; hideUI();
    WS().set(wi, wi, 'preview');
    drag = { kind: 'range', id: pressId, anchor: wi };
    try { capText.setPointerCapture(pressId); } catch (e) {}
    if (navigator.vibrate) try { navigator.vibrate(15); } catch (e) {}
  }

  function extendTo(x, y) {
    const wi = wordAt(x, y); if (wi < 0) return;
    WS().set(Math.min(drag.anchor, wi), Math.max(drag.anchor, wi), 'preview');
  }

  function endDrag() {
    if (!drag) return;
    const kind = drag.kind; drag = null;
    if (WS().get()) { open = true; placeUI(); } else closeUI(false);
    return kind;
  }

  function onHandleDown(e, which, el) {
    const g = WS().get(); if (!g) return;
    e.preventDefault(); e.stopPropagation();
    drag = { kind: 'handle', id: e.pointerId, anchor: which === 'start' ? g.b : g.a, which: which, el: el };
    try { el.setPointerCapture(e.pointerId); } catch (err) {}
    placeUI();                                                 // palette out of the way while a handle is dragged
  }
  function onHandleMove(e) {
    if (!drag || drag.kind !== 'handle' || e.pointerId !== drag.id) return;
    e.preventDefault();
    extendTo(e.clientX, e.clientY - HANDLE_LIFT);              // the finger is under the text: look at the line above it
  }
  function onHandleUp(e) {
    if (!drag || drag.kind !== 'handle' || e.pointerId !== drag.id) return;
    e.stopPropagation();
    endDrag();
  }

  function mkHandle(which) {
    const h = document.createElement('div');
    h.className = 'wh wh-' + which; h.dataset.which = which;
    h.addEventListener('pointerdown', e => onHandleDown(e, which, h));
    h.addEventListener('pointermove', onHandleMove);
    ['pointerup', 'pointercancel'].forEach(ev => h.addEventListener(ev, onHandleUp));
    ['click', 'contextmenu'].forEach(ev => h.addEventListener(ev, e => { e.preventDefault(); e.stopPropagation(); }));
    box.appendChild(h);
    return h;
  }

  /* ---- palette ---------------------------------------------------------------------------------------------------------- */
  function build() {
    pop = document.createElement('div'); pop.className = 'wc-pop'; pop.id = 'wcPop';
    nameEl = document.createElement('div'); nameEl.className = 'wc-name'; pop.appendChild(nameEl);
    const nav = document.createElement('div'); nav.className = 'wc-nav'; pop.appendChild(nav);
    const navBtn = (label, title, fn) => { const b = document.createElement('button'); b.type = 'button'; b.className = 'wc-btn'; b.textContent = label; b.title = title; b.addEventListener('click', fn); nav.appendChild(b); return b; };
    const pick = (a, z) => { const c = cue(); if (!c || !c.words.length) return; const last = c.words.length - 1; open = true; WS().set(Math.max(0, Math.min(last, a)), Math.max(0, Math.min(last, z)), 'preview'); placeUI(); };
    navBtn('‹ คำก่อน', 'เลือกคำก่อนหน้า', () => { const g = WS().get(); if (g) pick(g.a - 1, g.a - 1); });
    navBtn('คำถัดไป ›', 'เลือกคำถัดไป', () => { const g = WS().get(); if (g) pick(g.b + 1, g.b + 1); });
    navBtn('ทั้งประโยค', 'เลือกทั้งประโยค', () => { const c = cue(); if (c) pick(0, c.words.length - 1); });
    const palHost = document.createElement('div'); palHost.className = 'wc-pal'; pop.appendChild(palHost);
    pal = S.ui.palette.mount(palHost, (c, first) => { WS().color(c, first); });      // the full tone palette (same as the ข้อความ tab); dragging the wheel = ONE undo step
    const reset = document.createElement('button');
    reset.type = 'button'; reset.className = 'wc-btn'; reset.textContent = 'ล้างสีที่เลือก';
    reset.addEventListener('click', () => { WS().clearStyle(); });
    pop.appendChild(reset);
    const done = document.createElement('button');
    done.type = 'button'; done.className = 'wc-btn'; done.textContent = 'เสร็จ';
    done.addEventListener('click', () => closeUI(true));
    pop.appendChild(done);
    ['pointerdown', 'click'].forEach(ev => pop.addEventListener(ev, e => e.stopPropagation()));
    box.appendChild(pop);
    hS = mkHandle('start'); hE = mkHandle('end');
  }

  S.ui.wordColor = {
    init() {
      build();
      capText.addEventListener('pointerdown', e => {
        const span = e.target.closest && e.target.closest('.w');
        if (!span) return;
        cancelHold();
        if (WS().get()) closeUI(true);                         // a tap on the line while words are selected: start over
        startX = e.clientX; startY = e.clientY; pressId = e.pointerId; pressWi = +span.dataset.wi; pressCue = state.ui.activeCue;
        const now = performance.now(), dbl = lastTap.wi === pressWi && now - lastTap.t < DBL_MS;
        lastTap = { t: now, wi: pressWi };
        if (dbl) { lastTap = { t: 0, wi: -1 }; begin(pressWi); e.preventDefault(); return; }   // double tap = select this word right away (then drag to take more)
        timer = setTimeout(() => { timer = 0; begin(pressWi); }, HOLD_MS);
      });
      capText.addEventListener('pointermove', e => {
        if (timer) { if (Math.hypot(e.clientX - startX, e.clientY - startY) > MOVE_PX) cancelHold(); return; }
        if (drag && drag.kind === 'range' && e.pointerId === drag.id) { e.preventDefault(); extendTo(e.clientX, e.clientY); }
      });
      const up = e => {
        cancelHold();
        if (drag && drag.kind === 'range' && (!e || e.pointerId === drag.id)) endDrag();
      };
      ['pointerup', 'pointercancel'].forEach(ev => capText.addEventListener(ev, up));
      capText.addEventListener('pointerleave', () => { if (timer) cancelHold(); });   // while a hold is still pending only (a drag has the pointer captured)
      capText.addEventListener('contextmenu', e => e.preventDefault());                 // long-press must not open the browser menu
      // a tap anywhere outside the line, the palette, the handles and the style sheet ends the selection (the sheet keeps it: its swatches use it)
      document.addEventListener('pointerdown', e => {
        if (!WS().get() && !open) return;
        const t = e.target;
        if (pop.contains(t) || hS.contains(t) || hE.contains(t) || capText.contains(t)) return;
        if (t.closest && t.closest('#panels')) { open = false; hideUI(); return; }
        closeUI(true);
      });
      bus.on('wordsel:changed', e => {
        mark();
        if (e && e.src !== 'preview') { open = false; hideUI(); }  // chosen somewhere else: just outline it here
        else if (!WS().get()) closeUI(false);
        else placeUI();
      });
      bus.on('cue:text', () => { mark(); placeUI(); });         // the line was redrawn (a colour changed): outline + handles again
      bus.on('caption:laidout', placeUI);
      bus.on('cue:active', () => closeUI(false));
      bus.on('cues:structure', () => closeUI(false));
      window.addEventListener('resize', placeUI);
    }
  };
})(window.SubEd);
