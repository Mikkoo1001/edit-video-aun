/* =====================================================================
 * UI: free-form frame around the caption on the preview (while the clip is paused).
 *   - drag the frame's edge  -> move the line anywhere (cue.style.posX / posY)
 *   - drag the corner handle -> make this line bigger / smaller (cue.style.scale)
 *   - tap the x             -> delete this line
 * Each gesture is ONE undo step. Preview and export both read the same cue.style keys.
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, state = S.state, P = S.state.project;
  const video = S.dom.video, box = S.dom.videoBox, capText = S.dom.capText;
  let frame, del, rs, edit, dup, gesture = null;

  const cur = () => P.subtitle.cues[state.ui.activeCue];
  const num = (v, a, b) => Math.min(b, Math.max(a, v));

  function build() {
    frame = document.createElement('div'); frame.className = 'cap-frame'; frame.hidden = true;
    ['t', 'b', 'l', 'r'].forEach(k => { const e = document.createElement('div'); e.className = 'cf-edge cf-' + k; e.dataset.move = '1'; frame.appendChild(e); });
    del = document.createElement('button'); del.type = 'button'; del.className = 'cf-btn cf-del'; del.title = 'ลบประโยคนี้';
    del.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>';
    rs = document.createElement('div'); rs.className = 'cf-btn cf-rs'; rs.title = 'ลากเพื่อขยาย / ย่อ';
    rs.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M9 21h12V9M14 21l7-7"/></svg>';
    const mk = (cls, title, d) => { const b = document.createElement('button'); b.type = 'button'; b.className = 'cf-btn ' + cls; b.title = title;
      b.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' + d + '</svg>'; return b; };
    edit = mk('cf-edit', 'แก้ข้อความ', '<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16v4zM14 6l4 4"/>');
    dup = mk('cf-dup', 'ทำซ้ำ', '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M4 16V6a2 2 0 0 1 2-2h10"/>');
    frame.appendChild(del); frame.appendChild(edit); frame.appendChild(dup); frame.appendChild(rs); box.appendChild(frame);
  }

  function place() {
    if (!frame) return;
    const c = cur(), show = !!c && S.ui.sel.is() && S.ui.sel.get() === state.ui.activeCue && !!video.videoWidth;
    frame.hidden = !show;
    if (!show) return;
    const b = box.getBoundingClientRect(), t = capText.getBoundingClientRect(), pad = 8;
    if (!t.width) { frame.hidden = true; return; }
    frame.style.left = (t.left - b.left - pad) + 'px'; frame.style.top = (t.top - b.top - pad) + 'px';
    frame.style.width = (t.width + pad * 2) + 'px'; frame.style.height = (t.height + pad * 2) + 'px';
  }
  const later = () => requestAnimationFrame(place);

  function pic() { return S.ui.preview.contentRect(); }

  function down(e) {
    const c = cur(); if (!c) return;
    const isRs = rs.contains(e.target), isMove = e.target.dataset && e.target.dataset.move;
    if (!isRs && !isMove) return;
    e.preventDefault(); e.stopPropagation();
    const t = capText.getBoundingClientRect(), b = box.getBoundingClientRect(), r = pic();
    const es = S.subtitle.effectiveStyle(c, P.style);
    gesture = { id: e.pointerId, kind: isRs ? 'scale' : 'move', x: e.clientX, y: e.clientY, idx: state.ui.activeCue, recorded: false,
      px: ((t.left + t.width / 2) - b.left - r.x) / r.w, py: ((t.top + t.height / 2) - b.top - r.y) / r.h,
      cx: t.left + t.width / 2, cy: t.top + t.height / 2, scale: (c.style && c.style.scale) || 1, r: r };
    gesture.d0 = Math.max(10, Math.hypot(e.clientX - gesture.cx, e.clientY - gesture.cy));
    frame.setPointerCapture && frame.setPointerCapture(e.pointerId);
  }
  function move(e) {
    const g = gesture; if (!g || e.pointerId !== g.id) return;
    if (!g.recorded) { if (Math.hypot(e.clientX - g.x, e.clientY - g.y) < 3) return; if (S.history) S.history.record('free'); g.recorded = true; }
    e.preventDefault();
    if (g.kind === 'move') {
      S.subtitle.setCueLook(g.idx, { posX: +num(g.px + (e.clientX - g.x) / g.r.w, 0.05, 0.95).toFixed(4), posY: +num(g.py + (e.clientY - g.y) / g.r.h, 0.05, 0.97).toFixed(4) }, { history: false });
    } else {
      const k = num(g.scale * Math.hypot(e.clientX - g.cx, e.clientY - g.cy) / g.d0, 0.3, 4);
      S.subtitle.setCueLook(g.idx, { scale: Math.abs(k - 1) < 0.0005 ? null : +k.toFixed(4) }, { history: false });
    }
    later();
  }
  function up(e) { if (gesture && e.pointerId === gesture.id) { gesture = null; later(); } }

  S.ui.capFrame = {
    init() {
      build();
      frame.addEventListener('pointerdown', down);
      frame.addEventListener('pointermove', move);
      ['pointerup', 'pointercancel'].forEach(ev => frame.addEventListener(ev, up));
      [del, edit, dup].forEach(b => b.addEventListener('pointerdown', e => e.stopPropagation()));
      edit.addEventListener('click', e => { e.stopPropagation(); S.ui.tabs.open('style'); setTimeout(() => { const t = $('teInput'); if (t && !t.disabled) t.focus(); }, 300); });
      dup.addEventListener('click', e => { e.stopPropagation(); const i = state.ui.activeCue; if (i < 0) return; const at = S.subtitle.duplicateCue(i); if (at >= 0) { video.currentTime = P.subtitle.cues[at].start; bus.emit('time:changed', video.currentTime); } later(); });
      del.addEventListener('click', e => {
        e.stopPropagation();
        const i = state.ui.activeCue; if (i < 0) return;
        S.subtitle.removeCue(i); S.ui.sel.clear(); later();
      });
      ['cue:selected', 'caption:laidout', 'time:changed', 'cue:active', 'cue:text', 'cue:style', 'cue:timing', 'cues:structure', 'style:changed', 'sheet:toggle', 'media:metadata'].forEach(ev => bus.on(ev, later));
      ['play', 'pause', 'seeked', 'loadeddata'].forEach(ev => video.addEventListener(ev, later));
      window.addEventListener('resize', later);
    }
  };
})(window.SubEd);
