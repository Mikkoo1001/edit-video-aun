/* =====================================================================
 * "จัดฉาก" — lay b-roll clips along the audio and cut the scenes where the audio says so.
 *
 *   The loaded clip (or audio file) is only the SOUND + timing. Scenes tile its whole duration; every scene shows a part of
 *   one clip from the pool, cropped / fitted to the chosen frame (9:16 or 7:12). Captions are drawn on top exactly as before.
 *
 *   project.arrange = { on, aspect, fit, order, mode, minLen, maxLen, silMin, fixedLen,
 *                       clips:[{id,name,file,url,el,duration,w,h,thumb}],         (runtime only, never serialised)
 *                       scenes:[{id,start,end,clipId,offset,fit}], sel }          start/end = SOURCE time, like the cues
 *
 *   Preview: a <canvas> over the (hidden) main <video>; hidden <video> elements, one per pool clip, follow the main clock.
 *   Export:  export/arrange-export.js reads the same model through S.arrange.* (drawFit / sceneAt / clipTime are shared,
 *            so what you see is what is rendered).
 * Kept across a refresh (IndexedDB via SubEd.persist): key 'arrange' = settings + scenes + clip list, key 'arr:clip:<id>' = each clip's bytes.
 *   Scenes belong to the loaded audio (name+size), so they only come back with the same clip; the clip pool comes back regardless.
 * Still pictures (JPG / PNG / WebP / GIF): a pool clip with still:true — one picture held for the whole scene (duration = STILL_SEC when laid out),
 *   drawn through the same drawFit as video, with an optional slow zoom-in (A.stillZoom). Its element is an <img> wearing the few <video> properties the rest of
 *   the code reads (videoWidth / videoHeight / readyState / paused / currentTime), so the preview, the export and the AI frame sampler share one path.
 * Many clips: a pool clip only owns a live <video> while it is being shown (at most LIVE_MAX at once), thumbnails are made once.
 * Emits: arrange:changed.   Listens: time:changed, media:selected, media:cleared, media:metadata, sheet:toggle.
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, P = S.state.project;
  const video = S.dom.video, videoBox = S.dom.videoBox, capLayer = S.dom.capLayer;
  const A = P.arrange;
  const ASPECT = { '9:16': [9, 16], '7:12': [7, 12] };
  const COLORS = ['#f5c518', '#33c9b6', '#ff7a59', '#9b8cff', '#6fd16f', '#ff6fa8'];
  let seq = 0;
  const uid = p => p + (++seq);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const ft = t => { t = Math.max(0, t || 0); const m = Math.floor(t / 60); return m + ':' + (t - m * 60).toFixed(1).padStart(4, '0'); };
  const dur = () => P.media.duration || 0;
  const MIN_SCENE = 0.2, LIVE_MAX = 3, STILL_SEC = 3, STILL_ZOOM = 0.08, MAX_STILL_BYTES = 80 * 1024 * 1024;
  const isStillFile = f => !!f && (/^image\//.test(f.type || '') || /\.(jpe?g|png|webp|gif|bmp|avif)$/i.test(f.name || ''));
  const isVideoFile = f => !!f && (/^video\//.test(f.type || '') || /\.(mp4|m4v|mov|webm|mkv)$/i.test(f.name || ''));
  const MAX_CLIPS = (S.limits && S.limits.MAX_CLIPS) || 30;      // clips in the pool: any number up to this, whatever their length
  const keyOf = f => f ? f.name + '|' + f.size : '';
  const sigOf = f => f.name + '|' + f.size + '|' + (f.lastModified || 0);

  /* ------------------------------------------------------------ model helpers (shared with the exporter) */
  function ratio() { return ASPECT[A.aspect] || ASPECT['9:16']; }
  function clipOf(s) { return s && s.clipId ? A.clips.find(c => c.id === s.clipId) || null : null; }
  function sceneAt(t, scenes) {
    scenes = scenes || A.scenes;
    if (!scenes.length) return null;
    for (let i = 0; i < scenes.length; i++) if (t < scenes[i].end) return scenes[i];
    return scenes[scenes.length - 1];
  }
  /** Time inside the clip that scene `s` shows at source time `t` (loops when the clip is shorter than the scene). */
  function clipTime(s, t) {
    const c = clipOf(s); if (!c || !(c.duration > 0) || c.still) return 0;      // a still picture has no time inside it
    const d = c.duration;
    let x = (s.offset || 0) + Math.max(0, t - s.start);
    x = ((x % d) + d) % d;
    return Math.min(x, Math.max(0, d - 0.04));
  }
  function fitOf(s) { return (s && s.fit) || A.fit || 'cover'; }
  /** Zoom of a still picture at source time t of scene s (1 = none, grows to 1 + STILL_ZOOM at the end of the scene). Video clips never zoom. */
  function zoomOf(s, c, t) {
    if (!s || !c || !c.still || A.stillZoom === false) return 1;
    return 1 + STILL_ZOOM * Math.min(1, Math.max(0, (t - s.start) / Math.max(0.1, s.end - s.start)));
  }
  /** Draw a clip frame into the w×h canvas context. fit: 'cover' (fill + crop) | 'contain' (black bars) | 'blur' (contain over a blurred cover). */
  let tiny = null;
  function drawFit(ctx, el, w, h, fit, z) {
    const vw = el && el.videoWidth, vh = el && el.videoHeight;
    z = z > 1 ? z : 1;                          // z > 1: slow zoom-in on a still picture (about the centre)
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
    if (!vw || !vh) return;
    if (fit === 'contain' || fit === 'blur') {
      if (fit === 'blur') {                       // a tiny copy scaled up with smoothing = cheap blur that works in every browser
        if (!tiny) tiny = document.createElement('canvas');
        tiny.width = 24; tiny.height = Math.max(2, Math.round(24 * h / w));
        const tc = tiny.getContext('2d'), kk = Math.max(tiny.width / vw, tiny.height / vh);
        tc.drawImage(el, (tiny.width - vw * kk) / 2, (tiny.height - vh * kk) / 2, vw * kk, vh * kk);
        ctx.imageSmoothingEnabled = true; ctx.drawImage(tiny, 0, 0, w, h);
        ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillRect(0, 0, w, h);
      }
      const k = Math.min(w / vw, h / vh) * z;
      ctx.drawImage(el, (w - vw * k) / 2, (h - vh * k) / 2, vw * k, vh * k);
    } else {
      const k = Math.max(w / vw, h / vh) * z;
      ctx.drawImage(el, (w - vw * k) / 2, (h - vh * k) / 2, vw * k, vh * k);
    }
  }

  /* ------------------------------------------------------------ planning: where do the scenes start? */
  /** Pick cut points from `cands` (seconds) so scenes are >= minLen, and cut a stretch longer than maxLen by force. -> [0, ..., duration] */
  function planBounds(cands, duration, minLen, maxLen) {
    minLen = Math.max(0.3, minLen); maxLen = Math.max(minLen * 1.2, maxLen);
    const list = cands.filter(t => t > 0 && t < duration).sort((a, b) => a - b), out = [0];
    let last = 0, i = 0;
    for (let guard = 0; guard < 100000; guard++) {
      let pick = null;
      for (; i < list.length; i++) if (list[i] >= last + minLen) { pick = list[i]; break; }
      if (pick == null || pick > last + maxLen) {
        if (duration - last <= maxLen) break;      // the rest fits in one scene
        pick = last + maxLen;                      // no natural cut point close enough: cut anyway (the candidate stays for later)
        out.push(+pick.toFixed(3)); last = pick; continue;
      }
      if (duration - pick < minLen * 0.5) break;   // a tiny tail stays part of the last scene
      out.push(+pick.toFixed(3)); last = pick; i++;
    }
    out.push(+duration.toFixed(3));
    return out;
  }
  function cueCandidates() {
    const cues = P.subtitle.cues.slice().sort((a, b) => a.start - b.start), c = [];
    for (let i = 1; i < cues.length; i++) c.push(cues[i].start > cues[i - 1].end ? (cues[i - 1].end + cues[i].start) / 2 : cues[i].start);
    return c;
  }
  /** Loudness per 20 ms of the audio: streamed from the file when it is an MP4/WebM (cheap on RAM), whole-file decode otherwise (audio files). */
  async function loudness(file, onProgress) {
    const HOP = 0.02, rms = [];
    try {
      const ch = await S.audio.openChunks(file, { chunkSec: 120, durationHint: dur() });
      try {
        for (let piece; (piece = await ch.next());) {
          const a = new Int16Array(await piece.blob.arrayBuffer(), 44), n = 320;
          for (let i = 0; i + n <= a.length; i += n) { let s = 0; for (let j = 0; j < n; j++) { const v = a[i + j]; s += v * v; } rms.push(Math.sqrt(s / n) / 32768); }
          if (onProgress && dur()) onProgress(Math.min(1, rms.length * HOP / dur()));
        }
      } finally { ch.close(); }
      if (rms.length) return { hop: HOP, rms: rms };
    } catch (e) { /* not an MP4/WebM, or no WebCodecs: fall through to the whole-file decoder */ }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) throw new Error('เบราว์เซอร์นี้อ่านเสียงเพื่อแบ่งฉากไม่ได้');
    const ac = new AC();
    try {
      const buf = await ac.decodeAudioData(await (S.localCopy ? S.localCopy.readAll(file) : file.arrayBuffer()));
      const n = Math.max(1, Math.round(buf.sampleRate * HOP)), chs = [];
      for (let c = 0; c < buf.numberOfChannels; c++) chs.push(buf.getChannelData(c));
      for (let i = 0; i + n <= buf.length; i += n) {
        let s = 0; for (let j = 0; j < n; j++) { let v = 0; for (let c = 0; c < chs.length; c++) v += chs[c][i + j]; v /= chs.length; s += v * v; }
        rms.push(Math.sqrt(s / n));
      }
    } finally { try { ac.close(); } catch (e) {} }
    return { hop: HOP, rms: rms };
  }
  /** Quiet stretches (>= silMin seconds, clearly below the speech level) as [from, to] in seconds. */
  function pauseRanges(env, silMin) {
    const n = env.rms.length; if (n < 10) return [];
    const db = new Float32Array(n);
    for (let i = 0; i < n; i++) db[i] = 20 * Math.log10(Math.max(env.rms[i], 1e-5));
    const sm = new Float32Array(n);                                   // 3-frame average so a single click does not break a pause
    for (let i = 0; i < n; i++) sm[i] = ((db[Math.max(0, i - 1)] + db[i] + db[Math.min(n - 1, i + 1)]) / 3);
    const sorted = Array.from(sm).sort((a, b) => a - b), p10 = sorted[Math.floor(n * 0.1)], p90 = sorted[Math.floor(n * 0.9)];
    const thr = Math.max(p10 + 4, p90 - 26), need = Math.max(2, Math.round(silMin / env.hop)), out = [];
    for (let i = 0; i < n;) {
      if (sm[i] >= thr) { i++; continue; }
      let j = i; while (j < n && sm[j] < thr) j++;
      if (j - i >= need) out.push([i * env.hop, j * env.hop]);
      i = j;
    }
    return out;
  }
  /** Mid-points of the pauses (scene cut candidates). */
  function pauseCandidates(env, silMin) { return pauseRanges(env, silMin).map(r => (r[0] + r[1]) / 2); }

  /* ------------------------------------------------------------ clip pool */
  function hiddenVideo(url) {
    const el = document.createElement('video');
    el.muted = true; el.playsInline = true; el.preload = 'auto'; el.src = url;
    el.style.cssText = 'position:fixed;right:0;bottom:0;width:4px;height:4px;opacity:0.02;pointer-events:none;';
    document.body.appendChild(el);
    return el;
  }
  /** A still picture dressed as a <video> for the code that only reads videoWidth / videoHeight / readyState / paused / currentTime / play / pause.
   *  Not put in the page. 'loadedmetadata' is fired when the picture is decoded so `await ready(el)` style waits work for it too. */
  function hiddenImage(url) {
    const im = new Image(); im.decoding = 'async';
    Object.defineProperties(im, {
      videoWidth: { get() { return this.naturalWidth; } }, videoHeight: { get() { return this.naturalHeight; } },
      readyState: { get() { return this.complete && this.naturalWidth ? 4 : 0; } },
      paused: { get() { return true; } }, seeking: { get() { return false; } }, ended: { get() { return false; } },
      currentTime: { get() { return 0; }, set(v) {} }
    });
    im.play = () => Promise.resolve(); im.pause = () => {}; im.load = () => {};
    im.addEventListener('load', () => im.dispatchEvent(new Event('loadedmetadata')));
    if (url) im.src = url;
    return im;
  }
  /** The element a pool clip is drawn from: an <img> for a still picture, a hidden <video> otherwise. `still` = the clip is a picture. */
  function hiddenMedia(url, still) { return still ? hiddenImage(url) : hiddenVideo(url); }
  async function thumbOf(el) {
    try {
      await new Promise(res => { const tm = setTimeout(res, 2500); el.addEventListener('seeked', () => { clearTimeout(tm); res(); }, { once: true }); el.currentTime = Math.min(0.5, (el.duration || 1) / 2); });
      const w = 64, h = Math.max(2, Math.round(64 * el.videoHeight / el.videoWidth)), c = document.createElement('canvas'); c.width = w; c.height = h;
      c.getContext('2d').drawImage(el, 0, 0, w, h);
      return c.toDataURL('image/jpeg', 0.6);
    } catch (e) { return ''; }
  }
  /** A pool clip owns a live <video> only while it is in use (a pool of hundreds would otherwise hold hundreds of decoders). */
  let live = [], active = null;
  function releaseEl(c) { if (!c || !c.el) return; try { c.el.pause(); c.el.removeAttribute('src'); c.el.load(); c.el.remove(); } catch (e) {} c.el = null; }
  function elOf(c) {
    if (!c.el) c.el = hiddenMedia(c.url, c.still);
    const i = live.indexOf(c.id); if (i >= 0) live.splice(i, 1);
    live.push(c.id);
    while (live.length > LIVE_MAX) {
      const k = live.findIndex(id => !active || id !== active.id); if (k < 0) break;
      releaseEl(A.clips.find(x => x.id === live[k])); live.splice(k, 1);
    }
    return c.el;
  }
  /** A still picture joins the pool as a clip that is one picture held for the whole scene. */
  function addStillFile(file) {
    if (file.size > MAX_STILL_BYTES) return Promise.reject(new Error('“' + file.name + '” ใหญ่เกินไป (' + (file.size / 1048576).toFixed(0) + ' MB) — รูปรองรับสูงสุด ' + (MAX_STILL_BYTES / 1048576).toFixed(0) + ' MB'));
    const url = URL.createObjectURL(file), el = hiddenImage();
    return new Promise((resolve, reject) => {
      const fail = () => { try { URL.revokeObjectURL(url); } catch (e) {} reject(new Error('เปิดรูป “' + file.name + '” ไม่ได้ (รองรับ JPG / PNG / WebP / GIF — ไฟล์ HEIC ต้องแปลงเป็น JPG ก่อน)')); };
      el.addEventListener('error', fail, { once: true });
      el.addEventListener('load', () => {
        if (!el.naturalWidth || !el.naturalHeight) return fail();
        let thumb = ''; try {
          const w = 64, h = Math.max(2, Math.round(64 * el.naturalHeight / el.naturalWidth)), c = document.createElement('canvas'); c.width = w; c.height = h;
          c.getContext('2d').drawImage(el, 0, 0, w, h); thumb = c.toDataURL('image/jpeg', 0.6);
        } catch (e) {}
        const clip = { id: uid('k'), name: file.name || 'รูป', file: file, url: url, el: null, duration: STILL_SEC, w: el.naturalWidth, h: el.naturalHeight, thumb: thumb, sig: sigOf(file), still: true };
        A.clips.push(clip);
        resolve(clip);
      }, { once: true });
      el.src = url;
    });
  }
  function addClipFile(file) {
    if (A.clips.length >= MAX_CLIPS) return Promise.reject(new Error('มีคลิปครบ ' + MAX_CLIPS + ' คลิปแล้ว — เอาคลิปออกก่อนจึงจะเพิ่มได้'));
    if (isStillFile(file) && !isVideoFile(file)) return addStillFile(file);
    if (file.size > S.limits.MAX_VIDEO_BYTES) return Promise.reject(new Error('“' + file.name + '” ใหญ่เกินไป (' + (file.size / 1048576).toFixed(0) + ' MB) — รองรับสูงสุด ' + (S.limits.MAX_VIDEO_BYTES / 1048576).toFixed(0) + ' MB'));
    const url = URL.createObjectURL(file), el = hiddenVideo(url);
    return new Promise((resolve, reject) => {
      const fail = msg => { try { el.remove(); URL.revokeObjectURL(url); } catch (e) {} reject(new Error(msg)); };
      if (S.localCopy && file.size > S.limits.SNAPSHOT_MAX) S.localCopy.probe(file).catch(e => { if (e && e.name === 'NotReadableError') fail('เบราว์เซอร์อ่านไฟล์ “' + file.name + '” ไม่ได้ — ถ้าอยู่บนคลาวด์ให้ดาวน์โหลดลงเครื่องก่อน'); });   // big references: say so now, not when merging / exporting
      el.addEventListener('error', () => fail('เปิดไฟล์ “' + file.name + '” ไม่ได้'), { once: true });
      el.addEventListener('loadedmetadata', async () => {
        if (!el.videoWidth || !el.videoHeight) return fail('“' + file.name + '” ไม่มีภาพที่เบราว์เซอร์ถอดรหัสได้ (เช่น HEVC บางเครื่อง)');
        const clip = { id: uid('k'), name: file.name || 'clip', file: file, url: url, el: null, duration: el.duration || 0, w: el.videoWidth, h: el.videoHeight, thumb: '', sig: sigOf(file) };
        clip.thumb = await thumbOf(el);
        try { el.pause(); el.removeAttribute('src'); el.load(); el.remove(); } catch (e) {}      // the live element is made again when the clip is shown
        A.clips.push(clip);
        resolve(clip);
      }, { once: true });
    });
  }
  function dropClip(id) {
    const i = A.clips.findIndex(c => c.id === id); if (i < 0) return;
    const c = A.clips[i]; A.clips.splice(i, 1);
    releaseEl(c); try { URL.revokeObjectURL(c.url); } catch (e) {}
    live = live.filter(x => x !== id);
    if (S.persist) S.persist.del(['arr:clip:' + id]).catch(() => {});
    A.scenes.forEach(s => { if (s.clipId === id) { s.clipId = null; s.offset = 0; } });
  }

  /** No video in the pool: the loaded video ITSELF is the picture of the scenes (cut with the reference, effects and all) — without this
   *  every scene is empty and the preview / export is a black screen. It joins the pool as "วิดีโอหลัก" (never stored a second time: the editor
   *  already keeps the project's clip) and each scene shows the original picture at its own time (offset = scene start). */
  const MAIN_ID = 'kmain';
  const mainClip = () => A.clips.find(c => c.main) || null;
  async function ensureMainClip() {
    let c = mainClip(); if (c) return c;
    const f = P.media.file; if (!f || !video.videoWidth) return null;        // a sound file has no picture to show
    try { c = await addClipFile(f); } catch (e) { return null; }
    c.id = MAIN_ID; c.main = true; c._failed = true; c.name = 'วิดีโอหลัก · ' + (f.name || '');
    return c;
  }
  /** Scenes that have no clip show the loaded video. Returns how many scenes got it. */
  async function assignMain() {
    const c = await ensureMainClip(); if (!c) return 0;
    let n = 0;
    A.scenes.forEach(s => { if (!clipOf(s)) { s.clipId = c.id; s.offset = +Math.max(0, s.start).toFixed(3); s.fit = null; n++; } });
    return n;
  }

  /* ------------------------------------------------------------ scenes */
  function setScenes(bounds) {
    A.scenes = [];
    for (let i = 0; i + 1 < bounds.length; i++) A.scenes.push({ id: uid('s'), start: bounds[i], end: bounds[i + 1], clipId: null, offset: 0, fit: null, fx: null, sfx: null });
    A.sel = A.scenes.length ? 0 : -1;
  }
  function autoAssign(onlyEmpty) {
    if (!A.clips.length || !A.scenes.length) return 0;
    const order = A.clips.slice();
    if (A.order === 'shuffle') for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); const x = order[i]; order[i] = order[j]; order[j] = x; }
    const next = new Map();                                   // clip id -> where the next scene using it should start (so a long clip is used in order)
    if (onlyEmpty) A.scenes.forEach(s => { const c = clipOf(s); if (c) next.set(c.id, Math.max(next.get(c.id) || 0, (s.offset || 0) + s.end - s.start)); });
    let n = 0;
    A.scenes.forEach((s, i) => {
      if (onlyEmpty && clipOf(s)) return;
      const c = order[i % order.length], d = s.end - s.start;
      let off = c.still ? 0 : next.get(c.id) || 0;                                   // a still picture has no "further on"
      if (!c.still && c.duration > 0 && off + Math.min(d, c.duration) > c.duration) off = 0;       // not enough left in the clip: start it over
      s.clipId = c.id; s.offset = +off.toFixed(3); s.fit = null;
      next.set(c.id, off + d); n++;
    });
    return n;
  }
  /** Added videos become the MAIN video: with no scenes yet, lay the clips one after another along the timeline (each for its own
   *  length, in the order they were added; the list repeats if it is shorter than the audio). One scene per clip. */
  function layClips(even, list) {
    const D = dur(), cl = (list || A.clips).filter(c => c.duration > 0.2);      // list: lay only these clips (the ones whose sound was merged into the main sound)
    if (!D || !cl.length) return 0;
    // even: several clips were picked together (first screen) — no clip may take more than its equal share of the timeline, so every one of them shows up
    const cap = even ? Math.max(0.5, D / cl.length) : Infinity;
    const bounds = [0]; let t = 0, k = 0;
    while (t < D - 0.05 && bounds.length < 5000) { t += Math.min(cap, cl[k % cl.length].duration); k++; bounds.push(+Math.min(t, D).toFixed(3)); }
    bounds[bounds.length - 1] = +D.toFixed(3);
    if (bounds.length > 2 && D - bounds[bounds.length - 2] < 0.5) bounds.splice(bounds.length - 2, 1);        // a sliver at the end joins the scene before it
    setScenes(bounds);
    A.scenes.forEach((s, i) => { const c = cl[i % cl.length]; s.clipId = c.id; s.offset = 0; });
    return A.scenes.length;
  }
  /** Several clips merged into one main sound (ui/merge-clips.js): the clips are the picture, back to back, each for its own length. */
  function layMerged(list) {
    if (!A.on) { A.on = true; applyOn(); }
    const n = layClips(false, list); syncCuts(); renderAll(); scheduleSave();
    return n;
  }
  /** The main video track is cut at the scene boundaries too (the pieces are the "ตัดวิดีโอ" pieces: tap, delete, restore, export). */
  function syncCuts() {
    if (!S.videoCut || !S.videoCut.setBounds || A.scenes.length < 1 || !dur()) return;
    try { if (S.history) S.history.record('cut'); S.videoCut.setBounds(A.scenes.slice(1).map(s => s.start)); } catch (e) { console.warn('[arrange] could not cut the main video at the scenes:', e); }
  }
  /* scene edits made on the timeline can be taken back (a small stack of copies of the scene list) */
  let sceneUndo = [], replaceTarget = null;
  function pushUndo() { sceneUndo.push(JSON.stringify({ scenes: A.scenes, sel: A.sel })); if (sceneUndo.length > 40) sceneUndo.shift(); }
  function dropUndo() { sceneUndo.pop(); }
  function undoScenes() {
    const j = sceneUndo.pop(); if (!j) return false;
    const d = JSON.parse(j); A.scenes = d.scenes; A.sel = Math.min(d.sel, d.scenes.length - 1);
    syncCuts(); renderAll(); return true;
  }
  /** Take scene i off the timeline: its time goes to the scene before it (or, for the first scene, to the one after), so the picture never has a hole. */
  function removeScene(i) {
    if (A.scenes.length < 2 || i < 0 || i >= A.scenes.length) return false;
    pushUndo();
    const s = A.scenes[i];
    if (i > 0) A.scenes[i - 1].end = s.end;
    else { const n = A.scenes[1], gap = n.start - s.start; if (n.clipId) n.offset = +Math.max(0, (n.offset || 0) - gap).toFixed(3); n.start = s.start; }
    A.scenes.splice(i, 1); A.sel = Math.min(i, A.scenes.length - 1);
    syncCuts(); renderAll(); return true;
  }
  /** Swap scene i with its neighbour (dir -1 / +1): each keeps its own length, so the whole still fills the audio. Returns the new index. */
  function moveScene(i, dir) {
    const j = i + dir; if (i < 0 || j < 0 || i >= A.scenes.length || j >= A.scenes.length) return -1;
    pushUndo();
    const a = A.scenes[i], b = A.scenes[j], t0 = Math.min(a.start, b.start), t2 = Math.max(a.end, b.end);
    A.scenes[i] = b; A.scenes[j] = a;
    const lo = Math.min(i, j), x = A.scenes[lo], y = A.scenes[lo + 1], dx = x.end - x.start;
    x.start = t0; x.end = +(t0 + dx).toFixed(3); y.start = x.end; y.end = t2;
    A.sel = j; syncCuts(); renderAll(); return j;
  }
  function splitAtPlayhead() {
    pushUndo();
    const k = splitAt(video.currentTime || 0);
    if (k < 0) { dropUndo(); return -1; }
    syncCuts(); renderAll(); return k;
  }
  function replaceScene(i, all) { if (!A.scenes[i]) return; replaceTarget = { i: i, all: !!all }; $('arrReplaceInput').click(); }
  /** Make scene i `len` seconds long by moving the cut next to it (clamped by the neighbour). Call it BEFORE setting the scene's offset. */
  function setSceneLength(i, len) {
    const s = A.scenes[i]; if (!s || !(len > 0)) return;
    if (i < A.scenes.length - 1) moveCut(i, s.start + len);
    else if (i > 0) moveCut(i - 1, s.end - len);
  }
  function selectScene(i, play) {
    const s = A.scenes[i]; if (!s) return;
    A.sel = i; renderAll();
    if (play && S.ui.player) S.ui.player.replay(s.start, s.end);        // tap a scene on the timeline = look at it
  }
  function exportScene(i) {
    const s = A.scenes[i]; if (!s) return;
    if (!S.ui.exportPanel || !S.ui.exportPanel.exportRange) return;
    if (!A.on) { A.on = true; applyOn(); }
    S.ui.exportPanel.exportRange({ start: s.start, end: s.end });
  }
  function splitAt(t) {
    const i = A.scenes.findIndex(s => t > s.start + MIN_SCENE && t < s.end - MIN_SCENE);
    if (i < 0) return -1;
    const s = A.scenes[i], tail = { id: uid('s'), start: +t.toFixed(3), end: s.end, clipId: s.clipId, offset: +((s.offset || 0) + (t - s.start)).toFixed(3), fit: s.fit,
      fx: s.fx ? { tr: 'cut', trDur: 0.25, motion: s.fx.motion || 'none', amt: s.fx.amt } : null, sfx: null };
    s.end = tail.start; A.scenes.splice(i + 1, 0, tail); A.sel = i + 1;
    return i + 1;
  }
  function mergeWithNext(i) {
    if (i < 0 || i >= A.scenes.length - 1) return false;
    A.scenes[i].end = A.scenes[i + 1].end; A.scenes.splice(i + 1, 1);
    A.sel = Math.min(i, A.scenes.length - 1);
    return true;
  }
  /** Move the cut between scene i and i+1. */
  function moveCut(i, t) {
    const a = A.scenes[i], b = A.scenes[i + 1]; if (!a || !b) return;
    t = Math.min(b.end - MIN_SCENE, Math.max(a.start + MIN_SCENE, t));
    if (b.clipId) b.offset = +Math.max(0, (b.offset || 0) + (t - b.start)).toFixed(3);   // keep the picture of the next scene where it was
    a.end = b.start = +t.toFixed(3);
  }

  /* ------------------------------------------------------------ preview canvas */
  let cv = null, cx = null, raf = 0, lastKey = '', prevCv = null, lastSceneId = null;
  const sfxDone = new Set();                    // scenes whose sound effect is already scheduled in this stretch of playing
  function buildCanvas() {
    cv = document.createElement('canvas'); cv.className = 'arr-cv'; cx = cv.getContext('2d', { alpha: false });
    videoBox.insertBefore(cv, capLayer);
  }
  function layoutCanvas() {
    if (!cv) return;
    const r = S.ui.preview.contentRect(), key = [r.x, r.y, r.w, r.h, A.aspect].join('|');
    if (key === lastKey) return;
    lastKey = key;
    cv.style.left = r.x + 'px'; cv.style.top = r.y + 'px'; cv.style.width = r.w + 'px'; cv.style.height = r.h + 'px';
    const [aw, ah] = ratio(), w = Math.max(2, Math.min(720, Math.round(r.w * Math.min(2, window.devicePixelRatio || 1))));
    cv.width = w; cv.height = Math.max(2, Math.round(w * ah / aw));
  }
  function tick() {
    raf = requestAnimationFrame(tick);
    layoutCanvas();
    const t = video.currentTime || 0, s = sceneAt(t), c = clipOf(s);
    if (active && active !== c && active.el) { try { active.el.pause(); } catch (e) {} }
    active = c;
    if (s && s.id !== lastSceneId) {            // a new scene: the canvas still shows the old scene's last picture — keep a copy for the transition
      if (lastSceneId && cv.width) { if (!prevCv) prevCv = document.createElement('canvas'); prevCv.width = cv.width; prevCv.height = cv.height; prevCv.getContext('2d').drawImage(cv, 0, 0); }
      lastSceneId = s.id;
    }
    scheduleSfx(t, s);
    if (!c) {
      cx.fillStyle = '#000'; cx.fillRect(0, 0, cv.width, cv.height);
      cx.fillStyle = '#777'; cx.font = Math.round(cv.width / 20) + 'px sans-serif'; cx.textAlign = 'center';
      cx.fillText(s ? 'ฉากนี้ยังไม่มีคลิป' : 'ยังไม่ได้แบ่งฉาก', cv.width / 2, cv.height / 2);
      return;
    }
    const el = elOf(c), want = clipTime(s, t);
    if (c.still) { /* a picture: nothing to play or seek */ }
    else if (!video.paused) {
      if (el.paused) { el.currentTime = want; el.play().catch(() => {}); }
      else if (!el.seeking && Math.abs(el.currentTime - want) > 0.3) el.currentTime = want;     // scene switched, clip looped, or the clock jumped
    } else {
      if (!el.paused) el.pause();
      if (!el.seeking && Math.abs(el.currentTime - want) > 0.02) el.currentTime = want;           // scrubbing
    }
    const W = cv.width, H = cv.height, zm = zoomOf(s, c, t), base = k => drawFit(k, el, W, H, fitOf(s), zm);
    if (A.fxOn && s.fx) S.arrangeFx.drawScene(cx, W, H, base, s.fx, t - s.start, s.end - s.start, prevCv); else base(cx);
  }
  /** While playing, start the NEXT scene's sound effect early enough that its peak lands on the cut. */
  function scheduleSfx(t, s) {
    if (!A.sfxOn || video.paused || (S.ui.player && S.ui.player.userMuted ? S.ui.player.userMuted() : video.muted) || !s) return;      // muted main sound (ปิดเสียงวิดีโอหลัก) does not silence the effects
    const nx = A.scenes[A.scenes.indexOf(s) + 1];
    if (!nx || !nx.sfx || sfxDone.has(nx.id)) return;
    const sy = S.arrangeFx.synth(nx.sfx), dt = nx.start - t;
    if (sy && dt > -0.02 && dt <= sy.peak + 0.15) { sfxDone.add(nx.id); S.arrangeFx.player.play(nx.sfx, A.sfxVol, Math.max(0, dt)); }
  }
  ['pause', 'seeking', 'play'].forEach(ev => video.addEventListener(ev, () => { sfxDone.clear(); S.arrangeFx.player.stop(); }));
  function applyOn() {
    document.body.classList.toggle('arr-on', !!A.on);
    document.documentElement.style.setProperty('--arr-ar', ratio()[0] + ' / ' + ratio()[1]);
    if (A.on) { if (!cv) buildCanvas(); lastKey = ''; if (!raf) raf = requestAnimationFrame(tick); }
    else { if (raf) cancelAnimationFrame(raf); raf = 0; if (active && active.el) { try { active.el.pause(); } catch (e) {} } active = null; }
    [0, 60, 300].forEach(ms => setTimeout(() => window.dispatchEvent(new Event('resize')), ms));   // picture rect changed: captions re-measure
  }


  /* ------------------------------------------------------------ keep it across a refresh */
  let loaded = false, held = null, saveTimer = 0, chain = Promise.resolve(), warned = false, savedIds = [];
  const SETTINGS = ['aspect', 'fit', 'order', 'mode', 'minLen', 'maxLen', 'silMin', 'fixedLen', 'fxOn', 'sfxOn', 'sfxVol', 'autoSfx', 'refOpts', 'autoVoice', 'voiceTrim', 'voiceRhythm', 'webSearch', 'cast', 'stillZoom'];
  function scheduleSave() { if (!loaded) return; clearTimeout(saveTimer); saveTimer = setTimeout(saveNow, 600); }
  function saveNow() {
    clearTimeout(saveTimer); saveTimer = 0;
    if (!loaded || !S.persist) return chain;
    // scenes still waiting for their audio clip to come back are saved as they were (never overwritten by the empty live state)
    const src = held || { mainKey: keyOf(P.media.file), scenes: A.scenes, sel: A.sel, on: A.on };
    const meta = { v: 1, mainKey: src.mainKey || '', on: !!src.on, sel: src.sel, scenes: JSON.parse(JSON.stringify(src.scenes || [])),
      clips: A.clips.map(c => ({ id: c.id, name: c.name, size: c.file.size, type: c.file.type, lastModified: c.file.lastModified || 0, duration: c.duration, w: c.w, h: c.h, thumb: c.thumb, sig: c.sig, cuts: Array.isArray(c.cuts) ? c.cuts.slice() : [], ai: c.ai || null, aiKey: c.aiKey || '', names: Array.isArray(c.names) ? c.names.slice(0, 12) : [], still: !!c.still })) };
    SETTINGS.forEach(k => { meta[k] = A[k]; });
    meta.ref = A.ref ? JSON.parse(JSON.stringify(A.ref)) : null;
    const snapshot = A.clips.slice(), gone = savedIds.filter(id => !snapshot.some(c => c.id === id));
    chain = chain.then(async () => {
      if (S.ui.media && S.ui.media.settled && snapshot.some(c => !c._stored && !c._failed)) await S.ui.media.settled();   // one big disk job at a time: the main clip's copy first
      for (const c of snapshot) {                                    // every clip's bytes are stored once
        if (c._stored || c._failed) continue;
        try { await S.persist.put('arr:clip:' + c.id, c.file); c._stored = true; }
        catch (e) {
          c._failed = true;
          if (!warned) { warned = true; say('เบราว์เซอร์เก็บคลิป “' + c.name + '” ไว้ไม่ได้ (พื้นที่ไม่พอ) — ถ้ารีเฟรชต้องเพิ่มคลิปนั้นใหม่', 'err'); }
        }
      }
      if (gone.length) await S.persist.del(gone.map(id => 'arr:clip:' + id)).catch(() => {});
      meta.clips = meta.clips.filter(m => { const c = snapshot.find(x => x.id === m.id); return c && c._stored; });   // only clips that can really come back
      savedIds = meta.clips.map(m => m.id);
      await S.persist.put('arrange', meta);
    }).catch(e => console.warn('[arrange] could not save:', e));
    return chain;
  }
  /** Scenes saved earlier belong to the audio clip they were cut for: hand them back once that clip (same name + size) is loaded. */
  function adopt() {
    if (!held) return;
    const f = P.media.file; if (!f) return;
    if (keyOf(f) !== held.mainKey) { held = null; return; }
    const D = dur(); if (!D) return;                                 // metadata not read yet: media:metadata calls this again
    const h = held; held = null;
    if (!h.scenes.length || Math.abs(h.scenes[h.scenes.length - 1].end - D) > 0.5) { renderAll(); return; }
    const hadMain = h.scenes.some(s => s.clipId === MAIN_ID);
    A.scenes = h.scenes.map(s => ({ id: s.id, start: s.start, end: s.end, clipId: (A.clips.some(c => c.id === s.clipId) || (hadMain && s.clipId === MAIN_ID)) ? s.clipId : null, offset: s.offset || 0, fit: s.fit || null, fx: s.fx || null, sfx: s.sfx || null, sfxManual: !!s.sfxManual }));
    A.sel = Math.min(A.scenes.length - 1, h.sel == null ? 0 : h.sel);
    A.on = !!h.on; applyOn(); renderAll();
    if (hadMain) ensureMainClip().then(c => { if (!c) A.scenes.forEach(s => { if (s.clipId === MAIN_ID) s.clipId = null; }); renderAll(); });
    say('กู้คืนฉากที่จัดไว้แล้ว (' + A.scenes.length + ' ฉาก · ' + A.clips.length + ' คลิป)', 'ok');
  }
  async function restore() {
    try {
      const meta = S.persist && await S.persist.get('arrange');
      if (meta && meta.v === 1) {
        SETTINGS.forEach(k => { if (meta[k] != null) A[k] = meta[k]; });
        if (!ASPECT[A.aspect]) A.aspect = '9:16';
        A.refOpts = Object.assign({ mode: 'real', snap: false, fx: true, sfx: true, text: true, withText: true }, A.refOpts || {});
        A.ref = meta.ref && meta.ref.v === 1 ? meta.ref : null;
        let missing = 0;
        for (const m of meta.clips || []) {
          let blob; try { blob = await S.persist.get('arr:clip:' + m.id); } catch (e) {}
          if (!blob) { missing++; continue; }
          const file = new File([blob], m.name, { type: m.type || blob.type, lastModified: m.lastModified });
          A.clips.push({ id: m.id, name: m.name, file: file, url: URL.createObjectURL(file), el: null, duration: m.duration, w: m.w, h: m.h, thumb: m.thumb || '', sig: m.sig || sigOf(file), cuts: Array.isArray(m.cuts) ? m.cuts : [], ai: m.ai || null, aiKey: m.aiKey || '', names: Array.isArray(m.names) ? m.names : [], still: !!m.still, _stored: true });
          seq = Math.max(seq, parseInt(String(m.id).replace(/\D/g, ''), 10) || 0);
        }
        (meta.scenes || []).forEach(s => { seq = Math.max(seq, parseInt(String(s.id).replace(/\D/g, ''), 10) || 0); });
        savedIds = A.clips.map(c => c.id);
        held = { mainKey: meta.mainKey || '', scenes: meta.scenes || [], sel: meta.sel, on: meta.on };
        if (missing) say(missing + ' คลิปที่เคยเพิ่มไว้กู้คืนไม่ได้ (เบราว์เซอร์ไม่ได้เก็บไว้) — เพิ่มใหม่ได้', 'err');
      }
    } catch (e) { console.warn('[arrange] could not restore:', e); }
    loaded = true;
    adopt(); renderAll();
  }

  /* ------------------------------------------------------------ panel */
  const say = (msg, kind) => { const el = $('arrStatus'); if (el) { el.textContent = msg || ''; el.className = 'status' + (kind ? ' ' + kind : ''); } };
  function clipLabel(c) { return c ? (c.still ? '🖼 ' : '') + c.name : '— ไม่มีคลิป —'; }
  function renderClips() {
    const box = $('arrClips'), n = A.clips.length;
    $('arrClearClips').style.display = n ? '' : 'none';
    $('arrCount').textContent = n ? n + '/' + MAX_CLIPS + ' คลิป' : '';
    $('arrAddClips').disabled = n >= MAX_CLIPS;
    // CapCut-style strip: one tile per clip (thumbnail + length), then a "+" tile at the end — up to MAX_CLIPS clips, whatever their length
    box.innerHTML = A.clips.map((c, i) =>
      '<div class="arr-clip" data-id="' + c.id + '" title="' + esc((c.still ? '[รูปนิ่ง] ' : '') + c.name + (c.names && c.names.length ? ' · ' + c.names.join(', ') : '') + (c.ai ? ' — ' + c.ai.summary + (c.ai.subjects.length ? ' [' + c.ai.subjects.join(', ') + ']' : '') : '')) + '">' + (c.thumb ? '<img src="' + c.thumb + '" alt="">' : '<i></i>') +
      '<span class="arr-cd">' + (c.still ? '🖼 รูป' : ft(c.duration)) + '</span><span class="arr-ci">' + (i + 1) + '</span>' +
      '<button type="button" class="arr-nm' + (c.names && c.names.length ? ' on' : '') + '" data-act="nm" title="' + esc(c.names && c.names.length ? 'ชื่อที่ตั้งไว้: ' + c.names.join(', ') : 'ตั้งชื่อตัวละคร / สิ่งที่อยู่ในคลิปนี้ให้ AI') + '">✎</button>' +
      '<button type="button" class="arr-x" data-act="rm" title="เอาคลิปออก">✕</button></div>').join('') +
      (n >= MAX_CLIPS ? '' : '<button type="button" class="arr-add" data-act="add" title="เพิ่มคลิป (เลือกได้หลายคลิป สูงสุด ' + MAX_CLIPS + ' คลิป)"><b>+</b><span>' + (n ? 'เพิ่มอีก' : 'เพิ่มคลิป') + '</span></button>');
  }
  function curScene() { const s = sceneAt(video.currentTime || 0); return s ? A.scenes.indexOf(s) : -1; }
  function renderStrip() {
    const el = $('arrStrip'), D = dur();
    if (!A.scenes.length || !D) { el.innerHTML = ''; el.style.display = 'none'; return; }
    el.style.display = '';
    const cur = curScene();
    el.innerHTML = A.scenes.map((s, i) =>
      '<div class="arr-seg' + (i === A.sel ? ' sel' : '') + (i === cur ? ' cur' : '') + '" data-i="' + i + '" style="left:' + (s.start / D * 100) + '%;width:' + ((s.end - s.start) / D * 100) + '%;background:' + COLORS[i % COLORS.length] + (clipOf(s) ? '' : ';opacity:.45') + '"><b>' + (i + 1) + '</b></div>').join('') +
      A.scenes.slice(0, -1).map((s, i) => '<div class="arr-cut" data-cut="' + i + '" style="left:' + (s.end / D * 100) + '%"></div>').join('') +
      '<div class="arr-ph" id="arrPh"></div>';
    placeHead();
  }
  function placeHead() { const ph = $('arrPh'), D = dur(); if (ph && D) ph.style.left = ((video.currentTime || 0) / D * 100) + '%'; }
  const opt = (map, cur) => Object.keys(map).map(k => '<option value="' + k + '"' + (k === cur ? ' selected' : '') + '>' + map[k] + '</option>').join('');
  function fxBadge(s) {
    const F = S.arrangeFx, b = [], pk = F.packOf(s);
    if (pk) return pk === 'none' ? '' : '✦' + F.packByKey(pk).label + ' · ';
    if (s.fx && s.fx.tr && s.fx.tr !== 'cut') b.push(F.TR[s.fx.tr]);
    if (s.fx && s.fx.motion && s.fx.motion !== 'none') b.push(F.MOTION[s.fx.motion].replace(/ \(.*\)/, ''));
    if (s.sfx) b.push('♪' + F.SFX[s.sfx].replace(/ \(.*\)/, ''));
    return b.length ? b.join(' · ') + ' · ' : '';
  }
  function fxRows(s) {
    const F = S.arrangeFx, fx = s.fx || {}, mo = fx.motion || 'none', cur = F.packOf(s);
    return '<div class="arr-r arr-pk"><label>เอฟเฟกต์</label><div class="arr-packs">' +
        F.PACKS.map(p => '<div class="chip' + (p.key === cur ? ' active' : '') + '" data-act="pack" data-v="' + p.key + '">' + esc(p.label) + '</div>').join('') +
        (cur ? '' : '<div class="chip active" title="ตั้งค่าเองด้านล่าง">กำหนดเอง</div>') + '</div></div>' +
      '<div class="arr-r"><label>เข้าฉาก</label><select data-act="tr">' + opt(F.TR, fx.tr || 'cut') + '</select></div>' +
      '<div class="arr-r"><label>เคลื่อนไหว</label><select data-act="motion">' + opt(F.MOTION, mo) + '</select>' +
        '<input type="range" data-act="amt" min="0.04" max="0.4" step="0.01" value="' + (fx.amt == null ? 0.12 : fx.amt) + '"' + (mo === 'none' || mo === 'shake' ? ' disabled' : '') + ' title="ความแรง"></div>' +
      '<div class="arr-r"><label>เสียง</label><select data-act="sfx"><option value="">ไม่มี</option>' + opt(F.SFX, s.sfx || '') + '</select>' +
        '<button type="button" class="tx-tbtn" data-act="sfxplay"' + (s.sfx ? '' : ' disabled') + '>▶ ฟัง</button></div>';
  }
  function renderScenes() {
    const box = $('arrScenes'), D = dur();
    if (!A.scenes.length) { box.innerHTML = '<div class="hint">ยังไม่มีฉาก กด “แบ่งฉากอัตโนมัติ”</div>'; return; }
    const empty = A.scenes.filter(s => !clipOf(s)).length;
    box.innerHTML = (empty && A.clips.length ? '<div class="arr-warn">' + empty + ' ฉากยังไม่มีคลิป <button type="button" class="tx-tbtn" data-act="fill">เติมให้ฉากที่ว่าง</button></div>' : '') +
      A.scenes.map((s, i) => {
        const c = clipOf(s), sel = i === A.sel, d = s.end - s.start;
        let h = '<div class="arr-scene' + (sel ? ' sel' : '') + '" data-i="' + i + '"><div class="arr-sh" data-act="pick"><b style="color:' + COLORS[i % COLORS.length] + '">' + (i + 1) + '</b>' +
          (c && c.thumb ? '<img src="' + c.thumb + '" alt="">' : '<i></i>') +
          '<span class="arr-st">' + ft(s.start) + ' – ' + ft(s.end) + ' · ' + d.toFixed(1) + ' วิ</span><span class="arr-sn">' + esc(fxBadge(s)) + esc(clipLabel(c)) + (s.note ? ' · ' + esc(s.note) : '') + '</span></div>';
        if (sel) {
          const maxOff = c && !c.still ? Math.max(0, c.duration - Math.min(d, c.duration)) : 0, fit = s.fit || '';
          h += '<div class="arr-sb">' +
            '<div class="arr-r"><label>คลิป</label><select data-act="clip"><option value="">— ไม่มีคลิป —</option>' + A.clips.map(k => '<option value="' + k.id + '"' + (k.id === s.clipId ? ' selected' : '') + '>' + esc(k.name) + '</option>').join('') + '</select></div>' +
            (c && c.still ? '<div class="arr-r"><label>รูปนิ่ง</label><span class="hint" style="margin:0">ค้างรูปเดียวตลอดฉาก' + (A.stillZoom === false ? '' : ' · ซูมเข้าช้า ๆ') + '</span></div>' : '<div class="arr-r"><label>เริ่มที่</label><input type="range" data-act="off" min="0" max="' + maxOff.toFixed(2) + '" step="0.1" value="' + Math.min(maxOff, s.offset || 0).toFixed(2) + '"' + (c ? '' : ' disabled') + '><span class="num">' + (s.offset || 0).toFixed(1) + 's</span></div>') +
            '<div class="arr-r"><label>ภาพ</label><div class="chip-row">' + [['', 'ตามค่ารวม'], ['cover', 'เต็มกรอบ'], ['contain', 'พอดี'], ['blur', 'พอดี+เบลอ']].map(f => '<div class="chip' + (fit === f[0] ? ' active' : '') + '" data-act="fit" data-v="' + f[0] + '">' + f[1] + '</div>').join('') + '</div></div>' +
            '<div class="arr-r"><label>ขอบฉาก</label><div class="chip-row">' +
              (i > 0 ? '<button type="button" class="tx-tbtn" data-act="nudge" data-d="-0.1" data-e="0">◂ เริ่มเร็วขึ้น</button><button type="button" class="tx-tbtn" data-act="nudge" data-d="0.1" data-e="0">เริ่มช้าลง ▸</button>' : '') +
              (i < A.scenes.length - 1 ? '<button type="button" class="tx-tbtn" data-act="nudge" data-d="-0.1" data-e="1">◂ จบเร็วขึ้น</button><button type="button" class="tx-tbtn" data-act="nudge" data-d="0.1" data-e="1">จบช้าลง ▸</button>' : '') + '</div></div>' +
            fxRows(s) +
            '<div class="arr-r chip-row">' + (c && c.still ? '' : '<button type="button" class="tx-tbtn" data-act="pickPart">🎞 เลือกส่วนของวิดีโอ</button>') + '<button type="button" class="tx-tbtn" data-act="replace">แทนที่ด้วยวิดีโอ / รูป</button>' +
              (c && A.scenes.filter(x => x.clipId === c.id).length > 1 ? '<button type="button" class="tx-tbtn" data-act="replaceAll">แทนที่ทุกฉากที่ใช้คลิปนี้</button>' : '') +
              '<button type="button" class="tx-tbtn" data-act="split" title="ตัดฉากนี้ที่ตำแหน่งที่กำลังเล่น">✂ ตัดที่ตำแหน่งเล่น</button>' +
              (i < A.scenes.length - 1 ? '<button type="button" class="tx-tbtn" data-act="merge">รวมกับฉากถัดไป</button>' : '') +
              '<button type="button" class="tx-tbtn" data-act="play">▶ เล่นฉากนี้</button>' +
              '<button type="button" class="tx-tbtn" data-act="exportScene" title="ส่งออกเฉพาะฉากนี้เป็นไฟล์วิดีโอ">⬇ ส่งออกฉากนี้</button></div></div>';
        }
        return h + '</div>';
      }).join('');
    // an expanded scene is scrolled into view when it was picked from the strip
  }
  function renderAll() { renderClips(); renderStrip(); renderScenes(); syncControls(); bus.emit('arrange:changed'); scheduleSave(); }
  function syncControls() {
    $('arrOn').checked = !!A.on;
    document.querySelectorAll('[data-arr-aspect]').forEach(c => c.classList.toggle('active', c.dataset.arrAspect === A.aspect));
    document.querySelectorAll('[data-arr-mode]').forEach(c => c.classList.toggle('active', c.dataset.arrMode === A.mode));
    document.querySelectorAll('[data-arr-order]').forEach(c => c.classList.toggle('active', c.dataset.arrOrder === A.order));
    document.querySelectorAll('[data-arr-fit]').forEach(c => c.classList.toggle('active', c.dataset.arrFit === A.fit));
    $('arrSilRow').style.display = A.mode === 'silence' ? '' : 'none';
    $('arrFixRow').style.display = A.mode === 'fixed' ? '' : 'none';
    $('arrAutoSfx').checked = !!A.autoSfx; $('arrFxOn').checked = !!A.fxOn; $('arrSfxOn').checked = !!A.sfxOn; $('arrSfxVol').value = A.sfxVol; $('arrSfxVolN').textContent = Math.round(A.sfxVol * 100) + '%';
    document.querySelectorAll('[data-arr-refmode]').forEach(c => c.classList.toggle('active', c.dataset.arrRefmode === A.refOpts.mode));
    document.querySelectorAll('[data-arr-refuse]').forEach(c => c.classList.toggle('active', !!A.refOpts[c.dataset.arrRefuse]));
    $('arrRefSnap').classList.toggle('active', !!A.refOpts.snap); $('arrRefText').classList.toggle('active', !!A.refOpts.withText);
    $('arrRefApply').disabled = !A.ref || !dur();
    $('arrMinN').textContent = (+A.minLen).toFixed(1) + ' วิ'; $('arrMaxN').textContent = (+A.maxLen).toFixed(0) + ' วิ';
    $('arrSilN').textContent = (+A.silMin).toFixed(2) + ' วิ'; $('arrFixN').textContent = (+A.fixedLen).toFixed(1) + ' วิ';
  }
  function setOn(on) {
    if (on && !dur()) { say('วางคลิปหรือไฟล์เสียงก่อน', 'err'); $('arrOn').checked = false; return; }
    A.on = !!on; applyOn();
    if (A.on && !A.scenes.length) plan();
    renderAll();
  }
  let planning = false;
  async function plan() {
    if (planning) return;
    const D = dur(); if (!D) { say('วางคลิปหรือไฟล์เสียงก่อน', 'err'); return; }
    pushUndo();
    planning = true; $('arrPlan').disabled = true;
    try {
      let cands = [], used = A.mode;
      if (A.mode === 'cue') {
        cands = cueCandidates();
        if (!cands.length) { used = 'silence'; say('ยังไม่มีซับหลายประโยค ใช้จังหวะเสียงแบ่งแทน...'); }
      }
      if (used === 'silence') {
        say('กำลังฟังเสียงเพื่อหาช่วงหยุดพูด... 0%');
        const env = await loudness(P.media.file, p => say('กำลังฟังเสียงเพื่อหาช่วงหยุดพูด... ' + Math.round(p * 100) + '%'));
        cands = pauseCandidates(env, A.silMin);
      } else if (used === 'fixed') {
        for (let t = A.fixedLen; t < D; t += A.fixedLen) cands.push(t);
      }
      const bounds = used === 'fixed' ? planBounds(cands, D, Math.min(A.minLen, A.fixedLen), A.fixedLen + 0.5) : planBounds(cands, D, A.minLen, A.maxLen);
      setScenes(bounds);
      let got = autoAssign(false), onMain = false;
      if (!A.clips.length) { got = await assignMain(); onMain = got > 0; }
      syncCuts();
      say('แบ่งได้ ' + A.scenes.length + ' ฉาก' + (used !== A.mode ? ' (ตามจังหวะเสียง)' : '') + (onMain ? ' · ใช้ภาพจากวิดีโอหลัก ' + got + ' ฉาก (เพิ่มคลิปภาพเพื่อสลับภาพได้)' : A.clips.length ? ' · จัดคลิปลงให้แล้ว ' + got + ' ฉาก' : ' · เพิ่มคลิปภาพแล้วกด “จัดคลิปลงฉาก”'), 'ok');
    } catch (e) {
      say('แบ่งฉากไม่สำเร็จ: ' + (e && e.message || e), 'err');
    } finally { planning = false; $('arrPlan').disabled = false; }
    renderAll();
  }

  /* ------------------------------------------------------------ reference video: analyse once, then cut / effect / sound / text like it */
  const refSay = (msg, kind) => { const el = $('arrRefInfo'); if (el) { el.textContent = msg || ''; el.className = 'status' + (kind ? ' ' + kind : ''); } };
  const count = (list, key) => list.reduce((m, x) => { m[x[key]] = (m[x[key]] || 0) + 1; return m; }, {});
  const joinCount = (m, names) => Object.keys(m).filter(k => k !== 'none').map(k => (names[k] || k) + ' ' + m[k]).join(' · ');
  function refSummary(r) {
    const F = S.arrangeFx, n = r.shots.length, avg = r.duration / Math.max(1, n);
    const trs = joinCount(count(r.cuts, 'tr'), F.TR), mo = joinCount(count(r.shots, 'motion'), F.MOTION), sf = joinCount(count(r.sfx, 'type'), F.SFX);
    return '“' + r.name + '” · ' + r.duration.toFixed(1) + ' วิ · ' + n + ' ช็อต (ตัด ' + r.cuts.length + ' จุด · เฉลี่ย ' + avg.toFixed(1) + ' วิ/ช็อต)' +
      (trs ? '\nเข้าฉาก: ' + trs : '') + (mo ? '\nเคลื่อนไหว: ' + mo : '\nเคลื่อนไหว: ไม่พบการซูม') +
      '\nเสียงเอฟเฟกต์: ' + (sf || (r.hasAudio ? 'ไม่พบ' : 'ไม่มีเสียงที่อ่านได้')) +
      '\nข้อความ: ' + (r.text ? 'วัดสไตล์ได้แล้ว' : (r.textNote ? 'วัดไม่ได้ (' + r.textNote + ')' : 'ไม่ได้วิเคราะห์'));
  }
  async function analyzeRef(file) {
    refSay('กำลังวิเคราะห์ต้นแบบ...'); $('arrRefPick').disabled = true;
    try {
      const r = await S.ref.analyzeVideoFile(file, { onProgress: (p, m) => refSay(m + ' ' + Math.round(p * 100) + '%') });
      if (A.refOpts.withText && S.ui.styleCopy && S.ui.styleCopy.buildFromVideo) {
        try {
          const b = await S.ui.styleCopy.buildFromVideo(file, m => refSay('วัดสไตล์ข้อความ: ' + m));
          if (b.ok) r.text = { pr: b.pr, p: b.p, note: b.note }; else r.textNote = b.reason;
        } catch (e) { r.textNote = e.message; }
      }
      A.ref = r; refSay(refSummary(r), 'ok'); scheduleSave();
    } catch (e) { refSay('วิเคราะห์ต้นแบบไม่สำเร็จ: ' + (e && e.message || e), 'err'); }
    finally { $('arrRefPick').disabled = false; syncControls(); }
  }
  /** Boundaries [0 .. D] that copy the reference's shot lengths, + which shot each scene copies. */
  function refPlan(r, D, mode) {
    const shots = r.shots, m = shots.length, bounds = [0], idx = [];
    if (mode === 'fit') {
      const k = D / Math.max(0.1, r.duration);
      shots.forEach((s, i) => { bounds.push(i === m - 1 ? D : Math.min(D, +(s.end * k).toFixed(3))); idx.push(i); });
    } else {
      let t = 0;
      for (let i = 0; t < D - 0.05 && i < 5000; i++) {
        const s = shots[i % m]; t += Math.max(0.25, s.end - s.start);
        if (D - t < 0.25) t = D;
        bounds.push(+Math.min(t, D).toFixed(3)); idx.push(i % m);
      }
    }
    bounds[bounds.length - 1] = D;
    if (bounds.length > 2 && D - bounds[bounds.length - 2] < 0.5) { bounds.splice(bounds.length - 2, 1); idx.pop(); }      // a sliver at the end joins the scene before it
    for (let i = bounds.length - 2; i > 0; i--) if (bounds[i + 1] - bounds[i] < MIN_SCENE) { bounds.splice(i, 1); idx.splice(i, 1); }       // drop slivers
    return { bounds: bounds, idx: idx };
  }
  /** Pull each inner cut to the nearest natural pause / sentence edge within `tol` seconds. */
  async function snapBounds(bounds, tol) {
    let cands = cueCandidates();
    try { cands = cands.concat(pauseCandidates(await loudness(P.media.file), A.silMin)); } catch (e) { /* cues only */ }
    cands.sort((a, b) => a - b);
    for (let i = 1; i < bounds.length - 1; i++) {
      let best = null, bd = tol;
      cands.forEach(c => { const d = Math.abs(c - bounds[i]); if (d < bd && c > bounds[i - 1] + MIN_SCENE && c < bounds[i + 1] - MIN_SCENE) { bd = d; best = c; } });
      if (best != null) bounds[i] = +best.toFixed(3);
    }
    return bounds;
  }
  async function applyRef() {
    const r = A.ref, D = dur(), o = A.refOpts;
    if (!r || !D) return;
    pushUndo();
    $('arrRefApply').disabled = true;
    try {
      if (!A.on) { A.on = true; applyOn(); }
      refSay('กำลังตัดตามต้นแบบ...');
      const pl = refPlan(r, D, o.mode);
      if (o.snap) { refSay('กำลังเกาะจังหวะเสียงพูด...'); pl.bounds = await snapBounds(pl.bounds, 0.35); }
      setScenes(pl.bounds);
      A.scenes.forEach((s, i) => {
        const k = pl.idx[i], shot = r.shots[k], cut = k > 0 ? r.cuts[k - 1] : null, first = i === 0;
        if (o.fx) {
          const tr = first || !cut ? 'cut' : cut.tr;
          s.fx = { tr: tr, trDur: tr === 'cut' ? 0.25 : Math.min(0.8, Math.max(0.12, cut.dur || 0.25)), motion: shot.motion || 'none', amt: shot.amt || 0.12 };
        }
        if (o.sfx && cut && !first) { const h = r.sfx.find(x => Math.abs(x.t - cut.t) < 0.06); if (h) s.sfx = h.type; }
      });
      let got = A.clips.length ? autoAssign(false) : 0, onMain = false;
      if (!A.clips.length) { got = await assignMain(); onMain = got > 0; }          // no pool: the loaded video is the picture (it used to be a black screen)
      syncCuts();
      if (o.fx) A.fxOn = true;
      if (o.sfx) A.sfxOn = true;
      let textNote = '';
      if (o.text) {
        if (r.text && S.ui.styleCopy) { try { S.ui.styleCopy.applyBuilt({ pr: r.text.pr, p: Object.assign({}, r.text.p), note: r.text.note }); textNote = ' · ใส่สไตล์ข้อความแล้ว'; } catch (e) { textNote = ' · ใส่สไตล์ข้อความไม่สำเร็จ: ' + e.message; } }
        else textNote = ' · ต้นแบบนี้ไม่มีสไตล์ข้อความที่วัดได้';
      }
      const nfx = A.scenes.filter(s => s.fx && (s.fx.tr !== 'cut' || s.fx.motion !== 'none')).length, nsf = A.scenes.filter(s => s.sfx).length;
      refSay('ตัดตามต้นแบบแล้ว ' + A.scenes.length + ' ฉาก' + (o.fx ? ' · เอฟเฟกต์ภาพ ' + nfx + ' ฉาก' : '') + (o.sfx ? ' · เสียงเอฟเฟกต์ ' + nsf + ' จุด' : '') + textNote +
        (onMain ? ' · ใช้ภาพจากวิดีโอหลัก ' + got + ' ฉาก (เพิ่มคลิปภาพเพื่อสลับภาพได้)' : A.clips.length ? ' · จัดคลิปลงแล้ว ' + got + ' ฉาก' : ' · เพิ่มคลิปภาพแล้วกด “จัดคลิปลงฉาก”'), 'ok');
    } catch (e) { refSay('ใช้ต้นแบบไม่สำเร็จ: ' + (e && e.message || e), 'err'); }
    finally { renderAll(); }
  }

  /** One pack on every scene, or a random pack per scene (never the same twice in a row). The first scene has no cut in front of it: look only. */
  function packAll(which) {
    if (!A.scenes.length) { say('แบ่งฉากก่อน', 'err'); return; }
    const F = S.arrangeFx, pool = F.PACKS.filter(p => p.key !== 'none');
    let last = null;
    A.scenes.forEach((s, i) => {
      let key = which;
      if (which === 'random') { do { key = pool[Math.floor(Math.random() * pool.length)].key; } while (key === last && pool.length > 1); last = key; }
      F.applyPack(s, key);
      if (i === 0) { s.fx.tr = 'cut'; s.sfx = null; }
    });
    A.fxOn = true; A.sfxOn = true;
    say((which === 'random' ? 'สุ่มเอฟเฟกต์' : 'ใส่ “' + F.packByKey(which).label + '”') + ' ให้ ' + A.scenes.length + ' ฉากแล้ว', 'ok');
    renderAll();
  }
  function seekTo(t) { S.ui.player.seek(Math.max(0, Math.min(dur(), t))); }
  function replaceWith(file, scope) {
    const i = scope.i, s0 = A.scenes[i]; if (!s0) return;
    const oldId = s0.clipId;
    addClipFile(file).then(c => {
      A.scenes.forEach((s, k) => { if (k === i || (scope.all && oldId && s.clipId === oldId)) { s.clipId = c.id; s.offset = 0; } });
      say('แทนที่ด้วย “' + c.name + '” แล้ว', 'ok'); renderAll();
    }).catch(e => say(e.message, 'err'));
  }

  function init() {
    buildCanvas();
    const panel = $('arrPanel');
    $('arrOn').addEventListener('input', e => setOn(e.target.checked));
    panel.addEventListener('click', e => {
      const chip = e.target.closest('.chip');
      if (chip && chip.dataset.arrAspect) { A.aspect = chip.dataset.arrAspect; lastKey = ''; applyOn(); syncControls(); bus.emit('arrange:changed'); return; }
      if (chip && chip.dataset.arrMode) { A.mode = chip.dataset.arrMode; syncControls(); scheduleSave(); return; }
      if (chip && chip.dataset.arrOrder) { A.order = chip.dataset.arrOrder; syncControls(); scheduleSave(); return; }
      if (chip && chip.dataset.arrFit) { A.fit = chip.dataset.arrFit; renderAll(); return; }
    });
    let adding = false;
    async function addMany(list, opts) {
      const files = list.filter(f => f && (isVideoFile(f) || isStillFile(f)));
      if (!files.length) { if (list.length) say('เลือกได้เฉพาะไฟล์วิดีโอหรือรูปภาพ (JPG / PNG / WebP)', 'err'); return; }
      if (adding) { say('กำลังอ่านคลิปชุดก่อนหน้าอยู่ รอสักครู่', 'err'); return; }
      if (A.clips.length >= MAX_CLIPS) { say('มีคลิปครบ ' + MAX_CLIPS + ' คลิปแล้ว — เอาคลิปออกก่อนจึงจะเพิ่มได้', 'err'); return; }
      adding = true; $('arrAddClips').disabled = true; $('arrClips').classList.add('busy');
      let ok = 0, dup = 0, over = 0, laid = false, placed = 0; const bad = [], added = [];
      try {
        for (let i = 0; i < files.length; i++) {
          const f = files[i];
          if (A.clips.some(c => c.sig === sigOf(f))) { dup++; continue; }           // the same file picked twice
          if (A.clips.length >= MAX_CLIPS) { over = files.length - i; break; }        // the pool is full: the rest of this pick is left out
          say('กำลังอ่าน' + (isStillFile(f) && !isVideoFile(f) ? 'รูป ' : 'คลิป ') + (i + 1) + '/' + files.length + ' · ' + f.name);
          try { added.push(await addClipFile(f)); ok++; } catch (err) { bad.push(err.message); }
          renderClips();                                                             // each clip shows up as it is read
        }
        if (ok) {
          const mc = mainClip(); if (mc && added.length) dropClip(mc.id);               // real clips arrived: they take the scenes the loaded video was standing in for
          if (!A.on) { A.on = true; applyOn(); }                                    // the added video is now what the preview and the export show
          if (!A.scenes.length) { layClips(!!(opts && opts.even)); syncCuts(); laid = true; }            // nothing cut yet: the clips ARE the main video, back to back
          else if (autoAssign(true) === 0 && added.length) {                        // every scene already has a clip: the new video takes the scene at the playhead
            const s = sceneAt(video.currentTime || 0), at = s ? A.scenes.indexOf(s) : -1;   // the new videos take the scene at the playhead and the ones after it, one each
            if (at >= 0) {
              pushUndo();
              for (let k = 0; k < added.length && at + k < A.scenes.length; k++) { const t = A.scenes[at + k]; t.clipId = added[k].id; t.offset = 0; placed++; }
              A.sel = at;
            }
          }
        }
      } finally { adding = false; $('arrAddClips').disabled = false; $('arrClips').classList.remove('busy'); }
      const parts = [];
      if (ok) parts.push('เพิ่มคลิปแล้ว ' + ok + ' ไฟล์ (รวม ' + A.clips.length + ')' + (laid ? ' · วางเป็นวิดีโอหลักแล้ว ' + A.scenes.length + ' ช่วง' : '') + (placed ? ' · ใส่ในฉากที่กำลังเล่นและฉากถัดไปแล้ว ' + placed + ' ฉาก' : ''));
      if (over) parts.push('ครบ ' + MAX_CLIPS + ' คลิปแล้ว ข้ามอีก ' + over + ' ไฟล์');
      if (dup) parts.push('ข้ามไฟล์ซ้ำ ' + dup);
      if (bad.length) parts.push(bad.length > 3 ? bad.slice(0, 3).join(' · ') + ' · และอีก ' + (bad.length - 3) + ' ไฟล์' : bad.join(' · '));
      say(parts.join(' · '), bad.length || over ? 'err' : 'ok');
      if (opts && opts.even && S.ui.toast) S.ui.toast(parts.join(' · '));      // picked on the first screen: the sheet with the status is closed, so say it here too
      renderAll();
    }
    S.arrange.addMany = addMany;
    $('arrClipInput').addEventListener('click', e => { if (A.clips.length >= MAX_CLIPS) { e.preventDefault(); say('มีคลิปครบ ' + MAX_CLIPS + ' คลิปแล้ว — เอาคลิปออกก่อนจึงจะเพิ่มได้', 'err'); } });
    $('arrAddClips').addEventListener('click', () => $('arrClipInput').click());
    $('arrClipInput').addEventListener('change', e => { const files = Array.from(e.target.files || []); e.target.value = ''; addMany(files); });
    $('arrClearClips').addEventListener('click', () => {
      if (!A.clips.length) return;
      if (!confirm('เอาคลิปภาพออกทั้งหมด ' + A.clips.length + ' ไฟล์? ฉากจะกลับเป็นยังไม่มีคลิป')) return;
      A.clips.slice().forEach(c => dropClip(c.id)); say('เอาคลิปออกทั้งหมดแล้ว', 'ok'); renderAll();
    });
    ['dragenter', 'dragover'].forEach(ev => panel.addEventListener(ev, e => { if (e.dataTransfer && Array.from(e.dataTransfer.types || []).includes('Files')) { e.preventDefault(); panel.classList.add('arr-drag'); } }));
    ['dragleave', 'drop'].forEach(ev => panel.addEventListener(ev, e => { if (ev === 'dragleave' && panel.contains(e.relatedTarget)) return; panel.classList.remove('arr-drag'); }));
    panel.addEventListener('drop', e => { if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) { e.preventDefault(); addMany(Array.from(e.dataTransfer.files)); } });
    $('arrClips').addEventListener('click', e => {
      if (e.target.closest('[data-act="add"]')) { $('arrClipInput').click(); return; }
      const nm = e.target.closest('[data-act="nm"]');
      if (nm) {                                                                   // tell the AI what / who is in this clip (it will not guess a real person's name from a face)
        const c = A.clips.find(k => k.id === nm.closest('.arr-clip').dataset.id); if (!c) return;
        const cur = (c.names || []).join(', '), v = prompt('ชื่อตัวละคร / สิ่งที่อยู่ใน“' + c.name + '” (คั่นด้วย , เว้นว่าง = ล้าง)\nAI จะใช้ชื่อนี้จับคู่กับคำพูด', cur);
        if (v == null) return;
        c.names = v.split(/[,，、\n]/).map(x => x.trim()).filter(Boolean).slice(0, 12); scheduleSave(); renderClips(); return;
      }
      const b = e.target.closest('[data-act="rm"]'); if (!b) return;
      dropClip(b.closest('.arr-clip').dataset.id); renderAll();
    });
    [['arrMin', 'minLen'], ['arrMax', 'maxLen'], ['arrSil', 'silMin'], ['arrFix', 'fixedLen']].forEach(p => {
      $(p[0]).addEventListener('input', e => { A[p[1]] = +e.target.value; syncControls(); scheduleSave(); });
    });
    $('arrPlan').addEventListener('click', () => plan());
    // effect packs for the whole timeline
    $('arrPackAll').innerHTML = S.arrangeFx.PACKS.map(p => '<option value="' + p.key + '">' + esc(p.label) + '</option>').join('');
    $('arrPackAll').value = 'flashHit';
    $('arrAutoSfx').addEventListener('input', e => { A.autoSfx = e.target.checked; scheduleSave(); });
    $('arrPackApply').addEventListener('click', () => packAll($('arrPackAll').value));
    $('arrPackRandom').addEventListener('click', () => packAll('random'));
    // effects (global) and the reference video
    $('arrFxOn').addEventListener('input', e => { A.fxOn = e.target.checked; renderAll(); });
    $('arrSfxOn').addEventListener('input', e => { A.sfxOn = e.target.checked; if (!A.sfxOn) S.arrangeFx.player.stop(); renderAll(); });
    $('arrSfxVol').addEventListener('input', e => { A.sfxVol = +e.target.value; $('arrSfxVolN').textContent = Math.round(A.sfxVol * 100) + '%'; scheduleSave(); });
    $('arrRefPick').addEventListener('click', () => $('arrRefInput').click());
    $('arrRefInput').addEventListener('change', e => { const f = e.target.files && e.target.files[0]; e.target.value = ''; if (f) analyzeRef(f); });
    $('arrRefText').addEventListener('click', () => { A.refOpts.withText = !A.refOpts.withText; syncControls(); scheduleSave(); });
    $('arrRefSnap').addEventListener('click', () => { A.refOpts.snap = !A.refOpts.snap; syncControls(); scheduleSave(); });
    document.querySelectorAll('[data-arr-refmode]').forEach(c => c.addEventListener('click', () => { A.refOpts.mode = c.dataset.arrRefmode; syncControls(); scheduleSave(); }));
    document.querySelectorAll('[data-arr-refuse]').forEach(c => c.addEventListener('click', () => { const k = c.dataset.arrRefuse; A.refOpts[k] = !A.refOpts[k]; syncControls(); scheduleSave(); }));
    $('arrRefApply').addEventListener('click', () => applyRef());
    $('arrAssign').addEventListener('click', () => {
      if (!A.clips.length) { say('เพิ่มคลิปภาพก่อน', 'err'); return; }
      if (!A.scenes.length) { say('แบ่งฉากก่อน', 'err'); return; }
      pushUndo(); const n = autoAssign(false); say('จัดคลิปลง ' + n + ' ฉากแล้ว', 'ok'); renderAll();
    });
    $('arrReplaceInput').addEventListener('change', e => {
      const f = e.target.files && e.target.files[0]; e.target.value = '';
      if (f && replaceTarget) replaceWith(f, replaceTarget); replaceTarget = null;
    });
    const sc = $('arrScenes');
    sc.addEventListener('click', e => {
      if (e.target.closest('[data-act="fill"]')) { autoAssign(true); renderAll(); return; }
      const row = e.target.closest('.arr-scene'); if (!row) return;
      const i = +row.dataset.i, s = A.scenes[i], act = (e.target.closest('[data-act]') || {}).dataset;
      if (!s) return;
      if (!act || act.act === 'pick') { A.sel = i; seekTo(s.start + 0.01); renderAll(); return; }
      const a = act.act;
      if (a === 'pack') {
        S.arrangeFx.applyPack(s, act.v); A.fxOn = true; if (s.sfx) A.sfxOn = true;
        if (i === 0 && s.fx) { s.fx.tr = 'cut'; s.sfx = null; }
        renderAll();
        if (i > 0) S.ui.player.replay(Math.max(0, s.start - 0.7), Math.min(dur(), s.start + 1.3));      // hear and see it into the cut
        else S.ui.player.replay(s.start, Math.min(dur(), s.start + 1.5));
      }
      else if (a === 'fit') { s.fit = act.v || null; renderAll(); }
      else if (a === 'nudge') {
        const d = +act.d, cut = act.e === '1' ? i : i - 1;
        moveCut(cut, A.scenes[cut].end + d); syncCuts(); renderAll();
      }
      else if (a === 'replace' || a === 'replaceAll') { replaceTarget = { i: i, all: a === 'replaceAll' }; $('arrReplaceInput').click(); }
      else if (a === 'split') { pushUndo(); const k = splitAt(video.currentTime || 0); say(k < 0 ? 'ตำแหน่งเล่นอยู่ใกล้ขอบฉากเกินไป — เลื่อนไปกลางฉากนี้แล้วลองใหม่' : 'ตัดฉากแล้ว', k < 0 ? 'err' : 'ok'); if (k >= 0) syncCuts(); renderAll(); }
      else if (a === 'merge') { pushUndo(); mergeWithNext(i); syncCuts(); renderAll(); }
      else if (a === 'play') { S.ui.player.replay(s.start, s.end); }
      else if (a === 'exportScene') { exportScene(i); }
      else if (a === 'pickPart') { if (clipOf(s) && clipOf(s).still) say('รูปนิ่งไม่มีส่วนให้เลือก — ค้างรูปเดียวตลอดฉาก', ''); else if (S.ui.clipPicker) S.ui.clipPicker.open(i); }
      else if (a === 'sfxplay' && s.sfx) { S.arrangeFx.player.play(s.sfx, A.sfxVol, 0); }
    });
    sc.addEventListener('input', e => {
      const row = e.target.closest('.arr-scene'); if (!row) return;
      const s = A.scenes[+row.dataset.i]; if (!s) return;
      const act = e.target.dataset.act;
      if (act === 'tr' || act === 'motion' || act === 'amt') {
        s.fx = s.fx || { tr: 'cut', trDur: 0.25, motion: 'none', amt: 0.12 };
        if (act === 'tr') { s.fx.tr = e.target.value; if (s.fx.tr !== 'cut' && !s.fx.trDur) s.fx.trDur = 0.25; }
        else if (act === 'motion') s.fx.motion = e.target.value;
        else s.fx.amt = +e.target.value;
        if (!A.fxOn) A.fxOn = true;
        if (A.autoSfx && !s.sfxManual && act !== 'amt') { s.sfx = S.arrangeFx.suggestSfx(s.fx); if (s.sfx) A.sfxOn = true; }       // the sound that goes with this look
        renderAll(); return;
      }
      if (act === 'sfx') { s.sfx = e.target.value || null; s.sfxManual = true; if (s.sfx) { A.sfxOn = true; S.arrangeFx.player.play(s.sfx, A.sfxVol, 0); } renderAll(); return; }
      if (e.target.dataset.act === 'clip') { s.clipId = e.target.value || null; s.offset = 0; renderAll(); }
      else if (e.target.dataset.act === 'off') { s.offset = +e.target.value; e.target.nextElementSibling.textContent = s.offset.toFixed(1) + 's'; scheduleSave(); }
    });
    // strip: tap a segment = pick + seek; drag a cut to move it
    const strip = $('arrStrip'); let drag = null;
    strip.addEventListener('pointerdown', e => {
      const cut = e.target.closest('.arr-cut');
      if (cut) { drag = { i: +cut.dataset.cut, id: e.pointerId }; strip.setPointerCapture(e.pointerId); e.preventDefault(); }
    });
    strip.addEventListener('pointermove', e => {
      if (!drag || e.pointerId !== drag.id) return;
      const r = strip.getBoundingClientRect(); moveCut(drag.i, (e.clientX - r.left) / r.width * dur()); renderStrip();
    });
    const endDrag = e => { if (drag && e.pointerId === drag.id) { drag = null; renderAll(); } };
    strip.addEventListener('pointerup', endDrag); strip.addEventListener('pointercancel', endDrag);
    strip.addEventListener('click', e => {
      const seg = e.target.closest('.arr-seg'); if (!seg) return;
      const r = strip.getBoundingClientRect(); A.sel = +seg.dataset.i;
      seekTo((e.clientX - r.left) / r.width * dur()); renderAll();
      const row = document.querySelector('.arr-scene.sel'); if (row && row.scrollIntoView) row.scrollIntoView({ block: 'nearest' });
    });

    bus.on('time:changed', () => { placeHead(); const c = curScene(), el = strip.querySelector('.arr-seg.cur'); if (!el || +el.dataset.i !== c) { strip.querySelectorAll('.arr-seg').forEach(x => x.classList.toggle('cur', +x.dataset.i === c)); } });
    bus.on('media:selected', f => {            // a clip was picked: scenes cut for another clip do not apply (the same clip again gets its scenes back)
      if (held && keyOf(f) !== held.mainKey) held = null;
      { const mc = mainClip(); if (mc) dropClip(mc.id); }
      sceneUndo = [];
      A.scenes = []; A.sel = -1; renderAll(); adopt();
    });
    bus.on('media:cleared', () => { { const mc = mainClip(); if (mc) dropClip(mc.id); } held = null; sceneUndo = []; A.scenes = []; A.sel = -1; if (A.on) { A.on = false; applyOn(); } renderAll(); });
    bus.on('media:metadata', () => {
      if (A.scenes.length && Math.abs(A.scenes[A.scenes.length - 1].end - dur()) > 0.05) { A.scenes = []; A.sel = -1; }
      renderAll(); adopt();
    });
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') saveNow(); });
    window.addEventListener('pagehide', saveNow);
    renderAll();
    restore();
  }

  /** A fresh, empty scene (for ui/voice-arrange.js). */
  function newScene(start, end) { return { id: uid('s'), start: +start.toFixed(3), end: +end.toFixed(3), clipId: null, offset: 0, fit: null, fx: null, sfx: null }; }
  /** Replace the whole scene list (callers keep it sorted and tiling the timeline). */
  function putScenes(list, sel) { A.scenes = list; A.sel = list.length ? Math.max(0, Math.min(list.length - 1, sel == null ? 0 : sel)) : -1; }
  S.arrange = {
    newScene: newScene, putScenes: putScenes, save: scheduleSave, settings: () => A,
    active: () => !!A.on,
    ratio: ratio, aspectSize: () => A.on ? ratio() : null,
    ready: () => !!(A.on && A.scenes.length && A.scenes.some(s => clipOf(s))),
    sceneAt: sceneAt, clipOf: clipOf, clipTime: clipTime, fitOf: fitOf, drawFit: drawFit, zoomOf: zoomOf, hiddenVideo: hiddenVideo, hiddenMedia: hiddenMedia, isStillFile: isStillFile, isVideoFile: isVideoFile,
    planBounds: planBounds, pauseCandidates: pauseCandidates, pauseRanges: pauseRanges, loudness: loudness,
    addClipFile: addClipFile, layMerged: layMerged, sigOf: sigOf, clips: () => A.clips, setScenes: setScenes, autoAssign: autoAssign, splitAt: splitAt, mergeWithNext: mergeWithNext, moveCut: moveCut, plan: plan, layClips: layClips, syncCuts: syncCuts, selectScene: selectScene, setSceneLength: setSceneLength, commit: () => { syncCuts(); renderAll(); }, exportScene: exportScene, pushUndo: pushUndo, undoScenes: undoScenes, canUndo: () => sceneUndo.length > 0, removeScene: removeScene, moveScene: moveScene, splitAtPlayhead: splitAtPlayhead, replaceScene: replaceScene, scenes: () => A.scenes, setOn: setOn, renderAll: renderAll, saveNow: saveNow, elOf: elOf
  };
  S.ui.arrange = { init: init };
})(window.SubEd);
