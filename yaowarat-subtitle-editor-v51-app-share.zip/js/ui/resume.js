/* =====================================================================
 * UI: autosave of the clip being edited into "งานที่บันทึกไว้" (SubEd.drafts) — so a refresh, a crash or a browser that kicks the page
 * out never loses the video or the cuts / subtitles / style. Nothing is deleted here: only the user deletes a draft (ui/history-panel.js).
 *
 *   media:selected   a new clip is open -> a new draft (the video is copied to private storage in the background); the same file as an
 *                    unfinished draft whose video could not be kept ("pending") continues THAT draft instead.
 *   any edit         schedules a save ~0.5 s later; leaving the page / switching app flushes it at once.
 *   media:closing    just before the clip is swapped / closed (✕): one last save of the old clip, so nothing from the last 0.5 s is lost.
 *   media:cleared    ✕: autosave stops; the draft STAYS in the list.
 *   open(id)         the user taps a draft on the start screen: the clip is re-opened and the project restored exactly as it was.
 * The editor is NOT re-opened by itself after a refresh any more: the start screen shows the draft that was open ("ค้างไว้ล่าสุด") first.
 * ===================================================================== */
(function (S) {
  'use strict';
  const bus = S.bus, P = S.state.project, video = S.dom.video;
  const SAVE_EVENTS = ['cues:structure', 'cue:timing', 'cue:text', 'cue:style', 'style:changed', 'trim:changed', 'segmentation:changed', 'cut:structure', 'cut:timing', 'motion:structure', 'motion:changed', 'arrange:changed', 'audio:added', 'mainmute:changed'];
  const newId = () => 'd' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

  const sharedLaunch = /[?&]shared=/.test(location.search);      // the app was opened by Share: that clip wins over the last draft
  let ready = false;        // true only once the live project is the one that should be saved (never during a restore)
  let curId = null;         // the draft being edited
  let clipSeq = 0, timer = null, pending = null, note = null;
  let fresh = false;        // the open draft was created in this session (a draft the user re-opens is never auto-removed)
  let hadMeta = false;      // the open clip has really loaded (length known) -> it is worth keeping; a clip that never opened leaves no draft behind

  function saveProject() {
    clearTimeout(timer); timer = null;
    const f = P.media.file;
    if (!ready || !f || !curId) return Promise.resolve();
    if (P.media.duration > 0) hadMeta = true;
    return S.drafts.save(curId, {
      name: f.name, size: f.size, type: f.type, lastModified: f.lastModified, time: video.currentTime || 0, open: true,
      duration: P.media.duration || 0, cues: (P.subtitle && P.subtitle.cues && P.subtitle.cues.length) || 0
    }, S.project.snapshot()).catch(e => console.warn('[drafts] could not save the project:', e));
  }
  function schedule() {
    if (!ready || !P.media.file) return;
    clearTimeout(timer); timer = setTimeout(saveProject, 500);
  }
  function go() { ready = true; saveProject(); }

  /** Keep the video itself with the draft: on private disk storage (pinned, no RAM) or, without OPFS, in IndexedDB. */
  async function storeClip(file, id) {
    const seq = ++clipSeq;
    let st = 'none', opfs = '';
    try {
      if (S.localCopy && S.localCopy.supported()) { opfs = await S.localCopy.stash(file); if (opfs) st = 'opfs'; }
      if (st === 'none') { await S.persist.put('dclip:' + id, file); st = 'idb'; }
    } catch (e) { console.warn('[drafts] the browser would not store the video, keeping subtitles only:', e); }
    if (S.clipHistory) S.clipHistory.ask();
    await S.drafts.patch(id, { store: st, opfs: opfs });
    if (seq === clipSeq && id === curId) saveProject();
  }

  /** Restore the saved project into the live one as soon as the clip's metadata is known (timeline etc. already laid out). */
  function arm(project) {
    P.media.resumeTrim = Object.assign({}, project.trim);          // player.js keeps this trim instead of resetting to the full clip
    const off = bus.on('media:metadata', () => {
      off();
      try {
        S.project.restore(project);
        P.trim.start = Math.max(0, Math.min(P.trim.start, P.media.duration));
        P.trim.end = Math.max(P.trim.start, Math.min(P.trim.end || P.media.duration, P.media.duration));
        if (S.history) S.history.clear();
        if (S.style && S.style.ensureFont) S.style.ensureFont().then(() => bus.emit('style:changed'));
        const t = Math.min(P.trim.end, Math.max(P.trim.start, (arm.time || 0)));
        if (t > 0) S.ui.player.seek(t); else bus.emit('time:changed', video.currentTime);
      } catch (e) { console.error('[resume] could not restore the project:', e); }
      go();
    });
  }

  function showNote(rec) {
    hideNote();
    const drop = S.$('drop');
    note = document.createElement('div');
    note.className = 'drop-note';
    note.textContent = 'ตัวไฟล์วิดีโอของ "' + rec.name + '" ยังไม่ได้ถูกเก็บไว้ในเบราว์เซอร์ (หน้าถูกปิด/รีเฟรชระหว่างเก็บ หรือที่เก็บเต็ม) — เลือกไฟล์เดิมอีกครั้ง แล้วซับ จุดตัด และสไตล์จะกลับมาให้';
    drop.parentNode.insertBefore(note, drop.nextSibling);
  }
  function hideNote() { if (note && note.parentNode) note.parentNode.removeChild(note); note = null; }

  /** The user tapped a saved draft. -> Promise<boolean> (true: the editor is open). */
  async function open(id, auto) {
    if (P.media.file) return false;
    const got = await S.drafts.get(id);
    if (!got || !got.project || got.project.schema !== P.schema) return false;
    let clip = await S.drafts.clipFile(id);
    if (P.media.file) return false;
    if (clip && S.localCopy) {                                      // the stored copy can be gone/damaged on disk: find out now, not in the middle of the AI step
      try { await S.localCopy.probe(clip); }
      catch (e) { console.warn('[resume] the stored video cannot be read, asking for the file again:', e); clip = null; }
    }
    if (!clip) {                                                    // subtitles + cuts are safe; the video must be picked again
      pending = Object.assign({ id: id, project: got.project }, got.rec); showNote(got.rec);
      if (!auto && S.ui.media && S.ui.media.pick) S.ui.media.pick();        // (a refresh cannot open the picker by itself: the start screen shows the note)
      return false;
    }
    hideNote(); pending = null; ++clipSeq;
    curId = id; ready = false; fresh = false;
    arm.time = got.rec.time || 0;
    arm(got.project);
    S.ui.media.open(clip);                                          // no media:selected: that would wipe the subtitles
    S.drafts.patch(id, { open: true });
    if (S.localCopy) S.localCopy.keepOnly(clip);
    return true;
  }

  S.ui.resume = {
    open: open,
    init() {
      SAVE_EVENTS.forEach(e => bus.on(e, schedule));
      video.addEventListener('pause', schedule);
      video.addEventListener('seeked', schedule);
      document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') saveProject(); });
      window.addEventListener('pagehide', saveProject);
      bus.on('media:closing', saveProject);

      bus.on('media:selected', file => {
        const rec = pending; pending = null; hideNote(); hadMeta = false; fresh = false;
        // Fast open (ui/media.js): the safety copy is still being made -> the clip is stored when it is done ('media:relinked'), not now
        const later = !!(S.ui.media && S.ui.media.copying && S.ui.media.copying());
        if (rec && rec.name === file.name && rec.size === file.size) {   // same file as the unfinished draft: continue THAT one
          curId = rec.id; ready = false; arm.time = rec.time || 0; arm(rec.project); if (!later) storeClip(file, curId);
          return;
        }
        curId = newId(); ready = true; fresh = true;                                    // a different clip: a new draft (the old drafts stay in the list)
        const id = curId;
        S.drafts.create({ id: id, name: file.name, size: file.size, type: file.type, lastModified: file.lastModified, time: 0, duration: 0, cues: 0 })
          .then(() => { if (!later) return storeClip(file, id); });
      });
      bus.on('media:relinked', file => { if (curId) storeClip(file, curId); });          // the safety copy is ready (or a re-picked file): this is what the draft keeps
      bus.on('media:cleared', () => {
        const id = curId;
        ready = false; ++clipSeq; pending = null; hideNote(); curId = null;
        clearTimeout(timer); timer = null;
        if (id && fresh && !hadMeta) S.drafts.remove(id);                         // the clip never opened (unreadable / closed at once): no empty draft
        else if (id) S.drafts.patch(id, { open: false });                // closed on purpose: it is no longer "the one that was open when the page died"
        if (S.localCopy) S.localCopy.keepOnly(null);
      });
      // REFRESH / crash: go straight back into the clip that was open (picture, cuts, subtitles, style, playhead) — no tapping through the start screen
      (async () => {
        try {
          if (S.localCopy) await S.localCopy.pinsReady;
          const last = (await S.drafts.list()).filter(r => r.open && r.store !== 'none')[0];     // newest first
          if (last && !P.media.file && !sharedLaunch) await open(last.id, true);
        } catch (e) { console.warn('[resume] could not reopen the last clip:', e); }
      })();
      // a backup every 20 s while editing, for changes that fire no save event
      let lastSig = '';
      setInterval(() => {
        if (!ready || !P.media.file || document.visibilityState !== 'visible') return;
        let sig = ''; try { sig = JSON.stringify(S.project.snapshot()); } catch (e) { return; }
        if (sig !== lastSig) { lastSig = sig; saveProject(); }          // only when something really changed (the "last edited" time stays true)
      }, 20000);
      // private copies nobody uses any more (not pinned by a draft) are deleted once the pins are known
      if (S.localCopy) S.localCopy.keepOnly(null);
    }
  };
})(window.SubEd);
