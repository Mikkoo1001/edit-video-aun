/* =====================================================================
 * UI: sliding highlight for single-choice chip groups (ตำแหน่ง, เอฟเฟค, ไฮไลต์คำ, ความละเอียด, fps, ขอบเขตสไตล์, แบบสี).
 * The yellow "selected" pill glides from the old chip to the new one instead of jumping.
 * Pure observer: it watches the .active class the other panels already toggle, so no panel code needs to know about it.
 * ===================================================================== */
(function () {
  'use strict';
  const SEL = '.chip[data-pos],.chip[data-fx],.chip[data-km],.chip[data-res],.chip[data-fps],.chip[data-scope],.chip[data-scmode]';
  const groups = new Set();
  document.querySelectorAll(SEL).forEach(c => groups.add(c.parentElement));

  groups.forEach(grp => {
    const ind = document.createElement('i');
    ind.className = 'chip-ind'; grp.classList.add('chip-grp'); grp.insertBefore(ind, grp.firstChild);
    let placed = false;
    function place() {
      const on = grp.querySelector('.chip.active');
      if (!on || !on.offsetWidth) { ind.style.opacity = '0'; return; }   // nothing chosen yet, or the pane is hidden (observer calls again when shown)
      if (!placed) ind.style.transition = 'none';                        // first placement: jump into place
      ind.style.opacity = '1';
      ind.style.width = on.offsetWidth + 'px'; ind.style.height = on.offsetHeight + 'px';
      ind.style.transform = 'translate(' + on.offsetLeft + 'px,' + on.offsetTop + 'px)';
      if (!placed) { void ind.offsetWidth; ind.style.transition = ''; placed = true; }
    }
    new MutationObserver(place).observe(grp, { subtree: true, attributes: true, attributeFilter: ['class'] });
    if (window.ResizeObserver) new ResizeObserver(place).observe(grp);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(place);
    window.addEventListener('resize', place);
    place();
  });
})();
