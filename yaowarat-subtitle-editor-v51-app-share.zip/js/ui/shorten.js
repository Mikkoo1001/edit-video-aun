/* =====================================================================
 * "ย่อวิดีโอ" — shorten the video by its sound, then match each scene's picture to what the narration says.
 *
 *   1. Listen: quiet stretches of the narration (arrange.js loudness / pauseRanges) longer than MIN_PAUSE are cut out of the main
 *      video track, leaving PAD seconds of air on each side so words are never clipped. The cuts are ordinary "ตัดวิดีโอ" pieces
 *      (deleted, skipped by preview + export, restorable) — scenes stay in SOURCE time, so nothing else has to be re-timed.
 *   2. Match (optional, needs a Gemini key + subtitle lines): for each scene the spoken text and a few frames of every pool clip go to
 *      Gemini, which names the clip that illustrates it best. No key / no subtitles / a failed call -> clips are laid in order as before.
 * Reads: SubEd.state.project (arrange, cut, subtitle), SubEd.arrange, SubEd.videoCut.   Pure helper for tests: SubEd.shorten.deleteRanges.
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, P = S.state.project, A = P.arrange;
  const MIN_PAUSE = 0.5, PAD = 0.2, MIN_CUT = 0.12;
  let busy = false, useAi = true;
  const say = (m, kind) => { const el = $('arrShInfo'); if (el) { el.textContent = m || ''; el.className = 'status' + (kind ? ' ' + kind : ''); } };

  /** Pauses [[from,to]] -> the parts to delete: each long pause keeps PAD seconds next to the speech (nothing is kept at the very start / end). */
  function deleteRanges(pauses, D, minPause, pad) {
    minPause = minPause == null ? MIN_PAUSE : minPause; pad = pad == null ? PAD : pad;
    const out = [];
    (pauses || []).forEach(p => {
      if (p[1] - p[0] < minPause) return;
      const from = p[0] <= 0.05 ? 0 : p[0] + pad, to = p[1] >= D - 0.05 ? D : p[1] - pad;
      if (to - from >= MIN_CUT) out.push([+from.toFixed(3), +to.toFixed(3)]);
    });
    return out;
  }
  function applyDeletes(ranges) {
    const V = S.videoCut; let n = 0;
    if (S.history) S.history.record('cut');
    V.ensure();
    ranges.forEach(r => {
      if (r[0] > V.MIN) V.split(r[0]);
      if (r[1] < (P.media.duration || 0) - V.MIN) V.split(r[1]);
      // a scene cut can sit inside the pause, so the range may be several pieces: delete every piece that lies inside it
      P.cut.segs.filter(g => !g.del && g.start >= r[0] - 1e-3 && g.end <= r[1] + 1e-3).forEach(g => { if (V.remove(g.id)) n++; });
    });
    return n;
  }
  const textOf = s => P.subtitle.cues.filter(c => (c.start + c.end) / 2 >= s.start && (c.start + c.end) / 2 < s.end).map(c => c.text).join(' ').trim();

  /** A few small JPEG frames of one pool clip (spread over its length) for Gemini. */
  async function framesOf(c, count) {
    if (c.still) {                                                                    // a picture: one frame
      const im = S.arrange.hiddenMedia(c.url, true);
      try {
        await new Promise(res => { if (im.readyState >= 1) res(); else { im.addEventListener('loadedmetadata', res, { once: true }); im.addEventListener('error', res, { once: true }); setTimeout(res, 5000); } });
        if (!im.videoWidth) return [];
        const w = Math.min(512, im.videoWidth), h = Math.max(2, Math.round(w * im.videoHeight / im.videoWidth)), cv = document.createElement('canvas'); cv.width = w; cv.height = h;
        cv.getContext('2d').drawImage(im, 0, 0, w, h);
        return [cv.toDataURL('image/jpeg', 0.7).split(',')[1]];
      } finally { try { im.removeAttribute('src'); im.remove(); } catch (e) {} }
    }
    const el = S.arrange.hiddenVideo(c.url), out = [];
    try {
      await new Promise(res => { if (el.readyState >= 1) res(); else { el.onloadedmetadata = res; setTimeout(res, 4000); } });
      for (let k = 0; k < count; k++) {
        const t = Math.max(0, Math.min((c.duration || el.duration || 1) - 0.1, (c.duration || el.duration || 1) * (count === 1 ? 0.3 : (k + 0.5) / count)));
        await new Promise(res => { const tm = setTimeout(res, 2500); el.addEventListener('seeked', () => { clearTimeout(tm); res(); }, { once: true }); el.currentTime = t; });
        const w = 256, h = Math.max(2, Math.round(w * (el.videoHeight || 9) / (el.videoWidth || 16))), cv = document.createElement('canvas'); cv.width = w; cv.height = h;
        cv.getContext('2d').drawImage(el, 0, 0, w, h);
        out.push(cv.toDataURL('image/jpeg', 0.6).split(',')[1]);
      }
    } finally { try { el.removeAttribute('src'); el.load(); el.remove(); } catch (e) {} }
    return out;
  }
  /** Lay the clips by what is said. Returns how many scenes got a clip chosen by Gemini (0 = fell back to the plain order). */
  async function matchByNarration() {
    const key = ($('geminiKey') && $('geminiKey').value || '').trim(), clips = A.clips;
    if (!clips.length) return 0;
    const scenes = A.scenes.map((s, i) => ({ i: i, s: s, text: textOf(s), sec: S.videoCut.keptLength(s.start, s.end) })).filter(x => x.sec > 0.05);
    if (!key) { say('ไม่มี Gemini Key — จัดคลิปตามลำดับแทน'); return 0; }
    if (!scenes.some(x => x.text)) { say('ยังไม่มีซับ (ถอดเสียงก่อน) — จัดคลิปตามลำดับแทน'); return 0; }
    const per = clips.length <= 6 ? 3 : clips.length <= 12 ? 2 : 1, cl = [];
    for (let i = 0; i < clips.length; i++) { say('กำลังดูภาพของคลิป ' + (i + 1) + '/' + clips.length + '...'); cl.push({ name: clips[i].name, sec: clips[i].duration || 0, still: !!clips[i].still, names: clips[i].names || [], images: await framesOf(clips[i], per) }); }
    const pick = await S.ai.matchScenes({ geminiKey: key, geminiModel: $('geminiModel') && $('geminiModel').value, onStatus: m => say(m), clips: cl, cast: A.cast || '', scenes: scenes.map(x => ({ text: x.text, sec: x.sec })) });
    const next = new Map(); let n = 0;                      // clip id -> where the next scene using it starts, so a long clip plays on instead of restarting
    scenes.forEach((x, k) => {
      const c = clips[pick[k]]; if (!c) return;
      let off = c.still ? 0 : next.get(c.id) || 0;
      if (!c.still && c.duration > 0 && off + Math.min(x.sec, c.duration) > c.duration) off = 0;
      x.s.clipId = c.id; x.s.offset = +off.toFixed(3); x.s.fit = null; next.set(c.id, off + x.sec); n++;
    });
    return n;
  }

  async function run() {
    if (busy) return;
    const D = P.media.duration || 0; if (!D) { say('วางคลิปหรือไฟล์เสียงก่อน', 'err'); return; }
    busy = true; $('arrShorten').disabled = true;
    try {
      if (!A.on) S.arrange.setOn(true);
      await S.arrange.plan();                                   // scenes follow the narration (subtitle lines, else the pauses), not the clip lengths
      if (!A.scenes.length) throw new Error('แบ่งฉากไม่ได้');
      S.arrange.pushUndo();
      say('กำลังฟังเสียงเพื่อหาช่วงเงียบ... 0%');
      const env = await S.arrange.loudness(P.media.file, p => say('กำลังฟังเสียงเพื่อหาช่วงเงียบ... ' + Math.round(p * 100) + '%'));
      const ranges = deleteRanges(S.arrange.pauseRanges(env, MIN_PAUSE), D), before = S.videoCut.keptLength(0, D);
      if (ranges.length) applyDeletes(ranges); const after = S.videoCut.keptLength(0, D);
      let matched = 0, note = '';
      if (useAi && A.clips.length) { try { matched = await matchByNarration(); } catch (e) { note = ' · จับคู่ด้วย AI ไม่สำเร็จ (' + (e && e.message || e) + ')'; } }
      if (A.clips.length && !matched) S.arrange.autoAssign(false);
      S.arrange.commit();
      say('ย่อจาก ' + before.toFixed(1) + ' เป็น ' + after.toFixed(1) + ' วิ (ตัดช่วงเงียบ ' + ranges.length + ' จุด)' + (matched ? ' · AI จับคู่ภาพกับเสียง ' + matched + ' ฉาก' : '') + note, 'ok');
    } catch (e) { say('ย่อวิดีโอไม่สำเร็จ: ' + (e && e.message || e), 'err'); }
    finally { busy = false; $('arrShorten').disabled = false; }
  }

  function init() {
    const b = $('arrShorten'), ai = $('arrShAi'); if (!b) return;
    b.addEventListener('click', run);
    ai.addEventListener('click', () => { useAi = !useAi; ai.classList.toggle('active', useAi); });
  }
  S.shorten = { deleteRanges: deleteRanges, run: run };
  S.ui.shorten = { init: init };
})(window.SubEd);
