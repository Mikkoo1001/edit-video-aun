/* ───────────────────────────────────────────────────────────────────────────────────────────────────────────
 * caption-overlay.js — the live preview paints the caption with the SAME function the export uses
 * (S.render.drawCaption), so what you see in the editor is exactly what lands in the exported video:
 * same font, size, colours, outline, shadow, glow, background, position, animation.
 *
 * The old DOM caption (#capText) is still there — word selection, long-press colour, the frame/handles and
 * layout all read it — but its ink is hidden by `.cap-canvas-on` (see app.css). Only this canvas is visible.
 *
 * RULE: never add a second way of drawing caption ink in the DOM. Anything that changes how a caption looks
 * goes into js/render/caption-canvas.js (drawCaption); the preview and the export both pick it up.
 * Set localStorage.capDom = '1' to fall back to the old DOM look (only for comparing).
 * ─────────────────────────────────────────────────────────────────────────────────────────────────────────── */
(function (S) {
  'use strict';
  const bus = S.bus, state = S.state, P = state.project, dom = S.dom;
  let cv = null, ctx = null, lastKey = '', raf = 0, replay = null, live0 = 0;
  const enabled = (function () { try { return localStorage.getItem('capDom') !== '1'; } catch (e) { return true; } })();

  function build() {
    if (cv) return true;
    const box = dom.videoBox, layer = dom.capLayer;
    if (!box || !layer || !S.render || !S.render.drawCaption) return false;
    cv = document.createElement('canvas');
    cv.className = 'cap-cv';
    cv.style.cssText = 'position:absolute;left:0;top:0;pointer-events:none;';
    box.insertBefore(cv, layer);
    ctx = cv.getContext('2d');
    box.classList.add('cap-canvas-on');
    return true;
  }

  /** words of the active cue as the preview shows them: a word just coloured (clip paused) is kept visible for a moment. */
  function cueForDraw(cue, st) {
    const pk = S.ui.preview.peekInfo && S.ui.preview.peekInfo();
    if (!pk || pk.cue !== cue || !dom.video.paused || st.hlOff) return cue;
    return Object.assign({}, cue, { words: cue.words.map((w, i) => (pk.wis.has(i) && w.color) ? Object.assign({}, w, { hold: true }) : w) });
  }

  function draw() {
    raf = 0;
    if (!enabled || !build()) return;
    const r = S.ui.preview.contentRect(), dpr = Math.min(window.devicePixelRatio || 1, 3);
    const w = Math.max(2, Math.round(r.w * dpr)), h = Math.max(2, Math.round(r.h * dpr));
    cv.style.left = r.x + 'px'; cv.style.top = r.y + 'px'; cv.style.width = r.w + 'px'; cv.style.height = r.h + 'px';
    const resized = cv.width !== w || cv.height !== h;
    if (resized) { cv.width = w; cv.height = h; lastKey = ''; }
    const video = dom.video, t = video.currentTime;
    const idx = S.subtitle.indexAt(P.subtitle.cues, t);
    let cue = idx === -1 ? null : P.subtitle.cues[idx], st = cue ? S.subtitle.effectiveStyle(cue, P.style) : null;
    const refW = S.ui.preview.refWidth() || r.w, scale = w / refW;
    let live = !!cue && S.render.isLive(cue, st, t), tt = t;
    if (cue && replay && replay.idx === idx) {                 // an animation was re-triggered while the clip is paused: play it on a private clock
      const el = (performance.now() - replay.t0) / 1000, od = S.render.outLength(st, cue);
      if (replay.out) {                                        // ending animation demo: pretend the line ends `od - el` seconds from now
        cue = Object.assign({}, cue, { end: t + Math.max(0, od - el) }); live = true;
        if (el > od + 0.05) replay = null;
      } else {
        cue = Object.assign({}, cue, { start: t - el }); live = true;
        if (el > Math.min(S.render.introEnd(cue, st), 4) + 0.15) replay = null;
      }
    } else if (cue && live && video.paused) {                  // continuous motion (e.g. a wobble) keeps moving while paused, like the CSS preview did
      if (!live0) live0 = performance.now();
      cue = Object.assign({}, cue, { start: cue.start - (performance.now() - live0) / 1000 });
    } else live0 = 0;
    if (cue) cue = cueForDraw(cue, st);
    const key = cue ? [idx, cue.id, w, h, scale.toFixed(4), JSON.stringify(st), JSON.stringify(cue.words), cue.words.map(x => (t >= x.start ? 1 : 0) + (t >= x.end ? 1 : 0)).join('')].join('|') : 'none|' + w + 'x' + h;
    if (!live && key === lastKey && !resized) return;
    ctx.clearRect(0, 0, w, h);
    if (cue) S.render.drawCaption(ctx, w, h, cue, tt, scale, st);
    lastKey = live ? '' : key;
    if (live) schedule();                                      // animation running: next frame
  }
  function schedule() { if (!raf) raf = requestAnimationFrame(draw); }

  /** Make sure every font the caption needs is loaded, then redraw (fonts arrive late on a phone). */
  function fontsThenDraw() {
    schedule();
    if (S.fontKit) S.fontKit.ensure().then(function () { lastKey = ''; schedule(); });
  }

  S.ui.capOverlay = {
    enabled: enabled,
    redraw: function () { lastKey = ''; schedule(); },
    init: function () {
      if (!enabled) return;
      build();
      ['time:changed', 'cue:text', 'cue:timing', 'cue:style', 'cues:structure', 'word:colored', 'media:metadata', 'sheet:toggle', 'cue:active', 'arrange:changed', 'arrange:render'].forEach(function (ev) { bus.on(ev, schedule); });
      bus.on('style:changed', fontsThenDraw);
      bus.on('cues:structure', fontsThenDraw);
      bus.on('fx:replay', function () { replay = { idx: state.ui.activeCue, t0: performance.now(), out: false }; schedule(); });
      bus.on('fx:replay-out', function () { replay = { idx: state.ui.activeCue, t0: performance.now(), out: true }; schedule(); });
      if (window.ResizeObserver) new ResizeObserver(schedule).observe(dom.videoBox);
      window.addEventListener('resize', schedule);
      if (document.fonts && document.fonts.addEventListener) document.fonts.addEventListener('loadingdone', function () { lastKey = ''; schedule(); });
      setInterval(function () { if (!dom.video.paused || live0 || replay) schedule(); }, 250);   // safety net
      fontsThenDraw();
    }
  };
})(window.SubEd);
