/* =====================================================================
 * UI: timing bar for the selected line — fix a line that came out a little early / late without dragging.
 * Shown under the timeline while a line is selected (body.cue-selected), editing layout only.
 *
 *   เริ่ม ◀ ▶   move the START earlier / later          จบ ◀ ▶   move the END earlier / later
 *   ย้าย ◀ ▶    move the whole line                      ย้ายตามหลัง   (toggle) ย้าย also carries every later line with it,
 *                                                         for a whole stretch that drifted
 *   ทีละ 0.1วิ   step size (0.05 / 0.1 / 0.5 / 1 s)       เริ่ม=ตรงนี้ / จบ=ตรงนี้   set the start / end to the playhead
 *   ต่อก่อนหน้า / ต่อถัดไป   close the gap to the line before / after
 *   ตามเสียง     (green) after the words were edited: where the speech says this line should end — one tap puts it there
 *   สั่น          switch the buzz on / off (a line snapping onto another line / onto the guide)
 * Hold a ◀ ▶ button to repeat. Every press is ONE undo step. After a change the playhead jumps to the edge that moved, so the
 * result is seen at once (the playhead always stays inside the line: leaving it would deselect the line).
 * Uses: S.subtitle.setCueTiming, S.ui.sel, S.history. Emits: cue:timing, time:changed.
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, state = S.state, P = S.state.project, video = S.dom.video, fmt2 = S.util.fmt2;
  const STEPS = [0.05, 0.1, 0.5, 1];
  const NOHIST = { history: false };
  let si = 1, ripple = false, bar, readEl, stepBtn, rippleBtn, prevBtn, nextBtn, guideBtn, hapBtn, lastGuide = null;

  const cues = () => P.subtitle.cues;
  const idx = () => (S.ui.sel ? S.ui.sel.get() : -1);
  const cue = () => cues()[idx()] || null;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const dur = () => P.media.duration || 0;
  const step = () => STEPS[si];
  const record = () => { if (S.history) S.history.record('timing'); };
  const look = t => { video.currentTime = t; bus.emit('time:changed', t); };      // show the frame at t
  const pause = () => { if (!video.paused) video.pause(); };

  /** show the frame at the start / end of line c — at a time where c is still THE line on screen (when lines overlap, the one that
   *  starts later wins at a time they share; the playhead leaving c would deselect it) */
  function seek(c, edge) {
    const all = cues(), i = all.indexOf(c), from = edge === 'end' ? c.end - 0.05 : c.start + 0.01, dir = edge === 'end' ? -1 : 1;
    for (let k = 0; k < 400; k++) {
      const t = from + dir * 0.02 * k;
      if (t < c.start || t >= c.end) break;
      if (S.subtitle.indexAt(all, t) === i) { look(t); return; }
    }
    look(clamp(from, c.start, c.end - 0.001));
  }

  function setTiming(c, s, e) { S.subtitle.setCueTiming(cues().indexOf(c), s, e, NOHIST); }

  /** shift this line (and, with `ripple`, every line from it on) by dt seconds; returns the shift really applied */
  function shift(c, dt) {
    const list = ripple ? cues().filter(o => o.start >= c.start - 1e-6) : [c];
    const lo = Math.min.apply(null, list.map(o => o.start)), hi = Math.max.apply(null, list.map(o => o.end));
    dt = clamp(dt, -lo, dur() - hi);
    if (!dt) return 0;
    list.forEach(o => { o.start += dt; o.end += dt; o.words.forEach(w => { w.start += dt; w.end += dt; }); });
    bus.emit('cue:timing', { idx: cues().indexOf(c) });
    return dt;
  }

  const RAW = {
    startBy(sign) { const c = cue(); if (!c) return; setTiming(c, clamp(c.start + sign * step(), 0, c.end - 0.1), c.end); seek(c, 'start'); },
    endBy(sign) { const c = cue(); if (!c) return; setTiming(c, c.start, clamp(c.end + sign * step(), c.start + 0.1, dur())); seek(c, 'end'); },
    moveBy(sign) {
      const c = cue(); if (!c) return;
      const d = shift(c, sign * step());
      const t = clamp(video.currentTime + d, c.start, c.end - 0.001);
      if (S.subtitle.indexAt(cues(), t) === cues().indexOf(c)) look(t); else seek(c, 'start');
    },
    startHere() { const c = cue(); if (!c) return; setTiming(c, clamp(video.currentTime, 0, c.end - 0.1), c.end); seek(c, 'start'); },
    endHere() { const c = cue(); if (!c) return; setTiming(c, c.start, clamp(video.currentTime, c.start + 0.1, dur())); seek(c, 'end'); },
    joinPrev() { const i = idx(), c = cues()[i], p = cues()[i - 1]; if (!c || !p) return; setTiming(c, clamp(p.end, 0, c.end - 0.1), c.end); seek(c, 'start'); },
    joinNext() { const i = idx(), c = cues()[i], n = cues()[i + 1]; if (!c || !n) return; setTiming(c, c.start, clamp(n.start, c.start + 0.1, dur())); seek(c, 'end'); }
  };

  // while an action runs the playhead may be outside the line for a moment (the line was moved under it): the line must stay selected
  const A = {};
  Object.keys(RAW).forEach(k => { A[k] = function () { api.busy = true; try { return RAW[k].apply(null, arguments); } finally { api.busy = false; } }; });

  const ico = d => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="' + d + '"/></svg>';
  const LEFT = ico('m14 6-6 6 6 6'), RIGHT = ico('m10 6 6 6-6 6');

  /** a button that acts when pressed and keeps acting while held */
  function holdBtn(html, title, fn) {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'tb-btn'; b.innerHTML = html; b.title = title;
    let t = 0, rep = 0;
    const stop = () => { clearTimeout(t); clearInterval(rep); t = rep = 0; };
    b.addEventListener('pointerdown', e => {
      e.preventDefault(); pause(); record(); fn();
      try { b.setPointerCapture(e.pointerId); } catch (err) {}
      stop(); t = setTimeout(() => { rep = setInterval(fn, 90); }, 380);
    });
    ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(ev => b.addEventListener(ev, stop));
    b.addEventListener('contextmenu', e => e.preventDefault());
    return b;
  }
  function tapBtn(text, title, fn) {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'tb-btn'; b.textContent = text; b.title = title;
    b.addEventListener('click', () => { pause(); fn(b); });
    return b;
  }
  function group(label, fnName) {
    const g = document.createElement('div'); g.className = 'tb-grp';
    const l = document.createElement('span'); l.className = 'tb-lab'; l.textContent = label; g.appendChild(l);
    g.appendChild(holdBtn(LEFT, label + ' ช้าลง/เร็วขึ้น: ถอยไปทางซ้าย', () => A[fnName](-1)));
    g.appendChild(holdBtn(RIGHT, label + ': ไปทางขวา', () => A[fnName](1)));
    return g;
  }

  function refresh() {
    const c = cue(), i = idx();
    if (!c) return;
    readEl.innerHTML = '<b>' + fmt2(c.start) + '</b> → <b>' + fmt2(c.end) + '</b> · ' + (c.end - c.start).toFixed(2) + 'วิ';
    refreshGuide(c);
    prevBtn.disabled = !(i > 0);
    nextBtn.disabled = !(i >= 0 && i < cues().length - 1);
    stepBtn.textContent = 'ทีละ ' + step() + 'วิ';
    rippleBtn.classList.toggle('on', ripple);
  }

  function syncHap() {
    if (!hapBtn || !S.haptic) return;
    hapBtn.classList.toggle('on', S.haptic.enabled);
    hapBtn.textContent = !S.haptic.supported ? 'สั่น (เครื่องนี้ไม่รองรับ)' : S.haptic.enabled ? 'สั่น: เปิด' : 'สั่น: ปิด';
  }
  /** "ตามเสียง": where the speech says this line belongs (see subtitle/span-suggest.js). Tap = put it there (one undo step). */
  function refreshGuide(c) {
    if (!guideBtn) return;
    const g = c && S.ui.timeline && S.ui.timeline.guideOf ? S.ui.timeline.guideOf(c) : null;
    lastGuide = g;
    const dEnd = g ? g.end - c.end : 0, dStart = g ? g.start - c.start : 0;
    const off = !!g && (Math.abs(dEnd) > 0.08 || Math.abs(dStart) > 0.08);
    guideBtn.classList.toggle('on', off);
    guideBtn.classList.toggle('est', !!g && g.source !== 'speech');
    guideBtn.disabled = !off;
    const sgn = v => (v >= 0 ? '+' : '−') + Math.abs(v).toFixed(2);
    guideBtn.textContent = !g ? 'ตามเสียง' : !off ? 'ตรงเสียงแล้ว ✓'
      : (g.source === 'speech' ? 'ตามเสียง ' : 'ประมาณ ') + 'จบ ' + fmt2(g.end).replace(/^00:0?/, '') + ' (' + sgn(dEnd) + ')';
    guideBtn.title = g ? (g.source === 'speech'
      ? 'หาคำของประโยคนี้ในเสียงที่ฟังได้ ควรจบที่ ' + fmt2(g.end) + (Math.abs(dStart) > 0.08 ? ' และเริ่มที่ ' + fmt2(g.start) : '') + ' · กดเพื่อวางตามนี้ หรือลากขอบขวาไปหาเส้นเขียวบนไทม์ไลน์'
      : 'ไม่มีเสียงที่ฟังไว้ให้เทียบ (ซับพิมพ์เอง) จึงประมาณจากความยาวตัวอักษร · กดเพื่อใช้ค่าประมาณ') : '';
  }

  const api = S.ui.timeNudge = {
    busy: false,
    actions: A,
    init() {
      const tb = $('ccToolbar'); if (!tb) return;
      bar = document.createElement('div'); bar.id = 'ccTimeBar'; bar.className = 'cc-timebar';
      readEl = document.createElement('div'); readEl.className = 'tb-read';
      bar.appendChild(readEl);
      guideBtn = tapBtn('ตามเสียง', '', () => { const c = cue(); if (!c) return; api.busy = true; try { S.subtitle.fitToSpeech(idx()); seek(c, 'end'); } finally { api.busy = false; } });
      guideBtn.classList.add('tb-guide'); bar.appendChild(guideBtn);
      bar.appendChild(group('เริ่ม', 'startBy'));
      bar.appendChild(group('จบ', 'endBy'));
      bar.appendChild(group('ย้าย', 'moveBy'));
      stepBtn = tapBtn('', 'ขยับทีละกี่วินาที', () => { si = (si + 1) % STEPS.length; refresh(); });
      rippleBtn = tapBtn('ย้ายตามหลัง', 'เปิด: ปุ่ม ย้าย จะพาทุกประโยคหลังจากนี้ไปด้วย (ใช้เมื่อซับเลื่อนทั้งช่วง)', () => { ripple = !ripple; refresh(); });
      bar.appendChild(stepBtn); bar.appendChild(rippleBtn);
      bar.appendChild(tapBtn('เริ่ม=ตรงนี้', 'ให้ประโยคเริ่มที่ตำแหน่งเล่นตอนนี้', () => { record(); A.startHere(); }));
      bar.appendChild(tapBtn('จบ=ตรงนี้', 'ให้ประโยคจบที่ตำแหน่งเล่นตอนนี้', () => { record(); A.endHere(); }));
      prevBtn = tapBtn('ต่อก่อนหน้า', 'ให้เริ่มตรงกับจุดจบของประโยคก่อนหน้า', () => { record(); A.joinPrev(); });
      nextBtn = tapBtn('ต่อถัดไป', 'ให้จบตรงกับจุดเริ่มของประโยคถัดไป', () => { record(); A.joinNext(); });
      bar.appendChild(prevBtn); bar.appendChild(nextBtn);
      hapBtn = tapBtn('', 'สั่นเมื่อลากข้อความไปติดกับประโยคอื่น / ถึงจุดที่ควรจบ (Android เท่านั้น)', () => { if (S.haptic) S.haptic.setEnabled(!S.haptic.enabled); syncHap(); });
      hapBtn.classList.add('tb-hap'); bar.appendChild(hapBtn); syncHap();
      tb.parentNode.insertBefore(bar, tb);
      ['cue:timing', 'cue:selected', 'cues:structure', 'cue:active', 'cue:text', 'guide:changed'].forEach(e => bus.on(e, refresh));
    }
  };
})(window.SubEd);
