/* =====================================================================
 * UI: "คัดลอกสไตล์" pane (สไตล์ sheet -> sub-tab). Thin wrapper over SubEd.styleCopy.
 * Wires: reference preset, analyse-a-video, auto highlight, save/load style file, vertical-position slider.
 * Listens: style:changed.  Emits (via styleCopy / S.style): style:changed, cues:structure.
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, P = S.state.project;
  const FX = { none: 'ตัดตรง (ไม่มีแอนิเมชัน)', pop: 'ป๊อป', fade: 'เฟด', slide: 'เลื่อนขึ้น' };
  const parts = () => { const o = {}; document.querySelectorAll('#scParts [data-part]').forEach(c => { o[c.dataset.part] = c.classList.contains('active'); }); return o; };
  const status = m => { $('scStatus').textContent = m; };

  function rhythmLine(pr) {
    const r = pr.layout.rhythm;
    return '\nขนาดประโยค: ' + r.min.w + '–' + r.max.w + ' คำต่อบรรทัด (ส่วนใหญ่ ' + r.typical.w + ' คำ · ~' + r.typical.c + ' ตัวอักษร · ยาวสุด ' + r.max.c + ') · ตัดตามจังหวะเสียงพูด' +
      (r.opening && r.opening.on ? '\nประโยคเปิด: ' + r.opening.patterns.map(p => p.join('-')).join(' · ') + ' พยางค์ต่อบรรทัด' : '');
  }

  function describe(pr) {
    return 'ตำแหน่ง ' + Math.round(pr.layout.posY * 100) + '% จากบน · ขนาด ' + (pr.text.sizeFrac * 100).toFixed(1) + '% ของความกว้างภาพ · แอนิเมชัน: ' + (FX[pr.animation.fx] || pr.animation.fx) +
      '\nไฮไลท์: ' + pr.highlight.palette.length + ' สี · ' + Math.round(pr.highlight.coverage * 100) + '% ของประโยค ' + (({ off: '(สีติดทั้งประโยค)', stay: '(สีค้างหลังพูดถึง)', stayAll: '(สีค้างทุกคำ)' })[S.styleCopy.modeOverride || pr.highlight.mode] || '') + rhythmLine(pr);
  }

  function applyAndHighlight(pr, p, note) {
    S.styleCopy.apply(pr, p);
    let extra = '';
    if (p.segmentation) extra += P.subtitle.cues.length ? '\nตัดประโยคใหม่ตามขนาดต้นแบบ: ' + P.subtitle.cues.length + ' บรรทัด' : '\nตอนสร้างคำบรรยาย จะตัดประโยคตามขนาดต้นแบบนี้ให้เอง';
    if (p.highlight && P.subtitle.cues.length) { const r = S.styleCopy.autoHighlight(pr); extra = '\nลงสีคำให้ ' + r.colored + '/' + r.lines + ' ประโยค'; }
    else if (p.highlight) extra = '\nยังไม่มีคำบรรยาย — สร้างคำบรรยายแล้วกด "ไฮไลท์อัตโนมัติ"';
    status(describe(pr) + extra + (note ? '\n' + note : '') + '\n(กดย้อนกลับเพื่อยกเลิกได้)');
  }

  function syncPosY() {
    const v = S.ui.precise.r1((P.style.posY == null ? 0.62 : P.style.posY) * 100);
    $('scPosY').value = v; $('scPosYNum').textContent = S.ui.precise.f1(v);
  }

  /** Measure a reference video's caption style (position, size, colours, rhythm; font/outline/shadow too when a Gemini key is set).
   *  -> { ok, pr (profile), p (parts to apply), note }  or { ok:false, reason }.  Nothing is applied here. say(msg) reports progress. */
  async function buildFromVideo(f, say) {
    const key = ($('geminiKey') && $('geminiKey').value || '').trim();
    const res = await S.styleCopy.analyzeVideoFile(f, { wantLook: !!key, onProgress: (p, m) => say(m + ' ' + Math.round(p * 100) + '%') });
      if (!res.ok) return { ok: false, reason: res.reason };
    const pr = S.styleCopy.profileFromAnalysis(res, S.styleCopy.capture(), 'จากวิดีโอ ' + f.name);
    // font / weight / colours / outline / shadow / glow: only Gemini can READ them off the pictures (the pixel analysis measures position, size, colours of highlights, rhythm)
    let gotLook = false, lookNote = '';
    if (key && res.lookImages && res.lookImages.length) {
      say('Gemini กำลังดูฟอนต์และสไตล์ตัวอักษร…');
      try {
        const opts = Array.from($('fontSel').options).filter(o => !/^system-ui/.test(o.value));
        const look = await S.ai.identifyCaptionStyle({ geminiKey: key, geminiModel: $('geminiModel') ? $('geminiModel').value : '', onStatus: say, images: res.lookImages, fonts: opts.map(o => o.textContent.trim()) });
        const o = look.fontIndex != null ? opts[look.fontIndex] : null;
        S.styleCopy.mergeLook(pr, look, o ? { value: o.value, weight: o.dataset.weight ? +o.dataset.weight : null } : null);
        gotLook = true;
        lookNote = 'ฟอนต์: ' + (o ? o.textContent.trim() : 'ไม่ชัด คงเดิม') + ' · หนา ' + pr.text.weight + (look.italic ? ' · เอียง' : '') + ' · ขอบ ' + (look.outline.on ? 'มี' : 'ไม่มี') + ' · เงา ' + (look.shadow.on ? 'มี' : 'ไม่มี') +
          ' · เรืองแสง ' + (look.glow.on ? (look.glow.type === 'burst' ? 'แบบ 1 แสงพุ่ง' : 'แบบ 2 แสงฟุ้ง') : 'ไม่มี') + (look.box.on ? ' · มีกล่องพื้นหลัง' : '') + (look.note ? '\n(' + look.note + ')' : '');
      } catch (e) { lookNote = 'Gemini อ่านฟอนต์ไม่สำเร็จ: ' + e.message + ' — ฟอนต์/ขอบ/เงายังเป็นของเดิม'; }
    } else if (!key) lookNote = 'ใส่ Gemini API Key (แท็บสร้างคำบรรยาย) เพื่อให้ลอกฟอนต์ ขอบ เงา เรืองแสงจากวิดีโอด้วย — ตอนนี้ลอกได้แค่ตำแหน่ง ขนาด สี ประโยค';
    const p = Object.assign(parts(), { resetLines: false });
    if (!gotLook) Object.assign(p, { font: false, outline: false, shadow: false });
    p.segmentation = !!(p.segmentation && res.rhythm);          // no measured lines -> leave the current line cutting alone
    const got = res.rhythm ? 'วัดขนาดประโยคได้ ' + res.rhythm.lines.length + ' ประโยคแรก' : 'วัดขนาดประโยคไม่ได้ (เจอประโยคน้อยเกินไป) จึงไม่เปลี่ยนการตัดประโยค';
    const out = { ok: true, pr: pr, p: p, look: gotLook, rhythm: !!res.rhythm, note: 'วัดจากวิดีโอ ' + res.captionFrames + '/' + res.frames + ' เฟรม · ' + got + (lookNote ? '\n' + lookNote : '') };
    out.saved = libAdd(f, out);                                  // kept for next time (ต้นแบบที่บันทึกไว้)
    return out;
  }

  /* ---------- saved references (ต้นแบบที่บันทึกไว้) ----------
   * Every reference video that has been analysed is kept on this device (localStorage): the measured style profile + the note, NOT the video file itself
   * (a clip is tens of MB; the measured style is a few KB and applying it needs no new analysis and no new Gemini call). Newest first, max LIB_MAX. */
  const LIB_KEY = 'subed.refLib.v1', LIB_MAX = 30;
  const libRead = () => { try { const a = JSON.parse(localStorage.getItem(LIB_KEY) || '[]'); return Array.isArray(a) ? a.filter(e => e && e.id && e.pr) : []; } catch (e) { return []; } };
  const libWrite = a => { try { localStorage.setItem(LIB_KEY, JSON.stringify(a)); return true; } catch (e) { return false; } };

  /** keep one analysed reference (same file picked again = replaced and moved to the top). Returns true when it was stored. */
  function libAdd(f, b) {
    const id = f.name + '|' + f.size + '|' + (f.lastModified || 0);
    const list = libRead().filter(e => e.id !== id);
    list.unshift({ id: id, name: f.name, ts: Date.now(), pr: b.pr, note: b.note || '', look: !!b.look, rhythm: !!b.rhythm });
    list.length = Math.min(list.length, LIB_MAX);
    const ok = libWrite(list);
    libRender();
    return ok;
  }

  function libInfo(e) {
    const pr = e.pr || {}, lay = pr.layout || {}, tx = pr.text || {}, an = pr.animation || {};
    const bits = [];
    if (lay.posY != null) bits.push('ตำแหน่ง ' + Math.round(lay.posY * 100) + '%');
    if (tx.sizeFrac != null) bits.push('ขนาด ' + (tx.sizeFrac * 100).toFixed(1) + '%');
    bits.push(FX[an.fx] || an.fx || '');
    bits.push(e.look ? 'อ่านฟอนต์แล้ว' : 'ไม่มีฟอนต์');
    return bits.filter(Boolean).join(' · ');
  }

  function useSaved(e) {
    const p = Object.assign(parts(), { resetLines: false });
    if (!e.look) Object.assign(p, { font: false, outline: false, shadow: false });      // that clip was measured without Gemini: font / outline / shadow stay as they are now
    p.segmentation = !!(p.segmentation && e.rhythm);
    try {
      applyAndHighlight(e.pr, p, e.note);
      status('ใช้ต้นแบบ: ' + e.name + '\n' + $('scStatus').textContent);
    } catch (err) { status('ใช้ต้นแบบนี้ไม่ได้: ' + err.message); }
  }

  function libRender() {
    const box = $('scLib'), cnt = $('scLibCount');
    if (!box) return;
    const list = libRead();
    if (cnt) cnt.textContent = list.length;
    box.textContent = '';
    if (!list.length) {
      const em = document.createElement('div'); em.className = 'hint'; em.textContent = 'ยังไม่มีต้นแบบที่บันทึกไว้ — เลือกวิดีโอต้นแบบ (จากวิดีโอ) เมื่อวิเคราะห์เสร็จจะบันทึกไว้ให้เอง';
      box.appendChild(em); return;
    }
    list.forEach(e => {
      const it = document.createElement('div'); it.className = 'sc-lib-item'; it.setAttribute('role', 'button'); it.tabIndex = 0;
      const sw = document.createElement('span'); sw.className = 'sc-lib-sw';
      ((e.pr.highlight && e.pr.highlight.palette) || []).slice(0, 6).forEach(c => { const i = document.createElement('i'); i.style.background = /^#[0-9a-f]{6}$/i.test(c) ? c : '#888'; sw.appendChild(i); });
      const tx = document.createElement('span'); tx.className = 'sc-lib-tx';
      const n = document.createElement('b'); n.textContent = e.name;
      const m = document.createElement('small'); m.textContent = libInfo(e) + ' · ' + new Date(e.ts).toLocaleDateString('th-TH', { day: 'numeric', month: 'short' });
      tx.appendChild(n); tx.appendChild(m);
      const del = document.createElement('button'); del.type = 'button'; del.className = 'sc-lib-del'; del.title = 'ลบต้นแบบนี้'; del.setAttribute('aria-label', 'ลบ ' + e.name); del.textContent = '✕';
      del.addEventListener('click', ev => { ev.stopPropagation(); libWrite(libRead().filter(x => x.id !== e.id)); libRender(); status('ลบต้นแบบ ' + e.name + ' ออกจากรายการแล้ว'); });
      it.addEventListener('click', () => useSaved(e));
      it.addEventListener('keydown', ev => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); useSaved(e); } });
      it.appendChild(sw); it.appendChild(tx); it.appendChild(del);
      box.appendChild(it);
    });
  }

  function initLib() {
    const tg = $('scLibTg'), box = $('scLib');
    if (!tg || !box) return;
    tg.addEventListener('click', () => {
      const on = box.hidden; box.hidden = !on;                    // hidden -> shown (the switch turns on) and the other way round
      tg.classList.toggle('on', on); tg.setAttribute('aria-checked', on ? 'true' : 'false');
      if (on) libRender();
    });
    libRender();
  }

  S.ui.styleCopy = {
    buildFromVideo: buildFromVideo,
    applyBuilt: b => applyAndHighlight(b.pr, b.p, b.note),
    init() {
      document.querySelectorAll('#scParts [data-part]').forEach(c => c.addEventListener('click', () => c.classList.toggle('active')));

      document.querySelectorAll('#scModes [data-scmode]').forEach(c => c.addEventListener('click', () => {
        const m = c.dataset.scmode; S.styleCopy.modeOverride = m;
        P.style.karaokeMode = m; P.style.karaoke = m !== 'off'; bus.emit('style:changed');
        status('แบบสี: ' + c.textContent + ' (ใช้กับต้นแบบที่นำไปใช้ต่อจากนี้ด้วย)');
      }));
      bus.on('style:changed', () => document.querySelectorAll('#scModes [data-scmode]').forEach(c => c.classList.toggle('active', c.dataset.scmode === P.style.karaokeMode)));
      $('scRef1').addEventListener('click', () => applyAndHighlight(S.styleCopy.REFERENCE_1, parts(), 'ฟอนต์ใกล้เคียง: Prompt ExtraBold (ถ้ามีไฟล์ฟอนต์จริงของต้นแบบ วางใน fonts/ แล้วเลือกที่แท็บ "ข้อความ")'));

      $('scFromVideo').addEventListener('click', () => $('scVideo').click());
      $('scVideo').addEventListener('change', () => {
        const f = $('scVideo').files[0]; $('scVideo').value = ''; if (!f) return;
        status('กำลังวิเคราะห์วิดีโอ…');
        buildFromVideo(f, status).then(b => { if (!b.ok) { status(b.reason); return; } applyAndHighlight(b.pr, b.p, b.note); status($('scStatus').textContent + (b.saved ? '\nบันทึกเป็นต้นแบบไว้แล้ว — เปิด "ต้นแบบที่เคยใช้" เพื่อเลือกใช้ได้ทุกเมื่อ' : '\n(บันทึกต้นแบบไว้ไม่ได้ — พื้นที่เก็บข้อมูลในเครื่องเต็มหรือถูกปิดอยู่)')); }).catch(e => status('วิเคราะห์ไม่สำเร็จ: ' + e.message));
      });

      $('scAuto').addEventListener('click', () => {
        if (!P.subtitle.cues.length) { status('ยังไม่มีคำบรรยาย'); return; }
        const r = S.styleCopy.autoHighlight(S.styleCopy.lastProfile || S.styleCopy.REFERENCE_1);
        status('ลงสีคำให้ ' + r.colored + '/' + r.lines + ' ประโยค (กดอีกครั้งจะได้ผลเดิม · กดย้อนกลับได้)');
      });
      $('scClear').addEventListener('click', () => { S.styleCopy.clearWordColors(); status('ล้างสีรายคำทั้งหมดแล้ว'); });

      $('scSave').addEventListener('click', () => { const pr = S.styleCopy.exportProfile(S.styleCopy.capture()); status('บันทึกไฟล์สไตล์แล้ว: ' + pr.name); });
      $('scLoad').addEventListener('click', () => $('scFile').click());
      $('scFile').addEventListener('change', () => {
        const f = $('scFile').files[0]; $('scFile').value = ''; if (!f) return;
        S.styleCopy.importProfile(f).then(pr => applyAndHighlight(pr, parts())).catch(e => status('โหลดไม่ได้: ' + e.message));
      });

      $('scPosY').addEventListener('input', () => {
        S.subtitle.clearCuePositions();                  // lines with their own position follow too (only the first tick of a drag does anything)
        P.style.pos = 'custom'; P.style.posY = +(Math.round(parseFloat($('scPosY').value) * 10) / 1000).toFixed(4);
        $('scPosYNum').textContent = S.ui.precise.f1(parseFloat($('scPosY').value)); bus.emit('style:changed');
      });
      bus.on('style:changed', syncPosY);
      syncPosY();
      initLib();
    }
  };
})(window.SubEd);
