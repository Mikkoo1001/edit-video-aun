/* =====================================================================
 * UI helper: several clips -> ONE main sound.
 *
 * The editor's timeline, subtitles (ซับอัตโนมัติ) and export all hang off a single main file. To put n clips one after another
 * (each for its own length) this builds a 16-bit PCM WAV made of every clip's sound back to back; the pictures stay the
 * clips themselves in the "จัดฉาก" pool, laid by arrange.layMerged(). The sound of clip i starts exactly where clip i's
 * picture starts: every clip gets precisely round(duration * RATE) samples (cut or padded with silence).
 *
 *   SubEd.ui.mergeClips.build(clips, onProgress) -> Promise<{ file: File(audio/wav), silent: [names without sound] }>
 *     clips: pool clips { file, duration, name } (duration = the picture's length, from arrange.addClipFile)
 *     onProgress(i, n, name)
 *
 * Small files are decoded whole (decodeAudioData, full quality). Big ones (> BIG) are streamed through SubEd.audio.openChunks
 * (16 kHz mono, constant memory) and brought up to RATE. Up to STEREO_MAX seconds the WAV is stereo, longer it is mono
 * (keeps the file inside what the exporter and the AI step can read back whole: <= ~200 MB).
 * ===================================================================== */
(function (S) {
  'use strict';
  const RATE = 48000, BIG = 150 * 1024 * 1024, STEREO_MAX = 300;

  /** Linear resample of one channel. */
  function resample(src, from, to) {
    if (from === to || !src.length) return src;
    const n = Math.max(1, Math.round(src.length * to / from)), out = new Float32Array(n), k = from / to, last = src.length - 1;
    for (let i = 0; i < n; i++) {
      const p = i * k, i0 = Math.min(last, Math.floor(p)), f = p - i0, a = src[i0], b = src[Math.min(last, i0 + 1)];
      out[i] = a + (b - a) * f;
    }
    return out;
  }

  /** Whole-file decode -> [left, right?] Float32Array at RATE. Throws when the file has no decodable sound. */
  async function decodeSmall(file) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) throw new Error('เบราว์เซอร์นี้อ่านเสียงจากวิดีโอไม่ได้');
    let ac;
    try { ac = new AC({ sampleRate: RATE }); } catch (e) { ac = new AC(); }
    try {
      const buf = await ac.decodeAudioData(await (S.localCopy ? S.localCopy.readAll(file) : file.arrayBuffer()));
      const chs = [];
      for (let c = 0; c < Math.min(2, buf.numberOfChannels); c++) chs.push(resample(buf.getChannelData(c), buf.sampleRate, RATE));
      return chs;
    } finally { try { ac.close(); } catch (e) {} }
  }

  /** Streaming decode for big files -> [mono] at RATE. */
  async function decodeBig(file, durationHint) {
    const ch = await S.audio.openChunks(file, { chunkSec: 60, durationHint: durationHint });
    const parts = []; let total = 0;
    try {
      for (let piece; (piece = await ch.next());) {
        const a = new Int16Array(await piece.blob.arrayBuffer(), 44), f = new Float32Array(a.length);
        for (let i = 0; i < a.length; i++) f[i] = a[i] / 32768;
        parts.push(f); total += f.length;
      }
    } finally { ch.close(); }
    const mono = new Float32Array(total); let o = 0;
    parts.forEach(p => { mono.set(p, o); o += p.length; });
    return [resample(mono, 16000, RATE)];
  }

  function header(frames, ch) {
    const bytes = frames * ch * 2, buf = new ArrayBuffer(44), v = new DataView(buf);
    const str = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
    str(0, 'RIFF'); v.setUint32(4, 36 + bytes, true); str(8, 'WAVE'); str(12, 'fmt ');
    v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, ch, true);
    v.setUint32(24, RATE, true); v.setUint32(28, RATE * ch * 2, true); v.setUint16(32, ch * 2, true); v.setUint16(34, 16, true);
    str(36, 'data'); v.setUint32(40, bytes, true);
    return buf;
  }

  /** One clip's share of the timeline as 16-bit PCM (ch interleaved channels, exactly `len` frames; silence when it has no sound). */
  async function pcmOf(c, len, ch) {
    let src = null;
    try { src = c.file.size > BIG ? await decodeBig(c.file, c.duration) : await decodeSmall(c.file); }
    catch (e) { if (e && e.unreadable) throw e; src = null; }              // no sound track (or not decodable): silence for this clip
    const has = !!(src && src.length && src[0].length), pcm = new Int16Array(len * ch);
    if (has) {
      const L = src[0], R = src[1] || src[0], m = Math.min(len, L.length);
      for (let k = 0; k < m; k++) {
        if (ch === 2) { pcm[2 * k] = clamp(L[k]); pcm[2 * k + 1] = clamp(R[k]); }
        else pcm[k] = clamp(src[1] ? (L[k] + R[k]) / 2 : L[k]);
      }
    }
    return { pcm: pcm, silent: !has };
  }

  async function build(clips, onProgress) {
    const n = clips.length;
    if (!n) throw new Error('ไม่มีคลิป');
    const totalSec = clips.reduce((a, c) => a + c.duration, 0), ch = totalSec <= STEREO_MAX ? 2 : 1;
    // every clip's frame range is known up front, so the clips can be decoded side by side (decodeAudioData runs off the main thread).
    // At most WORKERS at a time and at most BUDGET bytes of source files in flight (a decoded clip is far bigger than its file), always >= 1.
    const lens = []; let cum = 0;
    for (let i = 0; i < n; i++) { const from = Math.round(cum * RATE); cum += clips[i].duration; lens.push(Math.max(0, Math.round(cum * RATE) - from)); }
    const mem = navigator.deviceMemory || 4, WORKERS = mem >= 8 ? 3 : mem >= 4 ? 2 : 1, BUDGET = 160 * 1048576;
    const out = new Array(n); let next = 0, flight = 0, bytes = 0, fail = null, started = 0, finished = 0;
    await new Promise((resolve, reject) => {
      const pump = () => {
        if (fail) return;
        while (next < n && flight < WORKERS && (flight === 0 || bytes + clips[next].file.size <= BUDGET)) {
          const i = next++, c = clips[i], size = c.file.size;
          flight++; bytes += size;
          if (onProgress) onProgress(started++, n, c.name);
          pcmOf(c, lens[i], ch).then(r => { out[i] = r; }, e => { fail = e; reject(e); })
            .then(() => new Promise(r => setTimeout(r, 0)))                    // let the screen breathe between clips
            .then(() => { flight--; bytes -= size; finished++; if (finished === n) resolve(); else pump(); });
        }
      };
      pump();
    });
    const parts = [null], silent = []; let frames = 0;
    for (let i = 0; i < n; i++) { parts.push(out[i].pcm); frames += lens[i]; if (out[i].silent) silent.push(clips[i].name); out[i] = null; }
    parts[0] = header(frames, ch);
    const name = 'รวม ' + n + ' คลิป.wav';
    return { file: new File(parts, name, { type: 'audio/wav', lastModified: Date.now() }), silent: silent };
  }
  const clamp = x => { x = x < -1 ? -1 : x > 1 ? 1 : x; return x < 0 ? x * 0x8000 : x * 0x7fff; };

  S.ui.mergeClips = { build: build, RATE: RATE };
})(window.SubEd);
