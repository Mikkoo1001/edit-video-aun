/* =====================================================================
 * Haptics — a short buzz when a dragged sentence snaps onto something, so you can feel it without looking.
 *   S.haptic.pulse('join')   a sentence touches the edge of another one (end meets start): firm buzz
 *   S.haptic.pulse('guide')  the edge reaches the spot where the speech says the sentence should end: double buzz
 *   S.haptic.pulse('tick')   lighter alignment (same edge as another line, the playhead, the clip ends)
 * Uses navigator.vibrate: Android Chrome / Edge / Firefox. iPhone Safari has no web vibration, so there the visual highlight
 * (.snap-join / the green guide) is the only signal. The user can switch it off (the "สั่น" button in the timing bar).
 * ===================================================================== */
(function (S) {
  'use strict';
  const KEY = 'subed.haptic';
  let on = true, last = 0, lastPrio = 0;
  try { on = localStorage.getItem(KEY) !== '0'; } catch (e) {}
  const PATTERNS = { tick: 8, join: 24, guide: [16, 45, 16] }, PRIO = { tick: 1, join: 2, guide: 2 };
  S.haptic = {
    supported: typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function',
    get enabled() { return on; },
    setEnabled(v) { on = !!v; try { localStorage.setItem(KEY, on ? '1' : '0'); } catch (e) {} if (on) S.haptic.pulse('join', true); },
    pulse(kind, force) {
      if (!on || !S.haptic.supported) return false;
      const now = Date.now();
      const pr = PRIO[kind] || 1;
      if (!force && now - last < 60 && pr <= lastPrio) return false;   // never a machine-gun while a finger crosses several targets (a firmer buzz still cuts in on a light tick)
      last = now; lastPrio = pr;
      try { return navigator.vibrate(PATTERNS[kind] || PATTERNS.tick); } catch (e) { return false; }
    }
  };
})(window.SubEd);
