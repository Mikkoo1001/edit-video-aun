/* =====================================================================
 * UI: ONE shared "which words are selected" store for the line on screen — the single source of truth for every place
 * that colours / glows only some words.
 *
 * A selection is a contiguous range of word indices [a..b] of the active cue. When it is made in a text box it ALSO carries the exact
 * character range [cs..ce) the person picked (snapped to whole letters: a vowel / tone mark never separates from its consonant).
 * The words are cut at those two points (align() below), so a part of a word — e.g. only "มาส" out of "รมาส" — is a selection of its own
 * and can be coloured / glowed alone. The pieces are ordinary words flagged joined (no gap) with their own share of the word's timing.
 * It can be made three ways, all kept in step:
 *   - 'preview'  : press-and-hold a word on the picture, drag across words (or drag the two handles)   -> ui/word-color.js
 *   - 'picker'   : press-and-hold in the line's text box inside the สีเฉพาะคำ / เรืองแสง tabs and drag, exactly like selecting
 *                  text anywhere on the phone (native handles)                                         -> makePicker() below
 *   - 'teInput'  : the same, in the editable text bar at the top of the สไตล์ sheet                    -> ui/cc-color.js
 * Whoever changes it, every other view follows (picture outline, the other text box, the tab info lines).
 *
 * Painting goes through color() / glow() / clearStyle(): ONE undo step per gesture, and a text colour always brings its own
 * glow with it (word.glow in the same colour), so the word lights up in the colour it was just given.
 * Emits: wordsel:changed({src}).
 * ===================================================================== */
(function (S) {
  'use strict';
  const bus = S.bus, state = S.state, P = S.state.project;
  let cur = null;                                            // { id, text, a, b, src, cs?, ce? }  (cs / ce: the exact characters, text boxes only)
  let pickerSeq = 0, settleT = 0;
  const SETTLE_MS = 350;                                     // the selection stopped moving for this long -> cut the words at its ends

  const activeCue = () => P.subtitle.cues[state.ui.activeCue] || null;
  const valid = () => {
    const c = activeCue();
    return !!(cur && c && c.id === cur.id && c.text === cur.text && cur.a >= 0 && cur.a <= cur.b && cur.b < c.words.length);
  };

  /** where each word sits inside cue.text -> [{s,e}|null] (null = the word could not be found in the text) */
  function spans(c) {
    let pos = 0; const out = [];
    c.words.forEach(w => {
      const t = w.word.trim(), at = t ? c.text.indexOf(t, pos) : -1;
      if (at < 0) { out.push(null); return; }
      pos = at + t.length; out.push({ s: at, e: pos });
    });
    return out;
  }

  function clear(src) {
    clearTimeout(settleT); settleT = 0;
    if (!cur) return;
    cur = null;
    bus.emit('wordsel:changed', { src: src || 'system' });
  }

  function set(a, b, src, chars) {
    const c = activeCue();
    if (!c || !c.words.length) { clear(src); return; }
    const last = c.words.length - 1;
    a = Math.max(0, Math.min(last, a | 0)); b = Math.max(0, Math.min(last, b | 0));
    if (a > b) { const t = a; a = b; b = t; }
    const cs = chars ? chars.cs : null, ce = chars ? chars.ce : null;
    if (cur && valid() && cur.a === a && cur.b === b && (cur.cs == null ? null : cur.cs) === cs && (cur.ce == null ? null : cur.ce) === ce) return;   // nothing changed (also swallows the echo of a text box that was just told to show this selection)
    if (chars && cur && valid() && cur.cs == null && cur.a === a && cur.b === b) {     // a text box repeating back the selection it was just told to show (same words, whole words): nothing changed for anyone
      const ch = charsOf();
      if (ch && ch.s === cs && ch.e === ce) { cur.cs = cs; cur.ce = ce; return; }
    }
    cur = { id: c.id, text: c.text, a: a, b: b, src: src };
    if (chars) { cur.cs = cs; cur.ce = ce; }
    bus.emit('wordsel:changed', { src: src });
  }

  /** a character range of cue.text (what a text box reports) -> [first, last] word it touches, or null */
  function rangeOfChars(cs, ce) {
    const c = activeCue();
    if (!c || cs === ce) return null;
    if (cs > ce) { const t = cs; cs = ce; ce = t; }
    const sp = spans(c); let lo = -1, hi = -1;
    sp.forEach((r, i) => { if (r && r.s < ce && r.e > cs) { if (lo < 0) lo = i; hi = i; } });
    return lo < 0 ? null : [lo, hi];
  }
  /* ---- cutting words at the ends of a character selection --------------------------------------------------------------- */
  const MARK = /[\u0E31\u0E33-\u0E3A\u0E47-\u0E4E]/;       // Thai vowels above / below, sara am, tone marks: they belong to the consonant before them
  const GRAPHEMES = (typeof Intl !== 'undefined' && Intl.Segmenter) ? new Intl.Segmenter('th', { granularity: 'grapheme' }) : null;

  /** move an offset of `text` to the nearest whole-letter boundary: dir -1 = back (start of a selection), +1 = forward (end of it) */
  function snapOffset(text, i, dir) {
    i = Math.max(0, Math.min(text.length, i | 0));
    while (i > 0 && i < text.length && MARK.test(text.charAt(i))) i += dir;
    if (GRAPHEMES && i > 0 && i < text.length) {
      let prev = 0, hit = false;
      for (const g of GRAPHEMES.segment(text)) {
        const at = g.index;
        if (at >= i) { i = (at === i || dir > 0) ? at : prev; hit = true; break; }
        prev = at;
      }
      if (!hit) i = dir > 0 ? text.length : prev;               // inside the very last letter
    }
    return Math.max(0, Math.min(text.length, i));
  }

  /** put a word boundary at offset `pos` of cue.text when it falls inside a word: the word becomes two joined pieces that share its
   *  timing by length and keep its colour / glow. Returns true when a word was cut. */
  function splitAt(c, pos) {
    const sp = spans(c);
    for (let i = 0; i < c.words.length; i++) {
      const r = sp[i]; if (!r || !(pos > r.s && pos < r.e)) continue;
      const w = c.words[i], t = w.word.trim(), k = pos - r.s, mid = w.start + (w.end - w.start) * k / t.length;
      const left = Object.assign({}, w, { word: t.slice(0, k), end: mid });
      const right = Object.assign({}, w, { word: t.slice(k), joined: true, start: mid, sp: true });
      delete right.nl;                                           // the Enter (new row) belongs to the FIRST piece only: a word is never broken in the middle
      if (w.glow) { left.glow = Object.assign({}, w.glow); right.glow = Object.assign({}, w.glow); }
      c.words.splice(i, 1, left, right);
      return true;
    }
    return false;
  }
  /** pieces made earlier by a selection that never got a colour or glow go back together, so moving a selection around does not leave crumbs */
  function mergeShards(c) {
    let changed = false;
    for (let i = c.words.length - 1; i > 0; i--) {
      const w = c.words[i], p = c.words[i - 1];
      if (w.sp && w.joined && !w.color && !w.glow && !p.color && !p.glow) {
        p.word = p.word.trim() + w.word.trim(); p.end = w.end; c.words.splice(i, 1); changed = true;
      }
    }
    return changed;
  }

  /** make the selection's word range match its characters exactly (cut the words at both ends). Called when the selection has settled
   *  and right before anything is painted. No undo step of its own: cutting a word changes nothing that can be seen. */
  function align() {
    clearTimeout(settleT); settleT = 0;
    const c = activeCue();
    if (!cur || cur.cs == null || !valid()) return;
    const cs = cur.cs, ce = cur.ce;
    let changed = mergeShards(c);
    changed = splitAt(c, ce) || changed;                      // the later point first: it does not move the earlier word indices
    changed = splitAt(c, cs) || changed;
    const r = rangeOfChars(cs, ce);
    if (!r) { clear('system'); return; }
    const moved = r[0] !== cur.a || r[1] !== cur.b;
    cur.a = r[0]; cur.b = r[1];                               // the indices are right again BEFORE anyone is told
    if (changed) bus.emit('cue:text', { idx: state.ui.activeCue });
    if (changed || moved) bus.emit('wordsel:changed', { src: 'align' });
  }

  function setFromChars(cs, ce, src) {
    const c = activeCue();
    if (!c || cs === ce) { clear(src); return; }
    if (cs > ce) { const t = cs; cs = ce; ce = t; }
    cs = snapOffset(c.text, cs, -1); ce = snapOffset(c.text, ce, 1);
    const r = cs < ce ? rangeOfChars(cs, ce) : null;
    if (r) { set(r[0], r[1], src, { cs: cs, ce: ce }); clearTimeout(settleT); settleT = setTimeout(align, SETTLE_MS); }
    else clear(src);
  }

  function get() { return valid() ? { idx: state.ui.activeCue, a: cur.a, b: cur.b, src: cur.src, cs: cur.cs, ce: cur.ce } : null; }
  function words() { const g = get(), r = []; if (g) for (let i = g.a; i <= g.b; i++) r.push(i); return r; }
  /** the characters of cue.text the selection covers (to show it in a text box) */
  function charsOf() {
    const g = get(), c = activeCue(); if (!g || !c) return null;
    if (g.cs != null) return { s: g.cs, e: g.ce };            // picked in a text box: exactly those letters (not the whole words they touch)
    const sp = spans(c); let s = -1, e = -1;
    for (let i = g.a; i <= g.b; i++) if (sp[i]) { if (s < 0) s = sp[i].s; e = sp[i].e; }
    return s < 0 ? null : { s: s, e: e };
  }
  function labelOf(max) {
    const g = get(), c = activeCue(); if (!g || !c) return '';
    const t = g.cs != null ? c.text.slice(g.cs, g.ce).trim() : words().map(i => c.words[i].word.trim()).join(' ');
    return max && t.length > max ? t.slice(0, max - 1) + '…' : t;
  }

  /* ---- painting --------------------------------------------------------------------------------------------------------- */
  /** text colour of every selected word; each word also gets a glow in the same colour. null = clear colour + its glow.
   *  first (default true) = record an undo step (pass false while a colour wheel is being dragged). */
  function color(col, first) {
    align();
    const g = get(); if (!g) return false;
    if (first !== false && S.history) S.history.record('wordcolor');
    if (col && P.style.hlOff) { P.style.hlOff = false; bus.emit('style:changed'); }     // the "ไฮไลท์สี" switch was off: a colour you just picked must show, so it goes back on
    words().forEach(wi => S.subtitle.setWordColor(g.idx, wi, col || null, { history: false, clearGlow: !col }));
    return true;
  }
  /** glow only (patch as in setWordGlow); patch null = back to the line's glow */
  function glow(patch, first) {
    align();
    const g = get(); if (!g) return false;
    if (first !== false && S.history) S.history.record('wordglow');
    words().forEach(wi => S.subtitle.setWordGlow(g.idx, wi, patch, { history: false }));
    return true;
  }
  /** drop the own colour AND glow of the selected words */
  function clearStyle() {
    align();
    const g = get(); if (!g) return false;
    if (S.history) S.history.record('wordcolor');
    words().forEach(wi => S.subtitle.setWordColor(g.idx, wi, null, { history: false, clearGlow: true }));
    return true;
  }
  /** drop the own colour and glow of EVERY word of the line on screen */
  function clearLine() {
    const c = activeCue(); if (!c) return false;
    if (S.history) S.history.record('wordcolor');
    c.words.forEach((_, wi) => S.subtitle.setWordColor(state.ui.activeCue, wi, null, { history: false, clearGlow: true }));
    return true;
  }

  /* ---- the text box you select words in --------------------------------------------------------------------------------- */
  /**
   * A read-only copy of the line's text. Press-and-hold + drag selects characters like in any text field (native handles, no
   * keyboard); the words they touch become the selection. Other views' selections are shown in it too.
   * Returns { el, info, refresh }.
   */
  function makePicker(host, opts) {
    opts = opts || {};
    const id = 'picker' + (++pickerSeq);
    const wrap = document.createElement('div'); wrap.className = 'wp';
    const ta = document.createElement('textarea');
    ta.className = 'wp-text'; ta.readOnly = true; ta.rows = 2; ta.spellcheck = false; ta.autocomplete = 'off';
    ta.setAttribute('inputmode', 'none'); ta.setAttribute('aria-label', 'ข้อความของประโยค กดค้างแล้วลากเพื่อเลือกคำ (หรือแตะคำจากแถบด้านล่าง)');
    const info = document.createElement('div'); info.className = 'wp-info';
    wrap.appendChild(ta);
    makeChips(wrap);                                           // tap words instead of press-and-hold + drag
    wrap.appendChild(info); host.appendChild(wrap);

    const fit = () => { ta.style.height = 'auto'; ta.style.height = Math.min(Math.max(ta.scrollHeight + 2, 64), 170) + 'px'; };

    function refresh() {
      const c = activeCue(), g = get();
      const txt = c ? c.text : '';
      if (ta.value !== txt) ta.value = txt;                   // writing the value drops the native selection, so only when it really differs
      if (ta.offsetParent) fit();                             // measured only while it is on screen (a hidden tab reports height 0)
      ta.placeholder = c ? '' : 'เล่นวิดีโอไปที่ประโยคที่ต้องการก่อน';
      // show the shared selection here too — but never touch a native selection that already covers the same words
      // (rewriting it while the person drags the phone's own selection handles would make them jump)
      const mine = rangeOfChars(ta.selectionStart, ta.selectionEnd);
      if (g) {
        const ch = charsOf();
        if (ch && !(mine && mine[0] === g.a && mine[1] === g.b)) { try { ta.setSelectionRange(ch.s, ch.e); } catch (e) {} }
      } else if (ta.selectionStart !== ta.selectionEnd) {
        try { ta.setSelectionRange(ta.selectionEnd, ta.selectionEnd); } catch (e) {}
      }
      info.textContent = typeof opts.info === 'function' ? opts.info(g, c) : (g ? 'เลือกอยู่: ' + labelOf(60) : '');
      info.classList.toggle('on', !!g);
    }

    function read() {
      const c = activeCue();
      if (!c || ta.value !== c.text) return;
      setFromChars(ta.selectionStart, ta.selectionEnd, id);
    }
    // the line must stay put while words are being picked
    ['pointerdown', 'focus'].forEach(ev => ta.addEventListener(ev, () => { if (S.dom.video && !S.dom.video.paused) S.dom.video.pause(); }));
    ['select', 'keyup', 'mouseup', 'touchend', 'pointerup'].forEach(ev => ta.addEventListener(ev, () => setTimeout(read, 0)));
    ta.addEventListener('selectionchange', read);
    document.addEventListener('selectionchange', () => { if (document.activeElement === ta) read(); });
    ta.addEventListener('contextmenu', e => { if (e.pointerType === 'mouse') e.preventDefault(); });

    ['wordsel:changed', 'cue:active', 'cue:text', 'cues:structure', 'sheet:toggle'].forEach(e => bus.on(e, refresh));
    document.querySelectorAll('#subTabs button').forEach(b => b.addEventListener('click', () => setTimeout(refresh, 0)));   // its tab was just shown
    refresh();
    return { el: ta, info: info, refresh: refresh };
  }

  /**
   * A row of the line's words as buttons — the easy way to pick words (no press-and-hold, no dragging):
   *   tap a word            -> that word is selected
   *   then tap another word -> every word from the first to this one is selected
   *   tap the lone selected word again -> selection off · "ทั้งประโยค" -> the whole line
   * Returns { el, refresh }.
   */
  function makeChips(host) {
    const row = document.createElement('div'); row.className = 'wchips';
    host.appendChild(row);
    let sig = '', anchor = -1;
    const lastIdx = c => c.words.length - 1;
    function build() {
      const c = activeCue();
      const s = c ? c.id + '|' + c.words.map(w => w.word + '~' + (w.color || '')).join('\u0001') : '';
      if (s === sig) return;
      sig = s; row.innerHTML = '';
      row.hidden = !c || !c.words.length;
      if (row.hidden) return;
      const all = document.createElement('button'); all.type = 'button'; all.className = 'wchip wchip-all'; all.dataset.all = '1'; all.textContent = 'ทั้งประโยค';
      row.appendChild(all);
      c.words.forEach((w, i) => {
        const b = document.createElement('button'); b.type = 'button'; b.className = 'wchip'; b.dataset.i = i; b.textContent = w.word.trim() || '·';
        if (w.color) { b.classList.add('has'); b.style.setProperty('--wc', w.color); }
        row.appendChild(b);
      });
    }
    function mark() {
      const g = get(), c = activeCue();
      row.querySelectorAll('.wchip').forEach(b => {
        const on = !!g && (b.dataset.all ? (g.a === 0 && g.b === lastIdx(c)) : (+b.dataset.i >= g.a && +b.dataset.i <= g.b));
        b.classList.toggle('on', on);
      });
    }
    function refresh() { build(); mark(); }
    row.addEventListener('pointerdown', e => { if (e.target.closest('button')) e.preventDefault(); });   // keep the focus where it was
    row.addEventListener('click', e => {
      const b = e.target.closest('.wchip'), c = activeCue(); if (!b || !c) return;
      if (S.dom.video && !S.dom.video.paused) S.dom.video.pause();      // the line must stay put while words are being picked
      const g = get();
      if (b.dataset.all) { anchor = 0; set(0, lastIdx(c), 'chips'); return; }
      const i = +b.dataset.i;
      if (g && g.a === g.b && g.a === i) { anchor = -1; clear('chips'); return; }
      if (g && g.a === g.b && anchor === g.a) set(Math.min(anchor, i), Math.max(anchor, i), 'chips');
      else { anchor = i; set(i, i, 'chips'); }
    });
    ['cue:active', 'cue:text', 'cues:structure', 'sheet:toggle'].forEach(ev => bus.on(ev, refresh));
    bus.on('wordsel:changed', mark);
    refresh();
    return { el: row, refresh: refresh };
  }

  S.ui.wordSel = {
    makeChips: makeChips,
    get: get, words: words, set: set, clear: clear, setFromChars: setFromChars, rangeOfChars: rangeOfChars, charsOf: charsOf, labelOf: labelOf, spans: spans,
    color: color, glow: glow, clearStyle: clearStyle, align: align, clearLine: clearLine, makePicker: makePicker,
    init() {
      bus.on('cue:active', () => clear('system'));
      bus.on('cues:structure', () => clear('system'));
      bus.on('media:cleared', () => clear('system'));
      bus.on('cue:text', () => { if (cur && !valid()) clear('system'); });   // the line's text changed under it: the indices are stale
    }
  };
})(window.SubEd);
