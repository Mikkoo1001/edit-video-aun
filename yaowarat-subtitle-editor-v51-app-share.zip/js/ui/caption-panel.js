/* =====================================================================
 * UI: "บทบรรยาย" tab — AI transcription trigger, editable cue list, SRT/VTT.
 * Calls:   SubEd.ai.transcribe, SubEd.subtitle.regroup / removeCue / toSRT / toVTT
 * Emits:   cue:text, cues:structure (through the model helpers)
 * Listens: media:selected, media:cleared, cues:structure, cue:timing, cue:active, cue:select, history:changed
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus, fmt = S.util.fmt, state = S.state, P = state.project;
  const video = S.dom.video;
  const txList = $('txList'), txEmpty = $('txEmpty');

  function setStatus(msg, kind) {
    const el = $('genStatus');
    el.textContent = msg || '';
    el.className = 'status' + (kind ? ' ' + kind : '');
  }

  /** The clip became unreadable in the middle of an AI step (access lapsed, file on a cloud drive ...): offer to pick the SAME file
   *  again. Subtitles, style and trim stay; only the file the AI/export reads from is swapped (ui/media.js relink). */
  const relinkBtns = new Map();
  const isUnreadable = err => !!err && (err.unreadable || err.name === 'NotReadableError' || /อ่านไฟล์(คลิป)?(นี้)?ไม่ได้/.test(err.message || ''));
  function offerRelink(anchor, say) {
    let b = relinkBtns.get(anchor);
    if (!b) {
      b = document.createElement('button'); b.type = 'button'; b.className = 'genbtn'; b.style.marginTop = '8px';
      b.textContent = 'เลือกไฟล์คลิปเดิมอีกครั้ง (ซับไม่หาย)';
      const inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'video/*,audio/*,.mkv,.mov,.m4v'; inp.style.display = 'none';
      b.addEventListener('click', () => inp.click());
      inp.addEventListener('change', async () => {
        const f = inp.files && inp.files[0]; inp.value = ''; if (!f) return;
        b.disabled = true; say('กำลังอ่านไฟล์...', '');
        const r = await S.ui.media.relink(f);
        b.disabled = false;
        if (r.ok) { b.style.display = 'none'; say('ต่อไฟล์เดิมให้แล้ว — กดลองอีกครั้งได้เลย (ซับและสไตล์ไม่เปลี่ยน)', 'ok'); }
        else say(r.msg, 'err');
      });
      anchor.parentNode.insertBefore(b, anchor.nextSibling); anchor.parentNode.insertBefore(inp, b.nextSibling);
      relinkBtns.set(anchor, b);
    }
    b.style.display = '';
  }
  const hideRelink = () => relinkBtns.forEach(b => { b.style.display = 'none'; });

  const ICONS = {
    replay: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>',
    split: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 3v18M8 7l4-4 4 4M8 17l4 4 4-4"/></svg>',
    merge: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 4l4 5 4-5M8 20l4-5 4 5M12 9v6"/></svg>',
    dup: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M4 16V6a2 2 0 0 1 2-2h10"/></svg>',
    del: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2m-9 0 1 13h8l1-13"/></svg>',
    chev: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 9l6 6 6-6"/></svg>'
  };
  const SWATCHES = ['#ffffff', '#f5c518', '#33c9b6', '#ff6b6b', '#ff9f43', '#8ec5ff'];

  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  const cues = () => P.subtitle.cues;
  const indexOfCue = c => cues().indexOf(c);

  function actionBtn(cls, label, svg, onClick) {
    const b = el('button', 'tx-act ' + cls);
    b.type = 'button';
    b.title = label;
    b.innerHTML = svg + '<span>' + label + '</span>';
    b.addEventListener('click', onClick);
    return b;
  }

  function timeInput(cls, value) {
    const inp = document.createElement('input');
    inp.type = 'text'; inp.className = 'tx-tin ' + cls;
    inp.value = S.util.fmt2(value);
    inp.inputMode = 'decimal';
    inp.spellcheck = false;
    return inp;
  }

  // ---------- list scrolling: only ever the list box, never the page ----------
  let holdFollowUntil = 0;
  const reduceMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

  /** Bring `row` into view by scrolling the list box itself (element.scrollTo can't move the page, unlike scrollIntoView). */
  function revealInList(row, smooth) {
    if (!row || !txList.offsetParent) return;
    const top = row.offsetTop, bottom = top + row.offsetHeight;
    if (top >= txList.scrollTop && bottom <= txList.scrollTop + txList.clientHeight) return;
    txList.scrollTo({ top: Math.max(0, top - 6), behavior: smooth && !reduceMotion ? 'smooth' : 'auto' });
  }

  function followActive(idx) {
    if (!state.ui.followList || idx < 0 || Date.now() < holdFollowUntil) return;
    const ae = document.activeElement;
    if (ae && txList.contains(ae) && /^(INPUT|TEXTAREA)$/.test(ae.tagName)) return;   // never yank the list while someone is typing
    revealInList(txList.children[idx], true);
  }

  // ---------- selection ----------
  let enterId = null;                                              // the row that was just opened by a tap: it animates once, rebuilds don't replay it
  function select(id, opts) {
    state.ui.selectedId = id;
    enterId = id;
    renderTxList();
    enterId = null;
    if (id && !(opts && opts.reveal === false)) revealInList(txList.querySelector('.tx-row.selected'), false);
  }
  function selectIdx(idx, opts) { const c = cues()[idx]; if (c) select(c.id, opts); }

  function goToCue(c) {
    // a hair inside the cue, so a frame-rounded seek can't land just before it and hide the caption
    S.ui.player.seek(Math.min(c.start + 0.01, (c.start + c.end) / 2));
  }

  // ---------- one row ----------
  function buildEditor(c) {
    const ed = el('div', 'tx-editor');

    // text
    const ta = document.createElement('textarea');
    ta.className = 'tx-text-in';
    ta.rows = 2; ta.value = c.text; ta.spellcheck = false;
    ta.placeholder = 'พิมพ์ข้อความซับที่นี่...';
    ta.setAttribute('aria-label', 'ข้อความซับ');
    let recorded = false;                                     // one undo step per typing session
    ta.addEventListener('input', () => {
      if (!recorded && S.history) { S.history.record('text'); recorded = true; }
      S.subtitle.setCueText(indexOfCue(c), ta.value, { history: false });      // Enter = a new row in the caption (the only way it breaks into rows)
      autosize(ta);
      const label = txList.querySelector('.tx-row[data-id="' + c.id + '"] .tx-text');
      if (label) { const has = !!c.text.trim(); label.textContent = has ? c.text.replace(/\n/g, ' ↵ ') : 'ประโยคว่าง — แตะเพื่อพิมพ์'; label.classList.toggle('blank', !has); }
    });
    ta.addEventListener('blur', () => { recorded = false; });
    ed.appendChild(ta);

    // colours
    const resetBtn = el('button', 'tx-reset', 'ใช้สไตล์ตามค่าหลัก (ล้างค่าเฉพาะประโยคนี้)');
    resetBtn.type = 'button';
    const syncReset = () => { resetBtn.style.display = c.style ? '' : 'none'; };
    resetBtn.addEventListener('click', () => { S.subtitle.setCueStyle(indexOfCue(c), null); renderTxList(); });

    function colorRow(label, key, fallback, withSwatches) {
      const row = el('div', 'row');
      row.appendChild(el('label', null, label));
      const field = el('div', 'field tx-cfield');
      const inp = document.createElement('input');
      inp.type = 'color'; inp.value = (c.style && c.style[key]) || fallback;
      inp.setAttribute('aria-label', label);
      let rec = false;
      const sw = [];
      const paintSwatches = () => sw.forEach(b => b.classList.toggle('on', b.dataset.c === inp.value.toLowerCase()));
      inp.addEventListener('input', () => {
        if (!rec && S.history) { S.history.record('style'); rec = true; }
        S.subtitle.setCueStyle(indexOfCue(c), { [key]: inp.value }, { history: false });
        paintSwatches(); syncReset(); paintDot(c);
      });
      inp.addEventListener('change', () => { rec = false; });
      if (withSwatches) {
        const wrap = el('div', 'tx-swatches');
        SWATCHES.forEach(hex => {
          const b = el('button', 'tx-sw'); b.type = 'button';
          b.dataset.c = hex; b.style.background = hex; b.title = hex; b.setAttribute('aria-label', label + ' ' + hex);
          b.addEventListener('click', () => {
            S.subtitle.setCueStyle(indexOfCue(c), { [key]: hex });
            inp.value = hex; paintSwatches(); syncReset(); paintDot(c);
          });
          sw.push(b); wrap.appendChild(b);
        });
        field.appendChild(wrap);
        paintSwatches();
      }
      field.appendChild(inp);
      row.appendChild(field);
      return row;
    }
    ed.appendChild(colorRow('สีตัวอักษร', 'color', P.style.color, true));
    if (P.style.karaoke) ed.appendChild(colorRow('สีไฮไลต์คำ', 'highlight', P.style.highlight, false));
    if (P.style.bg.on) ed.appendChild(colorRow('สีพื้นหลัง', 'bgColor', P.style.bg.color, false));

    // timing
    const trow = el('div', 'row');
    trow.appendChild(el('label', null, 'เวลา'));
    const tfield = el('div', 'field tx-tedit');
    const sIn = timeInput('tin-start', c.start), eIn = timeInput('tin-end', c.end);
    const commit = () => {
      const ns = S.util.parseTime(sIn.value), ne = S.util.parseTime(eIn.value);
      if (isNaN(ns) || isNaN(ne)) { sIn.value = S.util.fmt2(c.start); eIn.value = S.util.fmt2(c.end); return; }
      S.subtitle.setCueTiming(indexOfCue(c), ns, ne);
    };
    [sIn, eIn].forEach(inp => {
      inp.addEventListener('change', commit);
      inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); inp.blur(); } });
    });
    tfield.appendChild(sIn); tfield.appendChild(document.createTextNode('–')); tfield.appendChild(eIn);
    trow.appendChild(tfield);
    ed.appendChild(trow);

    // actions
    const actions = el('div', 'tx-actions');
    actions.appendChild(actionBtn('act-replay', 'ฟัง', ICONS.replay, () => S.ui.player.replay(c.start, c.end)));
    actions.appendChild(actionBtn('act-split', 'แยก', ICONS.split, () => {
      const t = video.currentTime;
      const at = S.subtitle.splitCue(indexOfCue(c), (t > c.start && t < c.end) ? t : undefined);
      if (at >= 0) selectIdx(at);
    }));
    actions.appendChild(actionBtn('act-merge', 'รวมถัดไป', ICONS.merge, () => {
      const at = S.subtitle.mergeCueWithNext(indexOfCue(c));
      if (at >= 0) selectIdx(at);
    }));
    actions.appendChild(actionBtn('act-dup', 'ทำซ้ำ', ICONS.dup, () => {
      const at = S.subtitle.duplicateCue(indexOfCue(c));
      if (at >= 0) selectIdx(at);
    }));
    actions.appendChild(actionBtn('act-del', 'ลบ', ICONS.del, () => S.subtitle.removeCue(indexOfCue(c))));
    ed.appendChild(actions);
    ed.appendChild(resetBtn);
    syncReset();
    return ed;
  }

  function autosize(ta) { ta.style.height = 'auto'; ta.style.height = Math.max(ta.scrollHeight, 48) + 'px'; }

  /** The small colour dot on a collapsed row that says "this line has its own colours". */
  function paintDot(c) {
    const row = txList.querySelector('.tx-row[data-id="' + c.id + '"]');
    const dot = row && row.querySelector('.tx-dot');
    if (!dot) return;
    const own = c.style && (c.style.color || c.style.highlight || c.style.bgColor);
    dot.style.display = c.style ? '' : 'none';              // any own setting (colour or look) shows the dot
    if (c.style) dot.style.background = own || '#19b6d6';
  }

  function buildRow(c, i) {
    const selected = c.id === state.ui.selectedId;
    const row = el('div', 'tx-row' + (i === state.ui.activeCue ? ' active' : '') + (selected ? ' selected' : '') + (selected && c.id === enterId ? ' tx-enter' : ''));
    row.dataset.idx = i; row.dataset.id = c.id;

    const head = el('button', 'tx-head');
    head.type = 'button';
    head.setAttribute('aria-expanded', selected ? 'true' : 'false');
    head.title = selected ? 'แตะเพื่อปิด' : 'แตะเพื่อแก้ไขประโยคนี้';

    const tc = el('span', 'tx-tc');
    tc.appendChild(el('b', null, S.util.fmt2(c.start)));
    tc.appendChild(el('i', null, S.util.fmt2(c.end)));
    head.appendChild(tc);

    const hasText = !!(c.text && c.text.trim());
    head.appendChild(el('span', 'tx-text' + (hasText ? '' : ' blank'), hasText ? c.text.replace(/\n/g, ' ↵ ') : 'ประโยคว่าง — แตะเพื่อพิมพ์'));

    head.appendChild(el('span', 'tx-dot'));
    const chev = el('span', 'tx-chev'); chev.innerHTML = ICONS.chev; head.appendChild(chev);

    head.addEventListener('click', () => {
      if (selected) { select(null); return; }
      select(c.id);
      goToCue(c);
    });
    row.appendChild(head);
    if (selected) row.appendChild(buildEditor(c));
    return row;
  }

  function renderTxList() {
    const ae = document.activeElement;
    const keep = ae && txList.contains(ae) ? {
      id: ae.closest('.tx-row') && ae.closest('.tx-row').dataset.id,
      cls: ae.classList.contains('tx-text-in') ? 'tx-text-in' : ae.classList.contains('tin-end') ? 'tin-end' : ae.classList.contains('tin-start') ? 'tin-start' : null,
      pos: ae.selectionStart
    } : null;
    const prevTop = txList.scrollTop;

    txList.innerHTML = '';
    const list = cues();
    txEmpty.style.display = list.length ? 'none' : '';
    txList.style.display = list.length ? '' : 'none';
    list.forEach((c, i) => txList.appendChild(buildRow(c, i)));
    txList.scrollTop = prevTop;                                  // a rebuild must not throw the list back to the top

    const ta = txList.querySelector('.tx-text-in');
    if (ta) autosize(ta);
    if (keep && keep.id && keep.cls) {
      const t = txList.querySelector('.tx-row[data-id="' + keep.id + '"] .' + keep.cls);
      if (t) { t.focus({ preventScroll: true }); try { t.setSelectionRange(keep.pos, keep.pos); } catch (e) {} }
    }
    const list2 = cues();
    list2.forEach(paintDot);
  }

  function syncHistoryButtons() {
    const u = $('txUndo'), r = $('txRedo');
    if (u) u.disabled = !S.history || !S.history.canUndo();
    if (r) r.disabled = !S.history || !S.history.canRedo();
  }

  let msgTimer = null;
  function flashMsg(msg) {
    const m = $('txMsg');
    m.textContent = msg;
    clearTimeout(msgTimer);
    msgTimer = setTimeout(() => { m.textContent = ''; }, 3500);
  }

  function download(content, filename, mime) {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 4000);       // revoking at once can cancel / empty the download on Safari and Firefox
  }

  S.ui.captionPanel = {
    init() {
      const bk = S.builtinKeys || {};                       // personal build: keys pre-filled (see core/builtin-keys.js)
      if (bk.groq && !$('apiKey').value) $('apiKey').value = bk.groq;
      if (bk.gemini && !$('geminiKey').value) $('geminiKey').value = bk.gemini;
      const tb = $('geminiTest');
      if (tb) tb.addEventListener('click', async () => {         // real round trip with the key, so the exact reason shows up on the phone
        const out = $('geminiTestMsg'); tb.disabled = true; out.style.color = ''; out.textContent = 'กำลังทดสอบ...';
        const r = S.ai && S.ai.testGeminiKey ? await S.ai.testGeminiKey($('geminiKey').value, $('geminiModel').value) : { ok: false, message: 'ไม่พบตัวทดสอบ' };
        out.style.color = r.ok ? 'var(--ok, #3ecf8e)' : 'var(--danger, #ff6b6b)'; out.textContent = r.message; tb.disabled = false;
      });
      const seg = () => P.subtitle.segmentation;            // read fresh every time: undo / redo replace this object
      const readSeg = () => {
        const g = seg();
        g.strategy = $('segMode').value;
        g.wordsPerLine = parseInt($('wplR').value, 10);
        g.maxChars = parseInt($('maxCharsR').value, 10);
      };
      const rhythmText = () => {
        const r = S.subtitle.normalizeRhythm(seg().rhythm) || (S.styleCopy && S.subtitle.normalizeRhythm((S.styleCopy.lastProfile || S.styleCopy.REFERENCE_1).layout.rhythm));
        if (!r) return '';
        return 'ขนาดประโยคตามต้นแบบ: ' + r.min.w + '–' + r.max.w + ' คำต่อบรรทัด (ส่วนใหญ่ ' + r.typical.w + ' คำ · ~' + r.typical.c + ' ตัวอักษร) ทั้งคลิป · ตัดตามจังหวะเสียงพูด (ช่วงหยุด จบประโยค) · เลือกต้นแบบได้ที่ สไตล์ › คัดลอกสไตล์';
      };
      const showRows = () => {
        const mode = $('aiMode').value, strat = $('segMode').value;
        $('rowGroq').style.display = mode === 'gemini' ? 'none' : '';
        $('rowGemini').style.display = mode === 'groq-whisper' ? 'none' : '';
        $('rowGeminiModel').style.display = mode === 'groq-whisper' ? 'none' : '';
        $('rowMaxChars').style.display = strat === 'smart' ? '' : 'none';
        $('rowWpl').style.display = strat === 'words-per-line' ? '' : 'none';
        $('rowRhythm').style.display = strat === 'rhythm' ? '' : 'none';
        if (strat === 'rhythm') $('rhythmInfo').textContent = rhythmText();
      };
      // the model's segmentation changed from elsewhere (style copy, undo / redo): show it in the controls
      const syncSegUi = () => {
        const g = seg();
        if (g.strategy && $('segMode').querySelector('option[value="' + g.strategy + '"]')) $('segMode').value = g.strategy;
        if (g.wordsPerLine) { $('wplR').value = g.wordsPerLine; $('wplNum').textContent = $('wplR').value; }
        if (g.maxChars) { $('maxCharsR').value = Math.min(48, Math.max(12, g.maxChars)); $('maxCharsNum').textContent = $('maxCharsR').value; }
        showRows();
      };
      bus.on('segmentation:changed', syncSegUi);
      const reflow = () => { readSeg(); if (P.subtitle.cues.length) S.subtitle.regroup({ from: 'cues' }); };
      // Gemini cuts the lines it returns to this length: with a reference rhythm that is the reference's longest line
      const aiMaxChars = () => { const g = seg(); if (g.strategy !== 'rhythm') return g.maxChars; const r = S.subtitle.normalizeRhythm(g.rhythm) || S.subtitle.normalizeRhythm((S.styleCopy.lastProfile || S.styleCopy.REFERENCE_1).layout.rhythm); return r ? r.max.c + 2 : g.maxChars; };
      readSeg(); showRows();
      $('aiMode').addEventListener('change', showRows);
      $('segMode').addEventListener('change', () => { showRows(); reflow(); });
      $('wplR').addEventListener('input', () => { $('wplNum').textContent = $('wplR').value; readSeg(); });
      $('wplR').addEventListener('change', reflow);
      $('maxCharsR').addEventListener('input', () => { $('maxCharsNum').textContent = $('maxCharsR').value; readSeg(); });
      $('maxCharsR').addEventListener('change', reflow);

      // with sentences on the timeline the main button re-times them instead of throwing them away and writing new ones
      const keepSentences = () => P.subtitle.cues.length > 0 && $('reuseMode').value === 'keep';
      const syncReuse = () => {
        const has = P.subtitle.cues.length > 0;
        $('rowReuse').style.display = has ? '' : 'none';
        $('reuseHint').style.display = has && $('reuseMode').value === 'keep' ? '' : 'none';
        $('genBtn').textContent = keepSentences() ? 'AI ปรับเวลาให้ตรงเสียง (ใช้ประโยคเดิม)' : 'สร้างซับอัตโนมัติ';
      };
      $('reuseMode').addEventListener('change', syncReuse);
      bus.on('cues:structure', syncReuse);
      syncReuse();

      $('genBtn').addEventListener('click', async () => {
        const mode = $('aiMode').value;
        const groqKey = $('apiKey').value.trim(), geminiKey = $('geminiKey').value.trim();
        if (S.ui.media && S.ui.media.copying()) { setStatus('รอเก็บสำเนาคลิปให้เสร็จก่อนสักครู่...', ''); await S.ui.media.settled(); }
        const file = P.media.file;
        if (!file) { setStatus('กรุณาวางคลิปวิดีโอก่อน', 'err'); return; }
        if (mode !== 'gemini' && !groqKey) { setStatus('กรุณาใส่ Groq API Key ก่อน (ขอฟรีได้ที่ console.groq.com/keys)', 'err'); return; }
        if (mode !== 'groq-whisper' && !geminiKey && mode === 'gemini') { setStatus('กรุณาใส่ Gemini API Key ก่อน (ขอฟรีได้ที่ aistudio.google.com/apikey)', 'err'); return; }
        // Groq + Gemini without a Gemini key: still useful, run Groq alone and say so
        const provider = (mode === 'groq-gemini' && !geminiKey) ? 'groq-whisper' : mode;
        readSeg();
        hideRelink();
        $('genBtn').disabled = true;
        $('progress').classList.add('show');
        $('progressBar').style.width = '0%';
        $('progress').classList.remove('busy');
        setStatus('กำลังเริ่มทำงาน...', '');
        if (keepSentences()) {                               // sentences already exist: keep every one, only fit their length to the voice
          try {
            const r = await S.ai.realign({
              file: file, language: $('langSel').value,
              provider: mode === 'gemini' ? 'gemini' : 'groq-whisper', apiKey: groqKey, geminiKey: geminiKey, geminiModel: $('geminiModel').value, maxChars: aiMaxChars(),
              onStatus: msg => setStatus(msg, ''),
              onProgress: pct => { $('progressBar').style.width = pct + '%'; if (pct >= 100) $('progress').classList.add('busy'); }
            });
            setStatus('ปรับเวลาให้ตรงเสียงแล้ว: ขยับ ' + r.changed + ' ประโยค (ตรงกับเสียง ' + r.matched + '/' + r.total + ' คำ) · ประโยคและเลนเดิมไม่เปลี่ยน · กด เลิกทำ ได้', 'ok');
          } catch (err) {
            setStatus('ไม่สำเร็จ: ' + err.message, 'err');
            if (isUnreadable(err)) offerRelink($('genStatus'), setStatus);
          } finally {
            $('progress').classList.remove('show', 'busy');
            $('genBtn').disabled = false;
          }
          return;
        }
        try {
          const result = await S.ai.transcribe({
            provider: provider, file: file, language: $('langSel').value,
            apiKey: groqKey, geminiKey: geminiKey, geminiModel: $('geminiModel').value,
            maxChars: aiMaxChars(),
            onStatus: msg => setStatus(msg, ''),
            onProgress: pct => {
              $('progressBar').style.width = pct + '%';
              if (pct >= 100) $('progress').classList.add('busy');
            }
          });
          if (!result.words.length) {
            setStatus('ไม่พบคำพูดในคลิปนี้', 'err');
            $('progress').classList.remove('show', 'busy');
            $('genBtn').disabled = false;
            return;
          }
          P.subtitle.words = result.words;
          readSeg();
          S.subtitle.regroup();
          $('progress').classList.remove('show', 'busy');
          let msg = 'สร้างซับสำเร็จ ' + P.subtitle.cues.length + ' บรรทัด', kind = 'ok';
          if (result.groqRejected) { msg += ' — คีย์ Groq ใช้ไม่ได้ จึงให้ Gemini ถอดเสียงเองทั้งหมด (ใส่คีย์ Groq ใหม่ถ้าอยากใช้ Groq)'; kind = ''; }
          else if (mode === 'groq-gemini' && !geminiKey) { msg += ' (ไม่ได้ใส่ Gemini Key จึงใช้ Groq อย่างเดียว)'; }
          else if (result.refineError) { msg += ' — Gemini ใช้ไม่ได้ (' + result.refineError + ') จึงใช้ผลจาก Groq แทน'; kind = ''; }
          else if (result.refineSkipped) { msg += ' (Gemini เกลาไม่สำเร็จ ' + result.refineSkipped + ' ช่วง ใช้ผลจาก Groq แทนในช่วงนั้น)'; }
          setStatus(msg, kind);
        } catch (err) {
          $('progress').classList.remove('show', 'busy');
          const hi = isUnreadable(err) && S.ui.media && S.ui.media.holdInfo ? S.ui.media.holdInfo() : '';
          setStatus('เกิดข้อผิดพลาด: ' + err.message + (hi ? ' {' + hi + '}' : ''), 'err');
          if (isUnreadable(err)) offerRelink($('genStatus'), setStatus);
        } finally {
          $('genBtn').disabled = false;
        }
      });

      $('realignBtn').addEventListener('click', async () => {
        const st = $('realignStatus'), btn = $('realignBtn'), say = (m, k) => { st.textContent = m; st.className = 'status' + (k ? ' ' + k : ''); };
        const key = $('apiKey').value.trim();
        if (!P.media.file) { say('กรุณาวางคลิปวิดีโอก่อน', 'err'); return; }
        if (!P.subtitle.cues.length) { say('ยังไม่มีซับให้จับเวลา', 'err'); return; }
        if (!key) { say('ใส่ Groq API Key ด้านบนก่อน (ใช้ฟังเสียงเพื่อจับเวลาเท่านั้น)', 'err'); return; }
        btn.disabled = true; say('กำลังฟังเสียง...', '');
        try {
          if (S.ui.media && S.ui.media.copying()) { say('รอเก็บสำเนาคลิปให้เสร็จก่อนสักครู่...', ''); await S.ui.media.settled(); }
          const r = await S.ai.realign({ file: P.media.file, apiKey: key, language: $('langSel').value, onStatus: m => say(m, '') });
          say('จับเวลาแล้ว: ปรับ ' + r.changed + ' ประโยค (ตรงกับเสียง ' + r.matched + '/' + r.total + ' คำ) · ข้อความไม่เปลี่ยน · กด เลิกทำ ได้', 'ok');
        } catch (err) { say('ไม่สำเร็จ: ' + err.message, 'err'); if (isUnreadable(err)) offerRelink(st, say); }
        finally { btn.disabled = false; }
      });

      $('expSrt').addEventListener('click', () => {
        const cues = S.subtitle.exportCues(P, S.ui.exportPanel && S.ui.exportPanel.range ? S.ui.exportPanel.range() : null);
        if (!cues.length) return;
        download(S.subtitle.toSRT(cues), 'subtitle.srt', 'text/plain;charset=utf-8');
      });
      $('expVtt').addEventListener('click', () => {
        const cues = S.subtitle.exportCues(P, S.ui.exportPanel && S.ui.exportPanel.range ? S.ui.exportPanel.range() : null);
        if (!cues.length) return;
        download(S.subtitle.toVTT(cues), 'subtitle.vtt', 'text/plain;charset=utf-8');
      });

      // ---- toolbar ----
      $('txUndo').addEventListener('click', () => { if (S.history) S.history.undo(); });
      $('txRedo').addEventListener('click', () => { if (S.history) S.history.redo(); });
      $('txAdd').addEventListener('click', () => {
        if (!P.media.duration) return;
        const idx = S.subtitle.addCue(video.currentTime);
        if (idx < 0) { flashMsg('ไม่มีช่วงว่างตรงนี้ ลองเลื่อนวิดีโอไปจุดอื่นที่ยังไม่มีซับ'); return; }
        selectIdx(idx);
        const ta = txList.querySelector('.tx-row.selected .tx-text-in');
        if (ta) ta.focus({ preventScroll: true });
      });
      const followBtn = $('txFollow');
      const paintFollow = () => followBtn.setAttribute('aria-pressed', state.ui.followList ? 'true' : 'false');
      followBtn.addEventListener('click', () => { state.ui.followList = !state.ui.followList; paintFollow(); });
      paintFollow();
      bus.on('history:changed', syncHistoryButtons);
      syncHistoryButtons();

      // someone is scrolling the list themselves: leave it alone for a few seconds
      ['wheel', 'touchstart', 'pointerdown'].forEach(ev => txList.addEventListener(ev, () => { holdFollowUntil = Date.now() + 4000; }, { passive: true }));

      // Ctrl/Cmd+Z, Shift+Ctrl/Cmd+Z, Ctrl/Cmd+Y — only when no text field has focus (fields keep their own undo)
      document.addEventListener('keydown', e => {
        if (!(e.ctrlKey || e.metaKey) || e.altKey || !S.history) return;
        const t = e.target, tag = t && t.tagName;
        if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || (t && t.isContentEditable)) return;
        const k = e.key.toLowerCase();
        if (k === 'z' && !e.shiftKey) { if (S.history.undo()) e.preventDefault(); }
        else if ((k === 'z' && e.shiftKey) || k === 'y') { if (S.history.redo()) e.preventDefault(); }
      });

      // ---- model events ----
      bus.on('cues:structure', e => {
        if (e.reason === 'undo' || e.reason === 'redo' || e.reason === 'restore') syncSegUi();
        if (e.reason === 'reset') { state.ui.selectedId = null; setStatus(''); }
        else if (state.ui.selectedId && !cues().some(c => c.id === state.ui.selectedId)) state.ui.selectedId = null;
        renderTxList();
      });
      bus.on('cue:timing', renderTxList);
      bus.on('cue:select', e => selectIdx(e.idx));
      bus.on('sheet:toggle', e => { if (e.open && e.tab === 'caption') renderTxList(); });   // per-line settings may have changed in the style sheet
      bus.on('cue:active', e => {
        txList.querySelectorAll('.tx-row').forEach((r, i) => r.classList.toggle('active', i === e.idx));
        followActive(e.idx);
      });
      renderTxList();
      bus.on('media:selected', file => {
        S.project.resetSubtitle();
        if (file.size > 20 * 1024 * 1024) {
          setStatus('ไฟล์ใหญ่ (' + (file.size / 1024 / 1024).toFixed(0) + ' MB) ระบบจะแยกเสียงและถอดเป็นช่วงๆ ช่วงละ 10 นาที อาจใช้เวลาสักครู่', '');
        } else {
          setStatus('');
        }
      });
      bus.on('media:cleared', () => S.project.resetSubtitle());
    }
  };
})(window.SubEd);
