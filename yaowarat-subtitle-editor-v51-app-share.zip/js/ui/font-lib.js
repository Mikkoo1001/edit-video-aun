/* =====================================================================
 * UI: คลังฟอนต์ (moved from Shadow Caption Lab), on top of the font grid of the ฟอนต์ tab.
 *   - the Thai font families of the lab are plain options of #fontSel (files in /fonts, declared in css/fonts-lib.css — the browser
 *     downloads a face only when a letter of it is drawn), so they show up as tiles in "ทั้งหมด", can be bookmarked, and the export draws them
 *   - a search box + category chips (เรียบ / มีหัว / มีเชิง / ลายมือ / ตัวโชว์ / ของฉัน / กำหนดเอง) filter the tiles
 *   - "เพิ่มฟอนต์": upload font files (.otf .ttf .woff .woff2, several at once or a whole folder; weights are read from the file names and
 *     the families are kept in this browser's IndexedDB), type any Google Fonts name, or read the fonts installed on this device
 * Uploaded / typed fonts become one more option + tile each (ui/cc-color.js addFontOption). Nothing is uploaded anywhere.
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus;
  const CATS = [['all', 'ทั้งหมด'], ['sans', 'เรียบ'], ['looped', 'มีหัว'], ['serif', 'มีเชิง'], ['hand', 'ลายมือ'], ['display', 'ตัวโชว์'], ['mine', 'ของฉัน'], ['custom', 'กำหนดเอง']];
  const WMAP = [['extralight', 200], ['extra light', 200], ['ultralight', 200], ['extrabold', 800], ['extra bold', 800], ['semibold', 600], ['semi bold', 600],
    ['demibold', 600], ['hairline', 100], ['heavy', 800], ['thin', 100], ['light', 300], ['medium', 500], ['regular', 400], ['bold', 700], ['black', 900]];
  const WORD_RE = '(?:thin|hairline|extra[-_ ]?light|ultra[-_ ]?light|extra[-_ ]?bold|semi[-_ ]?bold|demi[-_ ]?bold|light|medium|regular|bold|black|heavy)';
  const NAME_OK = /^[^"'\\;{}<>]{1,60}$/;
  const KEY_CUSTOM = 'yaowarat.customFonts.v1';
  const USER = new Map();      // family -> { weights: [], faces: {} }   uploaded files
  const CUSTOM = new Map();    // family -> { weights: [], local: bool }  Google Fonts names / installed fonts
  let q = '', cat = 'all', note = null, mineBox = null, idbFailed = false;

  const css = fam => "'" + fam + "',sans-serif";
  const sel = () => $('fontSel');
  const hasOption = value => Array.from(sel().options).some(o => o.value === value && !o.dataset.temp);
  const nearest = (list, target) => list.reduce((b, w) => (Math.abs(w - target) < Math.abs(b - target) ? w : b), list[0]);
  const say = (text, warn) => { if (!note) return; note.textContent = text; note.className = 'hint fl-note' + (warn ? ' warn' : ''); };

  // ---- filter -----------------------------------------------------------------------------------------------------
  function applyFilter() {
    const grid = $('fontGrid'); if (!grid) return;
    const on = !!q || cat !== 'all';
    let shown = 0;
    grid.querySelectorAll('.font-chip').forEach(chip => {
      const small = chip.querySelector('small'), name = (small ? small.textContent : '').toLowerCase();
      const ok = (cat === 'all' || chip.dataset.cat === cat) && (!q || name.indexOf(q) > -1);
      chip.dataset.fhide = ok ? '0' : '1';
      chip.dataset.fsearch = on ? '1' : '0';
      if (ok) shown++;
    });
    if (S.ui.fontFav) S.ui.fontFav.repaint();
    const c = $('flCount'); if (c) c.textContent = on ? 'พบ ' + shown + ' ฟอนต์' : '';
  }
  function buildFilter() {
    const grid = $('fontGrid');
    const bar = document.createElement('div'); bar.className = 'fl-bar';
    bar.innerHTML = '<input type="search" id="flSearch" placeholder="ค้นหาชื่อฟอนต์" aria-label="ค้นหาฟอนต์" autocomplete="off"><div class="fl-cats" id="flCats"></div><div class="hint" id="flCount"></div>';
    grid.parentNode.insertBefore(bar, grid);
    const box = bar.querySelector('#flCats');
    CATS.forEach(c => { const b = document.createElement('button'); b.type = 'button'; b.dataset.c = c[0]; b.textContent = c[1]; if (c[0] === 'all') b.className = 'on'; box.appendChild(b); });
    box.addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return;
      cat = b.dataset.c; box.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); applyFilter();
    });
    bar.querySelector('#flSearch').addEventListener('input', e => { q = e.target.value.trim().toLowerCase(); applyFilter(); });
  }

  // ---- IndexedDB for uploaded fonts -------------------------------------------------------------------------------------
  let dbp = null;
  function db() {
    if (!dbp) dbp = new Promise((res, rej) => {
      try {
        const r = indexedDB.open('yaowarat-fonts', 1);
        r.onupgradeneeded = () => { r.result.createObjectStore('fonts', { keyPath: 'key' }); };
        r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); r.onblocked = () => rej(new Error('blocked'));
      } catch (e) { rej(e); }
    });
    return dbp;
  }
  function tx(mode, fn) {
    return db().then(d => new Promise((res, rej) => {
      const t = d.transaction('fonts', mode), r = fn(t.objectStore('fonts'));
      t.oncomplete = () => res(r && r.result); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error);
    }));
  }
  const idbAll = () => tx('readonly', s => s.getAll());
  const idbPut = rec => tx('readwrite', s => s.put(rec));
  const idbDelFamily = fam => tx('readwrite', s => {
    const req = s.openCursor();
    req.onsuccess = () => { const c = req.result; if (c) { if (c.value.family === fam) c.delete(); c.continue(); } };
    return req;
  });

  // ---- options / tiles ----------------------------------------------------------------------------------------------------
  function ensureOption(family, cat2) {
    const value = css(family);
    const tmp = Array.from(sel().options).find(o => o.value === value && o.dataset.temp);
    if (tmp) tmp.remove();                                            // a stand-in made while this font was not loaded yet
    if (!hasOption(value)) S.ui.ccColor.addFontOption(value, family, cat2);
    return value;
  }
  function pick(value, weight) {
    const s = sel(), i = Array.from(s.options).findIndex(o => o.value === value && !o.dataset.temp);
    if (i < 0) return;
    if (weight) { $('weightR').value = weight; $('weightNum').textContent = weight; }
    s.selectedIndex = i;
    s.dispatchEvent(new Event('input', { bubbles: true })); s.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // ---- uploaded font files ------------------------------------------------------------------------------------------------
  function parseName(fn) {
    const base = fn.replace(/\.[^.]+$/, '').replace(/\s*\(\d+\)$/, ''), lower = base.toLowerCase();
    if (/italic|oblique/.test(lower)) return { skip: true };
    let range = null, weight = 400;
    if (/\[wght\]|variable/i.test(base)) range = '100 900';
    else { for (let i = 0; i < WMAP.length; i++) { if (lower.indexOf(WMAP[i][0]) > -1) { weight = WMAP[i][1]; break; } } }
    let fam = base.replace(/\[[^\]]*\]/g, '').replace(/[-_ ]*variable/i, '');
    let stripped = fam.replace(new RegExp('[-_\\s]+' + WORD_RE + '$', 'i'), '');
    if (stripped === fam) stripped = fam.replace(new RegExp(WORD_RE + '$', 'i'), '');
    fam = (stripped || fam).replace(/[-_]+$/, '').trim() || base;
    if (hasOption(css(fam)) && !USER.has(fam)) fam += ' (ไฟล์ของฉัน)';             // never shadow a font that is already in the list
    return { family: fam.replace(/["'\\;{}<>]/g, ''), weight: weight, range: range };
  }
  function registerUser(rec, persist) {
    const wkey = rec.range ? rec.range : String(rec.weight);
    const face = new FontFace(rec.family, rec.buf.slice(0), { weight: wkey, style: 'normal' });
    return face.load().then(() => {
      document.fonts.add(face);
      let u = USER.get(rec.family);
      if (!u) { u = { weights: [], faces: {} }; USER.set(rec.family, u); }
      if (u.faces[wkey]) document.fonts.delete(u.faces[wkey]);
      u.faces[wkey] = face;
      (rec.range ? [100, 200, 300, 400, 500, 600, 700, 800, 900] : [rec.weight]).forEach(x => { if (u.weights.indexOf(x) < 0) u.weights.push(x); });
      u.weights.sort((a, b) => a - b);
      ensureOption(rec.family, 'mine');
      if (persist) return idbPut({ key: rec.family + '|' + wkey, family: rec.family, weight: rec.weight, range: rec.range || null, buf: rec.buf }).catch(() => { idbFailed = true; });
    });
  }
  function addFiles(list) {
    const all = Array.prototype.slice.call(list || []), files = all.filter(f => /\.(otf|ttf|woff2?)$/i.test(f.name));
    if (!files.length) { say('ไม่พบไฟล์ .otf .ttf .woff หรือ .woff2 ในที่เลือก', true); return; }
    let ok = 0, bad = 0, skipped = all.length - files.length, i = 0, last = null;
    const fams = {};
    (function next() {
      if (i >= files.length) {
        say('เพิ่มฟอนต์แล้ว ' + ok + ' ไฟล์ ใน ' + Object.keys(fams).length + ' ตระกูล' + (bad ? ' · อ่านไม่ได้ ' + bad + ' ไฟล์' : '') + (skipped ? ' · ข้ามไฟล์อื่นหรือตัวเอียง ' + skipped + ' ไฟล์' : '') + (idbFailed ? ' · บันทึกถาวรไม่ได้ ฟอนต์จะหายเมื่อปิดหน้า' : ''), idbFailed);
        renderMine(); applyFilter();
        if (last) { const u = USER.get(last); pick(css(last), u.weights.length ? nearest(u.weights, +$('weightR').value || 700) : 0); }
        return;
      }
      const f = files[i++], meta = parseName(f.name);
      if (i % 5 === 1 || files.length < 6) say('กำลังเพิ่มฟอนต์ ' + i + '/' + files.length + ' …');
      if (meta.skip) { skipped++; return next(); }
      f.arrayBuffer().then(buf => registerUser({ family: meta.family, weight: meta.weight, range: meta.range, buf: buf }, true))
        .then(() => { ok++; fams[meta.family] = 1; last = meta.family; }, () => { bad++; }).then(next);
    })();
  }

  // ---- any Google Fonts name, or a font installed on this device -----------------------------------------------------------
  const gcss = (name, spec) => 'https://fonts.googleapis.com/css2?family=' + encodeURIComponent(name).replace(/%20/g, '+') + (spec ? ':' + spec : '') + '&display=swap';
  function linkLoad(url, cb) {
    const l = document.createElement('link');
    let done = false;
    const fin = ok => { if (done) return; done = true; if (!ok) l.remove(); cb(ok); };
    l.rel = 'stylesheet'; l.href = url; l.onload = () => fin(true); l.onerror = () => fin(false);
    setTimeout(() => fin(false), 15000);
    document.head.appendChild(l);
  }
  function probeGoogle(name) {
    return new Promise(resolve => {
      const ok = []; let pending = 9;
      [100, 200, 300, 400, 500, 600, 700, 800, 900].forEach(w => linkLoad(gcss(name, 'wght@' + w), good => {
        if (good) ok.push(w);
        if (--pending === 0) resolve(ok.sort((a, b) => a - b));
      }));
    });
  }
  function isInstalled(name) {
    const ctx = document.createElement('canvas').getContext('2d');
    if (!ctx) return false;
    const s = 'ทุกคนภาษาไทย AaBbGg 0123 mmmmwwww', n = '"' + name + '"', wd = f => { ctx.font = '40px ' + f; return ctx.measureText(s).width; };
    return wd(n + ',monospace') !== wd('monospace') || wd(n + ',serif') !== wd('serif') || wd(n + ',sans-serif') !== wd('sans-serif');
  }
  function saveCustom() {
    try { const arr = []; CUSTOM.forEach((c, n) => arr.push({ n: n, w: c.weights, l: c.local ? 1 : 0 })); localStorage.setItem(KEY_CUSTOM, JSON.stringify(arr)); } catch (e) { /* storage unavailable */ }
  }
  function addCustom(raw) {
    const name = (raw || '').trim().replace(/\s+/g, ' ');
    if (!name) return;
    if (!NAME_OK.test(name)) { say('ชื่อฟอนต์มีอักขระที่ใช้ไม่ได้ เช่น เครื่องหมายคำพูด', true); return; }
    const found = Array.from(sel().options).find(o => o.textContent.replace(/\s*\(.*\)/, '').trim().toLowerCase() === name.toLowerCase() && !o.dataset.temp);
    if (found) { pick(found.value, 0); say(name + ' อยู่ในรายการแล้ว เลือกให้แล้ว'); return; }
    say('กำลังค้นหา ' + name + ' …');
    const btn = $('flAdd'); btn.disabled = true;
    probeGoogle(name).then(ws => {
      if (ws.length) return { weights: ws, local: false };
      return new Promise(res => linkLoad(gcss(name, ''), ok => {
        if (ok) return res({ weights: [400], local: false });
        res(isInstalled(name) ? { weights: [100, 200, 300, 400, 500, 600, 700, 800, 900], local: true } : null);
      }));
    }).then(info => {
      btn.disabled = false;
      if (!info) { say('ไม่พบฟอนต์ชื่อ ' + name + ' ทั้งใน Google Fonts และในเครื่องนี้ ตรวจการสะกดให้ตรงกับชื่อบน fonts.google.com', true); return; }
      CUSTOM.set(name, info); saveCustom();
      const v = ensureOption(name, 'custom');
      renderMine(); applyFilter();
      pick(v, nearest(info.weights, +$('weightR').value || 700));
      say((info.local ? 'พบ ' + name + ' ในเครื่องของคุณ ฟอนต์นี้แสดงได้เฉพาะเครื่องที่ติดตั้งไว้ (ไฟล์ที่ส่งออกจะเห็นเหมือนกัน เพราะวาดจากเครื่องนี้)' : 'เพิ่ม ' + name + ' จาก Google Fonts แล้ว') + ' · ถ้าฟอนต์ไม่มีอักษรไทย ตัวอักษรไทยจะใช้ฟอนต์สำรองแทน');
    });
  }
  function importLocal() {
    if (!window.queryLocalFonts) { say('เบราว์เซอร์นี้ไม่รองรับการอ่านฟอนต์ในเครื่อง ใช้ช่องพิมพ์ชื่อฟอนต์แทนได้', true); return; }
    say('กำลังขออนุญาตอ่านฟอนต์ในเครื่อง …');
    window.queryLocalFonts().then(list => {
      const fam = {};
      list.forEach(f => {
        const style = (f.style || '').toLowerCase();
        if (/italic|oblique/.test(style)) return;
        let w = 400; for (let i = 0; i < WMAP.length; i++) { if (style.indexOf(WMAP[i][0]) > -1) { w = WMAP[i][1]; break; } }
        (fam[f.family] = fam[f.family] || []).push(w);
      });
      let added = 0;
      Object.keys(fam).forEach(n => {
        if (!NAME_OK.test(n) || hasOption(css(n))) return;
        CUSTOM.set(n, { weights: fam[n].filter((x, i, a) => a.indexOf(x) === i).sort((a, b) => a - b), local: true });
        ensureOption(n, 'custom'); added++;
      });
      saveCustom(); renderMine(); applyFilter();
      say('เพิ่มฟอนต์ในเครื่อง ' + added + ' ตระกูล ค้นหาฟอนต์ไทยได้จากช่องค้นหา');
    }).catch(() => say('หน้านี้ไม่ได้รับอนุญาตให้อ่านฟอนต์ในเครื่อง ใช้ช่องพิมพ์ชื่อฟอนต์แทนได้', true));
  }

  // ---- the list of fonts the user added (with a delete button) -----------------------------------------------------------------
  function renderMine() {
    if (!mineBox) return;
    mineBox.textContent = '';
    const rows = Array.from(USER.keys()).map(n => [n, 'ไฟล์ของฉัน']).concat(Array.from(CUSTOM.keys()).map(n => [n, CUSTOM.get(n).local ? 'ในเครื่อง' : 'Google Fonts']));
    mineBox.hidden = !rows.length;
    rows.forEach(r => {
      const row = document.createElement('div'); row.className = 'fl-row';
      const nm = document.createElement('span'); nm.textContent = r[0] + ' · ' + r[1]; nm.style.fontFamily = css(r[0]);
      const del = document.createElement('button'); del.type = 'button'; del.className = 'tx-tbtn'; del.textContent = 'ลบ'; del.dataset.f = r[0];
      row.appendChild(nm); row.appendChild(del); mineBox.appendChild(row);
    });
  }
  function removeFont(name) {
    const u = USER.get(name);
    if (u) { Object.keys(u.faces).forEach(k => { try { document.fonts.delete(u.faces[k]); } catch (e) { /* ignore */ } }); USER.delete(name); idbDelFamily(name).catch(() => {}); }
    else if (CUSTOM.has(name)) { CUSTOM.delete(name); saveCustom(); }
    else return;
    const used = S.state.project.style.font === css(name);
    S.ui.ccColor.removeFontOption(css(name));
    if (used) pick("'Kanit',sans-serif", 0);
    renderMine(); applyFilter();
  }

  function buildAdd() {
    const grid = $('fontGrid'), anchor = $('fontGridHint') || grid;
    const box = document.createElement('details'); box.className = 'font-add'; box.id = 'fontAdd';
    box.innerHTML = '<summary>เพิ่มฟอนต์ของคุณ · ไฟล์ฟอนต์ / ชื่อฟอนต์ Google / ฟอนต์ในเครื่อง</summary>' +
      '<div class="fl-body">' +
      '<div class="row"><label>ไฟล์ฟอนต์</label><div class="field"><input type="file" id="flFile" accept=".otf,.ttf,.woff,.woff2" multiple></div></div>' +
      '<div class="row"><label>ทั้งโฟลเดอร์</label><div class="field"><input type="file" id="flDir" webkitdirectory multiple></div></div>' +
      '<div class="row"><label>ชื่อฟอนต์</label><div class="field"><input type="text" id="flName" placeholder="พิมพ์ชื่อฟอนต์ใดก็ได้ เช่น Lobster, Roboto" autocomplete="off" autocapitalize="off" spellcheck="false"><button class="tx-tbtn" id="flAdd" type="button">เพิ่ม</button></div></div>' +
      '<div class="row"><label>ในเครื่อง</label><div class="field"><button class="tx-tbtn" id="flLocal" type="button" hidden>ดึงฟอนต์ที่ติดตั้งในเครื่องทั้งหมด</button></div></div>' +
      '<div class="fl-mine" id="flMine" hidden></div>' +
      '<p class="hint fl-note" id="flNote">เลือกหลายไฟล์พร้อมกันได้ ระบบจัดกลุ่มตามชื่อไฟล์และอ่านน้ำหนักจากชื่อ เช่น MyFont-Bold.otf · ฟอนต์ถูกเก็บไว้ในเบราว์เซอร์ของคุณเท่านั้น ไม่ถูกส่งไปที่ไหน · ฟอนต์ที่เพิ่มแล้วอยู่ในหมวด "ของฉัน" / "กำหนดเอง"</p></div>';
    anchor.parentNode.insertBefore(box, anchor.nextSibling);
    note = box.querySelector('#flNote'); mineBox = box.querySelector('#flMine');
    box.querySelector('#flFile').addEventListener('change', e => { addFiles(e.target.files); e.target.value = ''; });
    box.querySelector('#flDir').addEventListener('change', e => { addFiles(e.target.files); e.target.value = ''; });
    box.querySelector('#flAdd').addEventListener('click', () => addCustom($('flName').value));
    box.querySelector('#flName').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addCustom(e.target.value); } });
    const lb = box.querySelector('#flLocal'); lb.addEventListener('click', importLocal); if (window.queryLocalFonts) lb.hidden = false;
    mineBox.addEventListener('click', e => {
      const b = e.target.closest('button[data-f]'); if (!b) return;
      if (b.dataset.armed === '1') { removeFont(b.dataset.f); return; }
      b.dataset.armed = '1'; b.textContent = 'ยืนยันลบ';
      setTimeout(() => { if (b.isConnected) { b.dataset.armed = '0'; b.textContent = 'ลบ'; } }, 3000);
    });
  }

  // ---- bring back fonts saved on earlier visits -----------------------------------------------------------------------------
  function restore() {
    try {
      JSON.parse(localStorage.getItem(KEY_CUSTOM) || '[]').forEach(c => {
        if (!c || !c.n || !NAME_OK.test(c.n) || hasOption(css(c.n))) return;
        CUSTOM.set(c.n, { weights: c.w && c.w.length ? c.w : [400], local: !!c.l });
        ensureOption(c.n, 'custom');
        if (!c.l) linkLoad(gcss(c.n, c.w && c.w.length > 1 ? 'wght@' + c.w.join(';') : ''), () => {});
      });
    } catch (e) { /* ignore a damaged list */ }
    renderMine(); applyFilter();
    if (!window.indexedDB) return;
    idbAll().then(recs => {
      if (!recs || !recs.length) return;
      let i = 0, ok = 0;
      (function next() {
        if (i >= recs.length) {
          if (ok) { renderMine(); applyFilter(); say('โหลดฟอนต์ของคุณที่บันทึกไว้แล้ว ' + ok + ' ไฟล์ ใน ' + USER.size + ' ตระกูล'); }
          bus.emit('style:changed');                                // the project may be waiting for one of these fonts
          if (S.style && S.style.ensureFont) S.style.ensureFont().then(() => bus.emit('style:changed'));
          return;
        }
        const r = recs[i++];
        registerUser({ family: r.family, weight: r.weight, range: r.range, buf: r.buf }, false).then(() => { ok++; }, () => {}).then(next);
      })();
    }).catch(() => { /* storage unavailable: uploads last for this visit only */ });
  }

  S.ui.fontLib = {
    init() {
      if (!$('fontGrid') || !S.ui.ccColor || !S.ui.ccColor.addFontOption) return;
      buildFilter(); buildAdd();
      bus.on('font:chip', chip => { if (S.ui.fontFav) S.ui.fontFav.decorate(chip); applyFilter(); });
      restore();
    },
    /** for tests */
    parseName: parseName, addFiles: addFiles
  };
})(window.SubEd);
