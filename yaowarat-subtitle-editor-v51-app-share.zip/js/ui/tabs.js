/* UI: CapCut-style bottom toolbar + slide-up sheet that holds the สไตล์ / บทบรรยาย / ส่งออก panes.
 * Emits: sheet:toggle({open, tab}). */
(function (S) {
  'use strict';
  const $ = S.$, titles = { style: 'สไตล์ข้อความ', caption: 'ซับและบทบรรยาย', arrange: 'จัดฉากตามเสียง', motion: 'โมชันข้อความ', export: 'ส่งออกวิดีโอ' };
  const order = ['caption', 'arrange', 'style', 'motion', 'export'];
  let cur = null, closeTimer = 0;
  function open(tab) {
    // switching between panes while the sheet is open: the new pane slides in from the side you moved toward;
    // opening the sheet fresh: it just rises with the sheet
    const wasOpen = document.body.classList.contains('sheet-open') && cur !== null && cur !== tab;
    const dir = wasOpen ? (order.indexOf(tab) > order.indexOf(cur) ? 1 : -1) : 0;
    if (closeTimer) { clearTimeout(closeTimer); closeTimer = 0; }          // re-opened while the sheet was still sliding away
    document.body.classList.remove('sheet-closing');
    cur = tab;
    document.querySelectorAll('.tab-pane').forEach(p => {
      if (p.dataset.pane === tab) { p.style.setProperty('--dx', (dir * 22) + 'px'); p.style.setProperty('--dy', dir ? '0px' : '10px'); }
      p.classList.toggle('active', p.dataset.pane === tab);
    });
    document.querySelectorAll('.cc-tool[data-tab]').forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
    $('sheetTitle').textContent = titles[tab] || '';
    document.body.classList.toggle('sheet-export', tab === 'export');
    $('panels').classList.add('open'); document.body.classList.add('sheet-open');
    S.bus.emit('sheet:toggle', { open: true, tab: tab });
  }
  /** Closing (✓): first the sheet slides away over the unchanged layout, THEN the editor swaps back to the toolbar / bigger preview.
   *  (Swapping at once made the fading sheet, the returning toolbar and the re-laid timeline overlap for a moment.) */
  function close() {
    if (cur === null && !document.body.classList.contains('sheet-open')) return;
    cur = null;
    const ae = document.activeElement;
    if (ae && ae !== document.body && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName)) ae.blur();   // drop the keyboard so the viewport settles
    const panels = $('panels');
    panels.classList.remove('open');
    panels.classList.add('closing');
    document.body.classList.add('sheet-closing');
    document.querySelectorAll('.cc-tool').forEach(b => b.classList.remove('on'));
    S.bus.emit('sheet:toggle', { open: false });
    if (closeTimer) clearTimeout(closeTimer);
    closeTimer = setTimeout(() => {
      closeTimer = 0;
      panels.classList.remove('closing');
      document.body.classList.remove('sheet-open', 'sheet-closing', 'sheet-export');
      S.bus.emit('sheet:toggle', { open: false, settled: true });                                // layout changed now: timeline / frame re-measure
    }, 260);
  }
  S.ui.tabs = {
    open: open, close: close,
    init() {
      document.querySelectorAll('.cc-tool[data-tab]').forEach(b => b.addEventListener('click', () => open(b.dataset.tab)));
      $('sheetClose').addEventListener('click', close);
      $('topExport').addEventListener('click', () => open('export'));
      $('ccAdd').addEventListener('click', () => { $('txAdd').click(); open('caption'); });
      $('ccUndo').addEventListener('click', () => $('txUndo').click());
      $('ccRedo').addEventListener('click', () => $('txRedo').click());
    }
  };
})(window.SubEd);
