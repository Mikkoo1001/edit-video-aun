/* =====================================================================
 * UI: "เทียบต้นฉบับ" (moved from Shadow Caption Lab) — tools to judge the caption style against a reference:
 *   - preview background: the real clip (default), black, white, a gradient, or a picture / video of your own. It only changes what the
 *     PREVIEW shows (the video keeps playing underneath); the exported file always uses the real clip.
 *   - reference picture: a crop of the CapCut screenshot laid over the picture with a transparency / zoom / X / Y slider, to line the
 *     font, shadow and size up with the original. Never part of the export.
 * Both layers follow the picture rectangle inside the preview (ui/preview-caption.js contentRect, announced by caption:laidout).
 * ===================================================================== */
(function (S) {
  'use strict';
  const $ = S.$, bus = S.bus;
  const GRAD = 'linear-gradient(160deg,#ee7a13 0%,#8a2f6b 55%,#2a1650 100%)';
  let bg, ref, refImg, bgUrl = null, refUrl = null, mode = 'video', userBgOk = false;

  function place() {
    if (!bg) return;
    const r = S.ui.preview.contentRect();
    [bg, ref].forEach(el => { el.style.left = r.x + 'px'; el.style.top = r.y + 'px'; el.style.width = r.w + 'px'; el.style.height = r.h + 'px'; });
  }
  function note(t) { const n = $('cmpNote'); if (n) n.textContent = t || ''; }

  function setMode(m) {
    if (m === 'upload' && !userBgOk) return;
    mode = m;
    document.querySelectorAll('#cmpBgs [data-cbg]').forEach(c => c.classList.toggle('active', c.dataset.cbg === m));
    bg.classList.toggle('on', m !== 'video');
    bg.style.background = m === 'dark' ? '#0b0b0f' : m === 'light' ? '#f0f0f4' : m === 'grad' ? GRAD : m === 'upload' ? '#000' : 'none';
    const u = bg.querySelector('.user'); if (u) u.style.display = m === 'upload' ? '' : 'none';
    place();
  }
  function paintRef() {
    const o = +$('cmpRefO').value, sc = +$('cmpRefS').value, x = +$('cmpRefX').value, y = +$('cmpRefY').value;
    refImg.style.opacity = o / 100;
    refImg.style.transform = 'translate(' + x + '%,' + y + '%) scale(' + (sc / 100) + ')';
    $('cmpRefONum').textContent = o + '%'; $('cmpRefSNum').textContent = sc + '%'; $('cmpRefXNum').textContent = x + '%'; $('cmpRefYNum').textContent = y + '%';
    ref.classList.toggle('on', !!refUrl);
  }

  S.ui.compare = {
    init() {
      const box = S.dom.videoBox, layer = S.dom.capLayer;
      bg = document.createElement('div'); bg.className = 'pv-bg'; box.insertBefore(bg, layer);
      ref = document.createElement('div'); ref.className = 'pv-ref'; refImg = document.createElement('img'); refImg.alt = ''; ref.appendChild(refImg);
      layer.parentNode.insertBefore(ref, layer.nextSibling);
      ['caption:laidout', 'media:metadata'].forEach(e => bus.on(e, place));
      window.addEventListener('resize', place);
      document.querySelectorAll('#cmpBgs [data-cbg]').forEach(c => c.addEventListener('click', () => setMode(c.dataset.cbg)));
      $('cmpBgFile').addEventListener('change', e => {
        const f = e.target.files && e.target.files[0]; if (!f) return;
        const old = bg.querySelector('.user'); if (old) old.remove();
        if (bgUrl) URL.revokeObjectURL(bgUrl);
        bgUrl = URL.createObjectURL(f);
        const isVid = f.type.indexOf('video') === 0, el = document.createElement(isVid ? 'video' : 'img');
        el.className = 'user';
        if (isVid) { el.muted = true; el.loop = true; el.autoplay = true; el.playsInline = true; }
        else el.alt = '';
        el.addEventListener('error', () => { el.remove(); userBgOk = false; $('cmpBgUpChip').style.opacity = '.45'; setMode('video'); note('เปิดไฟล์พื้นหลังนี้ไม่ได้'); });
        el.src = bgUrl; bg.appendChild(el);
        userBgOk = true; $('cmpBgUpChip').style.opacity = '';
        setMode('upload'); note('ใช้ไฟล์ "' + f.name + '" เป็นพื้นหลังพรีวิว');
      });
      $('cmpRefFile').addEventListener('change', e => {
        const f = e.target.files && e.target.files[0]; if (!f) return;
        if (refUrl) URL.revokeObjectURL(refUrl);
        refUrl = URL.createObjectURL(f); refImg.src = refUrl;
        if (+$('cmpRefO').value === 0) $('cmpRefO').value = 50;
        paintRef(); place(); note('วางภาพต้นฉบับซ้อนแล้ว ปรับความโปร่งใส ซูม และตำแหน่งให้ตรงกับกรอบวิดีโอ');
      });
      $('cmpRefClear').addEventListener('click', () => {
        if (refUrl) URL.revokeObjectURL(refUrl);
        refUrl = null; refImg.removeAttribute('src'); $('cmpRefO').value = 0; $('cmpRefS').value = 100; $('cmpRefX').value = 0; $('cmpRefY').value = 0;
        $('cmpRefFile').value = ''; paintRef(); note('ล้างภาพต้นฉบับแล้ว');
      });
      ['cmpRefO', 'cmpRefS', 'cmpRefX', 'cmpRefY'].forEach(id => $(id).addEventListener('input', paintRef));
      paintRef(); setMode('video'); place();
    },
    /** for tests */
    mode: () => mode
  };
})(window.SubEd);
