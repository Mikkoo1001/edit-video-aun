/* =====================================================================
 * UI: "ติดตั้งเป็นแอป" — registers the service worker (sw.js) and shows an install button on the start screen when the browser offers one.
 *   Android / desktop Chrome, Edge: the button runs the browser's own install dialog (beforeinstallprompt).
 *   iPhone / iPad Safari: no such event exists, so the button explains "Share -> Add to Home Screen".
 * Hidden when the page already runs as an installed app. An installed app also gets persistent storage (saved work is not cleared).
 * ===================================================================== */
(function (S) {
  'use strict';
  const standalone = () => (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true;
  const ios = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  let deferred = null, btn = null;

  function show() { if (btn && !standalone()) btn.hidden = false; }

  /** Files shared to the installed app (sw.js keeps them in Cache storage) -> opened like a normal pick. */
  async function takeShared() {
    const m = /[?&]shared=(\d+)/.exec(location.search);
    if (!m) return;
    try { history.replaceState(null, '', location.pathname); } catch (e) {}
    const toast = t => { if (S.ui.toast) S.ui.toast(t, 7000); };
    if (!+m[1] || !window.caches) { toast('ไม่ได้รับไฟล์จากการแชร์ — ลองแชร์อีกครั้ง หรือเลือกไฟล์ในแอป'); return; }
    try {
      const c = await caches.open('subed-share'), keys = (await c.keys()).sort((a, b) => a.url.localeCompare(b.url, undefined, { numeric: true })), files = [];
      for (const k of keys) {
        const r = await c.match(k), b = await r.blob();
        files.push(new File([b], decodeURIComponent(r.headers.get('X-Name') || 'video.mp4'), { type: b.type || r.headers.get('Content-Type') || '', lastModified: +r.headers.get('X-Modified') || Date.now() }));
      }
      if (S.ui.media && files.length) await S.ui.media.loadFiles(files);
      for (const k of keys) await c.delete(k);
    } catch (e) { console.warn('[pwa] could not open the shared files:', e); toast('เปิดไฟล์ที่แชร์มาไม่ได้ — เลือกไฟล์ในแอปแทน'); }
  }

  function init() {
    takeShared();
    if ('launchQueue' in window) launchQueue.setConsumer(async p => {         // "open with" (desktop installed app): real, readable files
      try { const files = await Promise.all((p.files || []).map(h => h.getFile())); if (files.length && S.ui.media) S.ui.media.loadFiles(files); } catch (e) {}
    });
    btn = document.getElementById('installApp');
    if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
      navigator.serviceWorker.register('sw.js').catch(e => console.warn('[pwa] service worker not registered:', e));
    }
    if (!btn || standalone()) return;
    window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferred = e; show(); });
    window.addEventListener('appinstalled', () => { deferred = null; btn.hidden = true; if (S.ui.toast) S.ui.toast('ติดตั้งแล้ว — เปิดจากไอคอนบนหน้าจอหลักได้เลย', 4000); });
    if (ios) show();
    btn.addEventListener('click', async e => {
      e.stopPropagation();
      if (deferred) {
        deferred.prompt();
        try { await deferred.userChoice; } catch (x) {}
        deferred = null; btn.hidden = true;
      } else if (ios) alert('iPhone / iPad: กดปุ่มแชร์ (สี่เหลี่ยมมีลูกศรขึ้น) ใน Safari แล้วเลือก "เพิ่มไปยังหน้าจอโฮม"');
      else alert('เมนู ⋮ ของเบราว์เซอร์ → "ติดตั้งแอป" หรือ "เพิ่มลงหน้าจอหลัก"');
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})(window.SubEd);
