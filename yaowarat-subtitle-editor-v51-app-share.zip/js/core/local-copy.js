/* =====================================================================
 * SubEd.localCopy — make a picked File safe to read later. No DOM.
 *
 * Why: a File from the picker / gallery / drag-drop is only a REFERENCE to a file that still lives somewhere else (phone gallery
 * URI, Google Drive / iCloud / OneDrive placeholder, a folder whose permission may lapse). It can be read when picked and then
 * fail minutes later with NotReadableError — typically in the middle of "สร้างซับอัตโนมัติ", which streams the audio out of the clip.
 * ui/media.js already copies clips up to SNAPSHOT_MAX into memory. Bigger ones cannot live in RAM, so they are copied here
 * into the browser's private file system (OPFS): it is real disk, costs no RAM, and a File read back from it never goes stale.
 *
 *   await SubEd.localCopy.copy(file, { onProgress(0..1), cancelled() }) -> File (same name/type, disk backed) | null
 *        null  = could not be done here (no OPFS, not enough free space, private window ...): the caller keeps the reference.
 *        throws a NotReadableError when the ORIGINAL cannot be read right now (so the user hears about it at once, not later).
 *   SubEd.localCopy.keepOnly(file)   delete every private copy except the one behind `file` (call after the new clip is open)
 *   SubEd.localCopy.read(blob, start, end) -> Uint8Array   a read that retries and tries other routes before giving up
 *   await SubEd.localCopy.probe(blob)                      read a few bytes at the start / middle / end; throws NotReadableError
 * ===================================================================== */
(function (S) {
  'use strict';
  const DIR = 'subed-clips', PIECE = 8 * 1048576, SMALL = 256 * 1024;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const supported = () => !!(window.isSecureContext !== false && navigator.storage && navigator.storage.getDirectory &&
    window.FileSystemFileHandle && FileSystemFileHandle.prototype.createWritable);
  const names = new WeakMap();           // File -> name of its private copy
  const inUse = new Set();               // names of the copy that is currently open
  const writing = new Set();             // names being written right now (never purged, whatever keepOnly() says)
  const pinned = new Set();              // names that belong to a saved draft (core/drafts.js): never purged until the user deletes the draft

  const viaReader = blob => new Promise((res, rej) => {
    const fr = new FileReader();
    fr.onload = () => res(new Uint8Array(fr.result));
    fr.onerror = () => rej(fr.error || new Error('FileReader failed'));
    fr.readAsArrayBuffer(blob);
  });

  // A third way into the bytes: fetch() of a blob: URL. It goes through the same loader the <video> element uses, which keeps working on
  // some phones where Blob.slice().arrayBuffer() and FileReader both fail with NotReadableError.
  const urls = new WeakMap();
  async function viaFetch(blob, start, end) {
    let u = urls.get(blob);
    if (!u) { u = URL.createObjectURL(blob); urls.set(blob, u); }
    let buf, r;
    try {
      r = await fetch(u, { headers: { Range: 'bytes=' + start + '-' + (end - 1) } });
      if (!r.ok) throw new Error('fetch ' + r.status);
      if (r.status !== 206 && blob.size > 64 * 1048576) { try { r.body && r.body.cancel(); } catch (x) {} throw new Error('range not supported'); }   // would read the whole file for every piece
      buf = new Uint8Array(await r.arrayBuffer());
    } catch (e) { throw Object.assign(new Error('fetch route failed: ' + (e && e.message)), { name: 'NotReadableError' }); }   // any failure here = "still unreadable"; read() reports the first real error
    if (r.status === 206 || (start === 0 && buf.length >= end)) return buf.subarray(0, end - start);       // the range was honoured (or the whole thing came back)
    if (buf.length >= end) return buf.subarray(start, end);                                                  // the range was ignored: cut it ourselves
    throw Object.assign(new Error('short fetch'), { name: 'NotReadableError' });
  }

  let readerFirst = false;               // the FileReader route worked where slice().arrayBuffer() failed: use it first from now on (no wasted failed attempt per read)

  /** Read blob[start,end). A NotReadableError is retried over other routes at once (plain / FileReader / many small reads), then
   *  again after a short wait — a lapse in file access is sometimes momentary. */
  async function read(blob, start, end) {
    end = Math.min(blob.size, end);
    if (start >= end) return new Uint8Array(0);
    const plain = async () => new Uint8Array(await blob.slice(start, end).arrayBuffer());
    const reader = () => viaReader(blob.slice(start, end));
    const small = async () => {
      const out = new Uint8Array(end - start);
      for (let p = start, o = 0; p < end; p += SMALL) {
        const b = new Uint8Array(await blob.slice(p, Math.min(end, p + SMALL)).arrayBuffer());
        out.set(b, o); o += b.length;
      }
      return out;
    };
    const fetched = () => viaFetch(blob, start, end);
    const streamed = async () => {                                        // Response / stream() go through another loader than slice().arrayBuffer()
      const part = blob.slice(start, end);
      try { return new Uint8Array(await new Response(part).arrayBuffer()); }
      catch (e) { if (!part.stream) throw e; const rd = part.stream().getReader(), out = new Uint8Array(end - start); let o = 0; for (;;) { const r = await rd.read(); if (r.done) break; out.set(r.value, o); o += r.value.length; } return out.subarray(0, o); }
    };
    const routes = readerFirst ? [reader, plain, streamed, small, fetched] : [plain, reader, streamed, small, fetched];
    let last;
    for (let round = 0; round < 3; round++) {
      for (let i = 0; i < routes.length; i++) {
        try {
          const out = await routes[i]();
          if (routes[i] === reader && i > 0) readerFirst = true;
          return out;
        } catch (e) {
          last = e;
          if (!(e && e.name === 'NotReadableError')) throw e;
        }
      }
      await sleep(400 * (round + 1));
    }
    throw last;
  }

  /** Whole blob -> ArrayBuffer, read in pieces with the same retries (for decodeAudioData etc.). */
  async function readAll(blob) {
    const n = blob.size;
    if (n <= PIECE) return (await read(blob, 0, n)).buffer;
    const out = new Uint8Array(n);
    for (let p = 0; p < n; p += PIECE) out.set(await read(blob, p, p + PIECE), p);
    return out.buffer;
  }

  async function probe(blob) {
    const n = blob.size;
    if (!n) return;
    await read(blob, 0, Math.min(n, 4096));
    if (n > 8192) { await read(blob, Math.floor(n / 2), Math.floor(n / 2) + 4096); await read(blob, n - 4096, n); }
  }

  const dir = async () => (await navigator.storage.getDirectory()).getDirectoryHandle(DIR, { create: true });

  let chan = null;
  try {
    if (window.BroadcastChannel) {
      chan = new BroadcastChannel('subed-clips');
      chan.onmessage = ev => {
        const m = ev.data || {};
        if (m.q === 'inuse') chan.postMessage({ r: m.id, names: Array.from(inUse).concat(Array.from(writing), Array.from(pinned)) });
      };
    }
  } catch (e) { chan = null; }
  /** Names of private copies the OTHER open tabs are using (Set). */
  function askOthers() {
    return new Promise(resolve => {
      const out = new Set();
      if (!chan) { resolve(out); return; }
      const id = Math.random().toString(36).slice(2), prev = chan.onmessage;
      const ch2 = new BroadcastChannel('subed-clips');                   // a second handle: a tab does not hear its own posts, so this one listens while `chan` answers others
      ch2.onmessage = ev => { const m = ev.data || {}; if (m.r === id && Array.isArray(m.names)) m.names.forEach(n => out.add(n)); };
      chan.postMessage({ q: 'inuse', id: id });
      setTimeout(() => { try { ch2.close(); } catch (e) {} resolve(out); }, 300);
    });
  }

  async function purge() {
    if (!supported()) return;
    try { await S.localCopy.pinsReady; } catch (e) {}                 // the pins of the saved drafts are loaded first (core/drafts.js)
    try {
      const d = await dir(), list = [];
      for await (const name of d.keys()) list.push(name);
      // The private storage is shared by every open tab of the app: ask the other tabs which copies they still use (they answer within a moment).
      const others = await askOthers();
      const young = Date.now() - 6 * 3600 * 1000;                       // no way to ask (old browser): a copy younger than 6 h is left alone (names carry their creation time)
      for (const n of list) {
        if (inUse.has(n) || writing.has(n) || pinned.has(n) || others.has(n)) continue;
        if (!chan) { const t = parseInt((n.split('-')[1] || ''), 36); if (t && t > young) continue; }
        try { await d.removeEntry(n); } catch (e) {}
      }
    } catch (e) {}
  }

  const mbOf = n => Math.round(n / 1048576) + ' MB';
  async function copy(file, opts) {
    opts = opts || {};
    S.localCopy.lastWhy = '';
    if (!supported()) { S.localCopy.lastWhy = 'เบราว์เซอร์นี้ไม่มีที่เก็บไฟล์ส่วนตัว (OPFS) — หน้าต่างไม่ระบุตัวตน/โหมดส่วนตัว หรือเบราว์เซอร์เก่า'; return null; }
    if (!file || !file.size) return null;
    try {
      const est = navigator.storage.estimate && await navigator.storage.estimate();
      if (est && est.quota && est.quota - (est.usage || 0) < file.size * 1.05 + 64 * 1048576) {      // would not fit: keep the reference
        S.localCopy.lastWhy = 'พื้นที่เก็บของเบราว์เซอร์ไม่พอ (เหลือ ' + mbOf(est.quota - (est.usage || 0)) + ' ต้องใช้ ~' + mbOf(file.size * 1.05 + 64 * 1048576) + ')';
        return null;
      }
    } catch (e) {}
    let d, w, h, name;
    try {
      d = await dir();
      name = 'clip-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6);
      writing.add(name);
      h = await d.getFileHandle(name, { create: true });
      w = await h.createWritable();
    } catch (e) { writing.delete(name); S.localCopy.lastWhy = 'เปิดที่เก็บส่วนตัวไม่ได้ (' + (e && e.name || 'error') + ')'; return null; }                  // storage unavailable (private window, policy ...)
    try {
      for (let pos = 0; pos < file.size; pos += PIECE) {
        if (opts.cancelled && opts.cancelled()) { const c = new Error('cancelled'); c.cancelled = true; throw c; }
        const buf = await read(file, pos, pos + PIECE);
        if (!buf.length) throw new Error('short read');
        await w.write(buf);
        if (opts.onProgress) opts.onProgress(Math.min(1, (pos + buf.length) / file.size));
      }
      await w.close();
      const stored = await h.getFile();
      if (stored.size !== file.size) throw new Error('size mismatch');
      const out = new File([stored], file.name, { type: file.type || stored.type, lastModified: file.lastModified });
      names.set(out, name); inUse.add(name); writing.delete(name);
      return out;
    } catch (e) {
      try { await w.abort(); } catch (x) {}
      try { await d.removeEntry(name); } catch (x) {}
      writing.delete(name);
      if (e && (e.cancelled || e.name === 'NotReadableError')) throw e;   // cancelled by the caller / the original is unreadable
      console.warn('[localCopy] could not keep a private copy, using the picked file as is:', e);
      S.localCopy.lastWhy = 'เขียนสำเนาไม่สำเร็จ (' + (e && e.name || 'error') + (e && e.message ? ': ' + String(e.message).slice(0, 60) : '') + ')';
      return null;                                                       // quota, disk error ...: carry on with the reference
    }
  }

  const pin = name => { if (name) pinned.add(name); };
  const unpin = name => { pinned.delete(name); inUse.delete(name); };
  /** Put a private copy of `file` on disk for a draft and pin it, WITHOUT changing which File the editor uses. '' when that is not possible. */
  async function stash(file, opts) {
    const have = names.get(file);
    if (have) { pinned.add(have); return have; }                     // already a private copy: just keep it
    const f = await copy(file, opts);
    const n = f && names.get(f);
    if (n) pinned.add(n);
    return n || '';
  }

  function keepOnly(file) {
    const keep = file && names.get(file);
    inUse.clear();
    if (keep) inUse.add(keep);
    return purge();
  }

  /** Name of the private copy behind `file` ('' when it is not one). ui/resume.js stores that name instead of a second copy of the bytes. */
  const nameOf = file => (file && names.get(file)) || '';

  /** Re-open a private copy made earlier (after a page refresh) -> File | null. meta = { name, type, lastModified } of the clip. */
  async function open(name, meta) {
    if (!supported() || !name) return null;
    try {
      const stored = await (await (await dir()).getFileHandle(name)).getFile();
      meta = meta || {};
      const out = new File([stored], meta.name || name, { type: meta.type || stored.type, lastModified: meta.lastModified || stored.lastModified });
      names.set(out, name); inUse.add(name);
      return out;
    } catch (e) { return null; }
  }

  S.localCopy = { lastWhy: '', pinsReady: Promise.resolve(), pin: pin, unpin: unpin, stash: stash, supported: supported, copy: copy, keepOnly: keepOnly, nameOf: nameOf, open: open, read: read, readAll: readAll, probe: probe, purge: purge };
})(window.SubEd = window.SubEd || {});
