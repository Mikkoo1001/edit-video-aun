/* =====================================================================
 * Personal build: API keys pre-filled into the "สร้างคำบรรยายอัตโนมัติ" fields, so the app can
 * create subtitles right after opening (just pick a video and press generate).
 *
 * WARNING: this file is served to every visitor of the site. Anyone who can open the page can read
 * these keys. Keep this build private (or delete this file / empty the strings before sharing the link).
 * Fields the user types into are never overwritten.
 * ===================================================================== */
(function () {
  'use strict';
  const S = window.SubEd = window.SubEd || {};
  const GEMINI_KEYS = [
    'AQ.Ab8RN6L15XImEsFVCLE8tc_n6Ob_XOxZxl6C5GVU28k9xofRNw',
    'AQ.Ab8RN6KZgUz72fk6-mr80OPuA3u_SExC2k4uwPnIt3p4jMa61A',
    'AQ.Ab8RN6JDTVDNFdXRMrWB9IwPoHa5NeVC2TAsq-wh_b7P6B3few',
    'AQ.Ab8RN6IJ8wAKWvNkZx3_qPwMZFZ-v0f6PjD1RGZm3q_DqW9plw'
  ];
  const GROQ_KEYS = [
    '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',
    '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'
  ];
  S.builtinKeys = {
    groq: GROQ_KEYS.join(','),                    // several keys, comma separated: ai/transcription.js hands over to the next key when one is rejected / out of quota,
    gemini: GEMINI_KEYS.join(',')                // several keys, comma separated: gemini.js hands over to the next key when one is rejected / out of quota
  };
})();
