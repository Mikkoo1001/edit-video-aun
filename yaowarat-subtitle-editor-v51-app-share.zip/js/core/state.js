/* =====================================================================
 * SubEd.state — the single source of truth.
 *
 *   state.project   plain, JSON-safe data (except media.file). Everything a
 *                   renderer, exporter or AI feature needs to know lives here.
 *   state.ui        transient editor state (never serialised).
 *
 * Rules: modules MUTATE project fields in place (never replace the object),
 * then announce the change on SubEd.bus. UI renders from state; the renderer
 * and exporters read ONLY from state/arguments — never from DOM controls.
 *
 * Extending (later phases): add a key to project (e.g. project.broll = [],
 * project.audio = { music:[], sfx:[] }) and bump `schema`.
 * ===================================================================== */
(function (S) {
  'use strict';

  const state = S.state = {
    project: {
      schema: 1,
      media: { file: null, duration: 0 },        // runtime only: File is not serialisable
      trim: { start: 0, end: 0 },                 // seconds, in source-clip time
      subtitle: {
        words: [],                                // word-level timing {word,start,end} — raw ASR/AI output
        speech: [],                               // what the last AI re-timing run heard {word,start,end}: where a sentence should end is matched against it
        cues: [],                                 // displayed lines  {id,start,end,text,words[]}
        segmentation: { strategy: 'smart', wordsPerLine: 3, maxChars: 28 }
      },
      arrange: {                                  // "จัดฉาก": b-roll clips laid along the audio (runtime only, see ui/arrange.js)
        on: false, aspect: '9:16', fit: 'cover', order: 'seq', mode: 'cue', minLen: 1.5, maxLen: 8, silMin: 0.3, fixedLen: 3,
        clips: [], scenes: [], sel: -1,
        autoVoice: true, voiceTrim: true, voiceRhythm: true,
        webSearch: true, cast: '', stillZoom: true,                                  // AI may search the web for names · cast list the user typed · slow zoom on still pictures                          // new narration added on the เสียง track -> cut the scenes to what it says (ui/voice-arrange.js); trim the export to its length
        fxOn: true, sfxOn: true, sfxVol: 0.8, autoSfx: true,       // scene effects (visual / sound) switched on, effect volume
        ref: null,                                  // the analysed reference video (cuts, transitions, motion, sound effects, text style)
        refOpts: { mode: 'real', snap: false, fx: true, sfx: true, text: true, withText: true }
      },
      motion: { layers: [], sel: null, kfSel: 0, assets: {} },     // assets: id -> { name, url (data URL), w, h } — the pictures image layers use // "มูฟเมนต์ข้อความ" (Motion Graphics): extra text layers on keyframes, in front of / behind the caption (render/motion-text.js, ui/motion-text.js)
      cut: { segs: [], sel: null },               // "ตัดวิดีโอ": pieces of the clip (source time, tiling it) — deleted pieces are skipped on play and export (see ui/video-cut.js)
      audio: { clips: [], sel: null },            // "เสียง": sound clips on the timeline (see ui/audio-engine.js). Runtime store of the decoded files lives in SubEd.audioTracks.media
      style: {                                    // filled from the style controls at boot (see ui/style-panel.js)
        font: null, weight: 700, sharp: 0, thick: 0, opacity: 100, size: 32, bold: true, italic: false, color: '#ffffff',
        outline: { on: true, color: '#000000', width: 2 },
        glow: { on: false, type: 'halo', color: '#00e5ff', follow: true, intensity: 60, range: 12 },   // type: 'halo' (soft even glow) | 'burst' (light streaks radiating out, like CapCut glow 1)
        shadow: { on: false, color: '#000000', opacity: 100, blur: 4, dist: 3, angle: -45, dx: null, dy: null },   // drop shadow behind the text: opacity 0-100, angle in degrees (-45 = down-right, like CapCut). dx / dy (% of the font size, null = use angle + dist) = "เงาเหลื่อม"
        halo: { on: false, blur: 22, alpha: 85, layers: 2 },                     // "ขอบมืดรอบตัวอักษร": soft black edge around the letters (blur = % of the font size, alpha 0-100, layers 0-4)
        bg: { on: true, color: '#000000', opacity: 0.55 },
        pos: 'bottom', posY: 0.62, autoWrap: false,   // autoWrap: false = a caption only breaks into rows where Enter was pressed (it just grows with the font) · true = also wrap when wider than the picture
         fx: 'pop', fxDur: 0.22,   // fxDur = intro animation length in seconds (0.01-3); pos 'custom' uses posY = caption block centre as a fraction of picture height
        fxStep: 350, fxOut: 'none', fxOutDur: 0.4,       // fxStep = ms between words / letters for the per-word / per-letter animations · fxOut = ending animation (none | fade | zoom | down | shrink | blur), fxOutDur = its length in s
        karaoke: true, karaokeMode: 'custom', highlight: '#f5c518',
        hlOff: false, textOff: false, wgOff: false                       // switches: word colour highlight (colour + its glow) hidden · caption text hidden (preview AND export; nothing is deleted)
      }
    },
    ui: { activeCue: -1, selectedId: null, followList: true, rafId: null, dragging: null, styleScope: 'all' }   // styleScope: 'all' | 'cue' (which the สไตล์ sheet edits)
  };

  S.project = {
    /** Clear transcript data only (keeps the clip, trim and style). */
    resetSubtitle() {
      const sub = state.project.subtitle;
      sub.words = []; sub.cues = []; sub.speech = [];
      state.ui.activeCue = -1; state.ui.selectedId = null;
      if (S.history) S.history.clear();            // a new clip must not be able to undo into the old clip's lines
      S.bus.emit('cues:structure', { reason: 'reset' });
    },
    /** Forget the loaded clip. */
    resetMedia() {
      const p = state.project;
      p.media.file = null; p.media.duration = 0;
      p.trim.start = 0; p.trim.end = 0;
    },
    /** JSON-safe deep copy of the project (the File itself is excluded). */
    snapshot() {
      const p = state.project;
      return JSON.parse(JSON.stringify({ schema: p.schema, trim: p.trim, subtitle: p.subtitle, style: p.style, cut: { segs: p.cut.segs }, motion: { layers: p.motion.layers, assets: p.motion.assets } }));
    },
    /** Load a snapshot() back into the live project (in place) and refresh dependants. */
    restore(snap) {
      if (!snap || snap.schema !== state.project.schema) throw new Error('Unsupported project schema');
      const p = state.project, copy = JSON.parse(JSON.stringify(snap));
      Object.assign(p.trim, copy.trim);
      Object.assign(p.subtitle, copy.subtitle);
      if (S.subtitle && S.subtitle.normalizeCues) S.subtitle.normalizeCues(p.subtitle.cues);
      Object.assign(p.style, copy.style);
      if (copy.cut && Array.isArray(copy.cut.segs)) { p.cut.segs = copy.cut.segs; p.cut.sel = null; }
      if (copy.motion && Array.isArray(copy.motion.layers)) {                      // older snapshots have no motion layers: leave them as they are
        p.motion.assets = copy.motion.assets && typeof copy.motion.assets === 'object' ? copy.motion.assets : {};
        if (S.motionText) S.motionText.loadAssets(p.motion.assets);
        p.motion.layers = copy.motion.layers.map(l => S.motionText ? S.motionText.normalize(l) : l); p.motion.sel = null; p.motion.kfSel = 0;
        S.bus.emit('motion:structure', { reason: 'restore' });
      }
      state.ui.activeCue = -1;
      S.bus.emit('style:changed');
      S.bus.emit('trim:changed');
      S.bus.emit('cues:structure', { reason: 'restore' });
      S.bus.emit('cut:structure');
    }
  };
})(window.SubEd);
