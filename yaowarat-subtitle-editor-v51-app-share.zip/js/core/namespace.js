/* =====================================================================
 * SubEd core — namespace, event bus, registries, tiny utilities.
 * Layer rule: core/ never touches the DOM and never imports other layers.
 * Load order matters (classic <script> tags, no build step, works on file://).
 * ===================================================================== */
(function () {
  'use strict';
  const SubEd = window.SubEd = window.SubEd || {};

  // ---- event bus: how modules talk without importing each other ----------
  // Events used today (payload):
  //   media:selected(file)  media:metadata()  media:cleared()
  //   time:changed(t)       trim:changed()
  //   cues:structure({reason, index?})   cue:timing({idx})   cue:text({idx})   cue:active({idx})
  //   style:changed()
  const handlers = Object.create(null);
  SubEd.bus = {
    on(evt, fn) { (handlers[evt] = handlers[evt] || []).push(fn); return () => SubEd.bus.off(evt, fn); },
    off(evt, fn) { const a = handlers[evt]; if (a) { const i = a.indexOf(fn); if (i >= 0) a.splice(i, 1); } },
    emit(evt, payload) {
      (handlers[evt] || []).slice().forEach(fn => {
        try { fn(payload); } catch (e) { console.error('[SubEd.bus] handler for "' + evt + '" failed:', e); }
      });
    }
  };

  // ---- registry: the extension point for pluggable implementations -------
  // e.g. segmenters, transcribers, caption animations, exporters.
  SubEd.createRegistry = function (kind) {
    const items = new Map();
    return {
      register(id, impl) {
        if (items.has(id)) throw new Error(kind + ' "' + id + '" is already registered');
        items.set(id, Object.assign({ id: id }, impl));
      },
      get(id) {
        const it = items.get(id);
        if (!it) throw new Error('Unknown ' + kind + ': ' + id);
        return it;
      },
      has(id) { return items.has(id); },
      list() { return Array.from(items.values()); }
    };
  };

  // ---- size limits shared by loading / transcription / export -------------
  // Nothing in the pipeline reads a whole clip into memory beyond SNAPSHOT_MAX: audio is streamed in small pieces
  // (audio-extract.js), video is played frame by frame, and the output file is assembled from disk-backed Blobs.
  SubEd.limits = {
    MAX_VIDEO_BYTES: 8 * 1024 * 1024 * 1024, // largest clip the editor accepts (also each clip of the main video in จัดฉาก); raised from 4 GB — big clips live on disk (core/local-copy.js), not in RAM
    MAX_CLIPS: 30,                            // how many clips the main video / จัดฉาก pool may hold (any length — only the count is limited)
    // clips up to this size are copied into memory on load, bigger ones onto private disk storage (ui/media.js, core/local-copy.js).
    // Follows the device: 8 GB+ RAM -> 600 MB, 4 GB -> 300 MB, 2 GB or less -> 120 MB (a copy in RAM of a big clip is what made weak phones fail). Unknown (Safari / Firefox) -> 300 MB.
    SNAPSHOT_MAX: (function () { const m = navigator.deviceMemory; return (m >= 8 ? 600 : m >= 4 || !m ? 300 : 120) * 1024 * 1024; })()
  };

  // ---- pure helpers (moved verbatim from the monolith) --------------------
  SubEd.util = {
    fmt(t) {
      if (!isFinite(t)) return '0:00';
      const m = Math.floor(t / 60), s = Math.floor(t % 60);
      return m + ':' + String(s).padStart(2, '0');
    },
    pad(n, len) { len = len || 2; return String(n).padStart(len, '0'); },
    /** mm:ss.cc — the format the subtitle list shows ("00:02.10"). */
    fmt2(t) {
      if (!isFinite(t)) return '00:00.00';
      const m = Math.floor(t / 60), s = Math.floor(t % 60), cs = Math.round((t - Math.floor(t)) * 100);
      return SubEd.util.pad(m) + ':' + SubEd.util.pad(s) + '.' + SubEd.util.pad(cs);
    },
    /** Parse "ss", "ss.cc", "mm:ss" or "mm:ss.cc" into seconds; NaN if invalid. */
    parseTime(str) {
      const m = /^\s*(?:(\d+):)?(\d+(?:[.,]\d+)?)\s*$/.exec(str || '');
      if (!m) return NaN;
      return (m[1] ? parseInt(m[1], 10) * 60 : 0) + parseFloat(m[2].replace(',', '.'));
    },
    hexToRgba(hex, a) {
      const n = parseInt(hex.replace('#', ''), 16);
      const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
      return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
    }
  };
})();
