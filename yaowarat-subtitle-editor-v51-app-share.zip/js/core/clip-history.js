/* =====================================================================
 * SubEd.clipHistory — "ประวัติการตัด": every exported (cut) video is kept in the browser so it can be downloaded or re-opened later. No DOM.
 *
 * Where the bytes live:
 *   OPFS (the browser's private disk storage, dir 'subed-history')  — real disk, no RAM; used whenever the browser has it.
 *   IndexedDB record 'hist:<id>'                                    — fallback when OPFS is missing (the Blob is stored as is).
 * The list itself (name, size, date ...) is one small record 'history' in SubEd.persist.
 *
 * Nothing is ever deleted automatically: only the user removes entries. When the browser has no room left for a new video, add() rejects
 * with err.code === 'full' and the caller tells the user. The page also asks the browser for "persistent" storage so the history is
 * not evicted when the phone runs low on space.
 *
 *   await SubEd.clipHistory.add(blob, { name, ext, duration, source }) -> entry | null   (null = could not be kept; the export itself is never affected)
 *   await SubEd.clipHistory.list()                -> [entry] newest first
 *   await SubEd.clipHistory.file(id)              -> File | null
 *   await SubEd.clipHistory.remove(id) / clear()
 *   await SubEd.clipHistory.usage()               -> { used, quota, history }   (bytes; quota 0 when the browser does not say)
 * Emits: history:saved  (the list changed)
 * entry = { id, name, ext, type, size, duration, source, savedAt, store: 'opfs' | 'idb' }
 * ===================================================================== */
(function (S) {
  'use strict';
  const DIR = 'subed-history', KEY = 'history', RESERVE = 64 * 1048576, PIECE = 8 * 1048576;
  const supported = () => !!(window.isSecureContext !== false && navigator.storage && navigator.storage.getDirectory &&
    window.FileSystemFileHandle && FileSystemFileHandle.prototype.createWritable);
  const dir = async () => (await navigator.storage.getDirectory()).getDirectoryHandle(DIR, { create: true });
  const MIME = { mp4: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime' };
  let chain = Promise.resolve(), persistAsked = false;
  const ask = () => { if (!persistAsked && navigator.storage && navigator.storage.persist) { persistAsked = true; navigator.storage.persist().catch(() => {}); } };   // "persistent" storage: the browser will not clear it when space runs low
  const serial = fn => { const p = chain.then(fn, fn); chain = p.catch(() => {}); return p; };   // one writer at a time: add / remove never interleave on the list

  const load = async () => { try { const l = await S.persist.get(KEY); return Array.isArray(l) ? l : []; } catch (e) { return []; } };
  const save = list => S.persist.put(KEY, list);

  async function dropBytes(e) {
    try { if (e.store === 'opfs') await (await dir()).removeEntry(e.id); else await S.persist.del(['hist:' + e.id]); } catch (x) {}
  }
  async function writeOpfs(id, blob) {
    const d = await dir(), h = await d.getFileHandle(id, { create: true }), w = await h.createWritable();
    try {
      for (let p = 0; p < blob.size; p += PIECE) await w.write(S.localCopy ? await S.localCopy.read(blob, p, p + PIECE) : await blob.slice(p, p + PIECE).arrayBuffer());
      await w.close();
    } catch (e) { try { await w.abort(); } catch (x) {} try { await d.removeEntry(id); } catch (x) {} throw e; }
    if ((await h.getFile()).size !== blob.size) { try { await d.removeEntry(id); } catch (x) {} throw new Error('size mismatch'); }
  }

  /** Free bytes the browser still allows (minus a small reserve). Infinity when the browser does not say. */
  async function room() {
    let est = null;
    try { est = navigator.storage.estimate && await navigator.storage.estimate(); } catch (e) {}
    if (!est || !est.quota) return Infinity;                       // the browser will not say: try, and let the write fail if it is full
    return Math.max(0, est.quota - (est.usage || 0) - RESERVE);
  }
  const fail = (code, msg) => { const e = new Error(msg); e.code = code; return e; };

  /** Keep a finished video. NEVER deletes anything to make space: when it does not fit, it rejects with err.code === 'full'
   *  (the user decides what to delete). Other failures resolve to null. */
  function add(blob, meta) {
    return serial(async () => {
      meta = meta || {};
      if (!blob || !blob.size) return null;
      ask();
      const list = await load();
      if (blob.size > await room()) throw fail('full', 'พื้นที่เก็บในเบราว์เซอร์เต็ม');
      const ext = (meta.ext || 'mp4').replace(/^\./, '');
      const entry = { id: 'h' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6), name: meta.name || ('วิดีโอตัดแล้ว.' + ext), ext: ext,
        type: blob.type || MIME[ext] || 'video/mp4', size: blob.size, duration: +meta.duration || 0, source: meta.source || '', savedAt: Date.now(), store: 'opfs' };
      try {
        if (supported()) await writeOpfs(entry.id, blob);
        else { entry.store = 'idb'; await S.persist.put('hist:' + entry.id, blob); }
      } catch (e) {
        console.warn('[history] could not keep the exported video:', e);
        if (entry.store !== 'opfs') { if (e && e.name === 'QuotaExceededError') throw fail('full', 'พื้นที่เก็บในเบราว์เซอร์เต็ม'); return null; }
        try { entry.store = 'idb'; await S.persist.put('hist:' + entry.id, blob); }          // OPFS refused (private window, policy): one more try in IndexedDB
        catch (e2) { if (e2 && e2.name === 'QuotaExceededError') throw fail('full', 'พื้นที่เก็บในเบราว์เซอร์เต็ม'); return null; }
      }
      list.unshift(entry);
      try { await save(list); } catch (e) { await dropBytes(entry); return null; }
      S.bus.emit('history:saved');
      return entry;
    });
  }

  const list = () => load().then(l => l.sort((a, b) => b.savedAt - a.savedAt));

  async function file(id) {
    const e = (await load()).find(x => x.id === id); if (!e) return null;
    try {
      if (e.store === 'opfs') {
        const f = await (await (await dir()).getFileHandle(e.id)).getFile();
        return new File([f], e.name, { type: e.type || f.type, lastModified: e.savedAt });
      }
      const b = await S.persist.get('hist:' + e.id);
      return b ? new File([b], e.name, { type: e.type || b.type, lastModified: e.savedAt }) : null;
    } catch (x) { return null; }
  }

  const remove = id => serial(async () => {
    const l = await load(), e = l.find(x => x.id === id); if (!e) return;
    await dropBytes(e); await save(l.filter(x => x.id !== id)); S.bus.emit('history:saved');
  });
  const clear = () => serial(async () => {
    const l = await load();
    for (const e of l) await dropBytes(e);
    await save([]); S.bus.emit('history:saved');
  });

  async function usage() {
    let est = null;
    try { est = navigator.storage.estimate && await navigator.storage.estimate(); } catch (e) {}
    return { used: (est && est.usage) || 0, quota: (est && est.quota) || 0, history: (await load()).reduce((n, e) => n + e.size, 0) };
  }

  S.clipHistory = { ask: ask, add: add, list: list, file: file, remove: remove, clear: clear, usage: usage, supported: supported };
})(window.SubEd = window.SubEd || {});
