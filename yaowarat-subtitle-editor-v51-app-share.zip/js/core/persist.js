/* =====================================================================
 * SubEd.persist — tiny key/value store on IndexedDB (survives page refresh and closing the tab).
 *   get(key) -> Promise<value|undefined>     put(key, value) -> Promise     del([keys]) -> Promise
 * Values are structured-cloned, so a File/Blob (the video) can be stored as-is.
 * Every call rejects (never throws) when IndexedDB is unavailable or full — callers just carry on without saving.
 * Used by ui/resume.js to bring back the last clip + its subtitles + style after a refresh.
 * ===================================================================== */
(function (S) {
  'use strict';
  const DB = 'yaowarat-subtitle-editor', STORE = 'kv';
  let dbp = null;

  function open() {
    if (dbp) return dbp;
    dbp = new Promise((resolve, reject) => {
      if (!window.indexedDB) { reject(new Error('IndexedDB is not available')); return; }
      const req = indexedDB.open(DB, 1);
      req.onupgradeneeded = () => { req.result.createObjectStore(STORE); };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    dbp.catch(() => { dbp = null; });          // allow a retry next time
    return dbp;
  }

  function run(mode, fn) {
    return open().then(db => new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, mode);
      let out;
      fn(tx.objectStore(STORE), v => { out = v; });
      tx.oncomplete = () => resolve(out);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || new Error('IndexedDB transaction aborted'));
    }));
  }

  S.persist = {
    get(key) { return run('readonly', (st, set) => { const r = st.get(key); r.onsuccess = () => set(r.result); }); },
    put(key, value) { return run('readwrite', st => { st.put(value, key); }); },
    del(keys) { return run('readwrite', st => { keys.forEach(k => st.delete(k)); }); }
  };
})(window.SubEd);
