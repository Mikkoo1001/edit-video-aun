/* =====================================================================
 * SubEd.history — undo / redo for subtitle editing.
 *
 * Model: two stacks of JSON snapshots of the subtitle data (cues + words).
 *   record(label)  called by every editing op BEFORE it mutates.
 *   undo()         restores the most recent snapshot, pushes current onto redo.
 *   redo()         the reverse.
 *
 * Snapshots are deep copies, so restore re-decorates cues (the startTime /
 * endTime / duration aliases are getters and must be re-attached).
 * Emits 'history:changed' ({canUndo, canRedo}) so toolbar buttons can update,
 * and 'cues:structure' ({reason:'undo'|'redo'}) so every view re-renders.
 * ===================================================================== */
(function (S) {
  'use strict';
  const LIMIT = 100;
  let past = [], future = [], restoring = false;

  // withStyle: also keep project.style in the snapshot (only for ops that change the global style too,
  // e.g. "apply this line's style to all"). Ordinary text/cue edits leave the style alone on undo.
  function snap(withStyle) {
    const s = S.state.project.subtitle, o = { words: s.words, cues: s.cues, segmentation: s.segmentation, audio: S.state.project.audio.clips, cut: S.state.project.cut.segs, motion: S.state.project.motion.layers };
    if (withStyle) o.style = S.state.project.style;
    return JSON.stringify(o);
  }
  const hasStyle = json => JSON.parse(json).style !== undefined;
  function apply(json) {
    const data = JSON.parse(json);
    const s = S.state.project.subtitle;
    s.words = data.words;
    s.cues = S.subtitle.normalizeCues(data.cues);
    s.segmentation = data.segmentation;
    if (data.style) Object.assign(S.state.project.style, data.style);
    if (data.audio) S.state.project.audio.clips = data.audio;      // sound clips: same linear undo as the lines
    if (data.cut) { S.state.project.cut.segs = data.cut; S.state.project.cut.sel = null; }      // video pieces too
    if (data.motion) { const M = S.state.project.motion; M.layers = data.motion; if (M.sel && !M.layers.some(l => l.id === M.sel)) M.sel = null; }   // motion text layers too
    S.state.ui.activeCue = -1;
  }
  function changed() {
    S.bus.emit('history:changed', { canUndo: past.length > 0, canRedo: future.length > 0 });
  }

  S.history = {
    record(label, opts) {
      if (restoring) return;
      past.push(snap(opts && opts.style));
      if (past.length > LIMIT) past.shift();
      future = [];
      changed();
    },
    undo() {
      if (!past.length) return false;
      restoring = true;
      const prev = past.pop(), withStyle = hasStyle(prev);
      future.push(snap(withStyle));
      apply(prev);
      restoring = false;
      if (withStyle) S.bus.emit('style:changed');
      S.bus.emit('cues:structure', { reason: 'undo' }); S.bus.emit('motion:structure', { reason: 'undo' });
      S.bus.emit('audio:structure', { reason: 'undo' }); S.bus.emit('audio:changed'); S.bus.emit('cut:structure');
      changed();
      return true;
    },
    redo() {
      if (!future.length) return false;
      restoring = true;
      const next = future.pop(), withStyle = hasStyle(next);
      past.push(snap(withStyle));
      apply(next);
      restoring = false;
      if (withStyle) S.bus.emit('style:changed');
      S.bus.emit('cues:structure', { reason: 'redo' }); S.bus.emit('motion:structure', { reason: 'redo' });
      S.bus.emit('audio:structure', { reason: 'redo' }); S.bus.emit('audio:changed'); S.bus.emit('cut:structure');
      changed();
      return true;
    },
    clear() { past = []; future = []; changed(); },
    canUndo() { return past.length > 0; },
    canRedo() { return future.length > 0; }
  };
})(window.SubEd);
