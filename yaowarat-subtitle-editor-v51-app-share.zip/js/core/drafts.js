/* =====================================================================
 * SubEd.drafts — "งานที่บันทึกไว้": every clip that was opened for editing, with its cuts / subtitles / style, kept in the browser until
 * the USER deletes it. Nothing here is ever removed automatically (not on refresh, not when another clip is opened, not when ✕ closes
 * the editor, not when the storage is getting full). No DOM. ui/resume.js decides WHEN to save; ui/history-panel.js lists them.
 *
 * Where things live (all in SubEd.persist = IndexedDB, plus the browser's private disk storage for the video):
 *   'drafts'        list of small records  { id, name, size, type, lastModified, savedAt, time, duration, cues, open, store, opfs }
 *   'dproj:<id>'    the project snapshot (SubEd.project.snapshot()) of that draft
 *   'dclip:<id>'    the video itself when OPFS is not available (store 'idb')
 *   OPFS dir 'subed-clips' (core/local-copy.js): the video when store is 'opfs' — the names are PINNED so the clean-up of unused
 *                   copies never touches them.
 *   store: 'opfs' | 'idb' | 'none' (the browser would not keep the video: subtitles + cuts are kept, the same file must be picked again)
 *
 *   list() -> [rec] newest first      get(id) -> { rec, project } | null      create(rec)     save(id, patch, project)
 *   setClip(id, { store, opfs })      clipFile(id) -> File | null              remove(id)      migrate() (old single-slot resume record)
 * Emits: drafts:changed
 * ===================================================================== */
(function (S) {
  'use strict';
  const KEY = 'drafts';
  let chain = Promise.resolve();
  const serial = fn => { const p = chain.then(fn, fn); chain = p.catch(() => {}); return p; };
  const load = async () => { try { const l = await S.persist.get(KEY); return Array.isArray(l) ? l : []; } catch (e) { return []; } };
  const store = list => S.persist.put(KEY, list);
  const changed = () => S.bus.emit('drafts:changed');

  const list = () => load().then(l => l.sort((a, b) => b.savedAt - a.savedAt));
  async function get(id) {
    const rec = (await load()).find(r => r.id === id); if (!rec) return null;
    let project = null; try { project = await S.persist.get('dproj:' + id); } catch (e) {}
    return { rec: rec, project: project };
  }
  const create = rec => serial(async () => {
    const l = await load();
    if (!l.some(r => r.id === rec.id)) { l.push(Object.assign({ savedAt: Date.now(), store: 'none', opfs: '', open: true }, rec)); await store(l); changed(); }
  });
  /** Merge `patch` into the record and replace its project snapshot (snapshot is a plain object, taken by the caller at call time). */
  const save = (id, patch, project) => serial(async () => {
    const l = await load(), r = l.find(x => x.id === id); if (!r) return;      // deleted by the user meanwhile: never bring it back
    Object.assign(r, patch || {}, { savedAt: Date.now() });
    if (project) await S.persist.put('dproj:' + id, project);
    await store(l); changed();
  });
  /** Change only flags (open / store ...) without touching the project or the "last edited" time. */
  const patch = (id, p) => serial(async () => {
    const l = await load(), r = l.find(x => x.id === id); if (!r) return;
    Object.assign(r, p); await store(l); changed();
  });

  async function clipFile(id) {
    const rec = (await load()).find(r => r.id === id); if (!rec) return null;
    try {
      if (rec.store === 'opfs' && rec.opfs && S.localCopy) return await S.localCopy.open(rec.opfs, rec);
      if (rec.store === 'idb') {
        const b = await S.persist.get('dclip:' + id);
        return b ? new File([b], rec.name || 'video', { type: rec.type || b.type, lastModified: rec.lastModified }) : null;
      }
    } catch (e) {}
    return null;
  }

  const remove = id => serial(async () => {
    const l = await load(), r = l.find(x => x.id === id); if (!r) return;
    if (r.store === 'opfs' && r.opfs && S.localCopy) S.localCopy.unpin(r.opfs);
    await store(l.filter(x => x.id !== id));
    await S.persist.del(['dproj:' + id, 'dclip:' + id]).catch(() => {});
    if (S.localCopy) S.localCopy.purge();                           // the video file of this draft is no longer pinned: free the disk now
    changed();
  });

  /** Older versions kept ONE unfinished job ('project' + 'clip'): turn it into a draft so nothing is lost by upgrading. */
  async function migrate() {
    let rec; try { rec = await S.persist.get('project'); } catch (e) { return; }
    if (!rec || !rec.project) return;
    const id = 'd' + Date.now().toString(36) + 'm';
    let st = 'none', opfs = '';
    try {
      if (rec.hasClip && rec.opfs) { st = 'opfs'; opfs = rec.opfs; }
      else if (rec.hasClip) { const c = await S.persist.get('clip'); if (c) { await S.persist.put('dclip:' + id, c); st = 'idb'; } }
    } catch (e) {}
    if (opfs && S.localCopy) S.localCopy.pin(opfs);
    await S.persist.put('dproj:' + id, rec.project);
    await create({ id: id, name: rec.name, size: rec.size, type: rec.type, lastModified: rec.lastModified, savedAt: rec.savedAt || Date.now(), time: rec.time || 0,
      duration: (rec.project.media && rec.project.media.duration) || 0, cues: 0, open: false, store: st, opfs: opfs });
    await S.persist.del(['project', 'clip']).catch(() => {});
  }

  /** Pin the private video copies of all drafts. Set up at load time so that local-copy's clean-up waits for it (it must never run before the pins exist). */
  async function pinAll() {
    if (!S.localCopy) return;
    for (const r of await load()) if (r.store === 'opfs' && r.opfs) S.localCopy.pin(r.opfs);
    try { await migrate(); } catch (e) { console.warn('[drafts] migration failed:', e); }
  }
  if (S.localCopy) S.localCopy.pinsReady = pinAll();

  S.drafts = { list: list, get: get, create: create, save: save, patch: patch, clipFile: clipFile, remove: remove };
})(window.SubEd = window.SubEd || {});
