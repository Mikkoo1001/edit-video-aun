/* =====================================================================
 * MP4 muxer — no DOM, no libraries. Turns WebCodecs output (H.264 in AVCC form + raw AAC frames)
 * into a normal .mp4 (moov up front = "fast start") that plays in phone galleries, CapCut, TikTok,
 * Instagram, Windows/Mac players and browsers.
 *
 *   const w = S.mp4.createWriter({ width, height, fps, audio, durationUs });
 *   w.setVideoDescription(avcC);                     // Uint8Array = the encoder's decoderConfig.description
 *   w.addVideo(tsUs, isKey, Uint8Array) ...        // presentation order == decode order (no B-frames)
 *   const blob = w.finish();                         // 'video/mp4'
 *   audio = { chunks:[{ts,data}], sampleRate, channels, asc:Uint8Array } | null   (pre-encoded AAC-LC)
 *
 * Like the WebM writer, media data is handed to Blobs about once a second, so a long 1080p60 clip never
 * sits in JS memory; the sample tables are plain numbers (a few MB even for hours of video).
 * ===================================================================== */
(function (S) {
  'use strict';

  const enc = new TextEncoder();
  const VT = 90000;                               // video timescale

  function concat(parts) {
    let n = 0; parts.forEach(p => { n += p.length; });
    const out = new Uint8Array(n); let o = 0;
    parts.forEach(p => { out.set(p, o); o += p.length; });
    return out;
  }
  const u8 = (...a) => Uint8Array.from(a);
  const u16 = n => u8((n >> 8) & 255, n & 255);
  const u32 = n => u8((n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255);
  const u64 = n => concat([u32(Math.floor(n / 4294967296)), u32(n >>> 0)]);
  const zeros = n => new Uint8Array(n);
  const str4 = s => enc.encode(s);
  function box(type, ...payload) {
    const body = concat(payload);
    return concat([u32(8 + body.length), str4(type), body]);
  }
  const full = (type, version, flags, ...payload) => box(type, u8(version, (flags >> 16) & 255, (flags >> 8) & 255, flags & 255), ...payload);
  const MATRIX = concat([u32(0x00010000), u32(0), u32(0), u32(0), u32(0x00010000), u32(0), u32(0), u32(0), u32(0x40000000)]);

  function desc(tag, ...payload) {                // MPEG-4 descriptor with a 4-byte length
    const body = concat(payload), n = body.length;
    return concat([u8(tag, 0x80 | ((n >> 21) & 127), 0x80 | ((n >> 14) & 127), 0x80 | ((n >> 7) & 127), n & 127), body]);
  }
  function rle(values) {                          // [[count, value], ...]
    const out = [];
    for (let i = 0; i < values.length; i++) {
      const last = out[out.length - 1];
      if (last && last[1] === values[i]) last[0]++; else out.push([1, values[i]]);
    }
    return out;
  }

  function createWriter(o) {
    const fps = o.fps || 30;
    const audio = o.audio && o.audio.chunks && o.audio.chunks.length ? o.audio : null;
    const achunks = audio ? audio.chunks : [];
    let avcC = null;

    // sample tables
    const vSizes = [], vTs = [], vKeys = [];      // vTs in microseconds
    const aSizes = [];
    // chunk (interleave group) tables: { n: samples, off: offset inside mdat }
    const vChunks = [], aChunks = [];
    const mdat = [];                              // Blobs
    let mdatBytes = 0;
    let vbuf = [], vbufBytes = 0, vbufN = 0, ai = 0;

    function writeGroup(parts, bytes, list, n) {
      if (!n) return;
      list.push({ n: n, off: mdatBytes });
      mdat.push(new Blob(parts));
      mdatBytes += bytes;
    }
    function flushVideoGroup(untilUs) {
      writeGroup(vbuf, vbufBytes, vChunks, vbufN);
      vbuf = []; vbufBytes = 0; vbufN = 0;
      // audio that belongs before this point in time goes right after the video it accompanies
      const parts = []; let bytes = 0, n = 0;
      while (ai < achunks.length && achunks[ai].ts <= untilUs) {
        const d = achunks[ai].data; parts.push(d); bytes += d.length; aSizes.push(d.length); n++; ai++;
      }
      writeGroup(parts, bytes, aChunks, n);
    }

    function stblVideo(abs) {
      const n = vSizes.length;
      const dts = vTs.map(t => Math.round(t * VT / 1e6));
      const durs = dts.map((d, i) => i + 1 < n ? Math.max(1, dts[i + 1] - d) : Math.max(1, Math.round(VT / fps)));
      const stts = full('stts', 0, 0, u32(rle(durs).length), ...rle(durs).map(r => concat([u32(r[0]), u32(r[1])])));
      const keys = []; vKeys.forEach((k, i) => { if (k) keys.push(i + 1); });
      const stss = full('stss', 0, 0, u32(keys.length), ...keys.map(u32));
      const sc = rle(vChunks.map(c => c.n)); let first = 1; const scE = [];
      sc.forEach(r => { scE.push(concat([u32(first), u32(r[1]), u32(1)])); first += r[0]; });
      const stsc = full('stsc', 0, 0, u32(scE.length), ...scE);
      const stsz = full('stsz', 0, 0, u32(0), u32(n), ...vSizes.map(u32));
      const offs = vChunks.map(c => abs(c.off));
      const stco = chunkOffsets(offs);
      const avc1 = box('avc1', zeros(6), u16(1), zeros(16), u16(o.width), u16(o.height), u32(0x00480000), u32(0x00480000), zeros(4), u16(1),
        zeros(32), u16(0x0018), u16(0xFFFF), box('avcC', avcC));
      const stsd = full('stsd', 0, 0, u32(1), avc1);
      return box('stbl', stsd, stts, stss, stsc, stsz, stco);
    }
    function stblAudio(abs) {
      const sr = audio.sampleRate || 48000, n = aSizes.length;
      const dts = achunks.slice(0, n).map(c => Math.round(c.ts * sr / 1e6));
      const durs = dts.map((d, i) => i + 1 < n ? Math.max(1, dts[i + 1] - d) : (i > 0 ? Math.max(1, d - dts[i - 1]) : 1024));
      const stts = full('stts', 0, 0, u32(rle(durs).length), ...rle(durs).map(r => concat([u32(r[0]), u32(r[1])])));
      const sc = rle(aChunks.map(c => c.n)); let first = 1; const scE = [];
      sc.forEach(r => { scE.push(concat([u32(first), u32(r[1]), u32(1)])); first += r[0]; });
      const stsc = full('stsc', 0, 0, u32(scE.length), ...scE);
      const stsz = full('stsz', 0, 0, u32(0), u32(n), ...aSizes.map(u32));
      const stco = chunkOffsets(aChunks.map(c => abs(c.off)));
      const esds = full('esds', 0, 0, desc(0x03, u16(2), u8(0),
        desc(0x04, u8(0x40, 0x15), u8(0, 0x30, 0x00), u32(0), u32(0), desc(0x05, audio.asc)),
        desc(0x06, u8(0x02))));
      const mp4a = box('mp4a', zeros(6), u16(1), zeros(8), u16(audio.channels || 2), u16(16), u16(0), u16(0), u32(Math.min(65535, sr) * 65536), esds);
      const stsd = full('stsd', 0, 0, u32(1), mp4a);
      return box('stbl', stsd, stts, stsc, stsz, stco);
    }
    let useCo64 = false;
    function chunkOffsets(list) {
      return useCo64 ? full('co64', 0, 0, u32(list.length), ...list.map(u64)) : full('stco', 0, 0, u32(list.length), ...list.map(u32));
    }

    function buildMoov(base) {                    // base = absolute file offset of the first mdat payload byte
      const abs = off => base + off;
      const dur = Math.max(1, Math.round(o.durationUs / 1000));
      const vdur = Math.round((vTs.length ? (vTs[vTs.length - 1] + 1e6 / fps) : o.durationUs) / 1000);
      const nextId = audio ? 3 : 2;
      const mvhd = full('mvhd', 0, 0, u32(0), u32(0), u32(1000), u32(dur), u32(0x00010000), u16(0x0100), zeros(10), MATRIX, zeros(24), u32(nextId));
      const vtrak = box('trak',
        full('tkhd', 0, 3, u32(0), u32(0), u32(1), zeros(4), u32(vdur), zeros(8), u16(0), u16(0), u16(0), zeros(2), MATRIX, u32(o.width * 65536), u32(o.height * 65536)),
        box('mdia',
          full('mdhd', 0, 0, u32(0), u32(0), u32(VT), u32(Math.round(vdur * VT / 1000)), u16(0x55C4), u16(0)),
          full('hdlr', 0, 0, u32(0), str4('vide'), zeros(12), enc.encode('VideoHandler\0')),
          box('minf',
            full('vmhd', 0, 1, zeros(8)),
            box('dinf', full('dref', 0, 0, u32(1), full('url ', 0, 1))),
            stblVideo(abs))));
      const parts = [mvhd, vtrak];
      if (audio) {
        const sr = audio.sampleRate || 48000;
        const adur = Math.round((achunks.length ? achunks[achunks.length - 1].ts / 1e6 + 1024 / sr : 0) * 1000);
        parts.push(box('trak',
          full('tkhd', 0, 3, u32(0), u32(0), u32(2), zeros(4), u32(adur), zeros(8), u16(0), u16(0), u16(0x0100), zeros(2), MATRIX, u32(0), u32(0)),
          box('mdia',
            full('mdhd', 0, 0, u32(0), u32(0), u32(sr), u32(Math.round(adur * sr / 1000)), u16(0x55C4), u16(0)),
            full('hdlr', 0, 0, u32(0), str4('soun'), zeros(12), enc.encode('SoundHandler\0')),
            box('minf',
              full('smhd', 0, 0, zeros(4)),
              box('dinf', full('dref', 0, 0, u32(1), full('url ', 0, 1))),
              stblAudio(abs)))));
      }
      return box('moov', ...parts);
    }

    return {
      setVideoDescription(d) { if (d && d.length) avcC = d instanceof Uint8Array ? d : new Uint8Array(d.buffer || d); },
      addVideo(tsUs, key, data) {
        vSizes.push(data.length); vTs.push(tsUs); vKeys.push(!!key);
        vbuf.push(data); vbufBytes += data.length; vbufN++;
        if (vbufN >= fps) flushVideoGroup(tsUs);  // about one second of picture per chunk
      },
      finish() {
        if (!avcC) throw new Error('ไม่ได้รับข้อมูล avcC จากตัวเข้ารหัส H.264');
        flushVideoGroup(Infinity);
        const ftyp = box('ftyp', str4('isom'), u32(512), str4('isom'), str4('iso2'), str4('avc1'), str4('mp41'));
        const big = mdatBytes + 16 > 0xFFFFFFFF;
        const mdatHead = big ? concat([u32(1), str4('mdat'), u64(mdatBytes + 16)]) : concat([u32(mdatBytes + 8), str4('mdat')]);
        useCo64 = ftyp.length + mdatBytes + 16 > 0xF0000000;
        let moov = buildMoov(0);                  // first pass only to learn the size (offsets have fixed width)
        moov = buildMoov(ftyp.length + moov.length + mdatHead.length);
        return new Blob([ftyp, moov, mdatHead].concat(mdat), { type: 'video/mp4' });
      }
    };
  }

  S.mp4 = { createWriter: createWriter };
})(window.SubEd = window.SubEd || {});
