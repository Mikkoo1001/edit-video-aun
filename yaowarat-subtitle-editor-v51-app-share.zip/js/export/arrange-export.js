/* =====================================================================
 * Exporter 'arrange' — renders the arranged video: the scenes' clips (cropped / fitted to 9:16 or 7:12) + captions, over the
 * original audio. Frame by frame (WebCodecs), same container writers as the normal export (MP4 H.264/AAC, else WebM VP9/Opus).
 * It reads the model through SubEd.arrange (sceneAt / clipTime / drawFit), the same code the preview uses.
 *
 * Each scene is rendered by letting its clip PLAY slowly and taking the picture every time one is presented
 * (requestVideoFrameCallback); runs that cannot play (no rVFC, stalls) fall back to seeking frame by frame.
 * ===================================================================== */
(function (S) {
  'use strict';
  const K = () => S.exportKit;
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  async function start(job, token) {
    const kit = K(), AR = S.arrange, project = job.project, A = project.arrange, file = project.media.file, fps = job.fps;
    if (!(window.VideoEncoder && window.VideoFrame && window.AudioEncoder && window.AudioData && S.webm && kit)) {
      return { error: 'เบราว์เซอร์นี้ยังไม่รองรับการส่งออกแบบจัดฉาก (ต้องใช้ WebCodecs) — ลองใช้ Chrome หรือ Edge เวอร์ชันล่าสุด' };
    }
    const rng = job.range || project.trim, t0 = Math.max(0, rng.start), t1 = Math.max(t0, rng.end), span = t1 - t0;
    if (!(span > 0)) return { error: 'ช่วงที่ตัดไว้สั้นเกินไป' };
    if (!A.scenes.length || !A.scenes.some(s => AR.clipOf(s))) return { error: 'ยังไม่มีฉากที่ใส่คลิปภาพ' };
    // pieces deleted with "ตัดวิดีโอ" are left out: output frame i shows source time ranges[k][0] + (i - rslot[k]) / fps
    const ranges = S.videoCut ? S.videoCut.keptRanges(t0, t1) : [[t0, t1]];
    const rcounts = ranges.map(r => Math.max(1, Math.round((r[1] - r[0]) * fps)));
    const rslot = []; rcounts.reduce((n, c) => { rslot.push(n); return n + c; }, 0);
    const total = rcounts.reduce((n, c) => n + c, 0), spanOut = total / fps;
    job.onAttempt();
    try { job.video.pause(); } catch (e) {}
    if (S.style && S.style.ensureFont) await S.style.ensureFont();
    if (S.fontKit) S.fontKit.warnIfMissing();

    const [aw, ah] = AR.ratio(), dim = S.render.computeExportDims(aw, ah, job.preset), w = dim.w, h = dim.h;
    const scale = w / (job.previewWidth || w);
    const preset = S.render.presets[job.preset] || S.render.presets['1080p'];
    const bitrate = job.bitrate > 0 ? Math.round(job.bitrate) : Math.round(preset.bitrate * (fps > 30 ? 1.25 : 1));
    let encoder = null, closeAll = () => {};
    const els = new Map();                       // clip id -> its own <video> for the export (the preview's elements keep playing independently)
    try {
      // ---- container ----
      const notes = []; let kind = 'webm', pick = null;
      if (job.format !== 'webm') {
        const p = await kit.pickVideoConfig(w, h, fps, bitrate, 'h264');
        if (p && await kit.aacSupported()) { kind = 'mp4'; pick = p; }
        else if (job.format === 'mp4') notes.push('เครื่องนี้เข้ารหัส MP4 ไม่ได้ จึงส่งออกเป็น WebM แทน');
      }
      if (!pick) { pick = await kit.pickVideoConfig(w, h, fps, bitrate, 'vp9'); if (!pick) return { error: 'เครื่องนี้เข้ารหัสวิดีโอขนาดนี้ไม่ได้ ลองลดความละเอียดหรือเฟรมเรต' }; }

      const canvas = document.createElement('canvas'); canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext('2d', { alpha: false });
      const pic = document.createElement('canvas'); pic.width = w; pic.height = h;
      const pctx = pic.getContext('2d', { alpha: false }); pctx.imageSmoothingEnabled = true; pctx.imageSmoothingQuality = 'high';
      const cache = S.render.makeCaptionCache();
      const prevPic = document.createElement('canvas'); prevPic.width = w; prevPic.height = h;   // the previous scene's last picture (for transitions)
      const prevCtx = prevPic.getContext('2d', { alpha: false });
      let hasPrev = false;
      // sound effects: each scene's effect lands on its first frame; mixed into the audio track as it is encoded (together with the "เสียง" tracks)
      const FX = S.arrangeFx, AT = S.audioTracks, hasTracks = !!(AT && AT.count());
      const mixFor = (a, b) => {
        const ev = A.sfxOn ? A.scenes.filter(s => s.sfx && s.start > 0.05 && s.start >= a - (a <= t0 + 1e-6 ? 1.5 : 0.05) && s.start < b).map(s => ({ t: s.start - a, type: s.sfx, vol: A.sfxVol })) : [];
        return (AT ? AT.chain : (x, y) => x || y)(ev.length ? FX.makeMixer(ev) : null, hasTracks ? AT.makeMixer(a) : null);
      };
      const anyMix = ranges.some(r => mixFor(r[0], r[1]));
      const aKind = kind === 'mp4' ? 'aac' : 'opus', offs = rslot.map(n => Math.round(n / fps * 1e6));

      // ---- audio (from the loaded clip / audio file) ----
      job.onStatus('กำลังเตรียมเสียง...', '');
      let lastPct = -1;
      const mainOff = !!(S.mainMute && S.mainMute.get());               // "ปิดเสียงวิดีโอหลัก": the main sound is left out, effects / tracks stay
      let audio = mainOff ? null : await kit.encodeAudioRanges(file, ranges, offs, aKind, () => token.cancelled, project.media.duration, p => {
        const pc = Math.round(p * 100); if (pc !== lastPct) { lastPct = pc; job.onStatus('กำลังเตรียมเสียง... ' + pc + '%', ''); }
      }, mixFor);
      if (token.cancelled) return { cancelled: true };
      if (!audio && anyMix) {                                           // no decodable sound in the loaded clip (or it is switched off): the effects / tracks still get their own track
        audio = await kit.encodeEffectsRanges(ranges, offs, aKind, () => token.cancelled, mixFor);
        if (audio) notes.push(mainOff ? 'ปิดเสียงวิดีโอหลักไว้ จึงมีแต่เสียงเอฟเฟกต์/แทร็กเสียง' : 'ไม่พบเสียงที่ถอดรหัสได้ จึงมีแต่เสียงเอฟเฟกต์');
      }
      if (!audio) notes.push(mainOff ? 'ปิดเสียงวิดีโอหลักไว้ จึงส่งออกเป็นวิดีโอไม่มีเสียง' : 'ไม่พบเสียงที่ถอดรหัสได้ จึงส่งออกเป็นวิดีโอไม่มีเสียง');

      const writer = kind === 'mp4'
        ? S.mp4.createWriter({ width: w, height: h, fps: fps, audio: audio, durationUs: Math.round(spanOut * 1e6) })
        : S.webm.createWriter({ width: w, height: h, fps: fps, codec: pick.mux, audio: audio, durationUs: Math.round(spanOut * 1e6) });
      let encErr = null, nOut = 0;
      encoder = new VideoEncoder({
        output: (c, meta) => {
          const d = new Uint8Array(c.byteLength); c.copyTo(d);
          if (kind === 'mp4' && meta && meta.decoderConfig && meta.decoderConfig.description) writer.setVideoDescription(kit.toU8(meta.decoderConfig.description).slice());
          writer.addVideo(c.timestamp, c.type === 'key', d); nOut++;
        },
        error: e => { encErr = e; }
      });
      encoder.configure(pick.cfg);
      closeAll = () => { try { if (encoder.state !== 'closed') encoder.close(); } catch (e) {} };

      const frameUs = 1e6 / fps, tStart = performance.now();
      let slot = 0;
      const failed = () => encErr ? { error: 'เข้ารหัสวิดีโอไม่สำเร็จ: ' + (encErr.message || encErr) } : null;
      const timeOf = i => { let k = ranges.length - 1; while (k > 0 && i < rslot[k]) k--; return ranges[k][0] + (i - rslot[k]) / fps; };
      const sceneOf = i => AR.sceneAt(Math.min(t1 - 1e-6, timeOf(i) + 0.5 / fps));

      function exportEl(clip) {
        let el = els.get(clip.id);
        if (!el) {
          el = AR.hiddenMedia(URL.createObjectURL(clip.file), clip.still); el._url = el.src; els.set(clip.id, el);      // a still picture is an <img> dressed as a video (see arrange.js)
          while (els.size > 2) {                 // a pool of many clips: only the current one (and the one before it) keep a decoder
            const [oid, old] = els.entries().next().value; els.delete(oid);
            try { old.pause(); URL.revokeObjectURL(old._url); old.removeAttribute('src'); old.load(); old.remove(); } catch (e) {}
          }
        }
        return el;
      }
      async function ready(el) {
        if (el.readyState >= 1) return;
        await new Promise((res, rej) => { el.addEventListener('loadedmetadata', res, { once: true }); el.addEventListener('error', () => rej(new Error('เปิดคลิปภาพไม่ได้')), { once: true }); });
      }
      /** Encode the picture currently in `pic` as output frame `slot`, with its caption. */
      function emit() {
        const i = slot++;
        S.render.composeFrame(ctx, w, h, pic, timeOf(i), project, scale, cache);
        const vf = new VideoFrame(canvas, { timestamp: Math.round(i * frameUs), duration: Math.round(frameUs) });
        encoder.encode(vf, { keyFrame: i % (fps * 2) === 0 }); vf.close();
        if (i % 4 === 0 || i === total - 1) {
          const done = (i + 1) / total, el = (performance.now() - tStart) / 1000, left = done > 0.02 ? el / done - el : 0;
          job.onProgress(done * 100);
          job.onStatus('กำลังเรนเดอร์ฉาก... ' + Math.round(done * 100) + '% (' + job.preset + ' • ' + fps + 'fps • ' + A.aspect + ' • ' + (kind === 'mp4' ? 'MP4' : 'WebM') + ')' + (left > 2 ? ' • เหลือราว ' + S.util.fmt(left) : ''), '');
        }
      }
      const drain = async () => { while (encoder.encodeQueueSize > 4 && !token.cancelled && !encErr) await sleep(5); };

      /** Frames [i0, i1] belong to scene `s`, clip `c`; the clip time of frame i is ct(i). One monotonic stretch (no loop wrap inside). */
      async function renderRun(s, c, i0, i1) {
        const el = exportEl(c), fit = AR.fitOf(s);
        await ready(el);
        const ct = i => AR.clipTime(s, timeOf(i));
        const len = s.end - s.start, withFx = A.fxOn && s.fx;
        if (slot > 0) { prevCtx.drawImage(pic, 0, 0); hasPrev = true; }            // pic still holds the previous scene's last picture
        const base = k => AR.drawFit(k, el, w, h, fit);
        const draw = () => { if (withFx) FX.drawScene(pctx, w, h, base, s.fx, timeOf(slot) - s.start, len, hasPrev ? prevPic : null); else base(pctx); };
        await kit.waitSeek(el, ct(i0));
        draw(); emit();
        let k = i0 + 1;
        const seekRest = async () => {
          for (; k <= i1; k++) {
            if (token.cancelled || encErr) return;
            await kit.waitSeek(el, ct(k)); draw(); emit(); await drain();
          }
        };
        if (k > i1) return;
        if (!('requestVideoFrameCallback' in HTMLVideoElement.prototype)) return seekRest();
        // playback pass: emit every output frame whose clip time has been reached by the presented picture
        el.playbackRate = 0.5;
        await new Promise(resolve => {
          let done = false, cb = 0, lastCb = performance.now(), wd = 0;
          const stop = r => { if (done) return; done = true; clearInterval(wd); try { el.pause(); } catch (e) {} resolve(r); };
          const onFrame = async (now, md) => {
            if (done) return;
            lastCb = performance.now();
            if (token.cancelled || encErr) return stop();
            while (k <= i1 && ct(k) <= md.mediaTime + 0.5 / fps) { draw(); emit(); k++; }
            if (k > i1) return stop();
            if (encoder.encodeQueueSize > 4) { el.pause(); await drain(); if (done) return; el.play().catch(() => {}); }
            cb = el.requestVideoFrameCallback(onFrame);
          };
          wd = setInterval(() => { if (performance.now() - lastCb > 3000) stop('stalled'); }, 500);     // the clip stopped presenting pictures: finish by seeking
          el.play().then(() => { cb = el.requestVideoFrameCallback(onFrame); }).catch(() => stop('stalled'));
        }).then(async r => { if (r === 'stalled' && k <= i1) await seekRest(); });
      }
      /** A still picture: no seeking or playing, each output frame of the scene is the same picture (slowly zooming in when that is switched on). */
      async function renderStill(s, c, i0, i1) {
        const el = exportEl(c), fit = AR.fitOf(s);
        await ready(el);
        const len = s.end - s.start, withFx = A.fxOn && s.fx;
        if (slot > 0) { prevCtx.drawImage(pic, 0, 0); hasPrev = true; }
        const base = k => AR.drawFit(k, el, w, h, fit, AR.zoomOf(s, c, timeOf(slot)));
        for (let i = i0; i <= i1; i++) {
          if (token.cancelled || encErr) return;
          if (withFx) FX.drawScene(pctx, w, h, base, s.fx, timeOf(slot) - s.start, len, hasPrev ? prevPic : null); else base(pctx);
          emit(); await drain();
        }
      }
      async function renderBlack(i0, i1) {
        pctx.fillStyle = '#000'; pctx.fillRect(0, 0, w, h);
        for (let i = i0; i <= i1; i++) { if (token.cancelled || encErr) return; emit(); await drain(); }
      }

      // ---- walk the output frames, grouped by scene (and split where a short clip loops back) ----
      let i = 0;
      while (i < total) {
        if (token.cancelled) return { cancelled: true };
        if (encErr) return failed();
        const s = sceneOf(i), c = AR.clipOf(s);
        let j = i;
        while (j + 1 < total && sceneOf(j + 1) === s && (!c || AR.clipTime(s, timeOf(j + 1)) >= AR.clipTime(s, timeOf(j)) - 1e-6)) j++;
        if (c && c.still) await renderStill(s, c, i, j); else if (c) await renderRun(s, c, i, j); else await renderBlack(i, j);
        if (slot <= j && !token.cancelled && !encErr) return { error: 'ส่งออกฉากไม่ครบ (' + slot + '/' + total + ') ลองใหม่อีกครั้ง' };
        i = j + 1;
        await drain();
      }
      if (token.cancelled) return { cancelled: true };
      job.onStatus('กำลังประกอบไฟล์...', '');
      await encoder.flush();
      if (encErr) return failed();
      closeAll();
      if (nOut !== total) return { error: 'ตัวเข้ารหัสส่งเฟรมออกมาไม่ครบ (' + nOut + '/' + total + ') ลองใหม่อีกครั้ง' };
      const blob = writer.finish();
      if (!blob || !blob.size) return { error: 'ประกอบไฟล์ไม่สำเร็จ ลองลดความละเอียดหรือเฟรมเรตแล้วลองใหม่' };
      return { ok: true, blob: blob, mime: kind === 'mp4' ? 'video/mp4' : 'video/webm', ext: kind === 'mp4' ? 'mp4' : 'webm', frames: total, note: notes.join(' • ') };
    } catch (e) {
      const msg = (e && e.message) || String(e);
      if (e && (e.name === 'QuotaExceededError' || /quota|memory|allocation/i.test(msg))) return { error: 'หน่วยความจำไม่พอสำหรับไฟล์ขนาดนี้ ลองลดความละเอียด/เฟรมเรต' };
      return { error: 'ส่งออกไม่สำเร็จ: ' + msg };
    } finally {
      closeAll();
      els.forEach(el => { try { el.pause(); URL.revokeObjectURL(el._url); el.removeAttribute('src'); el.load(); el.remove(); } catch (e) {} });
    }
  }

  S.exporters.register('arrange', {
    label: 'Arranged scenes (MP4/WebM, frame-by-frame)',
    ext: 'mp4',
    start(job) {
      const token = { cancelled: false };
      return { done: start(job, token), cancel() { token.cancelled = true; } };
    }
  });
})(window.SubEd);
