/* =====================================================================
 * Export layer — turns the project into a video file. No UI elements.
 *
 * An exporter is  { start(job) -> { done: Promise<outcome>, cancel() } }
 *   job     = { video, project, preset, fps, previewWidth, onAttempt(), onStatus(msg,kind), onProgress(pct) }
 *   outcome = { ok:true, blob, mime, ext } | { cancelled:true } | { error:'message' }
 * The exporter owns retries; it never touches buttons or panels — it reports
 * through the callbacks. Add MP4 / offline (non-real-time) rendering later as
 * another registered exporter (e.g. 'mp4-webcodecs') and pick it by id.
 * ===================================================================== */
(function (S) {
  'use strict';
  const exporters = S.exporters = S.createRegistry('exporter');

  // ---- 'webm-realtime' (last-resort fallback): plays the clip while MediaRecorder captures canvas + audio ----
  // graph: video element -> speakerGain -> speakers ;  video element -> recordGain -> (per-attempt) recording destination
  // The element must be un-muted for audio to reach the graph, so a muted preview is handled with speakerGain = 0.
  let audioCtx = null, audioSource = null, speakerGain = null, recordGain = null;

  function pickMimeType() {
    const candidates = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
    for (const c of candidates) { if (window.MediaRecorder && MediaRecorder.isTypeSupported(c)) return c; }
    return '';
  }
  function seekTo(video, t) {
    return new Promise(resolve => {
      function onSeeked() { video.removeEventListener('seeked', onSeeked); resolve(); }
      video.addEventListener('seeked', onSeeked);
      video.currentTime = t;
    });
  }
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  /** One recording attempt. Resolves with an outcome, or { retry:true, recorderErr } when nothing was recorded. */
  async function attempt(job, token) {
    const ctl = { restore: null };
    try { return await attemptInner(job, token, ctl); }
    finally { if (ctl.restore) ctl.restore(); if (ctl.releaseTracks) ctl.releaseTracks(); }
  }

  async function attemptInner(job, token, ctl) {
    const video = job.video, project = job.project;
    const rng = job.range || project.trim;      // { start, end } in source seconds: the trim, or the whole clip
    const mimeType = pickMimeType();
    if (!mimeType) return { error: 'เบราว์เซอร์นี้ไม่รองรับการส่งออกวิดีโอ ลองใช้ Chrome หรือ Edge เวอร์ชันล่าสุด' };

    if (S.style && S.style.ensureFont) await S.style.ensureFont();
    if (S.fontKit) S.fontKit.warnIfMissing();
    const preset = job.preset, fps = job.fps;
    const dim = S.render.computeExportDims(video.videoWidth, video.videoHeight, preset);
    const w = dim.w, h = dim.h;
    const previewW = job.previewWidth || w;
    const scale = w / previewW;

    const canvas = document.createElement('canvas');
    canvas.width = w; canvas.height = h;
    const ctx = canvas.getContext('2d');

    try {
      if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === 'suspended') await audioCtx.resume();
      if (!audioSource) {
        audioSource = audioCtx.createMediaElementSource(video);
        speakerGain = audioCtx.createGain();
        recordGain = audioCtx.createGain();
        audioSource.connect(speakerGain);
        speakerGain.connect(audioCtx.destination);
        audioSource.connect(recordGain);
      }
    } catch (e) {
      return { error: 'ไม่สามารถเข้าถึงเสียงของวิดีโอได้: ' + e.message };
    }
    // a muted element feeds silence into the graph: un-mute it for the export, keep the speakers quiet, restore afterwards
    const wasMuted = video.muted;
    speakerGain.gain.value = wasMuted ? 0 : 1;
    recordGain.gain.value = (S.mainMute && S.mainMute.get()) ? 0 : 1;          // "ปิดเสียงวิดีโอหลัก": the main sound stays out of the recording (the เสียง tracks are added separately)
    if (wasMuted) video.muted = false;
    ctl.restore = () => { video.muted = wasMuted; speakerGain.gain.value = 1; };
    const dest = audioCtx.createMediaStreamDestination();
    recordGain.connect(dest);

    const canvasStream = canvas.captureStream(fps);
    const mixed = new MediaStream([...canvasStream.getVideoTracks(), ...dest.stream.getAudioTracks()]);

    const bitrate = job.bitrate > 0 ? Math.round(job.bitrate) : (S.render.presets[preset] || S.render.presets['1080p']).bitrate;
    let recorder;
    try {
      recorder = new MediaRecorder(mixed, { mimeType: mimeType, videoBitsPerSecond: bitrate });
    } catch (e) {
      recordGain.disconnect(dest);
      return { error: 'สร้างตัวบันทึกวิดีโอไม่สำเร็จ: ' + e.message };
    }

    const buf = [];
    let recorderErr = null, userCancelled = false, running = false, raf = null, frameErr = null;
    recorder.ondataavailable = e => { if (e.data && e.data.size) buf.push(e.data); };
    recorder.onerror = e => { recorderErr = (e && e.error && e.error.message) || 'unknown recorder error'; };

    const finished = new Promise(resolve => {
      recorder.onstop = () => {
        try { recordGain.disconnect(dest); } catch (e) {}
        if (ctl.releaseTracks) ctl.releaseTracks();
        if (userCancelled) return resolve({ cancelled: true });
        if (frameErr) return resolve({ error: 'วาดเฟรมวิดีโอไม่สำเร็จ: ' + frameErr });   // never hang on a render failure
        if (!buf.length) return resolve({ retry: true, recorderErr: recorderErr });
        resolve({ ok: true, blob: new Blob(buf, { type: mimeType.split(';')[0] }), mime: mimeType.split(';')[0], ext: 'webm' });
      };
    });

    function finish() {
      if (!running) return;
      running = false;
      cancelAnimationFrame(raf);
      video.pause();
      try { recorder.stop(); } catch (e) {}
    }
    token.stopNow = () => { userCancelled = true; finish(); };
    if (token.cancelled) { try { recordGain.disconnect(dest); } catch (e) {} return { cancelled: true }; }   // cancelled while still setting up

    running = true;
    job.onAttempt();
    job.onStatus('กำลังเตรียมส่งออก...', '');

    video.pause();
    await seekTo(video, rng.start);
    if (userCancelled) { try { recordGain.disconnect(dest); } catch (e) {} return { cancelled: true }; }   // cancelled during the seek: never start recording
    job.onStatus('กำลังส่งออก... (' + preset + ' • ' + fps + 'fps)', '');

    recorder.start(250);
    const AT = S.audioTracks; let trackNodes = [];
    if (AT && AT.count()) {                          // the "เสียง" tracks go straight into the recording (the preview is held silent meanwhile)
      AT.hold(true);
      try { trackNodes = AT.scheduleInto(audioCtx, dest, rng.start, audioCtx.currentTime + 0.08); } catch (e) { trackNodes = []; }
    }
    if (S.videoCut) S.videoCut.hold(true);                                         // this exporter jumps over deleted pieces itself
    ctl.releaseTracks = () => { if (AT) { AT.stopNodes(trackNodes); trackNodes = []; AT.hold(false); } if (S.videoCut) S.videoCut.hold(false); ctl.releaseTracks = null; };
    try { await video.play(); } catch (e) {}

    function frame() {
      if (!running) return;
      try { S.render.composeFrame(ctx, w, h, video, video.currentTime, project, scale); }
      catch (e) { frameErr = (e && e.message) || String(e); finish(); return; }
      const t = video.currentTime;
      const skip = S.videoCut && S.videoCut.skipInfo(t);            // a piece the user deleted: jump over it (the recording just carries on)
      if (skip) {
        if (skip.to >= rng.end - 0.03) { finish(); return; }
        video.currentTime = Math.max(skip.to, rng.start);
        if (AT && AT.count()) { AT.stopNodes(trackNodes); trackNodes = AT.scheduleInto(audioCtx, dest, skip.to, audioCtx.currentTime + 0.1); }
        raf = requestAnimationFrame(frame); return;
      }
      const span = Math.max(0.001, rng.end - rng.start);
      job.onProgress(Math.min(100, Math.max(0, (t - rng.start) / span * 100)));
      if (t >= rng.end - 0.02 || video.ended) { finish(); return; }
      raf = requestAnimationFrame(frame);
    }
    raf = requestAnimationFrame(frame);

    return finished;
  }


  // ---- 'offline': frame-by-frame rendering with WebCodecs (no real-time playback) ----
  // Why: the real-time exporter plays the clip and records whatever the phone manages to paint, so a heavy
  // 1080p / 60 fps job drops frames (frozen picture, clip cut short, blocky quality). Here every output frame is
  // produced on purpose — take the source picture for time t, draw video + caption, hand it to VideoEncoder — so the
  // file always has every frame of the chosen range, however slow the device is.
  //   container  MP4 (H.264 + AAC) when the browser can encode both — plays everywhere (phone gallery, CapCut, TikTok ...);
  //              otherwise WebM (VP9/Opus). The user's choice is a preference, never a dead end.
  //   memory     nothing proportional to the clip is held as JS arrays: audio is demuxed + decoded + re-encoded a few
  //              packets at a time (so a 600 MB file works), and the output is built from Blobs the browser pages to disk.
  const OFFLINE_MAX_FILE = (S.limits && S.limits.MAX_VIDEO_BYTES) || 2 * 1024 * 1024 * 1024;
  const LEGACY_AUDIO_MAX = 200 * 1024 * 1024;   // whole-file decodeAudioData() fallback (formats the streaming reader cannot open)

  function offlineSupported(file) {
    return !!(window.VideoEncoder && window.VideoFrame && window.AudioEncoder && window.AudioData &&
      window.AudioContext && S.webm && file && file.size <= OFFLINE_MAX_FILE);
  }
  const toU8 = d => d instanceof Uint8Array ? d : (d && d.buffer ? new Uint8Array(d.buffer, d.byteOffset || 0, d.byteLength) : new Uint8Array(d));

  /** H.264 level_idc that fits the picture size AND the macroblock rate (1080p60 needs 4.2, 1440p60 needs 5.1). */
  function avcLevel(w, h, fps) {
    const mbs = Math.ceil(w / 16) * Math.ceil(h / 16), rate = mbs * fps;
    const L = [[0x28, 8192, 245760], [0x2A, 8704, 522240], [0x32, 22080, 589824], [0x33, 36864, 983040], [0x34, 36864, 2073600]];
    for (const l of L) if (mbs <= l[1] && rate <= l[2]) return l[0];
    return 0x34;
  }

  async function pickVideoConfig(w, h, fps, bitrate, kind) {
    let list;
    if (kind === 'h264') {
      const lv = avcLevel(w, h, fps).toString(16).toUpperCase().padStart(2, '0');
      list = [['avc1.6400' + lv, 'V_AVC'], ['avc1.4D40' + lv, 'V_AVC'], ['avc1.42E0' + lv, 'V_AVC']];
    } else {
      const big = w * h > 2228224 || w * h * fps > 133693440 * 1.0;   // beyond VP9 level 4.1 (1080p60 still fits 4.1)
      list = big
        ? [['vp09.00.51.08', 'V_VP9'], ['vp09.00.50.08', 'V_VP9'], ['vp8', 'V_VP8']]
        : [['vp09.00.41.08', 'V_VP9'], ['vp09.00.40.08', 'V_VP9'], ['vp09.00.51.08', 'V_VP9'], ['vp8', 'V_VP8']];
    }
    for (const [codec, mux] of list) {
      for (const mode of ['variable', 'constant']) {
        const cfg = { codec: codec, width: w, height: h, bitrate: bitrate, framerate: fps, bitrateMode: mode, latencyMode: 'quality' };
        if (kind === 'h264') cfg.avc = { format: 'avc' };       // length-prefixed NAL units + avcC, what MP4 stores
        try { const r = await VideoEncoder.isConfigSupported(cfg); if (r && r.supported) return { cfg: r.config || cfg, mux: mux }; } catch (e) {}
      }
    }
    return null;
  }

  function audioEncoderConfig(kind, ch) {
    return kind === 'aac'
      ? { codec: 'mp4a.40.2', sampleRate: 48000, numberOfChannels: ch, bitrate: ch > 1 ? 192000 : 128000 }
      : { codec: 'opus', sampleRate: 48000, numberOfChannels: ch, bitrate: 160000 };
  }
  async function aacSupported() {
    try { const r = await AudioEncoder.isConfigSupported(audioEncoderConfig('aac', 2)); return !!(r && r.supported); } catch (e) { return false; }
  }
  function makeOpusHead(channels) {
    const b = new Uint8Array(19), dv = new DataView(b.buffer);
    b.set([0x4F, 0x70, 0x75, 0x73, 0x48, 0x65, 0x61, 0x64], 0);   // "OpusHead"
    b[8] = 1; b[9] = channels; dv.setUint16(10, 312, true); dv.setUint32(12, 48000, true); dv.setInt16(16, 0, true); b[18] = 0;
    return b;
  }
  function makeAsc(channels) {                    // AudioSpecificConfig for AAC-LC @ 48 kHz (used only if the encoder gives none)
    const v = (2 << 11) | (3 << 7) | (channels << 3);
    return Uint8Array.from([v >> 8, v & 255]);
  }

  /** Wraps AudioEncoder so both audio paths share it: feed 48 kHz planar float blocks, get { chunks, head }. */
  function makeAudioSink(kind, ch, mix) {            // mix(planes, n, firstSampleIndex): optional, ADDS sound effects into each block before it is encoded
    const chunks = []; let head = null, err = null, sent = 0;
    const encoder = new AudioEncoder({
      output: (c, meta) => {
        const d = new Uint8Array(c.byteLength); c.copyTo(d);
        chunks.push({ ts: c.timestamp, data: d });
        if (!head && meta && meta.decoderConfig && meta.decoderConfig.description) head = toU8(meta.decoderConfig.description).slice();
      },
      error: e => { err = e; }
    });
    encoder.configure(audioEncoderConfig(kind, ch));
    return {
      get error() { return err; },
      get queue() { return encoder.encodeQueueSize; },
      /** planes: array of Float32Array (one per channel), n frames */
      send(planes, n) {
        if (mix) mix(planes, n, sent);
        const data = new Float32Array(n * ch);
        for (let c = 0; c < ch; c++) data.set(planes[Math.min(c, planes.length - 1)].subarray(0, n), c * n);
        const ad = new AudioData({ format: 'f32-planar', sampleRate: 48000, numberOfFrames: n, numberOfChannels: ch, timestamp: Math.round(sent / 48000 * 1e6), data: data });
        encoder.encode(ad); ad.close(); sent += n;
      },
      async finish() {
        if (!err) await encoder.flush();
        try { encoder.close(); } catch (e) {}
        if (err || !chunks.length) return null;
        const h = kind === 'aac' ? (head && head.length >= 2 ? head : makeAsc(ch)) : (head && head.length >= 19 ? head : makeOpusHead(ch));
        return { kind: kind, chunks: chunks, channels: ch, sampleRate: 48000, head: h, opusHead: kind === 'opus' ? h : null, asc: kind === 'aac' ? h : null };
      },
      abort() { try { if (encoder.state !== 'closed') encoder.close(); } catch (e) {} }
    };
  }

  /** STREAMING path: demux (own parser, a few MB at a time) -> AudioDecoder -> cut to [start,end] -> 48 kHz -> encoder.
   *  Never holds the file or the decoded sound in memory, so a 600 MB clip of any length works. Throws err.unsupported
   *  when the container/codec cannot be streamed (the caller then tries the whole-file fallback). */
  async function encodeAudioStream(file, start, end, kind, isCancelled, durationHint, onProgress, mix) {
    const unsupported = m => { const e = new Error(m); e.unsupported = true; return e; };
    if (!(S.audio && S.audio._demux && window.AudioDecoder && window.EncodedAudioChunk)) throw unsupported('no streaming audio');
    const demux = await S.audio._demux.open(file, durationHint);
    const info = demux.info;
    const dcfg = { codec: info.codec, sampleRate: info.sampleRate, numberOfChannels: info.channels };
    if (info.description) dcfg.description = info.description;
    let sup = null; try { sup = await AudioDecoder.isConfigSupported(dcfg); } catch (e) {}
    if (!sup || !sup.supported) throw unsupported('audio codec not decodable');

    const OUT = 48000, ch = info.channels >= 2 ? 2 : 1;
    const sink = makeAudioSink(kind, ch, mix);
    let decErr = null, reachedEnd = false;

    // --- position bookkeeping (all in SOURCE sample frames; "relative" = counted from the start of the chosen range) ---
    let srcRate = 0, fromF = 0, toF = 0, skip = 0, shift = 0, decoded = 0, gNext = 0;
    // --- 48 kHz output block (1 s) and the linear resampler ---
    let oL = new Float32Array(OUT), oR = ch > 1 ? new Float32Array(OUT) : null, fill = 0;
    let tL = new Float32Array(0), tR = new Float32Array(0), nextOut = 0, prevL = 0, prevR = 0;
    const planes = () => ch > 1 ? [oL, oR] : [oL];

    function pushOut(L, R, n) {                   // samples already at 48 kHz
      let i = 0;
      while (i < n) {
        const k = Math.min(n - i, OUT - fill);
        oL.set(L.subarray(i, i + k), fill); if (oR) oR.set(R.subarray(i, i + k), fill);
        fill += k; i += k;
        if (fill === OUT) { sink.send(planes(), OUT); fill = 0; }
      }
    }
    function feed(L, R, n) {                      // contiguous source-rate samples
      if (n <= 0) return;
      if (srcRate === OUT) { pushOut(L, R, n); gNext += n; return; }
      const ratio = srcRate / OUT, g0 = gNext, cap = Math.ceil(n / ratio) + 2;
      if (tL.length < cap) { tL = new Float32Array(cap); tR = new Float32Array(cap); }
      let m = 0;
      for (;;) {
        const pos = nextOut * ratio, i0 = Math.floor(pos);
        if (i0 + 1 >= g0 + n) break;
        const f = pos - i0;
        let aL, bL, aR, bR;
        if (i0 < g0) { aL = prevL; aR = prevR; bL = L[0]; bR = R[0]; }
        else { const j = i0 - g0; aL = L[j]; bL = L[j + 1]; aR = R[j]; bR = R[j + 1]; }
        tL[m] = aL + (bL - aL) * f; tR[m] = aR + (bR - aR) * f; m++; nextOut++;
      }
      prevL = L[n - 1]; prevR = R[n - 1]; gNext += n;
      pushOut(tL, tR, m);
    }
    function init(sr) {
      srcRate = sr; fromF = Math.max(0, Math.round(start * sr)); toF = Math.round(end * sr);
      shift = Math.round(Math.max(0, info.startShift || 0) * sr); skip = Math.round(Math.max(0, -(info.startShift || 0)) * sr);
      if (shift > fromF) {                        // the sound starts later than the picture: fill the gap with silence
        const n = Math.min(shift, toF) - fromF;
        if (n > 0) { const z = new Float32Array(Math.min(n, sr)); for (let done = 0; done < n; done += z.length) feed(z, z, Math.min(z.length, n - done)); }
      }
    }

    const dec = new AudioDecoder({
      output(ad) {
        try {
          const nf = ad.numberOfFrames, nch = ad.numberOfChannels;
          if (!srcRate) init(ad.sampleRate);
          const v0 = decoded - skip + shift; decoded += nf;
          let a = 0, b = nf;
          if (v0 < fromF) a = Math.min(nf, fromF - v0);
          if (v0 + nf > toF) b = Math.max(a, toF - v0);
          if (v0 + nf >= toF) reachedEnd = true;
          if (b > a) {
            const L = new Float32Array(nf); ad.copyTo(L, { planeIndex: 0, format: 'f32-planar' });
            let R = L;
            if (ch > 1) { R = new Float32Array(nf); if (nch > 1) ad.copyTo(R, { planeIndex: 1, format: 'f32-planar' }); else R.set(L); }
            feed(L.subarray(a, b), R.subarray(a, b), b - a);
          }
        } catch (e) { decErr = decErr || e; }
        finally { ad.close(); }
      },
      error(e) { decErr = decErr || e; }
    });
    dec.configure(dcfg);

    const it = demux.packets();
    let tsUs = 0, pk = 0;
    try {
      while (!isCancelled() && !decErr && !sink.error && !reachedEnd) {
        const r = await it.next();
        if (r.done) break;
        while ((dec.decodeQueueSize > 24 || sink.queue > 16) && !decErr && !sink.error && !isCancelled()) await sleep(2);
        dec.decode(new EncodedAudioChunk({ type: 'key', timestamp: tsUs, data: r.value.data })); tsUs += 1000;
        if ((++pk & 127) === 0 && onProgress) onProgress(demux.progress());
      }
      if (!isCancelled() && !decErr) { try { await dec.flush(); } catch (e) { decErr = decErr || e; } }
    } finally {
      try { if (it.return) await it.return(); } catch (e) {}
      try { if (dec.state !== 'closed') dec.close(); } catch (e) {}
    }
    if (isCancelled()) { sink.abort(); return null; }
    if (decErr) { sink.abort(); throw decErr; }
    if (fill > 0) { sink.send(planes(), fill); fill = 0; }
    return sink.finish();
  }

  /** WHOLE-FILE fallback for containers the streaming reader cannot open (needs the file + its PCM in RAM, so small clips only). */
  async function encodeAudioLegacy(file, start, end, kind, isCancelled, mix) {
    let ac;
    try {
      ac = new AudioContext({ sampleRate: 48000 });
      const buf = await ac.decodeAudioData(await (S.localCopy ? S.localCopy.readAll(file) : file.arrayBuffer()));
      const rate = buf.sampleRate, ch = Math.min(2, buf.numberOfChannels);
      const from = Math.max(0, Math.floor(start * rate)), to = Math.min(buf.length, Math.ceil(end * rate));
      if (to <= from || rate !== 48000) return null;
      const sink = makeAudioSink(kind, ch, mix);
      const pl = []; for (let c = 0; c < ch; c++) pl.push(buf.getChannelData(c));
      for (let pos = from; pos < to; pos += rate) {
        if (isCancelled() || sink.error) break;
        const n = Math.min(rate, to - pos);
        sink.send(pl.map(p => p.subarray(pos, pos + n)), n);
        while (sink.queue > 8) await sleep(2);
      }
      if (isCancelled()) { sink.abort(); return null; }
      return sink.finish();
    } catch (e) {
      return null;                               // no audio track / undecodable codec: the caller reports it
    } finally {
      if (ac) { try { ac.close(); } catch (e) {} }
    }
  }

  async function encodeAudio(file, start, end, kind, isCancelled, durationHint, onProgress, mix) {
    try {
      return await encodeAudioStream(file, start, end, kind, isCancelled, durationHint, onProgress, mix);
    } catch (e) {
      if (isCancelled()) return null;
      console.warn('[export] streaming audio failed, trying the whole-file reader:', e);
      if (file.size > LEGACY_AUDIO_MAX) return null;
      return encodeAudioLegacy(file, start, end, kind, isCancelled, mix);
    }
  }

  function waitSeek(v, t) {
    return new Promise(resolve => {
      if (Math.abs(v.currentTime - t) < 1e-4 && v.readyState >= 2) return resolve();
      let done = false;
      const end = () => { if (done) return; done = true; v.removeEventListener('seeked', end); clearTimeout(tm); resolve(); };
      const tm = setTimeout(end, 4000);          // a seek that never reports back must not hang the export
      v.addEventListener('seeked', end);
      v.currentTime = t;
    });
  }

  async function startOffline(job, token) {
    const project = job.project, file = project.media.file;
    const fps = job.fps;
    const rng = job.range || project.trim;
    const start = Math.max(0, rng.start), end = Math.max(start, rng.end);
    const span = end - start;
    if (!(span > 0)) return { error: 'ช่วงที่ตัดไว้สั้นเกินไป' };
    // pieces the user deleted ("ตัดวิดีโอ") are left out: the kept parts are rendered one after another into one continuous file
    const ranges = S.videoCut ? S.videoCut.keptRanges(start, end) : [[start, end]];
    const rcounts = ranges.map(r => Math.max(1, Math.round((r[1] - r[0]) * fps)));
    const rslot = []; rcounts.reduce((n, c) => { rslot.push(n); return n + c; }, 0);
    const total = rcounts.reduce((n, c) => n + c, 0), spanOut = total / fps;
    job.onAttempt();
    try { job.video.pause(); } catch (e) {}      // free the preview decoder: two 1080p decoders at once is what kills phones

    if (S.style && S.style.ensureFont) await S.style.ensureFont();
    if (S.fontKit) S.fontKit.warnIfMissing();
    const src = document.createElement('video');
    src.muted = true; src.playsInline = true; src.preload = 'auto';
    src.style.cssText = 'position:fixed;right:0;bottom:0;width:4px;height:4px;opacity:0.02;pointer-events:none;';
    document.body.appendChild(src);
    const url = URL.createObjectURL(file);
    let encoder = null, closeAll = () => {};
    try {
      src.src = url;
      await new Promise((res, rej) => {
        if (src.readyState >= 1) return res();
        src.addEventListener('loadedmetadata', res, { once: true });
        src.addEventListener('error', () => rej(new Error('เปิดวิดีโอต้นฉบับไม่ได้')), { once: true });
      });
      const dim = S.render.computeExportDims(src.videoWidth, src.videoHeight, job.preset);
      const w = dim.w, h = dim.h, scale = w / (job.previewWidth || w);
      const preset = S.render.presets[job.preset] || S.render.presets['1080p'];
      const bitrate = job.bitrate > 0 ? Math.round(job.bitrate) : Math.round(preset.bitrate * (fps > 30 ? 1.25 : 1));   // the export page's bitrate slider wins over the preset

      // ---- choose the container: MP4 (H.264 + AAC) when possible, else WebM (VP9 + Opus) ----
      const notes = [];
      let kind = 'webm', pick = null;
      if (job.format !== 'webm') {
        const p = await pickVideoConfig(w, h, fps, bitrate, 'h264');
        if (p && await aacSupported()) { kind = 'mp4'; pick = p; }
        else if (job.format === 'mp4') notes.push('เครื่องนี้เข้ารหัส MP4 ไม่ได้ จึงส่งออกเป็น WebM แทน');
      }
      if (!pick) {
        pick = await pickVideoConfig(w, h, fps, bitrate, 'vp9');
        if (!pick) return { fallback: true };
      }
      const estBytes = spanOut * (bitrate + 192000) / 8;
      if (estBytes > 1.5 * 1024 * 1024 * 1024) notes.push('ไฟล์ผลลัพธ์ใหญ่ราว ' + (estBytes / 1073741824).toFixed(1) + ' GB');

      const canvas = document.createElement('canvas'); canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext('2d', { alpha: false });
      ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
      const cache = S.render.makeCaptionCache();

      // ---- audio first (it is quick and streamed), so a missing track can be reported up front ----
      job.onStatus('กำลังเตรียมเสียง...', '');
      let lastPct = -1;
      const AT = S.audioTracks, hasTracks = !!(AT && AT.count());                      // the "เสียง" tracks are added into the sound as it is encoded
      const mixFor = a => (hasTracks ? AT.makeMixer(a) : null);
      const aKind = kind === 'mp4' ? 'aac' : 'opus', offs = rslot.map(n => Math.round(n / fps * 1e6));
      const mainOff = !!(S.mainMute && S.mainMute.get());                              // "ปิดเสียงวิดีโอหลัก": leave the main sound out, keep the tracks
      let audio = mainOff ? null : await encodeAudioRanges(file, ranges, offs, aKind, () => token.cancelled, src.duration || project.media.duration, p => {
        const pc = Math.round(p * 100); if (pc !== lastPct) { lastPct = pc; job.onStatus('กำลังเตรียมเสียง... ' + pc + '%', ''); }
      }, mixFor);
      if (token.cancelled) return { cancelled: true };
      if (!audio && hasTracks) {                                                       // the clip itself has no decodable sound (or it is switched off): the tracks still get their own
        audio = await encodeEffectsRanges(ranges, offs, aKind, () => token.cancelled, mixFor);
        if (audio) notes.push(mainOff ? 'ปิดเสียงวิดีโอหลักไว้ จึงมีแต่เสียงจากแทร็กเสียง' : 'ไม่พบเสียงที่ถอดรหัสได้ในคลิปนี้ จึงมีแต่เสียงจากแทร็กเสียง');
      }
      if (token.cancelled) return { cancelled: true };
      if (!audio) notes.push(mainOff ? 'ปิดเสียงวิดีโอหลักไว้ จึงส่งออกเป็นวิดีโอไม่มีเสียง' : 'ไม่พบเสียงที่ถอดรหัสได้ในคลิปนี้ จึงส่งออกเป็นวิดีโอไม่มีเสียง');

      // ---- video: encoder output goes straight into the container writer (Blob-backed) ----
      const writer = kind === 'mp4'
        ? S.mp4.createWriter({ width: w, height: h, fps: fps, audio: audio, durationUs: Math.round(spanOut * 1e6) })
        : S.webm.createWriter({ width: w, height: h, fps: fps, codec: pick.mux, audio: audio, durationUs: Math.round(spanOut * 1e6) });
      let encErr = null, nOut = 0;
      encoder = new VideoEncoder({
        output: (c, meta) => {
          const d = new Uint8Array(c.byteLength); c.copyTo(d);
          if (kind === 'mp4' && meta && meta.decoderConfig && meta.decoderConfig.description) writer.setVideoDescription(toU8(meta.decoderConfig.description).slice());
          writer.addVideo(c.timestamp, c.type === 'key', d); nOut++;
        },
        error: e => { encErr = e; }
      });
      encoder.configure(pick.cfg);
      closeAll = () => { try { if (encoder.state !== 'closed') encoder.close(); } catch (e) {} };

      const frameUs = 1e6 / fps, t0 = performance.now();
      let slot = 0;                              // index of the next OUTPUT frame
      let segStart = start, slotBase = 0, slotEnd = total;   // the kept part being rendered now: its source start, its first output frame, the frame after its last (its time is segStart + (slot - slotBase) / fps)

      /** Draw output frame `slot` from `source` (video element or canvas) + its caption, and hand it to the encoder. */
      function emit(source) {
        const i = slot++, t = segStart + (i - slotBase) / fps;
        S.render.composeFrame(ctx, w, h, source, t, project, scale, cache);
        const vf = new VideoFrame(canvas, { timestamp: Math.round(i * frameUs), duration: Math.round(frameUs) });
        encoder.encode(vf, { keyFrame: i % (fps * 2) === 0 });
        vf.close();
        if (i % 4 === 0 || i === total - 1) {
          const done = (i + 1) / total, el = (performance.now() - t0) / 1000, left = done > 0.02 ? el / done - el : 0;
          job.onProgress(done * 100);
          job.onStatus('กำลังเรนเดอร์... ' + Math.round(done * 100) + '% (' + job.preset + ' • ' + fps + 'fps • ' + (kind === 'mp4' ? 'MP4' : 'WebM') + ')' + (left > 2 ? ' • เหลือราว ' + S.util.fmt(left) : ''), '');
        }
      }
      const failed = () => encErr ? { error: 'เข้ารหัสวิดีโอไม่สำเร็จ: ' + (encErr.message || encErr) } : null;

      // Provider A (preferred): let the source play SLOWLY and take every frame it presents (requestVideoFrameCallback).
      // Decoding runs forward the way it is designed to; seeking to every frame re-decodes from the last keyframe each time
      // (~0.3 s per frame on a slow device). The speed adapts: if frames get skipped it slows down, if the encoder
      // falls behind it pauses. Gaps are filled with the previous frame, so the clip never loses time.
      async function renderByPlayback() {
        const mk = () => { const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d', { alpha: false }); x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high'; return { c: c, x: x }; };
        let prev = mk(), cur = mk();
        const snap = o => o.x.drawImage(src, 0, 0, w, h);
        await waitSeek(src, segStart);
        snap(prev);                              // the picture that is on screen at `start`
        return new Promise(resolve => {
          const EPS = 0.001;
          let finished = false, rate = 0.5, lastM = -1, minD = Infinity, samples = 0, clean = 0, cbId = 0, lastCb = performance.now(), stalls = 0, pressure = false;
          let recoverFor = null, gapM = -1, tries = 0, realGaps = 0, vfr = false;
          const finish = r => { if (finished) return; finished = true; clearInterval(wd); try { src.pause(); } catch (e) {} resolve(r || { ok: true }); };
          const reg = () => { if (cbId) { try { src.cancelVideoFrameCallback(cbId); } catch (e) {} } cbId = src.requestVideoFrameCallback(onFrame); };
          const drain = () => new Promise(r => { const poll = () => (encoder.encodeQueueSize <= 2 || token.cancelled || encErr) ? r() : setTimeout(poll, 10); poll(); });
          const resume = () => { pressure = false; if (finished) return; src.play().catch(() => {}); reg(); };
          function onFrame(now, md) {
            if (finished) return;
            lastCb = performance.now(); stalls = 0;
            if (token.cancelled) return finish({ cancelled: true });
            if (encErr) return finish(failed());
            const m = md.mediaTime;
            if (lastM >= 0) { const d = m - lastM; if (d > 0.0005) { minD = Math.min(minD, d); samples++; } }

            // A picture the browser never handed us (the device could not keep up)? Rewind to just after the last one we
            // have and replay that stretch more slowly, instead of repeating the old picture. If the very same gap shows up
            // again it is really in the file (variable frame rate): accept it, and stop looking after a few of them.
            if (!vfr && samples >= 3 && lastM >= 0 && m - lastM > minD * 1.6 && segStart + (slot - slotBase) / fps < m - EPS) {
              if (recoverFor === lastM && Math.abs(m - gapM) < 1e-4) { realGaps++; recoverFor = null; if (realGaps >= 3) vfr = true; }
              else {
                if (recoverFor !== lastM) tries = 0;
                if (tries < 3) {
                  tries++; recoverFor = lastM; gapM = m;
                  rate = Math.max(0.1, rate * 0.7); src.playbackRate = rate; clean = 0;
                  pressure = true; src.pause();
                  waitSeek(src, lastM + EPS).then(resume);
                  return;
                }
                realGaps++; if (realGaps >= 3) vfr = true;
              }
            }
            lastM = m;
            try {
              while (slot < slotEnd && segStart + (slot - slotBase) / fps < m - EPS) emit(prev.c);      // time passed with no new picture: hold the previous one
              snap(cur);
              while (slot < slotEnd && segStart + (slot - slotBase) / fps <= m + EPS) emit(cur.c);
            } catch (e) { return finish({ error: 'วาดเฟรมวิดีโอไม่สำเร็จ: ' + ((e && e.message) || e) }); }
            const t = prev; prev = cur; cur = t;
            if (slot >= slotEnd) return finish();
            if (++clean >= 90 && rate < 1) { rate = Math.min(1, rate * 1.25); src.playbackRate = rate; clean = 0; }
            if (encoder.encodeQueueSize > 8) {   // the encoder is behind: stop the picture until it has caught up
              pressure = true; src.pause();
              drain().then(resume);
              return;
            }
            reg();
          }
          src.addEventListener('ended', () => { if (finished) return; try { while (slot < slotEnd) emit(prev.c); } catch (e) {} finish(); });
          const wd = setInterval(() => {         // the source stopped delivering pictures
            if (finished || pressure || performance.now() - lastCb < 6000) return;
            if (++stalls >= 3) return finish({ error: 'วิดีโอต้นฉบับหยุดตอบสนองระหว่างส่งออก ลองลดความละเอียด/เฟรมเรตแล้วลองใหม่' });
            src.play().catch(() => {}); reg();
          }, 1000);
          src.playbackRate = rate;
          reg();
          src.play().catch(e => finish({ error: 'เล่นวิดีโอต้นฉบับไม่ได้: ' + ((e && e.message) || e) }));
        });
      }

      // Provider B (browsers without requestVideoFrameCallback): seek to every frame — exact but slower.
      async function renderBySeeking() {
        for (let i = slotBase; i < slotEnd; i++) {
          if (token.cancelled) return { cancelled: true };
          if (encErr) return failed();
          await waitSeek(src, Math.min(segStart + (i - slotBase) / fps + 0.25 / fps, Math.max(segStart, src.duration - 0.001)));
          emit(src);
          while (encoder.encodeQueueSize > 6) { await sleep(2); if (encErr || token.cancelled) break; }
        }
        return { ok: true };
      }

      for (let k = 0; k < ranges.length; k++) {                    // each kept part in turn (usually just one)
        segStart = ranges[k][0]; slotBase = rslot[k]; slotEnd = slotBase + rcounts[k];
        const pass = ('requestVideoFrameCallback' in HTMLVideoElement.prototype) ? await renderByPlayback() : await renderBySeeking();
        if (pass.cancelled) return pass;
        if (pass.error) return pass;
        if (slot < slotEnd) return { error: 'ส่งออกไม่ครบทุกเฟรม (' + slot + '/' + total + ') ลองใหม่อีกครั้ง' };
      }
      if (slot < total) return { error: 'ส่งออกไม่ครบทุกเฟรม (' + slot + '/' + total + ') ลองใหม่อีกครั้ง' };
      if (token.cancelled) return { cancelled: true };
      job.onStatus('กำลังประกอบไฟล์...', '');
      await encoder.flush();
      if (encErr) return { error: 'เข้ารหัสวิดีโอไม่สำเร็จ: ' + (encErr.message || encErr) };
      closeAll();
      if (nOut !== total) return { error: 'ตัวเข้ารหัสส่งเฟรมออกมาไม่ครบ (' + nOut + '/' + total + ') ลองใหม่อีกครั้ง' };

      const blob = writer.finish();
      if (!blob || !blob.size) return { error: 'ประกอบไฟล์ไม่สำเร็จ ลองลดความละเอียดหรือเฟรมเรตแล้วลองใหม่' };
      return { ok: true, blob: blob, mime: kind === 'mp4' ? 'video/mp4' : 'video/webm', ext: kind === 'mp4' ? 'mp4' : 'webm', frames: total, note: notes.join(' • ') };
    } catch (e) {
      const msg = (e && e.message) || String(e);
      if (e && (e.name === 'QuotaExceededError' || /quota|memory|allocation/i.test(msg))) return { error: 'หน่วยความจำหรือพื้นที่เก็บของเบราว์เซอร์ไม่พอสำหรับไฟล์ขนาดนี้ ลองลดความละเอียด/เฟรมเรต หรือส่งออกทีละช่วง' };
      return { error: 'ส่งออกไม่สำเร็จ: ' + msg };
    } finally {
      closeAll();
      URL.revokeObjectURL(url);
      src.removeAttribute('src'); src.load();
      if (src.parentNode) src.parentNode.removeChild(src);
    }
  }

  exporters.register('offline', {
    label: 'MP4 (H.264/AAC) or WebM (VP9/Opus), frame-by-frame',
    ext: 'mp4',
    supported: offlineSupported,
    start(job) {
      const token = { cancelled: false };
      const done = startOffline(job, token);
      return { done: done, cancel() { token.cancelled = true; } };
    }
  });

  // 'auto': frame-by-frame when the browser can do it, otherwise (or if it declines the job) the real-time recorder
  exporters.register('auto', {
    label: 'Auto',
    ext: 'mp4',
    start(job) {
      const file = job.project.media.file;
      let inner = null, cancelled = false;
      const done = (async () => {
        if (offlineSupported(file)) {
          inner = exporters.get('offline').start(job);
          const r = await inner.done;
          if (!r.fallback) return r;
          if (cancelled) return { cancelled: true };
          job.onStatus('เครื่องนี้ไม่รองรับการเข้ารหัสแบบเฟรมต่อเฟรม ใช้โหมดบันทึกเรียลไทม์แทน...', '');
        }
        inner = exporters.get('webm-realtime').start(job);
        return inner.done;
      })();
      return { done: done, cancel() { cancelled = true; if (inner) inner.cancel(); } };
    }
  });

  exporters.register('webm-realtime', {
    label: 'WebM (VP9/Opus, real-time capture)',
    ext: 'webm',
    start(job) {
      const token = { cancelled: false, stopNow: null };
      const done = (async () => {
        for (let n = 0; ; n++) {
          const r = await attempt(job, token);
          if (!r.retry) return r;
          if (n >= 2) return { error: 'ส่งออกไม่สำเร็จ' + (r.recorderErr ? ' (' + r.recorderErr + ')' : '') + ' ลองลดความละเอียดหรือเฟรมเรตแล้วลองใหม่อีกครั้ง' };
          job.onStatus('พบปัญหาชั่วคราวระหว่างส่งออก กำลังลองใหม่อีกครั้ง...', '');
          await sleep(250);
          if (token.cancelled) return { cancelled: true };
        }
      })();
      return { done: done, cancel() { token.cancelled = true; if (token.stopNow) token.stopNow(); } };
    }
  });

  /** A track of silence + the effects (mix) for `seconds` — used when the loaded clip has no decodable sound but effects were asked for. */
  async function encodeEffectsOnly(seconds, kind, isCancelled, mix) {
    const sink = makeAudioSink(kind, 2, mix), n = Math.round(seconds * 48000), z = new Float32Array(48000);
    for (let done = 0; done < n && !isCancelled() && !sink.error; done += 48000) {
      const k = Math.min(48000, n - done); z.fill(0); sink.send([z, z], k);
      while (sink.queue > 16) await sleep(2);
    }
    if (isCancelled()) { sink.abort(); return null; }
    return sink.finish();
  }
  /** Concatenate encoded audio of several parts: part k's chunks are moved to offs[k] microseconds (the video frame grid, so sound and picture stay together). */
  function appendAudio(base, part, off) {
    if (!part) return base;
    if (!base) { part.chunks.forEach(c => { c.ts += off; }); return part; }
    part.chunks.forEach(c => base.chunks.push({ ts: c.ts + off, data: c.data }));
    return base;
  }
  /** Sound of the kept parts of the clip, one after another. mixFor(a) -> the mix hook for a part that starts at source time a. */
  async function encodeAudioRanges(file, ranges, offs, kind, isCancelled, durationHint, onProgress, mixFor) {
    let out = null;
    for (let k = 0; k < ranges.length; k++) {
      if (isCancelled()) return null;
      const part = await encodeAudio(file, ranges[k][0], ranges[k][1], kind, isCancelled, durationHint, p => onProgress && onProgress((k + p) / ranges.length), mixFor ? mixFor(ranges[k][0], ranges[k][1]) : null);
      out = appendAudio(out, part, offs[k]);
    }
    return out;
  }
  async function encodeEffectsRanges(ranges, offs, kind, isCancelled, mixFor) {
    let out = null;
    for (let k = 0; k < ranges.length; k++) {
      if (isCancelled()) return null;
      out = appendAudio(out, await encodeEffectsOnly(ranges[k][1] - ranges[k][0], kind, isCancelled, mixFor(ranges[k][0], ranges[k][1])), offs[k]);
    }
    return out;
  }
  S.exportKit = { encodeAudioRanges: encodeAudioRanges, encodeEffectsRanges: encodeEffectsRanges, encodeEffectsOnly: encodeEffectsOnly, pickVideoConfig: pickVideoConfig, aacSupported: aacSupported, encodeAudio: encodeAudio, waitSeek: waitSeek, toU8: toU8, sleep: sleep };   // shared with export/arrange-export.js
  exporters.defaultId = 'auto';   // what the Export tab uses: frame-by-frame when supported, real-time recorder otherwise
})(window.SubEd);
