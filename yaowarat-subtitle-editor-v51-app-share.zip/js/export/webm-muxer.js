/* =====================================================================
 * WebM muxer — no DOM, no libraries. Turns WebCodecs output (VP9/VP8 video chunks and
 * Opus audio chunks) into a complete .webm Blob that knows its duration, has a seek index
 * (Cues) and keyframe flags. MediaRecorder output has none of these, which is why a
 * recorded clip looks "cut short" / can't be scrubbed in many players.
 *
 *   S.webm.mux({
 *     width, height, fps, codec: 'V_VP9' | 'V_VP8',
 *     video: [{ ts, key, data }],              // ts = presentation time in MICROseconds, data = Uint8Array
 *     audio: { chunks:[{ ts, data }], sampleRate, channels, opusHead:Uint8Array } | null,
 *     durationUs                                // total length in microseconds
 *   }) -> Blob ('video/webm')
 * ===================================================================== */
(function (S) {
  'use strict';

  const enc = new TextEncoder();

  function uintBytes(n) {                       // minimal big-endian unsigned integer
    if (n < 0) n = 0;
    const out = [];
    do { out.unshift(n % 256); n = Math.floor(n / 256); } while (n > 0);
    return Uint8Array.from(out);
  }
  function sizeBytes(n) {                       // EBML variable-length size
    let len = 1;
    while (len < 8 && n >= Math.pow(2, 7 * len) - 1) len++;
    const out = new Uint8Array(len);
    let v = n;
    for (let i = len - 1; i >= 0; i--) { out[i] = v % 256; v = Math.floor(v / 256); }
    out[0] |= 1 << (8 - len);
    return out;
  }
  const idBytes = id => uintBytes(id);
  function concat(parts) {
    let n = 0; parts.forEach(p => { n += p.length; });
    const out = new Uint8Array(n); let o = 0;
    parts.forEach(p => { out.set(p, o); o += p.length; });
    return out;
  }
  function el(id, payload) {                    // payload: Uint8Array | Uint8Array[]
    const body = Array.isArray(payload) ? concat(payload) : payload;
    return concat([idBytes(id), sizeBytes(body.length), body]);
  }
  const elUint = (id, n) => el(id, uintBytes(n));
  const elStr = (id, s) => el(id, enc.encode(s));
  function elFloat(id, x) { const b = new Uint8Array(8); new DataView(b.buffer).setFloat64(0, x); return el(id, b); }

  /** Streaming writer: blocks are added one by one and every ~1 s cluster is handed to a Blob straight away, so a long
   *  1080p60 export never keeps more than a second or two of encoded data as JS arrays (the browser pages Blobs to disk).
   *    const w = S.webm.createWriter({ width, height, fps, codec, audio, durationUs });
   *    w.addVideo(tsUs, isKey, Uint8Array) ...      // in presentation order
   *    const blob = w.finish();
   *  audio = { chunks:[{ts,data}], channels, opusHead } is pre-encoded; it is woven in by timestamp as video arrives. */
  function createWriter(o) {
    const fps = o.fps || 30, ms = us => Math.round(us / 1000);
    const audio = o.audio && o.audio.chunks && o.audio.chunks.length ? o.audio : null;
    const durationMs = Math.max(1, ms(o.durationUs));

    const ebml = el(0x1A45DFA3, [
      elUint(0x4286, 1), elUint(0x42F7, 1), elUint(0x42F2, 4), elUint(0x42F3, 8),
      elStr(0x4282, 'webm'), elUint(0x4287, 4), elUint(0x4285, 2)
    ]);
    const info = el(0x1549A966, [
      elUint(0x2AD7B1, 1000000),                // timestamps are in milliseconds
      elFloat(0x4489, durationMs),
      elStr(0x4D80, 'SubEd'), elStr(0x5741, 'SubEd')
    ]);
    const trackList = [el(0xAE, [
      elUint(0xD7, 1), elUint(0x73C5, 1), elUint(0x83, 1), elUint(0x9C, 0),
      elStr(0x86, o.codec || 'V_VP9'),
      elUint(0x23E383, Math.round(1e9 / fps)),
      el(0xE0, [elUint(0xB0, o.width), elUint(0xBA, o.height)])
    ])];
    if (audio) {
      const preSkip = audio.opusHead && audio.opusHead.length >= 12 ? (audio.opusHead[10] | (audio.opusHead[11] << 8)) : 312;
      trackList.push(el(0xAE, [
        elUint(0xD7, 2), elUint(0x73C5, 2), elUint(0x83, 2), elUint(0x9C, 0),
        elStr(0x86, 'A_OPUS'),
        el(0x63A2, audio.opusHead),
        elUint(0x56AA, Math.round(preSkip * 1e9 / 48000)),     // CodecDelay
        elUint(0x56BB, 80000000),                              // SeekPreRoll 80 ms
        el(0xE1, [elFloat(0xB5, 48000), elUint(0x9F, audio.channels)])
      ]));
    }
    const tracksEl = el(0x1654AE6B, trackList);

    const clusterBlobs = [], cuePts = [];
    let pos = info.length + tracksEl.length;    // offset of the next cluster inside the Segment
    let cur = null, ai = 0;
    const achunks = audio ? audio.chunks : [];

    function closeCluster() {
      if (!cur) return;
      const tc = elUint(0xE7, cur.t);
      const bodyLen = tc.length + cur.size;
      const head = concat([idBytes(0x1F43B675), sizeBytes(bodyLen), tc]);
      if (cur.keyT !== null) cuePts.push(el(0xBB, [elUint(0xB3, cur.keyT), el(0xB7, [elUint(0xF7, 1), elUint(0xF1, pos)])]));
      clusterBlobs.push(new Blob([head].concat(cur.parts)));
      pos += head.length + cur.size;
      cur = null;
    }
    function put(track, t, key, data) {
      const age = cur ? t - cur.t : 0;
      if (!cur || (track === 1 && key && age >= 1000) || age >= 5000) {
        closeCluster();
        cur = { t: t, parts: [], size: 0, keyT: null };
      }
      if (track === 1 && key && cur.keyT === null) cur.keyT = t;
      const head = new Uint8Array(4);
      head[0] = 0x80 | track;
      const rel = Math.max(-32768, Math.min(32767, t - cur.t));
      head[1] = (rel >> 8) & 255; head[2] = rel & 255;
      head[3] = key ? 0x80 : 0;
      const hdr = concat([idBytes(0xA3), sizeBytes(4 + data.length), head]);
      cur.parts.push(hdr, data);
      cur.size += hdr.length + data.length;
    }
    function flushAudio(uptoMs) {
      while (ai < achunks.length && ms(achunks[ai].ts) <= uptoMs) { put(2, ms(achunks[ai].ts), true, achunks[ai].data); ai++; }
    }
    return {
      addVideo(tsUs, key, data) {
        const t = ms(tsUs);
        flushAudio(t);
        put(1, t, !!key, data);
      },
      finish() {
        flushAudio(Infinity);
        closeCluster();
        const cues = cuePts.length ? el(0x1C53BB6B, cuePts) : new Uint8Array(0);
        let segLen = info.length + tracksEl.length + cues.length;
        clusterBlobs.forEach(b => { segLen += b.size; });
        const segHead = concat([idBytes(0x18538067), sizeBytes(segLen)]);
        return new Blob([ebml, segHead, info, tracksEl].concat(clusterBlobs, [cues]), { type: 'video/webm' });
      }
    };
  }

  /** One-shot form (kept for callers that already hold every chunk). */
  function mux(o) {
    const w = createWriter(o);
    o.video.forEach(c => w.addVideo(c.ts, c.key, c.data));
    return w.finish();
  }

  S.webm = { mux: mux, createWriter: createWriter };
})(window.SubEd);
