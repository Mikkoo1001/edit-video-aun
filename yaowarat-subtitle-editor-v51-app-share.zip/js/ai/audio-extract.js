/* =====================================================================
 * AI layer helper — streaming audio extraction for very large videos. No DOM.
 *
 * Why this exists: decoding a whole video with decodeAudioData() needs the entire file in RAM
 * (file.arrayBuffer()) plus the fully decoded PCM (~1.3 GB per hour of stereo 44.1 kHz float).
 * A 300-400 MB clip therefore crashes the tab. This module never holds more than a few MB:
 *
 *   File --(File.slice, a few MB at a time)--> demuxer (MP4/MOV or WebM/MKV, own parser, no libs)
 *        --> compressed audio packets --> WebCodecs AudioDecoder --> mono --> 16 kHz --> 16-bit WAV
 *        --> one Blob per CHUNK_SEC seconds, produced on demand (pull based = natural back-pressure)
 *
 *   const s = await SubEd.audio.openChunks(file, { chunkSec: 600, durationHint })
 *   s.total        estimated chunk count (0 = unknown)      s.progress()  0..1 of the source file read
 *   await s.next() -> { blob, name, offset(sec) } | null    s.close()
 *
 * openChunks() rejects with err.unsupported === true when the container/codec can't be streamed
 * (fragmented MP4, AVI, AC-3, no WebCodecs ...). The caller then decides on a fallback.
 * ===================================================================== */
(function (S) {
  'use strict';
  const RATE = 16000;                       // Whisper's native rate
  const MIN_TAIL = Math.round(RATE * 0.1);  // a trailing piece shorter than 0.1 s is dropped

  class Unsupported extends Error {
    constructor(msg) { super(msg); this.unsupported = true; }
  }

  // ---------------------------------------------------------------- byte helpers
  const be16 = (b, o) => (b[o] << 8) | b[o + 1];
  const be32 = (b, o) => ((b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]) >>> 0;
  const be64 = (b, o) => be32(b, o) * 4294967296 + be32(b, o + 4);
  const fourcc = (b, o) => String.fromCharCode(b[o], b[o + 1], b[o + 2], b[o + 3]);

  async function readRange(file, start, len) {
    const end = Math.min(file.size, start + len);
    if (start >= end) return new Uint8Array(0);
    try {
      // SubEd.localCopy.read retries a NotReadableError over several routes (plain, FileReader, small pieces) before giving up
      return S.localCopy ? await S.localCopy.read(file, start, end) : new Uint8Array(await file.slice(start, end).arrayBuffer());
    } catch (e) {
      if (e && e.name === 'NotReadableError') {
        const er = new Error('เบราว์เซอร์อ่านไฟล์คลิปไม่ได้ระหว่างแยกเสียง (ไฟล์อาจอยู่บนคลาวด์เช่น Google Drive / iCloud / OneDrive, ถูกย้ายหรือแก้ไขหลังเลือก, หรือหมดสิทธิ์เข้าถึง) — ให้ดาวน์โหลดไฟล์ลงเครื่องก่อน แล้วกด “เปลี่ยนคลิป” เลือกไฟล์เดิมอีกครั้ง (ระบบจะคัดลอกเก็บไว้ในเบราว์เซอร์ให้ตอนเลือก)');
        er.unreadable = true;
        throw er;
      }
      throw e;
    }
  }

  /** Sliding read window: many small sequential reads are served from one big slice. */
  class Win {
    constructor(file, size) { this.file = file; this.size = size; this.start = 0; this.buf = new Uint8Array(0); }
    async get(pos, len) {
      const end = Math.min(this.file.size, pos + len);
      if (pos >= end) return new Uint8Array(0);
      if (pos < this.start || end > this.start + this.buf.length) {
        this.buf = await readRange(this.file, pos, Math.max(this.size, len));
        this.start = pos;
      }
      return this.buf.subarray(pos - this.start, Math.min(end, this.start + this.buf.length) - this.start);
    }
  }

  // ---------------------------------------------------------------- MP4 / MOV
  /** Child boxes of b[start,end). Each: { type, start (payload), end, box (box start) } */
  function boxes(b, start, end) {
    const out = [];
    let p = start;
    while (p + 8 <= end) {
      let size = be32(b, p), hdr = 8;
      const type = fourcc(b, p + 4);
      if (size === 1) { if (p + 16 > end) break; size = be64(b, p + 8); hdr = 16; }
      else if (size === 0) size = end - p;
      if (size < hdr) break;
      if (p + size > end) size = end - p;
      out.push({ type: type, start: p + hdr, end: p + size, box: p });
      p += size;
    }
    return out;
  }
  const child = (list, type) => list.find(x => x.type === type);
  function findDeep(b, start, end, type) {          // 'esds' may sit inside a QuickTime 'wave' box
    for (const x of boxes(b, start, end)) {
      if (x.type === type) return x;
      if (x.type === 'wave') { const r = findDeep(b, x.start, x.end, type); if (r) return r; }
    }
    return null;
  }

  /** Locate the 'moov' box by walking top-level box headers (never reads 'mdat'). Returns its payload. */
  async function findMoov(file) {
    let pos = 0;
    while (pos + 8 <= file.size) {
      const h = await readRange(file, pos, 16);
      if (h.length < 8) break;
      let size = be32(h, 0), hdr = 8;
      const type = fourcc(h, 4);
      if (size === 1) { size = be64(h, 8); hdr = 16; }
      else if (size === 0) size = file.size - pos;
      if (size < hdr) break;
      if (type === 'moov') {
        if (size > 768 * 1048576) throw new Unsupported('โครงสร้างไฟล์ (moov) ใหญ่ผิดปกติ');
        return readRange(file, pos + hdr, size - hdr);
      }
      pos += size;
    }
    return null;
  }

  function descLen(b, p) {                          // MPEG-4 descriptor length (1-4 bytes, 7 bits each)
    let len = 0, n = 0, c;
    do { c = b[p + n]; len = (len << 7) | (c & 0x7f); n++; } while ((c & 0x80) && n < 4);
    return { len: len, n: n };
  }
  function parseEsds(b, start, end) {
    let p = start + 4;
    const res = { oti: 0, asc: null };
    while (p < end) {
      const tag = b[p++], d = descLen(b, p);
      p += d.n;
      if (tag === 0x03) {                           // ES_Descriptor: descend
        p += 2; const fl = b[p++];
        if (fl & 0x80) p += 2;
        if (fl & 0x40) p += 1 + b[p];
        if (fl & 0x20) p += 2;
      } else if (tag === 0x04) { res.oti = b[p]; p += 13; }          // DecoderConfigDescriptor: descend
      else if (tag === 0x05) { res.asc = b.slice(p, p + d.len); p += d.len; }
      else p += d.len;
    }
    return res;
  }
  const aacCodec = asc => {
    let aot = asc[0] >> 3;
    if (aot === 31) aot = 32 + (((asc[0] & 7) << 3) | (asc[1] >> 5));
    return 'mp4a.40.' + aot;
  };

  function opusHeadFromDops(b, s, e) {              // MP4 'dOps' (big-endian) -> Ogg 'OpusHead' (little-endian)
    const ch = b[s + 1], pre = be16(b, s + 2), rate = be32(b, s + 4), gain = be16(b, s + 8), fam = b[s + 10];
    const extra = fam !== 0 ? b.slice(s + 11, e) : new Uint8Array(0);
    const h = new Uint8Array(19 + extra.length), v = new DataView(h.buffer);
    h.set([0x4f, 0x70, 0x75, 0x73, 0x48, 0x65, 0x61, 0x64]);       // "OpusHead"
    h[8] = 1; h[9] = ch; v.setUint16(10, pre, true); v.setUint32(12, rate, true); v.setUint16(16, gain, true); h[18] = fam;
    h.set(extra, 19);
    return h;
  }

  function parseMoov(b) {
    const top = boxes(b, 0, b.length);
    const mvhd = child(top, 'mvhd');
    const movieTs = mvhd ? be32(b, mvhd.start + (b[mvhd.start] === 1 ? 20 : 12)) || 1000 : 1000;

    for (const trak of top.filter(x => x.type === 'trak')) {
      const tc = boxes(b, trak.start, trak.end);
      const mdia = child(tc, 'mdia'); if (!mdia) continue;
      const mc = boxes(b, mdia.start, mdia.end);
      const hdlr = child(mc, 'hdlr');
      if (!hdlr || fourcc(b, hdlr.start + 8) !== 'soun') continue;
      const mdhd = child(mc, 'mdhd'), minf = child(mc, 'minf');
      if (!mdhd || !minf) continue;
      const timescale = be32(b, mdhd.start + (b[mdhd.start] === 1 ? 20 : 12)) || 1;
      const stbl = child(boxes(b, minf.start, minf.end), 'stbl'); if (!stbl) continue;
      const sc = boxes(b, stbl.start, stbl.end);
      const stsd = child(sc, 'stsd'), stts = child(sc, 'stts'), stsz = child(sc, 'stsz') || child(sc, 'stz2'),
            stsc = child(sc, 'stsc'), stco = child(sc, 'stco') || child(sc, 'co64');
      if (!stsd || !stts || !stsz || !stsc || !stco) continue;
      if (stsz.type === 'stz2') throw new Unsupported('ไฟล์ใช้ตารางตัวอย่างแบบ stz2 ซึ่งยังไม่รองรับ');

      // ---- codec ----
      const entry = boxes(b, stsd.start + 8, stsd.end)[0];
      if (!entry) continue;
      const ver = be16(b, entry.start + 8);
      if (ver > 1) throw new Unsupported('รูปแบบเสียงของไฟล์ (' + entry.type + ') ยังไม่รองรับ');
      const channels = be16(b, entry.start + 16) || 2, entryRate = be16(b, entry.start + 24) || 48000;
      const kids = entry.start + 28 + (ver === 1 ? 16 : 0);
      let codec, description = null;
      if (entry.type === 'mp4a') {
        const esds = findDeep(b, kids, entry.end, 'esds');
        if (!esds) throw new Unsupported('ไม่พบข้อมูลตั้งค่า AAC (esds)');
        const es = parseEsds(b, esds.start, esds.end);
        if (es.oti === 0x40 && es.asc && es.asc.length >= 2) { codec = aacCodec(es.asc); description = es.asc; }
        else if (es.oti === 0x6b || es.oti === 0x69) codec = 'mp3';
        else throw new Unsupported('รูปแบบเสียงของไฟล์ (mp4a/0x' + es.oti.toString(16) + ') ยังไม่รองรับ');
      } else if (entry.type === 'Opus') {
        const dops = findDeep(b, kids, entry.end, 'dOps');
        if (!dops) throw new Unsupported('ไม่พบข้อมูลตั้งค่า Opus (dOps)');
        codec = 'opus'; description = opusHeadFromDops(b, dops.start, dops.end);
      } else if (entry.type === '.mp3') codec = 'mp3';
      else throw new Unsupported('รูปแบบเสียงของไฟล์ (' + entry.type + ') ยังไม่รองรับ');

      // ---- sample table ----
      const nS = be32(b, stsz.start + 8), fixed = be32(b, stsz.start + 4);
      if (!nS) throw new Unsupported('ไฟล์ MP4 แบบแบ่งท่อน (fragmented) ยังไม่รองรับการอ่านแบบสตรีม');
      const sizes = new Uint32Array(nS);
      if (fixed) sizes.fill(fixed); else for (let i = 0; i < nS; i++) sizes[i] = be32(b, stsz.start + 12 + i * 4);

      const nC = be32(b, stco.start + 4), big = stco.type === 'co64';
      const chunkOff = new Float64Array(nC);
      for (let i = 0; i < nC; i++) chunkOff[i] = big ? be64(b, stco.start + 8 + i * 8) : be32(b, stco.start + 8 + i * 4);

      const nE = be32(b, stsc.start + 4), first = [], per = [];
      for (let i = 0; i < nE; i++) { first.push(be32(b, stsc.start + 8 + i * 12)); per.push(be32(b, stsc.start + 12 + i * 12)); }
      const offsets = new Float64Array(nS);
      let s = 0;
      for (let e = 0; e < nE && s < nS; e++) {
        const last = e + 1 < nE ? first[e + 1] : nC + 1;
        for (let c = first[e]; c < last && s < nS; c++) {
          let off = chunkOff[c - 1];
          for (let k = 0; k < per[e] && s < nS; k++, s++) { offsets[s] = off; off += sizes[s]; }
        }
      }
      if (s < nS) throw new Unsupported('ตารางตัวอย่างของไฟล์ไม่สมบูรณ์');

      // ---- duration (sum of stts) ----
      let ticks = 0;
      for (let i = 0, n = be32(b, stts.start + 4); i < n; i++) ticks += be32(b, stts.start + 8 + i * 8) * be32(b, stts.start + 12 + i * 8);
      const duration = ticks / timescale;

      // ---- edit list: where the audio really starts relative to the movie ----
      let shift = 0;
      const edts = child(tc, 'edts'), elst = edts && child(boxes(b, edts.start, edts.end), 'elst');
      if (elst) {
        const v1 = b[elst.start] === 1, n = be32(b, elst.start + 4), stepSz = v1 ? 20 : 12;
        for (let i = 0; i < n; i++) {
          const o = elst.start + 8 + i * stepSz;
          const segDur = v1 ? be64(b, o) : be32(b, o);
          let mt = v1 ? be64(b, o + 8) : be32(b, o + 4);
          if (!v1 && mt === 0xffffffff) mt = -1;
          if (mt === -1) shift += segDur / movieTs;                       // empty edit: audio starts later
          else { if (codec !== 'opus') shift -= mt / timescale; break; }  // media_time: priming samples to drop (Opus: decoder does it)
        }
      }
      return {
        info: { codec: codec, sampleRate: entryRate, channels: channels, description: description, duration: duration, startShift: shift },
        sizes: sizes, offsets: offsets
      };
    }
    return null;
  }

  async function openMp4(file) {
    const moov = await findMoov(file);
    if (!moov) throw new Unsupported('ไม่พบโครงสร้างของไฟล์ MP4/MOV (moov) — ไฟล์อาจไม่สมบูรณ์');
    const t = parseMoov(moov);
    if (!t) throw new Unsupported('ไม่พบแทร็กเสียงในวิดีโอนี้');
    const n = t.sizes.length, MAXREAD = 4 * 1048576, PREFETCH = 3;
    let prog = 0;

    function* groups() {                             // merge neighbouring samples into <= 4 MB reads
      let i = 0;
      while (i < n) {
        const start = t.offsets[i];
        let end = start + t.sizes[i], j = i + 1;
        while (j < n && t.offsets[j] === end && (end - start) + t.sizes[j] <= MAXREAD) { end += t.sizes[j]; j++; }
        yield { from: i, to: j, start: start, len: end - start };
        i = j;
      }
    }
    async function* packets() {
      const it = groups(), q = [];
      const fill = () => {
        while (q.length < PREFETCH) {
          const g = it.next(); if (g.done) break;
          const p = readRange(file, g.value.start, g.value.len); p.catch(() => {});
          q.push({ g: g.value, p: p });
        }
      };
      fill();
      while (q.length) {
        const x = q.shift(), buf = await x.p;
        fill();
        if (buf.length < x.g.len) throw new Error('อ่านไฟล์ไม่ครบ — ไฟล์อาจไม่สมบูรณ์หรือถูกตัดท้าย');
        let o = 0;
        for (let k = x.g.from; k < x.g.to; k++) { yield { data: buf.subarray(o, o + t.sizes[k]) }; o += t.sizes[k]; }
        prog = x.g.to / n;
      }
      prog = 1;
    }
    return { info: t.info, packets: packets, progress: () => prog };
  }

  // ---------------------------------------------------------------- WebM / Matroska
  const EBML = { SEGMENT: 0x18538067, INFO: 0x1549A966, TCSCALE: 0x2AD7B1, DURATION: 0x4489, TRACKS: 0x1654AE6B, ENTRY: 0xAE,
    TNUM: 0xD7, TTYPE: 0x83, CODEC: 0x86, PRIVATE: 0x63A2, AUDIO: 0xE1, FREQ: 0xB5, CHANNELS: 0x9F,
    CLUSTER: 0x1F43B675, GROUP: 0xA0, BLOCK: 0xA1, SBLOCK: 0xA3 };
  const DESCEND = new Set([EBML.SEGMENT, EBML.INFO, EBML.TRACKS, EBML.ENTRY, EBML.AUDIO, EBML.CLUSTER, EBML.GROUP]);
  const WANT = new Set([EBML.TCSCALE, EBML.DURATION, EBML.TNUM, EBML.TTYPE, EBML.CODEC, EBML.PRIVATE, EBML.FREQ, EBML.CHANNELS]);

  function vint(b, o, keepMarker) {                  // -> { len, value, unknown }
    let len = 1, m = 0x80;
    while (len <= 8 && !(b[o] & m)) { len++; m >>= 1; }
    if (len > 8 || o + len > b.length) throw new Error('bad ebml');
    let v = keepMarker ? b[o] : (b[o] & (m - 1));
    let ones = (b[o] & (m - 1)) === m - 1;
    for (let i = 1; i < len; i++) { v = v * 256 + b[o + i]; if (b[o + i] !== 0xff) ones = false; }
    return { len: len, value: v, unknown: ones };
  }
  async function ebmlHeader(win, pos) {
    const b = await win.get(pos, 32);
    if (b.length < 2) return null;
    const id = vint(b, 0, true);
    if (id.len > 4) throw new Error('bad ebml id');
    const sz = vint(b, id.len, false);
    return { id: id.value, size: sz.unknown ? -1 : sz.value, dataPos: pos + id.len + sz.len };
  }
  const ebmlUint = p => { let v = 0; for (let i = 0; i < p.length; i++) v = v * 256 + p[i]; return v; };
  const ebmlFloat = p => { const dv = new DataView(p.buffer, p.byteOffset, p.byteLength); return p.length === 4 ? dv.getFloat32(0) : p.length === 8 ? dv.getFloat64(0) : 0; };
  const ebmlStr = p => { let s = ''; for (let i = 0; i < p.length && p[i]; i++) s += String.fromCharCode(p[i]); return s; };

  async function openWebm(file, durationHint) {
    const win = new Win(file, 1048576);
    let pos = 0, scale = 1e6, durRaw = 0, cur = null, clusterPos = -1;
    const tracks = [];
    try {
      while (pos < file.size) {                       // header part: everything before the first Cluster
        const h = await ebmlHeader(win, pos);
        if (!h) break;
        if (h.id === EBML.CLUSTER) { clusterPos = pos; break; }
        if (DESCEND.has(h.id)) { if (h.id === EBML.ENTRY) { cur = {}; tracks.push(cur); } pos = h.dataPos; continue; }
        if (h.size < 0) throw new Error('unknown-size element');
        if (WANT.has(h.id) && h.size <= 65536) {
          const p = await win.get(h.dataPos, h.size);
          switch (h.id) {
            case EBML.TCSCALE: scale = ebmlUint(p) || 1e6; break;
            case EBML.DURATION: durRaw = ebmlFloat(p); break;
            case EBML.TNUM: if (cur) cur.num = ebmlUint(p); break;
            case EBML.TTYPE: if (cur) cur.type = ebmlUint(p); break;
            case EBML.CODEC: if (cur) cur.codec = ebmlStr(p); break;
            case EBML.PRIVATE: if (cur) cur.priv = p.slice(); break;
            case EBML.FREQ: if (cur) cur.rate = ebmlFloat(p); break;
            case EBML.CHANNELS: if (cur) cur.ch = ebmlUint(p); break;
          }
        }
        pos = h.dataPos + h.size;
      }
    } catch (e) { if (e && e.unreadable) throw e; throw new Unsupported('อ่านโครงสร้างไฟล์ WebM/MKV ไม่สำเร็จ'); }
    if (clusterPos < 0) throw new Unsupported('ไม่พบข้อมูลวิดีโอ/เสียงในไฟล์ WebM/MKV');

    const tr = tracks.find(t => t.type === 2);
    if (!tr) throw new Unsupported('ไม่พบแทร็กเสียงในวิดีโอนี้');
    let codec, description = tr.priv || null;
    const cid = tr.codec || '';
    if (cid === 'A_OPUS') codec = 'opus';
    else if (cid.indexOf('A_AAC') === 0 && description && description.length >= 2) codec = aacCodec(description);
    else if (cid === 'A_MPEG/L3') { codec = 'mp3'; description = null; }
    else if (cid === 'A_VORBIS' && description) codec = 'vorbis';
    else throw new Unsupported('รูปแบบเสียงของไฟล์ (' + (cid || 'ไม่ทราบ') + ') ยังไม่รองรับ');

    let duration = durRaw > 0 ? durRaw * scale / 1e9 : 0;
    if (!duration && durationHint > 0 && isFinite(durationHint)) duration = durationHint;
    let prog = 0;

    async function* packets() {
      let p = clusterPos;
      while (p < file.size) {
        let h;
        try { h = await ebmlHeader(win, p); } catch (e) { if (e && e.unreadable) throw e; return; }      // damaged tail (interrupted recording): stop quietly — but an UNREADABLE file must not look like the end of the clip
        if (!h) return;
        prog = p / file.size;
        if (h.id === EBML.SBLOCK || h.id === EBML.BLOCK) {
          if (h.size < 4) return;
          const t = await win.get(h.dataPos, 4);
          let len = 1, m = 0x80;
          while (len <= 4 && !(t[0] & m)) { len++; m >>= 1; }
          let num = t[0] & (m - 1);
          for (let i = 1; i < len; i++) num = num * 256 + t[i];
          if (num === tr.num) {
            const body = await win.get(h.dataPos, h.size);
            if (body.length < h.size) return;                             // truncated last block
            if (body[len + 2] & 0x06) throw new Unsupported('ไฟล์ใช้ lacing ของ Matroska ซึ่งยังไม่รองรับ');
            yield { data: body.subarray(len + 3) };
          }
          p = h.dataPos + h.size;
          continue;
        }
        if (DESCEND.has(h.id)) { p = h.dataPos; continue; }
        if (h.size < 0) return;
        p = h.dataPos + h.size;
      }
      prog = 1;
    }
    return {
      info: { codec: codec, sampleRate: tr.rate || 48000, channels: tr.ch || 2, description: description, duration: duration, startShift: 0 },
      packets: packets, progress: () => prog
    };
  }

  async function openDemux(file, durationHint) {
    const h = await readRange(file, 0, 16);
    if (h.length >= 4 && h[0] === 0x1a && h[1] === 0x45 && h[2] === 0xdf && h[3] === 0xa3) return openWebm(file, durationHint);
    if (h.length >= 8 && /^(ftyp|moov|mdat|free|skip|wide|pnot)$/.test(fourcc(h, 4))) {
      const d = await openMp4(file);
      if (!d.info.duration && durationHint > 0 && isFinite(durationHint)) d.info.duration = durationHint;
      return d;
    }
    throw new Unsupported('รูปแบบไฟล์นี้ยังไม่รองรับการอ่านแบบสตรีม (รองรับ MP4, MOV, WebM, MKV)');
  }

  // ---------------------------------------------------------------- PCM -> 16 kHz mono 16-bit WAV pieces
  function wavHeader(n) {
    const h = new ArrayBuffer(44), v = new DataView(h);
    const str = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
    str(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); str(8, 'WAVE'); str(12, 'fmt ');
    v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, RATE, true); v.setUint32(28, RATE * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
    str(36, 'data'); v.setUint32(40, n * 2, true);
    return h;
  }

  /** Streaming resampler (area average = cheap anti-aliasing, fine for speech) that writes straight into the piece buffer. */
  class Sink {
    constructor(chunkSec, startAt) {
      this.chunkSec = chunkSec; this.cap = chunkSec * RATE;
      this.pieceStart = startAt > 0 ? startAt : 0;                 // media time (s) where the piece being filled begins
      this.buf = new Int16Array(this.cap); this.fill = 0; this.index = 0; this.ready = [];
      this.sr = 0; this.r = 1; this.acc = 0; this.need = 1;
    }
    setRate(sr) { this.sr = sr; this.r = sr / RATE; this.acc = 0; this.need = this.r; }
    flush() {
      if (!this.fill) return;
      const blob = new Blob([wavHeader(this.fill), new Int16Array(this.buf.buffer, 0, this.fill)], { type: 'audio/wav' });   // Blob copies the bytes
      this.ready.push({ blob: blob, name: 'part' + (this.index + 1) + '.wav', offset: this.pieceStart });
      this.index++; this.pieceStart += this.fill / RATE; this.fill = 0;
    }
    /** Close the piece being filled right now, however short (used when the source stops in the middle). A sliver under MIN_TAIL is dropped. */
    cut() {
      if (this.fill >= MIN_TAIL) this.flush();
      else { this.pieceStart += this.fill / RATE; this.fill = 0; }
    }
    silence(n) {
      while (n > 0) {
        const k = Math.min(n, this.cap - this.fill);
        this.buf.fill(0, this.fill, this.fill + k); this.fill += k; n -= k;
        if (this.fill === this.cap) this.flush();
      }
    }
    push(x, n, sr) {
      if (sr !== this.sr) this.setRate(sr);
      const r = this.r, buf = this.buf, cap = this.cap;
      let acc = this.acc, need = this.need, fill = this.fill;
      for (let i = 0; i < n; i++) {
        const v = x[i];
        let w = 1;
        while (w > 0) {
          if (w >= need) {
            acc += v * need; w -= need;
            let o = acc / r;
            o = o > 1 ? 1 : (o < -1 ? -1 : o);
            buf[fill++] = o < 0 ? o * 32768 : o * 32767;
            acc = 0; need = r;
            if (fill === cap) { this.fill = fill; this.flush(); fill = 0; }
          } else { acc += v * w; need -= w; w = 0; }
        }
      }
      this.acc = acc; this.need = need; this.fill = fill;
    }
    finish() { if (this.fill >= MIN_TAIL || (this.index === 0 && this.fill > 0)) this.flush(); else this.fill = 0; }
  }

  // ---------------------------------------------------------------- demuxer + decoder + sink = pull-based pump
  async function makePump(demux, chunkSec) {
    const info = demux.info;
    if (typeof AudioDecoder === 'undefined' || typeof EncodedAudioChunk === 'undefined') {
      throw new Unsupported('เบราว์เซอร์นี้ไม่รองรับ WebCodecs (AudioDecoder) — ลองใช้ Chrome หรือ Edge เวอร์ชันล่าสุด');
    }
    const cfg = { codec: info.codec, sampleRate: info.sampleRate, numberOfChannels: info.channels };
    if (info.description) cfg.description = info.description;
    let sup = null;
    try { sup = await AudioDecoder.isConfigSupported(cfg); } catch (e) {}
    if (!sup || !sup.supported) throw new Unsupported('เบราว์เซอร์นี้ถอดรหัสเสียงแบบ ' + info.codec + ' ไม่ได้');

    const sink = new Sink(chunkSec);
    let err = null, finished = false, waiter = null, timer = 0, tsUs = 0, mix = new Float32Array(0), tmp = new Float32Array(0);
    let skipSec = info.startShift < 0 ? -info.startShift : 0, skipFrames = 0;
    const wake = () => { if (timer) { clearTimeout(timer); timer = 0; } if (waiter) { const w = waiter; waiter = null; w(); } };

    const dec = new AudioDecoder({
      output(ad) {
        try {
          const nf = ad.numberOfFrames, nch = ad.numberOfChannels, sr = ad.sampleRate;
          if (mix.length < nf) { mix = new Float32Array(nf); tmp = new Float32Array(nf); }
          mix.fill(0, 0, nf);
          for (let c = 0; c < nch; c++) {
            ad.copyTo(tmp, { planeIndex: c, format: 'f32-planar' });
            for (let i = 0; i < nf; i++) mix[i] += tmp[i];
          }
          if (nch > 1) { const k = 1 / nch; for (let i = 0; i < nf; i++) mix[i] *= k; }
          if (skipSec > 0) { skipFrames = Math.round(skipSec * sr); skipSec = 0; }
          let from = 0;
          if (skipFrames > 0) { from = Math.min(skipFrames, nf); skipFrames -= from; }
          if (from < nf) sink.push(mix.subarray(from, nf), nf - from, sr);
        } catch (e) { err = err || e; }
        finally { ad.close(); }
      },
      error(e) { err = err || e; wake(); }
    });
    dec.ondequeue = wake;
    dec.configure(cfg);
    if (info.startShift > 0) sink.silence(Math.round(info.startShift * RATE));

    const it = demux.packets();
    function waitRoom() {                           // back-pressure: never queue more than ~24 packets in the decoder
      return new Promise(resolve => { waiter = resolve; timer = setTimeout(wake, 100); });
    }
    async function step() {
      if (err) throw err;
      const r = await it.next();
      if (err) throw err;
      if (r.done) {
        try { await dec.flush(); } catch (e) { err = err || e; }
        if (err) throw err;
        sink.finish(); finished = true;
        return;
      }
      while (dec.decodeQueueSize > 24 && !err) await waitRoom();
      if (err) throw err;
      dec.decode(new EncodedAudioChunk({ type: 'key', timestamp: tsUs, data: r.value.data }));
      tsUs += 1000;
    }
    return {
      async next() {
        while (!sink.ready.length && !finished) await step();
        return sink.ready.length ? sink.ready.shift() : null;
      },
      /** The file became unreadable in the middle: let the decoder finish what it already has, close the piece being filled and stop.
       *  -> media time (s) up to which the sound is safe in pieces (next() hands those out, then returns null). */
      async salvage() {
        let to = 0;
        try { await Promise.race([dec.flush(), new Promise((_, rej) => { to = setTimeout(rej, 8000); })]); } catch (e) {}
        clearTimeout(to);
        sink.cut(); finished = true;
        return sink.pieceStart;
      },
      close() {
        try { it.return(); } catch (e) {}
        try { if (dec.state !== 'closed') dec.close(); } catch (e) {}
        wake();
      }
    };
  }

  // ---------------------------------------------------------------- last resort: listen to the clip while the browser plays it
  /** For a clip the browser can PLAY but will not let us READ (Android gallery / cloud files: every File.slice() fails with NotReadableError).
   *  The <video> element has its own way into the file, so its sound is recorded while it plays (real time, 1x, silently: the graph is not
   *  connected to the speakers). Same shape as openChunks(); `realtime: true` lets the caller say so. */
  async function captureChunks(file, opts) {
    opts = opts || {};
    const chunkSec = opts.chunkSec || 600, startAt = opts.startAt > 0 ? opts.startAt : 0;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) throw new Unsupported('เบราว์เซอร์นี้ดักเสียงจากวิดีโอไม่ได้');
    const el = document.createElement('video');
    el.playsInline = true; el.preload = 'auto'; el.setAttribute('playsinline', '');
    const url = URL.createObjectURL(file);
    const cleanup = () => { try { el.pause(); } catch (e) {} el.removeAttribute('src'); try { el.load(); } catch (e) {} URL.revokeObjectURL(url); };
    try {
      await new Promise((res, rej) => {
        const t = setTimeout(() => rej(new Unsupported('เปิดวิดีโอเพื่อดักเสียงไม่ทัน')), 20000);
        el.onloadedmetadata = () => { clearTimeout(t); res(); };
        el.onerror = () => { clearTimeout(t); rej(new Unsupported('เบราว์เซอร์เปิดวิดีโอนี้ไม่ได้')); };
        el.src = url;
      });
    } catch (e) { cleanup(); throw e; }
    const duration = isFinite(el.duration) && el.duration > 0 ? el.duration : (opts.durationHint > 0 ? opts.durationHint : 0);
    if (startAt > 0 && duration && startAt >= duration - 0.25) {            // nothing left to listen to
      cleanup();
      return { realtime: true, duration: duration, total: 0, info: { codec: 'capture', sampleRate: RATE, channels: 1, duration: duration }, progress: () => 1, next: async () => null, close() {} };
    }
    if (startAt > 0) {                                                       // resume where the file stopped being readable
      try {
        await new Promise((res, rej) => {
          const t = setTimeout(() => rej(new Unsupported('เลื่อนวิดีโอไปจุดที่ค้างไม่ทัน')), 20000);
          el.onseeked = () => { clearTimeout(t); res(); };
          el.onerror = () => { clearTimeout(t); rej(new Unsupported('เบราว์เซอร์เลื่อนวิดีโอไปจุดที่ค้างไม่ได้')); };
          el.currentTime = startAt;
        });
      } catch (e) { cleanup(); throw e; }
    }

    const ac = new AC();
    try { await ac.resume(); } catch (e) {}
    const src = ac.createMediaElementSource(el);
    const proc = ac.createScriptProcessor(4096, 2, 1);
    const mute = ac.createGain(); mute.gain.value = 0;
    src.connect(proc); proc.connect(mute); mute.connect(ac.destination);       // the sound goes ONLY into the recorder (not to the speakers)
    const sink = new Sink(chunkSec, startAt);
    let finished = false, closed = false, failed = null, mono = new Float32Array(4096), poke = null;
    const wake = () => { if (poke) { const p = poke; poke = null; p(); } };
    proc.onaudioprocess = ev => {
      if (finished || closed || el.paused || el.ended || el.readyState < 3) return;
      const b = ev.inputBuffer, n = b.length, nch = b.numberOfChannels;
      if (mono.length < n) mono = new Float32Array(n);
      const c0 = b.getChannelData(0);
      for (let i = 0; i < n; i++) mono[i] = c0[i];
      for (let c = 1; c < nch; c++) { const d = b.getChannelData(c); for (let i = 0; i < n; i++) mono[i] += d[i]; }
      if (nch > 1) for (let i = 0; i < n; i++) mono[i] /= nch;
      sink.push(mono, n, ac.sampleRate);
      if (sink.ready.length >= 2 && !el.paused) el.pause();                      // the consumer is slow: wait for it (next() plays on)
      if (sink.ready.length) wake();
    };
    el.onended = () => { if (!finished) { sink.finish(); finished = true; wake(); } };
    el.onerror = () => { failed = failed || new Error('เบราว์เซอร์เล่นวิดีโอต่อไม่ได้ระหว่างดักเสียง'); wake(); };
    const play = async () => {
      try { await el.play(); }
      catch (e) { failed = failed || new Error('เบราว์เซอร์ไม่ยอมเล่นวิดีโอเพื่อดักเสียง — แตะหน้าจอแล้วกดสร้างซับอีกครั้ง'); }
    };
    await play();
    if (failed) { closed = true; cleanup(); try { ac.close(); } catch (e) {} throw new Unsupported(failed.message); }
    return {
      realtime: true, duration: duration, total: duration ? Math.max(1, Math.ceil(duration / chunkSec - MIN_TAIL / RATE / chunkSec)) : 0,
      info: { codec: 'capture', sampleRate: RATE, channels: 1, duration: duration },
      progress: () => finished ? 1 : (duration ? Math.min(1, el.currentTime / duration) : 0),
      async next() {
        while (!sink.ready.length && !finished) {
          if (failed) throw failed;
          if (el.paused && !el.ended) await play();
          await new Promise(res => { poke = res; setTimeout(wake, 500); });
        }
        if (failed && !sink.ready.length) throw failed;
        return sink.ready.length ? sink.ready.shift() : null;
      },
      close() { closed = true; cleanup(); try { ac.close(); } catch (e) {} wake(); }
    };
  }

  /** The bytes cannot be read but maybe the browser can still PLAY the clip: record its sound instead of giving up. When that is
   *  impossible too, the original error is raised, with the reason listening failed added (it used to vanish into the console). */
  async function listenOrThrow(file, opts, why, startAt) {
    if (opts.noListen) throw why;                              // the caller only wants the bytes read (ai/audio-cache.js)
    let cap = null, why2 = null;
    try { cap = await captureChunks(file, Object.assign({}, opts, { startAt: startAt })); }
    catch (e2) { why2 = e2; console.warn('[audio] capture fallback not possible:', e2); }
    if (cap) return cap;
    const er = new Error(why.message + (why2 && why2.message ? ' [ลองฟังเสียงจากการเล่นวิดีโอแทนแล้วแต่ไม่สำเร็จ: ' + why2.message + ']' : ''));
    er.unreadable = true;
    throw er;
  }

  /** Open a streaming 16 kHz WAV piece source for a big video. See the header comment.
   *  opts.onNotice(text): called when the source switches to listening in real time part-way through. */
  async function openChunks(file, opts) {
    opts = opts || {};
    const chunkSec = opts.chunkSec || 600;
    let demux;
    try { demux = await openDemux(file, opts.durationHint); }
    catch (e) {
      if (!(e && e.unreadable)) throw e;
      return listenOrThrow(file, opts, e, 0);                  // unreadable from the very start
    }
    const pump = await makePump(demux, chunkSec);
    const duration = demux.info.duration || 0;
    let cap = null, resumeAt = -1, why = null;                 // cap: the real-time listener that took over after the file went unreadable
    return {
      get realtime() { return !!cap; },
      duration: duration, total: duration ? Math.max(1, Math.ceil(duration / chunkSec - MIN_TAIL / RATE / chunkSec)) : 0, info: demux.info,
      progress() { return cap ? Math.max(cap.progress(), Math.min(1, resumeAt / (duration || Infinity))) : demux.progress(); },
      async next() {
        if (cap) return cap.next();
        if (resumeAt < 0) {
          try { return await pump.next(); }
          catch (e) {
            if (!(e && e.unreadable)) throw e;
            // The file read fine at first and then stopped (cloud placeholder, gallery permission, a file still being written ...):
            // keep the sound already cut, and listen to the REST of the clip while the browser plays it.
            why = e; resumeAt = await pump.salvage();
          }
        }
        const left = await pump.next();                        // pieces cut before the failure come first
        if (left) return left;
        cap = await listenOrThrow(file, opts, why, resumeAt);
        try { if (opts.onNotice) opts.onNotice('ไฟล์อ่านต่อไม่ได้ที่ ' + Math.floor(resumeAt / 60) + ':' + ('0' + Math.floor(resumeAt % 60)).slice(-2) + ' — กำลังฟังเสียงที่เหลือจากวิดีโอแบบเรียลไทม์ (ใช้เวลาเท่าความยาวที่เหลือ อย่าปิดหน้านี้)'); } catch (e) {}
        return cap.next();
      },
      close() { pump.close(); if (cap) cap.close(); }
    };
  }

  S.audio = { Unsupported: Unsupported, openChunks: openChunks, captureChunks: captureChunks, _demux: { open: openDemux } };
})(window.SubEd = window.SubEd || {});
