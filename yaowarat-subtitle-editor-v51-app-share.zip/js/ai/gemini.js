/* =====================================================================
 * AI layer — Google Gemini. No DOM.
 *
 * Two providers are registered on SubEd.transcribers:
 *
 *   'gemini'       Gemini listens to the audio and writes subtitle lines with timestamps.
 *                  Needs only a Gemini key. Line timing is as accurate as Gemini's own timestamps.
 *
 *   'groq-gemini'  Groq Whisper gives accurate word timing, Gemini then regroups the words into
 *                  natural lines and fixes misheard words / spelling. Timing stays Whisper's.
 *                  Needs both keys. If Gemini fails the Whisper result is returned untouched
 *                  (it is already Thai-aware, see subtitle/thai-text.js).
 *
 * Both return { words: [{ word, start, end, joined, brk? }] }. `brk` marks the last word of a line
 * Gemini ended, so the 'smart' segmenter keeps Gemini's line breaks.
 *
 * Transport: same-origin proxy /api/gemini/* (_worker.js) first, direct call to
 * generativelanguage.googleapis.com as the fallback (file://, plain static hosts).
 * ===================================================================== */
(function (S) {
  'use strict';
  const transcribers = S.transcribers;
  const API = 'https://generativelanguage.googleapis.com/v1beta/';
  const PROXY = '/api/gemini/';
  const ALIAS_MODEL = 'gemini-flash-latest';         // alias that always points at the current Flash model (used when the default below is not available)
  const DEFAULT_MODEL = 'gemini-3.8-flash';          // model used when the model field is left empty
  const DIRECT_MAX = 9 * 1024 * 1024;                // original file sent as-is up to this size (inline request cap is 20 MB incl. base64)
  const CHUNK_SEC = 300;                             // 5 min of 16 kHz mono WAV = 9.6 MB
  const WINDOW = 180;                                // words per refine request
  const MAX_RETRY = 4;
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // ---------------- transport ----------------
  let proxyState = 'unknown';                        // 'unknown' | 'ok' | 'missing'

  function toError(status, bodyText, ct) {
    let msg = 'สถานะ ' + status, retry = null, j = null;
    try { j = JSON.parse(bodyText); } catch (e) {}
    if (j && j.error) {
      if (j.error.message) msg = j.error.message;
      (j.error.details || []).forEach(d => { if (d && d.retryDelay) { const s = parseFloat(d.retryDelay); if (isFinite(s)) retry = s; } });
    }
    const orig = msg;
    if (status === 400 && /api key/i.test(msg)) msg = 'Gemini API Key ไม่ถูกต้อง';
    else if (status === 401 || status === 403) msg = 'Gemini ปฏิเสธคำขอ (' + (/api key|permission|denied/i.test(msg) ? 'ตรวจสอบ API Key และสิทธิ์ใช้งาน' : msg) + ')' + (orig !== 'สถานะ ' + status ? ' — Google แจ้งว่า: ' + orig.replace(/\s+/g, ' ').slice(0, 240) : '');
    else if (status === 429) msg = 'ใช้ Gemini เกินโควตา (rate limit) รอสักครู่แล้วลองใหม่';
    else if (status === 503) msg = 'Gemini กำลังมีผู้ใช้งานหนาแน่น';
    const er = new Error(msg);
    er.status = status; er.retryAfter = retry;
    er.proxyMissing = (status === 404 || status === 405 || status === 501) && !/json/i.test(ct || '');
    return er;
  }

  async function call(url, method, key, body) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 4 * 60 * 1000);
    let res;
    try {
      res = await fetch(url, {
        method: method, signal: ctl.signal,
        headers: Object.assign({ 'x-goog-api-key': key }, body ? { 'Content-Type': 'application/json' } : {}),
        body: body ? JSON.stringify(body) : undefined
      });
    } catch (e) {
      const er = new Error(e && e.name === 'AbortError' ? 'หมดเวลารอการตอบกลับจาก Gemini' : 'เชื่อมต่อ Gemini ไม่ได้ (เครือข่าย)');
      er.network = true;
      throw er;
    } finally { clearTimeout(timer); }
    const text = await res.text();
    if (!res.ok) throw toError(res.status, text, res.headers.get('Content-Type'));
    try { return JSON.parse(text); }
    catch (e) { const er = new Error('รูปแบบข้อมูลจาก Gemini ไม่ถูกต้อง'); er.proxyMissing = url.indexOf(PROXY) === 0; throw er; }
  }

  // ---- Vertex AI express mode (keys that start with "AQ." can be Vertex express keys, which the Gemini Developer API rejects) ----
  const VERTEX = 'https://aiplatform.googleapis.com/v1/publishers/google/';
  const VERTEX_PROXY = '/api/vertex/';
  const VERTEX_FALLBACK_MODELS = ['gemini-flash-latest', 'gemini-3.8-flash', 'gemini-3.5-flash', 'gemini-3-flash', 'gemini-2.5-flash', 'gemini-2.0-flash'];
  const routes = {};                                 // key -> 'studio' | 'vertex' (what worked last time)
  const vertexModel = {};                            // requested model -> model name that Vertex accepted
  let vertexProxyState = 'unknown';
  const looksAQ = k => /^AQ\./.test(String(k || ''));

  const direct = {};                                 // key -> true: the proxy was refused for this key but a call straight from the browser worked, so skip the proxy
  async function requestStudio(path, method, key, body) {
    const canProxy = /^https?:$/.test(window.location.protocol) && proxyState !== 'missing' && !direct[key];
    if (canProxy) {
      try { const r = await call(PROXY + path, method, key, body); proxyState = 'ok'; return r; }
      catch (e) {
        if (e.proxyMissing) proxyState = 'missing';
        else if (e.status === 401 || e.status === 403) {   // the key may only accept calls from a browser (referrer / IP restriction): same as the Lingo app does
          try { const r = await call(API + path, method, key, body); direct[key] = true; return r; }
          catch (e2) { throw e2.network ? e : e2; }
        }
        else if (!e.network || proxyState === 'ok') throw e;
      }
    }
    return call(API + path, method, key, body);
  }

  async function vertexCall(rest, method, key, body) {
    const canProxy = /^https?:$/.test(window.location.protocol) && vertexProxyState !== 'missing' && !direct['v:' + key];
    if (canProxy) {
      try { const r = await call(VERTEX_PROXY + rest, method, key, body); vertexProxyState = 'ok'; return r; }
      catch (e) {
        if (e.proxyMissing) vertexProxyState = 'missing';
        else if (e.status === 401 || e.status === 403) {
          try { const r = await call(VERTEX + rest, method, key, body); direct['v:' + key] = true; return r; }
          catch (e2) { throw e2.network ? e : e2; }
        }
        else if (!e.network || vertexProxyState === 'ok') throw e;
      }
    }
    return call(VERTEX + rest, method, key, body);
  }

  async function requestVertex(path, method, key, body) {
    const m = /^models\/([A-Za-z0-9._-]+):generateContent$/.exec(path);
    if (!m) { const er = new Error('Vertex Express ไม่มีรายการโมเดล'); er.status = 501; er.noList = true; throw er; }
    const want = m[1];
    const cands = vertexModel[want] ? [vertexModel[want]] : (/-latest$/.test(want) ? VERTEX_FALLBACK_MODELS : [want].concat(want === DEFAULT_MODEL ? VERTEX_FALLBACK_MODELS.filter(n => n !== want) : []));
    let last = null;
    for (const name of cands) {
      try { const r = await vertexCall('models/' + name + ':generateContent', method, key, body); vertexModel[want] = name; return r; }
      catch (e) { last = e; if (e.status !== 404) throw e; }      // 404 = this model name does not exist here: try the next
    }
    throw last;
  }

  async function requestOne(path, method, key, body) {
    if (routes[key] === 'vertex') return requestVertex(path, method, key, body);
    try { const r = await requestStudio(path, method, key, body); routes[key] = 'studio'; return r; }
    catch (e) {
      const keyRejected = e.status === 400 || e.status === 401 || e.status === 403;
      if (!(looksAQ(key) && keyRejected)) throw e;
      try { const r = await requestVertex(path, method, key, body); routes[key] = 'vertex'; return r; }
      catch (e2) {
        if (e2.status === 404 || e2.status === 429 || (e2.status >= 500 && e2.status < 600)) { routes[key] = 'vertex'; throw e2; }     // the key itself was accepted by Vertex
        e.message = e.message + ' | ลองทางสำรอง Vertex Express แล้วก็ไม่ผ่าน: ' + e2.message;
        throw e;
      }
    }
  }

  // ---- several keys in one field: "k1,k2,k3" (comma / space / newline separated). A key that is rejected or out of quota hands the call to the next key ----
  const splitKeys = k => String(k || '').split(/[\s,;]+/).filter(Boolean);
  let keyCursor = 0;                                 // index of the key that worked last: the next call starts there
  const curKey = key => { const ks = splitKeys(key); return ks.length ? ks[keyCursor % ks.length] : key; };
  const keyProblem = e => !!e && (e.status === 401 || e.status === 403 || e.status === 429 || (e.status === 400 && /API Key/i.test(e.message || '')));

  async function request(path, method, key, body) {
    const keys = splitKeys(key);
    if (keys.length < 2) return requestOne(path, method, keys[0] || key, body);
    let last = null;
    for (let n = 0; n < keys.length; n++) {
      const i = (keyCursor + n) % keys.length;
      try { const r = await requestOne(path, method, keys[i], body); keyCursor = i; return r; }
      catch (e) { if (!keyProblem(e)) throw e; if (!last || e.status === 429 || last.status !== 429) last = e; }
    }
    throw last;                                        // every key failed (a 429 wins so requestRetry waits and tries the whole list again)
  }

  /** Real round trip with the key — what the "ทดสอบคีย์" button shows. Resolves { ok, route, model, message }. */
  async function testKey(key, model) {
    key = String(key || '').trim();
    if (!key) return { ok: false, message: 'ยังไม่ได้ใส่ Gemini API Key' };
    const list = splitKeys(key);
    if (list.length > 1) {                               // several keys: test each one and say how many work
      const out = []; for (const k of list) out.push(await testKey(k, model));
      const good = out.filter(r => r.ok).length;
      return { ok: good > 0, message: (good ? 'ใช้งานได้ ' + good + '/' + list.length + ' คีย์ ✓' : 'ใช้ไม่ได้ทั้ง ' + list.length + ' คีย์') + out.map((r, i) => r.ok ? '' : ' · คีย์ที่ ' + (i + 1) + ': ' + r.message).join('') };
    }
    model = String(model || '').trim() || DEFAULT_MODEL;
    const body = { contents: [{ role: 'user', parts: [{ text: 'Reply with the single word OK.' }] }], generationConfig: { maxOutputTokens: 16 } };
    try {
      let r;
      try { r = await request('models/' + model + ':generateContent', 'POST', key, body); }
      catch (e) {
        if (e.status === 404 && model !== ALIAS_MODEL) { model = ALIAS_MODEL; r = await request('models/' + model + ':generateContent', 'POST', key, body); }
        else throw e;
      }
      const route = routes[key] || 'studio';
      const used = route === 'vertex' ? (vertexModel[model] || model) : model;
      return { ok: true, route: route, model: used, message: 'ใช้งานได้ ✓ (' + (route === 'vertex' ? 'Vertex Express' : 'Gemini API') + ' · ' + used + ')' };
    } catch (e) { return { ok: false, status: e.status, message: e.message }; }
  }

  /** request() with automatic retry for 429 / 5xx / network blips. */
  async function requestRetry(path, method, key, body, onStatus, label) {
    for (let attempt = 0; ; attempt++) {
      try { return await request(path, method, key, body); }
      catch (e) {
        const transient = e.status === 429 || e.network || (e.status >= 500 && e.status < 600);
        if (!transient || attempt >= MAX_RETRY) throw e;
        if (e.status === 429 && e.retryAfter > 120) throw new Error('ใช้ Gemini เกินโควตา ต้องรอประมาณ ' + Math.ceil(e.retryAfter / 60) + ' นาที แล้วค่อยลองใหม่');
        const wait = e.retryAfter != null ? Math.max(2, Math.ceil(e.retryAfter)) : Math.min(3 * Math.pow(2, attempt), 30);
        if (onStatus) onStatus(label + ' — Gemini ติดขัด รอ ' + wait + ' วินาทีแล้วลองใหม่ (' + (attempt + 1) + '/' + MAX_RETRY + ')...');
        await sleep(wait * 1000);
        if (onStatus) onStatus(label + '...');
      }
    }
  }

  /** The configured model is gone (404)? Pick the newest regular Flash model the key can use. */
  async function pickFallbackModel(key) {
    if (routes[curKey(key)] === 'vertex') return null;              // Vertex express cannot list models (the request path already tries several names)
    const r = await request('models?pageSize=200', 'GET', key, null);
    const list = (r.models || []).filter(m => (m.supportedGenerationMethods || []).includes('generateContent'))
      .map(m => m.name.replace(/^models\//, ''))
      .filter(n => /^gemini-[\d.]+-flash(-\d+)?$/.test(n));
    list.sort((a, b) => parseFloat(b.split('-')[1]) - parseFloat(a.split('-')[1]));
    return list[0] || null;
  }

  /** The shape of a response schema as text ("[{"a": integer, "b": [string]}, ...]") — for calls that cannot use responseSchema. */
  function shapeOf(sc) {
    if (!sc) return 'any';
    if (sc.type === 'ARRAY') return '[' + shapeOf(sc.items) + ', ...]';
    if (sc.type === 'OBJECT') return '{' + Object.keys(sc.properties || {}).map(k => '"' + k + '": ' + shapeOf(sc.properties[k])).join(', ') + '}';
    return sc.type === 'INTEGER' ? 'integer' : sc.type === 'NUMBER' ? 'number' : sc.type === 'BOOLEAN' ? 'true or false' : 'string';
  }
  /** The JSON inside a free-text answer (the answer of a search-grounded call may carry words around it). */
  function jsonFrom(text, schema) {
    let t = String(text || '').replace(/```(?:json)?/gi, '').trim();
    const open = schema && schema.type === 'ARRAY' ? '[' : '{', close = open === '[' ? ']' : '}', a = t.indexOf(open), b = t.lastIndexOf(close);
    if (a >= 0 && b > a) t = t.slice(a, b + 1);
    return JSON.parse(t);
  }

  /** generateContent with JSON output. Returns the parsed JSON.
   *  opts.search = true: the call may use Google Search (grounding). Gemini cannot always combine that with a JSON response mode, so the shape is asked for in
   *  the prompt and the answer is read back out of the text. When the search call is refused (key / model / quota) the SAME request is sent once more
   *  without search and ctx.searchNote tells why. ctx.searchQueries collects the web searches Gemini actually ran. */
  async function generateJSON(ctx, parts, schema, label, opts) {
    opts = opts || {};
    const useSearch = !!(opts.search && !ctx.searchOff);
    const body = useSearch
      ? { contents: [{ role: 'user', parts: parts.concat([{ text: '\nAfter you have looked things up, reply with ONLY valid JSON (no markdown fences, no commentary before or after) in exactly this shape: ' + shapeOf(schema) }]) }],
          tools: [{ google_search: {} }], generationConfig: { maxOutputTokens: 8192 } }
      : { contents: [{ role: 'user', parts: parts }], generationConfig: { responseMimeType: 'application/json', responseSchema: schema, maxOutputTokens: 8192 } };
    let res;
    try { res = await requestRetry('models/' + ctx.model + ':generateContent', 'POST', ctx.key, body, ctx.onStatus, label); }
    catch (e) {
      if (e.status === 404 && !ctx.triedFallback) {          // model name retired / not available to this key
        ctx.triedFallback = true;
        const alt = await pickFallbackModel(ctx.key);
        if (!alt || alt === ctx.model) throw new Error('ไม่พบโมเดล Gemini "' + ctx.model + '" — ลองเว้นช่องโมเดลไว้ให้ระบบเลือกเอง');
        ctx.model = alt;
        return generateJSON(ctx, parts, schema, label, opts);
      }
      if (useSearch && (e.status === 400 || e.status === 403 || e.status === 429 || e.status === 404)) {      // search not allowed for this key / model / quota: do the job without it
        ctx.searchOff = true; ctx.searchNote = e.message;
        if (ctx.onStatus) ctx.onStatus(label + ' — ค้นเว็บไม่ได้ (' + e.message + ') ทำต่อโดยไม่ค้นเว็บ...');
        return generateJSON(ctx, parts, schema, label, opts);
      }
      throw e;
    }
    const cand = res.candidates && res.candidates[0];
    if (!cand) {
      const why = res.promptFeedback && res.promptFeedback.blockReason;
      throw new Error('Gemini ไม่ตอบกลับ' + (why ? ' (ถูกบล็อก: ' + why + ')' : ''));
    }
    const text = (cand.content && cand.content.parts || []).map(p => p.text || '').join('').trim();
    if (!text) throw new Error('Gemini ตอบกลับว่างเปล่า' + (cand.finishReason ? ' (' + cand.finishReason + ')' : ''));
    if (useSearch) {
      const q = cand.groundingMetadata && cand.groundingMetadata.webSearchQueries;
      if (Array.isArray(q)) q.forEach(x => { if (x && ctx.searchQueries.indexOf(x) < 0) ctx.searchQueries.push(String(x)); });
    }
    try { return useSearch ? jsonFrom(text, schema) : JSON.parse(text.replace(/^```(?:json)?\s*|\s*```$/g, '')); }
    catch (e) {
      if (useSearch && !ctx.searchRetried) {                 // the grounded answer was not clean JSON: ask once more without search rather than fail
        ctx.searchRetried = true; ctx.searchOff = true; ctx.searchNote = 'ได้คำตอบที่อ่านไม่ได้';
        return generateJSON(ctx, parts, schema, label, opts);
      }
      throw new Error('อ่านคำตอบของ Gemini ไม่ได้ (ผลลัพธ์ถูกตัด) ลองใหม่อีกครั้ง');
    }
  }

  const makeCtx = req => ({ key: req.geminiKey, model: (req.geminiModel || '').trim() || DEFAULT_MODEL, onStatus: req.onStatus, triedFallback: false, searchOff: false, searchNote: '', searchQueries: [] });
  const langName = l => l === 'th' ? 'Thai' : l === 'en' ? 'English' : 'the language that is spoken (detect it)';

  // ---------------- helpers ----------------
  function toBase64(blob) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(String(r.result).split(',')[1] || '');
      r.onerror = () => rej(new Error('อ่านไฟล์เสียงไม่ได้'));
      r.readAsDataURL(blob);
    });
  }
  function mimeOf(piece) {
    const t = piece.blob.type;
    if (t) return t;
    const n = (piece.name || '').toLowerCase();
    return /\.wav$/.test(n) ? 'audio/wav' : /\.webm$/.test(n) ? 'video/webm' : /\.(mov|qt)$/.test(n) ? 'video/quicktime' : /\.mp3$/.test(n) ? 'audio/mpeg' : 'video/mp4';
  }
  /** "01:23.5", "1:02:03", "83.5" or 83.5 -> seconds (NaN if unreadable). */
  function parseTs(v) {
    if (typeof v === 'number') return v;
    const parts = String(v == null ? '' : v).trim().split(':').map(x => parseFloat(x.replace(',', '.')));
    if (!parts.length || parts.some(x => !isFinite(x))) return NaN;
    return parts.reduce((acc, x) => acc * 60 + x, 0);
  }
  /** Spread a line's text over [start, end] by character weight -> words (last one flagged brk). */
  function wordsForLine(text, start, end) {
    const toks = S.subtitle.tokenize(text);
    if (!toks.length) return [];
    const total = toks.reduce((n, t) => n + Math.max(1, S.thai.visLen(t.text)), 0), span = Math.max(0.05, end - start);
    let acc = 0;
    const out = toks.map(t => {
      const w = Math.max(1, S.thai.visLen(t.text)), a = start + span * acc / total;
      acc += w;
      return { word: t.text, joined: t.joined, start: a, end: start + span * acc / total };
    });
    out[out.length - 1].brk = true;
    return out;
  }

  // ---------------- provider 1: Gemini listens to the audio ----------------
  transcribers.register('gemini', {
    label: 'Gemini (ถอดเสียงเอง)',
    async transcribe(req) {
      if (!req.geminiKey) throw new Error('กรุณาใส่ Gemini API Key');
      const onStatus = req.onStatus || function () {}, onProgress = req.onProgress || function () {};
      const ctx = makeCtx(req);
      const duration = req.durationHint || (S.state && S.state.project.media.duration) || 0;
      const maxChars = req.maxChars || 28;
      onProgress(0);
      const src = await S.ai.openSource(req.file, onStatus, duration, { directMax: DIRECT_MAX, chunkSec: CHUNK_SEC });
      const words = [];
      let prevEnd = 0;
      try {
        let cur = await src.next();
        if (!cur) throw new Error('ไม่พบแทร็กเสียงในวิดีโอนี้');
        for (let i = 0; cur; i++) {
          const total = Math.max(src.total, i + 1);
          const label = total > 1 ? 'Gemini กำลังฟังและถอดเสียง ช่วงที่ ' + (i + 1) + '/' + total : 'Gemini กำลังฟังและถอดเสียง';
          const ahead = src.next(); ahead.catch(function () {});
          onStatus(label + '...');
          const data = await toBase64(cur.blob);
          const prompt =
            'Transcribe the speech in this audio into subtitles.\n' +
            'Language: ' + langName(req.language) + '.\n' +
            'Return JSON {"segments":[{"start":"MM:SS.s","end":"MM:SS.s","text":"..."}]}.\n' +
            'Rules:\n' +
            '- Each segment is ONE natural subtitle line: a short phrase or sentence, at most ' + maxChars + ' characters and at most 5 seconds long.\n' +
            '- Timestamps are measured from the very start of THIS audio clip, in order, without overlap, and must match when the words are actually spoken.\n' +
            '- Write exactly what is said, spelled correctly. For Thai: no spaces between Thai words; use a single space only between phrases or around English words/numbers.\n' +
            '- Keep English words and brand names in Latin letters. Do not translate. No speaker labels, no descriptions of sounds or music.\n' +
            '- If nobody speaks, return {"segments":[]}.';
          const result = await generateJSON(ctx, [
            { inline_data: { mime_type: mimeOf(cur), data: data } },
            { text: prompt }
          ], {
            type: 'OBJECT',
            properties: { segments: { type: 'ARRAY', items: { type: 'OBJECT', properties: { start: { type: 'STRING' }, end: { type: 'STRING' }, text: { type: 'STRING' } }, required: ['start', 'end', 'text'] } } },
            required: ['segments']
          }, label);
          const segs = (result && result.segments || []).map(s => ({ s: parseTs(s.start), e: parseTs(s.end), t: String(s.text || '').trim() })).filter(s => s.t);
          segs.forEach(sg => {
            let s = isFinite(sg.s) ? sg.s + cur.offset : prevEnd;
            let e = isFinite(sg.e) ? sg.e + cur.offset : s;
            s = Math.max(s, prevEnd);
            if (!(e > s + 0.1)) e = s + Math.max(0.8, S.thai.visLen(sg.t) * 0.09);
            if (duration) { e = Math.min(e, duration); s = Math.min(s, Math.max(0, duration - 0.1)); }
            if (e <= s) return;
            wordsForLine(sg.t, s, e).forEach(w => words.push(w));
            prevEnd = e;
          });
          onProgress(Math.min(99, Math.round((i + 1) / total * 100)));
          cur = await ahead;
        }
      } finally { if (src.close) src.close(); }
      onProgress(100);
      return { words: words };
    }
  });

  // ---------------- provider 2: Whisper timing + Gemini text ----------------
  /** Split into windows of about WINDOW words, cutting at the longest pause near the end of each window. */
  function windows(words) {
    const out = [];
    let i = 0;
    while (i < words.length) {
      let end = Math.min(words.length, i + WINDOW);
      if (end < words.length) {
        let bestGap = -1, bestAt = end;
        for (let k = end; k > i + WINDOW - 40 && k > i + 1; k--) {
          const gap = words[k].start - words[k - 1].end;
          if (gap > bestGap) { bestGap = gap; bestAt = k; }
        }
        end = bestAt;
      }
      out.push([i, end]);
      i = end;
    }
    return out;
  }

  const norm = t => String(t || '').replace(/\s+/g, '');

  /** Validate Gemini's line list against the window: contiguous, in order, covering every word. */
  function sanitizeLines(lines, count) {
    const out = [];
    let next = 0;
    (Array.isArray(lines) ? lines : []).slice().sort((a, b) => a.from - b.from).forEach(l => {
      let from = Math.max(next, Math.floor(l.from)), to = Math.min(count - 1, Math.floor(l.to));
      if (!isFinite(from) || !isFinite(to) || to < from) return;
      out.push({ from: from, to: to, text: String(l.text || '') });
      next = to + 1;
    });
    if (!out.length) return null;
    out[0].from = 0;                                           // close gaps by stretching, never by dropping words
    for (let i = 1; i < out.length; i++) out[i].from = out[i - 1].to + 1;
    if (out[out.length - 1].to < count - 1) out[out.length - 1].to = count - 1;
    return out;
  }

  async function refineWindow(ctx, ws, req) {
    const maxChars = req.maxChars || 28;
    const tokens = ws.map((w, i) => i + ':' + w.word + (i < ws.length - 1 && ws[i + 1].start - w.end >= 0.5 ? ' ‖' : '')).join(' ');
    const prompt =
      'You are a professional subtitle editor for ' + langName(req.language) + ' videos.\n' +
      'Below are the words recognised from speech, in order, each written as ID:word. "‖" marks a pause in the speech.\n' +
      'Group the words into subtitle lines and correct recognition mistakes.\n' +
      'Rules:\n' +
      '1. Every ID belongs to exactly one line. Lines follow each other in order with no gaps and no overlap. Give each line as from/to (inclusive IDs).\n' +
      '2. A line is a natural, easy-to-read phrase or sentence of at most ' + maxChars + ' characters (about ' + Math.round(maxChars * 1.5) + ' for English), ideally ' + Math.min(10, Math.round(maxChars * 0.4)) + ' or more. Break at sentence ends, pauses (‖) and phrase boundaries. Do not end a line with a linking word such as ที่, และ, แต่, เพราะ, ว่า, ของ, กับ when it can start the next line; keep particles such as ครับ, ค่ะ, นะ with the line before.\n' +
      '3. "text" is the corrected text of that line. Fix misheard or misspelled words, tone marks and doubled or missing letters using the context, but keep the speaker\'s meaning and wording. Never translate, summarise, add or remove content.\n' +
      '4. Thai: no spaces between Thai words; one space only between phrases or around English words and numbers. English: normal spacing. No full stop at the end of a line.\n\n' +
      'WORDS:\n' + tokens;
    const result = await generateJSON(ctx, [{ text: prompt }], {
      type: 'OBJECT',
      properties: { lines: { type: 'ARRAY', items: { type: 'OBJECT', properties: { from: { type: 'INTEGER' }, to: { type: 'INTEGER' }, text: { type: 'STRING' } }, required: ['from', 'to', 'text'] } } },
      required: ['lines']
    }, 'Gemini กำลังเกลาข้อความ');
    const lines = sanitizeLines(result && result.lines, ws.length);
    if (!lines) throw new Error('Gemini ตอบกลับรูปแบบที่ใช้ไม่ได้');
    const out = [];
    lines.forEach(l => {
      const src = ws.slice(l.from, l.to + 1), rawText = S.subtitle.joinWords(src), fixed = l.text.trim();
      const ratio = S.thai.visLen(norm(fixed)) / Math.max(1, S.thai.visLen(norm(rawText)));
      let lineWords;
      if (!fixed || norm(fixed) === norm(rawText) || ratio < 0.5 || ratio > 1.8) {
        lineWords = src.map(w => Object.assign({}, w));          // unchanged, or Gemini went off the rails: keep Whisper's words
      } else {
        lineWords = wordsForLine(fixed, src[0].start, src[src.length - 1].end);
      }
      if (lineWords.length) lineWords[lineWords.length - 1].brk = true;
      lineWords.forEach(w => out.push(w));
    });
    return out;
  }

  async function refine(words, req) {
    const ctx = makeCtx(req), onProgress = req.refineProgress || function () {};
    const wins = windows(words), out = [];
    let skipped = 0;
    for (let i = 0; i < wins.length; i++) {
      const ws = words.slice(wins[i][0], wins[i][1]);
      if (req.onStatus) req.onStatus('Gemini กำลังเกลาข้อความและตัดประโยค' + (wins.length > 1 ? ' ' + (i + 1) + '/' + wins.length : '') + '...');
      try { (await refineWindow(ctx, ws, req)).forEach(w => out.push(w)); }
      catch (e) {
        if (e.status === 401 || e.status === 403 || (e.status === 400 && /Key/.test(e.message))) throw e;   // a bad key is the user's to fix
        ws.forEach(w => out.push(w));                              // otherwise keep Whisper's version of this part
        skipped++;
      }
      onProgress((i + 1) / wins.length);
    }
    return { words: out, skipped: skipped };
  }

  /**
   * Look at a few frames of a reference clip and describe how its caption is DRAWN: which of our fonts is the closest, the weight,
   * colours, outline / shadow / glow / box. req = { geminiKey, geminiModel?, onStatus?, images: [base64 jpeg], fonts: [label...] }.
   * Returns plain numbers / hex colours (sizes are % of the font size so they fit any clip); a field is null when unclear.
   */
  const hex6 = v => (typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v.trim())) ? v.trim().toLowerCase() : null;
  const num = (v, lo, hi) => (typeof v === 'number' && isFinite(v)) ? Math.min(hi, Math.max(lo, v)) : null;
  S.ai.identifyCaptionStyle = async function (req) {
    if (!req.geminiKey) throw new Error('กรุณาใส่ Gemini API Key');
    const ctx = makeCtx(req), fonts = req.fonts || [];
    const schema = {
      type: 'OBJECT',
      properties: {
        fontIndex: { type: 'INTEGER' }, weight: { type: 'INTEGER' }, italic: { type: 'BOOLEAN' }, textColor: { type: 'STRING' },
        outlineOn: { type: 'BOOLEAN' }, outlineColor: { type: 'STRING' }, outlineWidthPct: { type: 'NUMBER' },
        shadowOn: { type: 'BOOLEAN' }, shadowColor: { type: 'STRING' }, shadowDistPct: { type: 'NUMBER' }, shadowBlurPct: { type: 'NUMBER' },
        glowOn: { type: 'BOOLEAN' }, glowColor: { type: 'STRING' }, glowType: { type: 'STRING' }, glowStrength: { type: 'INTEGER' },
        boxOn: { type: 'BOOLEAN' }, boxColor: { type: 'STRING' }, boxOpacity: { type: 'NUMBER' },
        note: { type: 'STRING' }
      },
      required: ['fontIndex', 'weight', 'textColor', 'outlineOn', 'shadowOn', 'glowOn', 'boxOn']
    };
    const prompt = 'These images are crops of the burned-in caption of a reference video (Thai subtitles). Describe how the caption text is DRAWN so it can be copied.\n' +
      'Pick the CLOSEST font from this list by its index (look at letter shapes: loops, terminals, stroke contrast, proportions) — judge the Thai letters first:\n' +
      fonts.map((f, i) => i + ': ' + f).join('\n') + '\n' +
      'Then give: weight (300-900, in steps of 100), italic, the main text colour as #rrggbb, ' +
      'outline (a solid contour around the letters: on/off, colour, width as % of the font size, 0-15), ' +
      'drop shadow (a hard or soft copy offset behind the letters: on/off, colour, distance and blur as % of the font size, 0-15), ' +
      'glow (light spreading out around the letters: on/off, colour, glowType = "burst" when light rays/streaks shoot outward, "halo" when it is an even soft halo, glowStrength 0-100), ' +
      'box (a filled rectangle behind the text: on/off, colour, opacity 0-1). ' +
      'Several frames show the same style; coloured words are highlights, not the base colour. Use false / null when something is not there. note = one short sentence on what you see.';
    const parts = (req.images || []).slice(0, 4).map(b64 => ({ inline_data: { mime_type: 'image/jpeg', data: b64 } }));
    parts.push({ text: prompt });
    const r = await generateJSON(ctx, parts, schema, 'Gemini กำลังดูฟอนต์และสไตล์ตัวอักษร');
    const fi = Math.round(r.fontIndex);
    return {
      fontIndex: fi >= 0 && fi < fonts.length ? fi : null,
      weight: num(r.weight, 300, 900) == null ? null : Math.round(num(r.weight, 300, 900) / 100) * 100,
      italic: !!r.italic, textColor: hex6(r.textColor),
      outline: { on: !!r.outlineOn, color: hex6(r.outlineColor), widthPct: num(r.outlineWidthPct, 0, 15) },
      shadow: { on: !!r.shadowOn, color: hex6(r.shadowColor), distPct: num(r.shadowDistPct, 0, 15), blurPct: num(r.shadowBlurPct, 0, 15) },
      glow: { on: !!r.glowOn, color: hex6(r.glowColor), type: r.glowType === 'burst' ? 'burst' : 'halo', strength: num(r.glowStrength, 0, 100) },
      box: { on: !!r.boxOn, color: hex6(r.boxColor), opacity: num(r.boxOpacity, 0, 1) },
      note: typeof r.note === 'string' ? r.note.slice(0, 200) : ''
    };
  };

  /** The names the user gave for the story (characters, people, things). A real person is only ever named from these / the picture's own text / the narration, never from a face. */
  const castBlock = cast => String(cast || '').trim() ? 'CAST / NAMES given by the user (use these names for what you see; a line may say how the person or character looks):\n' + String(cast).trim().slice(0, 1500) : '';
  const clipHead = (c, i) => 'CLIP ' + i + ' (' + c.name + ', ' + (c.still ? 'a STILL PICTURE, one image' : c.sec.toFixed(1) + ' s') + ')' + (c.names && c.names.length ? ' — the user says it shows: ' + c.names.join(', ') : '');

  /** Which pool clip fits what is being said in each scene? req = { geminiKey, geminiModel?, onStatus?, cast?, scenes:[{text, sec}], clips:[{name, sec, still?, names?, images:[base64 jpeg]}] }
   *  -> [clipIndex per scene] (null where Gemini gave no usable answer). */
  S.ai.matchScenes = async function (req) {
    if (!req.geminiKey) throw new Error('กรุณาใส่ Gemini API Key');
    const ctx = makeCtx(req), parts = [];
    req.clips.forEach((c, i) => {
      parts.push({ text: clipHead(c, i) + (c.still ? ':' : ' — frames from start to end:') });
      c.images.forEach(b64 => parts.push({ inline_data: { mime_type: 'image/jpeg', data: b64 } }));
    });
    if (castBlock(req.cast)) parts.push({ text: castBlock(req.cast) });
    parts.push({ text: 'Above are the b-roll clips (a STILL PICTURE is one image that is simply held on screen). Below is the narration, split into scenes. For EACH scene pick the clip whose picture best illustrates what is being said ' +
      '(subject, place, mood). Reuse a clip when it fits several scenes; prefer variety only when two clips fit equally well. A scene with no speech: pick any clip.\n' +
      req.scenes.map((s, i) => 'SCENE ' + i + ' (' + s.sec.toFixed(1) + ' s): ' + (s.text || '(no speech)')).join('\n') });
    const schema = { type: 'ARRAY', items: { type: 'OBJECT', properties: { scene: { type: 'INTEGER' }, clip: { type: 'INTEGER' } }, required: ['scene', 'clip'] } };
    const r = await generateJSON(ctx, parts, schema, 'Gemini กำลังจับคู่ฉากกับเสียงบรรยาย');
    const out = req.scenes.map(() => null);
    (Array.isArray(r) ? r : []).forEach(x => { const a = Math.round(x.scene), c = Math.round(x.clip); if (a >= 0 && a < out.length && c >= 0 && c < req.clips.length) out[a] = c; });
    return out;
  };

  /** Gemini LOOKS at time-stamped frames of each clip and reports what is in it: a one-line summary, the characters / animals / objects / places
   *  (named when it recognises them — cartoon & game characters, animal species, landmarks, products) and the clip cut into consecutive parts [from, to] seconds,
   *  each marked usable or not (black, blurry, shaky, logo / credits / text-only). A STILL PICTURE is one frame and one part.
   *  Names: a real person is never named from the face. A name is used only when it is written in the picture, in the cast list the user gave (req.cast),
   *  in the user's own note on the clip (clip.names), in the file name or in the narration (req.context). With req.search Gemini may look things up on the web
   *  (Google Search grounding) — to find out what a character / item / place / product is called, never who a real face belongs to.
   *  req = { geminiKey, geminiModel?, onStatus?, search?, cast?, context?, clips:[{name, sec, still?, names?, frames:[{t, b64}]}] }
   *  -> [ { summary, subjects:[string], segments:[{from, to, what, usable}] } | null per clip ]  (the array also carries .search = { queries, off, note }) */
  S.ai.describeClips = async function (req) {
    if (!req.geminiKey) throw new Error('กรุณาใส่ Gemini API Key');
    const ctx = makeCtx(req), parts = [], search = !!req.search;
    req.clips.forEach((c, i) => {
      parts.push({ text: 'CLIP ' + i + ' (file name: "' + c.name + '", ' + (c.still ? 'a STILL PICTURE — one image, no motion' : 'total length ' + c.sec.toFixed(1) + ' s') + ')' +
        (c.names && c.names.length ? '. The user says this clip shows: ' + c.names.join(', ') : '') + (c.still ? '.' : '. Frames, each one labelled with its time in the clip:') });
      c.frames.forEach(f => { if (!c.still) parts.push({ text: 't=' + f.t.toFixed(1) + 's' }); parts.push({ inline_data: { mime_type: 'image/jpeg', data: f.b64 } }); });
    });
    if (castBlock(req.cast)) parts.push({ text: castBlock(req.cast) });
    if (String(req.context || '').trim()) parts.push({ text: 'NARRATION of the video these clips are for (context only: it tells you the topic and which names matter):\n' + String(req.context).trim().slice(0, 1800) });
    parts.push({ text: 'Look at every frame of every clip above and report, for EACH clip (write all text values in Thai): ' +
      '`summary` — one sentence: what happens in the clip (for a still picture: what it shows). ' +
      '`subjects` — the characters, animals, objects and places that appear, each with its NAME. ' +
      'Cartoon / anime / game / film characters, animal species, landmarks, products and logos: name them when you recognise them' +
      (search ? ', and CHECK the name with Google Search whenever you are not sure (search for what that character, item, place or product looks like and what it is called; the narration, the cast list and the file name tell you which franchise or topic to search in)' : '') + '. ' +
      'A REAL person is never named from their face. Name a real person only when the name is written in the picture (caption, name tag, jersey, title card), is in the cast list, in the user\'s note on the clip, in the file name, or is said in the narration — ' +
      'and only when it is clear which person in the picture it belongs to. Otherwise describe them (for example "ผู้ชายใส่เสื้อแดง"). ' +
      (search ? 'Never use search to work out who a real person is from how they look. ' : '') +
      '`segments` — the clip cut into consecutive parts (`from`, `to` in seconds, covering 0 to the clip length) where the picture changes; for each part `what` = a short description and ' +
      '`usable` = false when the part is black, blurry, badly shaky, only a logo / credits / text, or otherwise not good footage to cut into a video; true otherwise. A still picture has exactly one part.' });
    const schema = { type: 'ARRAY', items: { type: 'OBJECT', properties: {
      clip: { type: 'INTEGER' }, summary: { type: 'STRING' }, subjects: { type: 'ARRAY', items: { type: 'STRING' } },
      segments: { type: 'ARRAY', items: { type: 'OBJECT', properties: { from: { type: 'NUMBER' }, to: { type: 'NUMBER' }, what: { type: 'STRING' }, usable: { type: 'BOOLEAN' } }, required: ['from', 'to', 'what', 'usable'] } }
    }, required: ['clip', 'summary', 'subjects', 'segments'] } };
    const r = await generateJSON(ctx, parts, schema, search ? 'Gemini กำลังดูคลิปและค้นเว็บหาชื่อ' : 'Gemini กำลังดูว่าในคลิปมีอะไร', { search: search });
    const out = req.clips.map(() => null);
    (Array.isArray(r) ? r : []).forEach(x => {
      const i = Math.round(x.clip); if (!(i >= 0 && i < out.length)) return;
      const c = req.clips[i], sec = c.sec || 0, raw = Array.isArray(x.segments) ? x.segments : [];
      let segs = raw.map(g => ({ from: Math.max(0, +g.from || 0), to: Math.min(sec || 1e9, +g.to || 0), what: String(g.what || '').slice(0, 120), usable: g.usable !== false }))
        .filter(g => g.to > g.from + 0.05).sort((p, q) => p.from - q.from);
      if (c.still) segs = [{ from: 0, to: sec || 1, what: String((raw[0] && raw[0].what) || x.summary || '').slice(0, 120), usable: !raw.some(g => g.usable === false) }];
      out[i] = { summary: String(x.summary || '').slice(0, 200), subjects: (x.subjects || []).map(t => String(t).slice(0, 60)).slice(0, 12),
        segments: segs.length ? segs : [{ from: 0, to: sec || 1, what: String(x.summary || ''), usable: true }] };
    });
    out.search = { queries: ctx.searchQueries.slice(), off: ctx.searchOff, note: ctx.searchNote };
    return out;
  };

  /** Which clip, and where in it, fits what is said in each scene? Gemini gets the narration split into scenes plus, for every clip, what describeClips found
   *  in it (`info`, text only — cheap) or, for a clip without that, time-stamped frames. It names the clip and the second inside it, and why.
   *  The cast list (req.cast) and the user's notes on a clip (clip.names) tell it which name in the narration is which picture.
   *  req = { geminiKey, geminiModel?, onStatus?, cast?, scenes:[{text, sec}], clips:[{name, sec, still?, names?, info?, frames?:[{t, b64}]}] }
   *  -> [ { clip, at, why } | null per scene ]   (`at` is always 0 for a still picture) */
  S.ai.matchVoice = async function (req) {
    if (!req.geminiKey) throw new Error('กรุณาใส่ Gemini API Key');
    const ctx = makeCtx(req), parts = [];
    req.clips.forEach((c, i) => {
      const user = c.names && c.names.length ? '\nUser\'s note: this clip shows ' + c.names.join(', ') : '', still = c.still ? ' — a STILL PICTURE (one image held on screen; use at = 0)' : '';
      if (c.info) {
        const I = c.info, subj = (c.names || []).concat(I.subjects.filter(t => (c.names || []).indexOf(t) < 0));
        parts.push({ text: 'CLIP ' + i + ' (' + c.name + ', ' + (c.still ? 'still picture' : 'total length ' + c.sec.toFixed(1) + ' s') + ')' + still + ': ' + I.summary + '\nSubjects: ' + (subj.join(', ') || '-') + '\nParts:\n' +
          I.segments.map(g => '  [' + g.from.toFixed(1) + '–' + g.to.toFixed(1) + ' s] ' + g.what + (g.usable ? '' : ' (NOT USABLE)')).join('\n') });
      } else {
        parts.push({ text: 'CLIP ' + i + ' (' + c.name + ', ' + (c.still ? 'still picture' : 'total length ' + c.sec.toFixed(1) + ' s') + ')' + still + user + (c.still ? '. The picture:' : '. Frames, each one labelled with its time in the clip:') });
        (c.frames || []).forEach(f => { if (!c.still) parts.push({ text: 't=' + f.t.toFixed(1) + 's' }); parts.push({ inline_data: { mime_type: 'image/jpeg', data: f.b64 } }); });
      }
    });
    if (castBlock(req.cast)) parts.push({ text: castBlock(req.cast) });
    parts.push({ text: 'Above are the video clips and still pictures (the picture material). Below is the narration, cut into scenes in the order it is spoken. ' +
      'For EACH scene work out WHO or WHAT the words are about (a character, an animal, an object, a place, an action, a mood — use the cast list and the user\'s notes to know which name is which picture), then choose the clip AND the moment in that clip (`at`, in seconds from the clip start) whose picture shows exactly that. ' +
      'Give `why` in Thai: a few words saying what the scene is about and what the chosen part shows. ' +
      'Choose `at` inside a part that is usable — never inside a part marked NOT USABLE — and so that `at` + the scene length stays inside that part whenever the part is long enough. ' +
      'Never use the same part of a video clip for two scenes; use another part of the same clip, or another clip, instead. A still picture is the same image every time, so use it again only when no other clip fits as well. Reuse a clip only when it clearly fits better than the others. ' +
      'When several clips fit equally well keep the story moving: prefer a clip not used yet, and the earlier part of a clip for the earlier scene. ' +
      'A scene without speech: take the clip that has been used least.\n' +
      req.scenes.map((s, i) => 'SCENE ' + i + ' (' + s.sec.toFixed(1) + ' s): ' + (s.text || '(no speech)')).join('\n') });
    const schema = { type: 'ARRAY', items: { type: 'OBJECT', properties: { scene: { type: 'INTEGER' }, clip: { type: 'INTEGER' }, at: { type: 'NUMBER' }, why: { type: 'STRING' } }, required: ['scene', 'clip', 'at'] } };
    const r = await generateJSON(ctx, parts, schema, 'Gemini กำลังจับคู่ภาพกับคำพูด');
    const out = req.scenes.map(() => null);
    (Array.isArray(r) ? r : []).forEach(x => {
      const a = Math.round(x.scene), c = Math.round(x.clip), at = +x.at;
      if (a >= 0 && a < out.length && c >= 0 && c < req.clips.length) out[a] = { clip: c, at: req.clips[c].still ? 0 : (isFinite(at) && at > 0 ? at : 0), why: String(x.why || '').slice(0, 140) };
    });
    return out;
  };

  S.ai = S.ai || {};
  S.ai.testGeminiKey = testKey;

  transcribers.register('groq-gemini', {
    label: 'Groq Whisper + Gemini',
    async transcribe(req) {
      if (!req.geminiKey) throw new Error('กรุณาใส่ Gemini API Key');
      const onProgress = req.onProgress || function () {};
      let base;
      try { base = await transcribers.get('groq-whisper').transcribe(Object.assign({}, req, { onProgress: p => onProgress(Math.round(p * 0.75)) })); }
      catch (e) {
        if (!(e && e.keyRejected)) throw e;
        // Groq refused the key (wrong / revoked): do not lose the whole job — let Gemini listen to the clip itself
        if (req.onStatus) req.onStatus('คีย์ Groq ใช้ไม่ได้ — ให้ Gemini ถอดเสียงเองแทน...');
        const g = await transcribers.get('gemini').transcribe(req);
        return { words: g.words, groqRejected: true };
      }
      if (!base.words.length) return base;
      try {
        const r = await refine(base.words, Object.assign({}, req, { refineProgress: f => onProgress(75 + Math.round(f * 24)) }));
        onProgress(100);
        return { words: r.words, refineSkipped: r.skipped };
      } catch (e) {
        onProgress(100);                                           // keep the (expensive) Whisper result, tell the user why Gemini did not help
        return { words: base.words, refineError: e.message };
      }
    }
  });
})(window.SubEd);
