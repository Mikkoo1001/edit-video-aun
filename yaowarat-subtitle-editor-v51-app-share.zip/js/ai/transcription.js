/* =====================================================================
 * AI layer — speech-to-text providers. No DOM.
 *
 * A transcriber is { transcribe({file, apiKey, language, onProgress, onStatus}) -> Promise<{words}> }
 * where words = [{ word, start, end }] in seconds. Each provider hides its own
 * wire format. Providers: groq-whisper (this file), gemini + groq-gemini (ai/gemini.js). Add more (local Whisper, ...) with
 *   SubEd.transcribers.register('id', { transcribe(req){...} })
 * Other AI tasks (smart cut, style analysis, auto-edit planning) should be added
 * as sibling registries in this folder, each returning plain data that the
 * editor applies to state.project.
 *
 * Groq provider, how a request travels:
 *   1. Big videos (> DIRECT_MAX) are NOT uploaded as-is (Groq rejects > 25 MB and the browser then
 *      only reports a vague "network/CORS" error). The audio is streamed out of the file (ai/audio-extract.js:
 *      reads a few MB at a time, so 300-400 MB+ clips work), turned into 16 kHz mono WAV and cut into
 *      CHUNK_SEC pieces; timestamps are shifted back by each piece's offset. Each piece is produced while the
 *      previous one is uploading. Formats the streamer can't read fall back to the old whole-file decode,
 *      which only works for files up to LEGACY_MAX.
 *   2. Each piece goes to the same-origin proxy  /api/transcribe  (public/_worker.js on Cloudflare Pages)
 *      -> no CORS, works even where api.groq.com is blocked on the user's network.
 *   3. If the proxy does not exist (file://, plain static host, local dev) it falls back to calling
 *      https://api.groq.com directly from the browser, exactly like before.
 *   4. Rate limits (429), 5xx and network blips are retried with back-off (a long video is many requests).
 * ===================================================================== */
(function (S) {
  'use strict';
  const transcribers = S.transcribers = S.createRegistry('transcriber');

  const GROQ_URL = 'https://api.groq.com/openai/v1/audio/transcriptions';
  const PROXY_URL = '/api/transcribe';
  const DIRECT_MAX = 20 * 1024 * 1024;   // <= this: send the original file untouched (Groq limit is 25 MB)
  const HARD_MAX = 25 * 1024 * 1024;
  const TARGET_RATE = 16000;             // Whisper's native rate: nothing is lost by downsampling
  const CHUNK_SEC = 600;                 // 10 min of 16 kHz/16-bit mono WAV = 19.2 MB, under the 25 MB cap
  const LEGACY_MAX = 150 * 1024 * 1024;  // whole-file decode (fallback only) needs the file + its PCM in RAM
  const MAX_RETRY = 5;
  const MAX_WAIT_SEC = 180;              // a 429 asking us to wait longer than this is reported instead of waited out
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  function wordsFromSegments(segments, offset) {
    const out = [];
    segments.forEach(seg => {
      const parts = (seg.text || '').trim().split(/\s+/).filter(Boolean);
      if (!parts.length) return;
      const dur = (seg.end - seg.start) / parts.length;
      parts.forEach((w, i) => out.push({ word: w, start: offset + seg.start + i * dur, end: offset + seg.start + (i + 1) * dur }));
    });
    return out;
  }

  // ---------------- audio extraction (browser side) ----------------
  function encodeWav(samples, rate) {
    const n = samples.length, buf = new ArrayBuffer(44 + n * 2), v = new DataView(buf);
    const str = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
    str(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); str(8, 'WAVE'); str(12, 'fmt ');
    v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, rate, true); v.setUint32(28, rate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
    str(36, 'data'); v.setUint32(40, n * 2, true);
    for (let i = 0; i < n; i++) {
      const s = Math.max(-1, Math.min(1, samples[i]));
      v.setInt16(44 + i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    }
    return new Blob([buf], { type: 'audio/wav' });
  }

  async function decodeToMono16k(file) {
    const Ctx = window.OfflineAudioContext || window.webkitOfflineAudioContext;
    if (!Ctx) throw new Error('เบราว์เซอร์นี้ไม่รองรับการแยกเสียงจากวิดีโอ');
    const data = await (S.localCopy ? S.localCopy.readAll(file) : file.arrayBuffer());
    const ctx = new Ctx(1, 1, TARGET_RATE);
    const audio = await new Promise((res, rej) => { const p = ctx.decodeAudioData(data, res, rej); if (p && p.catch) p.catch(rej); });
    let src = audio;
    if (audio.sampleRate !== TARGET_RATE) {        // some browsers ignore the context rate when decoding -> resample
      const off = new Ctx(1, Math.max(1, Math.ceil(audio.duration * TARGET_RATE)), TARGET_RATE);
      const node = off.createBufferSource(); node.buffer = audio; node.connect(off.destination); node.start();
      src = await off.startRendering();
    }
    const ch = src.numberOfChannels, len = src.length, mono = new Float32Array(len);
    for (let c = 0; c < ch; c++) { const d = src.getChannelData(c); for (let i = 0; i < len; i++) mono[i] += d[i] / ch; }
    return mono;
  }

  /** A list of ready-made pieces as a pull source (same shape as SubEd.audio.openChunks()). */
  function listSource(list) {
    let i = 0;
    return { total: list.length, next: () => Promise.resolve(i < list.length ? list[i++] : null), progress: () => i / list.length, close() {} };
  }

  /** A canonical 16-bit PCM WAV (44-byte header) — what ui/merge-clips.js writes. -> { ch, rate, frames } or null. */
  async function wavInfo(file) {
    if (file.size < 45) return null;
    try {
      const v = new DataView(await file.slice(0, 44).arrayBuffer()), tag = o => String.fromCharCode(v.getUint8(o), v.getUint8(o + 1), v.getUint8(o + 2), v.getUint8(o + 3));
      if (tag(0) !== 'RIFF' || tag(8) !== 'WAVE' || tag(12) !== 'fmt ' || tag(36) !== 'data') return null;
      const fmt = v.getUint16(20, true), ch = v.getUint16(22, true), rate = v.getUint32(24, true), bits = v.getUint16(34, true);
      if (fmt !== 1 || bits !== 16 || ch < 1 || ch > 2 || !rate) return null;
      return { ch: ch, rate: rate, frames: Math.floor((file.size - 44) / (2 * ch)) };
    } catch (e) { return null; }
  }
  /** Pull source for a big PCM WAV: each chunk is read, mixed to mono and brought to 16 kHz on demand (constant memory). */
  function wavSource(file, info, chunkSec) {
    const per = Math.round(chunkSec * info.rate), ratio = info.rate / TARGET_RATE;
    let pos = 0, idx = 0;
    return {
      total: Math.max(1, Math.ceil(info.frames / per)),
      progress: () => Math.min(1, pos / Math.max(1, info.frames)),
      close() {},
      async next() {
        if (pos >= info.frames) return null;
        const n = Math.min(per, info.frames - pos);
        const pcm = new Int16Array(await file.slice(44 + pos * info.ch * 2, 44 + (pos + n) * info.ch * 2).arrayBuffer());
        const outN = Math.max(1, Math.floor(n / ratio)), out = new Float32Array(outN);
        for (let i = 0; i < outN; i++) {
          const a = Math.floor(i * ratio), b = Math.max(a + 1, Math.min(n, Math.floor((i + 1) * ratio)));
          let sum = 0;
          for (let j = a; j < b; j++) for (let c = 0; c < info.ch; c++) sum += pcm[j * info.ch + c];
          out[i] = sum / ((b - a) * info.ch * 32768);
        }
        const piece = { blob: encodeWav(out, TARGET_RATE), name: 'part' + (++idx) + '.wav', offset: pos / info.rate };
        pos += n;
        return piece;
      }
    };
  }

  /** -> source { total (0 = unknown), next() -> Promise<{blob,name,offset}|null>, progress() 0..1, close() } */
  async function openSource(file, onStatus, durationHint, cfg) {
    cfg = cfg || {};
    const directMax = cfg.directMax != null ? cfg.directMax : DIRECT_MAX, chunkSec = cfg.chunkSec || CHUNK_SEC;
    if (S.audioCache) { const cached = await S.audioCache.source(file, chunkSec, onStatus); if (cached) return cached; }   // the sound was taken when the clip was picked: the file is not read again
    let small = file.size <= directMax;
    if (small && S.localCopy) { try { await S.localCopy.probe(file); } catch (e) { if (e && e.name === 'NotReadableError') small = false; else throw e; } }   // unreadable: not sent as is, the sound is taken another way below
    if (small) return listSource([{ blob: file, name: file.name || 'clip.mp4', offset: 0 }]);
    onStatus('กำลังแยกเสียงจากวิดีโอ (ไฟล์ ' + (file.size / 1048576).toFixed(0) + ' MB)...');
    const wi = await wavInfo(file);                      // the merged sound of several clips (or any 16-bit PCM WAV): cut straight from the bytes
    if (wi) return wavSource(file, wi, chunkSec);

    // 1) streaming: constant memory, any file size
    let why = '';
    if (S.audio && S.audio.openChunks) {
      try {
        const src = await S.audio.openChunks(file, { chunkSec: chunkSec, durationHint: durationHint, onNotice: onStatus });
        if (src.realtime) onStatus('เบราว์เซอร์ไม่ยอมให้อ่านไฟล์ตรงๆ — กำลังฟังเสียงจากวิดีโอแบบเรียลไทม์ (ใช้เวลาเท่าความยาวคลิป อย่าปิดหน้านี้)');
        return src;
      }
      catch (e) {
        if (e && e.unreadable) throw e;
        if (!e || !e.unsupported) throw new Error('แยกเสียงจากไฟล์นี้ไม่ได้ (' + (e && e.message ? e.message : 'read failed') + ')');
        why = e.message;
      }
    }

    // 2) legacy whole-file decode: only for files small enough to fit in memory
    if (file.size > LEGACY_MAX) {
      throw new Error((why || 'อ่านเสียงจากไฟล์นี้ไม่ได้') + ' — ลองแปลงไฟล์เป็น MP4 (H.264/AAC) แล้วเปิดด้วย Chrome หรือ Edge เวอร์ชันล่าสุด หรือตัดคลิปให้สั้นลง');
    }
    let mono;
    try { mono = await decodeToMono16k(file); }
    catch (e) {
      if (e && e.name === 'NotReadableError') throw new Error('เบราว์เซอร์อ่านไฟล์ไม่ได้ — ให้คัดลอกไฟล์มาไว้ในเครื่อง แล้วกด “เปลี่ยนคลิป” เลือกไฟล์ใหม่อีกครั้ง');
      throw new Error('แยกเสียงจากไฟล์นี้ไม่ได้ (' + (e && e.message ? e.message : 'decode failed') + ') — ลองใช้ไฟล์ที่เล็กลงหรือแปลงเป็น MP4 (H.264/AAC)');
    }
    if (!mono.length) throw new Error('ไม่พบแทร็กเสียงในวิดีโอนี้');
    const per = chunkSec * TARGET_RATE, out = [];
    for (let s = 0, i = 0; s < mono.length; s += per, i++) {
      out.push({ blob: encodeWav(mono.subarray(s, Math.min(s + per, mono.length)), TARGET_RATE), name: 'part' + (i + 1) + '.wav', offset: s / TARGET_RATE });
    }
    return listSource(out);
  }

  // ---------------- transport ----------------
  function send(url, blob, name, apiKey, language, onFrac) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', url);
      xhr.setRequestHeader('Authorization', 'Bearer ' + apiKey);
      xhr.upload.onprogress = e => { if (e.lengthComputable) onFrac(e.loaded / e.total); };
      xhr.onload = () => {
        const ct = xhr.getResponseHeader('Content-Type') || '';
        if (xhr.status >= 200 && xhr.status < 300) {
          try { resolve(JSON.parse(xhr.responseText)); }
          catch (e) { const er = new Error('รูปแบบข้อมูลที่ได้รับไม่ถูกต้อง'); er.proxyMissing = url === PROXY_URL; reject(er); }
          return;
        }
        let msg = 'สถานะ ' + xhr.status;
        try { const j = JSON.parse(xhr.responseText); if (j.error && j.error.message) msg = j.error.message; } catch (e) {}
        if (xhr.status === 401) msg = 'Groq API Key ไม่ถูกต้องหรือถูกยกเลิก — สร้างคีย์ใหม่ที่ console.groq.com/keys แล้ววางในช่อง Groq API Key';
        else if (xhr.status === 413) msg = 'ไฟล์เสียงใหญ่เกินที่ Groq รับได้ (25 MB)';
        else if (xhr.status === 429) msg = 'ใช้ Groq เกินโควตา (rate limit) รอสักครู่แล้วลองใหม่ — ' + msg;
        const er = new Error(msg);
        er.status = xhr.status;
        er.keyRejected = xhr.status === 401;
        const ra = parseFloat(xhr.getResponseHeader('Retry-After'));
        if (isFinite(ra) && ra >= 0) er.retryAfter = ra;
        // a static host answers /api/transcribe with 404/405/501 + html: that means "no proxy here", not a real failure
        er.proxyMissing = url === PROXY_URL && (xhr.status === 404 || xhr.status === 405 || xhr.status === 501) && !/json/i.test(ct);
        reject(er);
      };
      xhr.onerror = () => { const er = new Error('เชื่อมต่อไม่ได้ (เครือข่ายหรือ CORS)'); er.network = true; reject(er); };
      xhr.ontimeout = () => { const er = new Error('หมดเวลารอการตอบกลับ'); er.network = true; reject(er); };
      xhr.timeout = 15 * 60 * 1000;
      const fd = new FormData();
      fd.append('file', blob, name);
      fd.append('model', 'whisper-large-v3');
      fd.append('response_format', 'verbose_json');
      fd.append('temperature', '0');                       // no random re-tries: the same sound gives the same words
      fd.append('timestamp_granularities[]', 'word');
      if (language !== 'auto') fd.append('language', language);
      xhr.send(fd);
    });
  }

  let proxyState = 'unknown';   // 'unknown' | 'ok' | 'missing'
  async function request(blob, name, apiKey, language, onFrac) {
    const canProxy = /^https?:$/.test(window.location.protocol) && proxyState !== 'missing';
    if (canProxy) {
      try {
        const r = await send(PROXY_URL, blob, name, apiKey, language, onFrac);
        proxyState = 'ok';
        return r;
      } catch (e) {
        if (e.proxyMissing) proxyState = 'missing';
        else if (!e.network || proxyState === 'ok') throw e;   // real API answer (bad key, quota...) -> show it
        // proxy missing or unreachable -> try the direct route below
      }
    }
    return send(GROQ_URL, blob, name, apiKey, language, onFrac);
  }

  // Several Groq keys may be given (comma separated). A key Groq rejects (401) is skipped from then on; a key that is out of quota (429)
  // hands over to the next one; the key that worked last goes first.
  const splitKeys = k => String(k || '').split(/[\s,;]+/).filter(Boolean);
  const deadKeys = new Set();
  let goodKey = '';
  async function requestAnyKey(blob, name, apiKeys, language, onFrac) {
    const all = splitKeys(apiKeys), live = all.filter(k => !deadKeys.has(k)), list = (live.length ? live : all).slice();
    const gi = list.indexOf(goodKey); if (gi > 0) list.unshift(list.splice(gi, 1)[0]);
    let last = null, limited = null, rejected = 0;
    for (const k of list) {
      try { const r = await request(blob, name, k, language, onFrac); goodKey = k; return r; }
      catch (e) {
        last = e;
        if (e.status === 401) { deadKeys.add(k); rejected++; continue; }
        if (e.status === 429) { limited = limited || e; continue; }
        throw e;
      }
    }
    if (limited) throw limited;
    if (last) last.keyRejected = rejected === list.length;
    throw last || new Error('กรุณาใส่ Groq API Key');
  }

  /** request() + automatic retry for rate limits (429), server errors (5xx) and network blips. */
  async function requestWithRetry(c, req, onFrac, onStatus, label) {
    for (let attempt = 0; ; attempt++) {
      try { return await requestAnyKey(c.blob, c.name, req.apiKey, req.language, onFrac); }
      catch (e) {
        const limited = e.status === 429, transient = limited || e.network || (e.status >= 500 && e.status < 600);
        if (!transient || attempt >= MAX_RETRY) throw e;
        if (limited && e.retryAfter > MAX_WAIT_SEC) {
          const mins = Math.ceil(e.retryAfter / 60);
          throw new Error('ใช้ Groq เกินโควตา ต้องรอประมาณ ' + (mins >= 60 ? Math.ceil(mins / 60) + ' ชั่วโมง' : mins + ' นาที') + ' แล้วค่อยลองใหม่ (ช่วงที่ถอดเสร็จแล้วจะต้องเริ่มใหม่)');
        }
        const wait = e.retryAfter != null ? Math.max(1, Math.ceil(e.retryAfter)) : Math.min(2 * Math.pow(2, attempt), 30);
        onStatus(label + ' — ' + (limited ? 'ติดโควตา Groq' : 'เชื่อมต่อมีปัญหา') + ' รอ ' + wait + ' วินาทีแล้วลองใหม่ (' + (attempt + 1) + '/' + MAX_RETRY + ')...');
        await sleep(wait * 1000);
        onStatus(label + '...');
      }
    }
  }

  transcribers.register('groq-whisper', {
    label: 'Groq Whisper large-v3',
    async transcribe(req) {
      const onProgress = req.onProgress || function () {};
      const onStatus = req.onStatus || function () {};
      const duration = req.durationHint || (S.state && S.state.project.media.duration) || 0;
      onProgress(0);
      const src = await openSource(req.file, onStatus, duration);
      try {
        const words = [];
        onStatus(src.total > 1 ? 'กำลังเตรียมเสียงช่วงที่ 1/' + src.total + '...' : 'กำลังอัปโหลดไฟล์...');
        // while the sound is recorded as the clip plays (from the start, or after the file turned unreadable part-way) say so, with a moving bar
        const listening = async (p, base) => {
          const tick = () => { if (!src.realtime) return; const f = src.progress(); onProgress(Math.min(99, Math.max(base, Math.round(f * 99)))); onStatus('กำลังฟังเสียงจากวิดีโอแบบเรียลไทม์ ' + Math.round(f * 100) + '% — อย่าปิดหน้านี้'); };
          const iv = setInterval(tick, 700);
          try { return await p; } finally { clearInterval(iv); }
        };
        // Pieces are sent up to CONC at a time (they used to go one after another) while the next piece is still being cut from the video.
        // Every finished piece is also kept in the browser (key = clip + language + piece), so after a crash / refresh / error the pieces that
        // were already transcribed are NOT paid for or waited for again.
        const CONC = Math.max(1, (S.ai && S.ai.concurrency) || 3);
        const fracs = [], parts = [], running = new Set();
        let idx = 0, failure = null, cur;
        const sigOf = f => (f && (f.name + '|' + f.size + '|' + f.lastModified)) || '';
        const lang = req.language || 'auto';
        const progressNow = () => { const t = src.total > 0 ? src.total : Math.max(idx, 1); let sum = 0; fracs.forEach(f => { sum += f || 0; }); onProgress(Math.min(99, Math.round(sum / t * 100))); };
        const launch = (piece, i) => {
          const total = Math.max(src.total, idx), tag = total > 1 ? ' ช่วงที่ ' + (i + 1) + '/' + total : '';
          const ck = 'tx|' + sigOf(req.file) + '|' + lang + '|' + Math.round(piece.offset) + '|' + piece.blob.size;
          const job = (async () => {
            let hit = null; try { hit = await S.persist.get(ck); } catch (e) {}
            if (hit && Array.isArray(hit.words)) { parts[i] = hit.words; fracs[i] = 1; progressNow(); return; }
            let announced = false;
            onStatus('กำลังอัปโหลด' + tag + '...');
            const data = await requestWithRetry(piece, req, f => {
              fracs[i] = f * 0.5; progressNow();
              if (f >= 1 && !announced) { announced = true; onStatus('กำลังถอดเสียง' + tag + '...'); }
            }, onStatus, 'กำลังถอดเสียง' + tag);
            let w = Array.isArray(data.words) ? data.words : [];
            if (!w.length && Array.isArray(data.segments)) w = wordsFromSegments(data.segments, 0);
            const chunkWords = w.map(x => ({ word: x.word, start: x.start + piece.offset, end: x.end + piece.offset }));
            S.thai.annotateSpacing(chunkWords, data.text);   // keep "Ultimatetrix" as one word, not "Ul ti mate trix"
            parts[i] = chunkWords; fracs[i] = 1; progressNow();
            try { await S.persist.put(ck, { words: chunkWords }); } catch (e) {}
          })();
          const tracked = job.then(() => { running.delete(tracked); }, e => { failure = failure || e; running.delete(tracked); });
          running.add(tracked);
        };
        if (src.realtime) onProgress(0);
        cur = await listening(src.next(), 0);
        if (!cur) throw new Error('ไม่พบแทร็กเสียงในวิดีโอนี้');
        while (cur && !failure) {
          if (cur.blob.size > HARD_MAX) throw new Error('ไฟล์เสียงใหญ่เกินที่ Groq รับได้ (25 MB)');
          launch(cur, idx++);
          if (running.size >= CONC) await Promise.race(Array.from(running));
          if (failure) break;
          cur = await listening(src.next(), 0);
        }
        await Promise.all(Array.from(running));
        if (failure) throw failure;
        parts.forEach(pw => { (pw || []).forEach(x => words.push(x)); });
        onProgress(100);
        // Whisper cuts Thai into sub-word fragments: glue them back into real words (see subtitle/thai-text.js)
        return { words: S.thai.rebuildWords(words) };
      } finally {
        if (src.close) src.close();
      }
    }
  });

  S.ai = {
    defaultTranscriber: 'groq-whisper',
    openSource: openSource,                       // shared by every provider that needs the audio track in pieces
    transcribe(req) { return transcribers.get(req.provider || S.ai.defaultTranscriber).transcribe(req); }
  };
})(window.SubEd);
