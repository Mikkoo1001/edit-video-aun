/* =====================================================================
 * AI layer — "จับเวลาให้ตรงเสียง": re-time the cues you already edited WITHOUT touching a single character.
 *
 *   1. The audio is transcribed again (Groq Whisper, word timestamps) — only the TIMES are used from that.
 *   2. Your cue words are aligned to the Whisper words (banded Needleman-Wunsch on fuzzy word similarity), so spelling
 *      differences / edits / removed or added words do not matter.
 *   3. Each of your words takes the time of the Whisper word it matches; words with no match are interpolated
 *      between their matched neighbours. Cue start/end follow their first/last word.
 *
 * cue.text, cue.words[].word, colours, glow, styles and the lane a block was dropped on are never modified; only start / end
 * numbers change (so a sentence gets longer or shorter to fit the voice, nothing else).
 * SubEd.ai.realign({ file, apiKey, language, provider?, geminiKey?, geminiModel?, onStatus, onProgress }) -> { changed, matched, total }
 * ===================================================================== */
(function (S) {
  'use strict';
  const norm = s => (s || '').toLowerCase().replace(/[\s.,!?;:"'“”‘’()\[\]{}\-–—…]/g, '');
  const bigrams = s => { const o = new Map(); for (let i = 0; i < s.length - 1; i++) { const g = s.substr(i, 2); o.set(g, (o.get(g) || 0) + 1); } return o; };
  function sim(a, b) {
    if (!a || !b) return -1;
    if (a === b) return 2;
    if (a.length < 2 || b.length < 2) return a[0] === b[0] ? 0.2 : -1;
    if (a.indexOf(b) !== -1 || b.indexOf(a) !== -1) return 1.2;
    const A = bigrams(a), B = bigrams(b); let inter = 0;
    A.forEach((n, g) => { if (B.has(g)) inter += Math.min(n, B.get(g)); });
    const dice = 2 * inter / (a.length - 1 + b.length - 1);
    return dice >= 0.5 ? 0.4 + dice : -1;
  }

  /** Global alignment of token lists A (yours) and B (whisper). Returns map i -> j (or -1). */
  function align(A, B) {
    const n = A.length, m = B.length, GAP = -0.6;
    const band = Math.max(60, Math.ceil(Math.abs(n - m) + 0.15 * Math.max(n, m)));
    const W = 2 * band + 1, NEG = -1e9;
    const sc = new Float32Array((n + 1) * W).fill(NEG), tb = new Uint8Array((n + 1) * W);
    const ctr = i => Math.round(i * m / Math.max(1, n));               // diagonal centre for row i
    const col = (i, j) => j - ctr(i) + band;
    const get = (i, j) => { const c = col(i, j); return (c < 0 || c >= W || j < 0 || j > m) ? NEG : sc[i * W + c]; };
    for (let i = 0; i <= n; i++) {
      for (let c = 0; c < W; c++) {
        const j = ctr(i) - band + c; if (j < 0 || j > m) continue;
        let best, dir;
        if (i === 0 && j === 0) { sc[c] = 0; continue; }
        best = NEG; dir = 0;
        if (i > 0 && j > 0) { const d = get(i - 1, j - 1); if (d > NEG / 2) { const s = d + sim(A[i - 1], B[j - 1]); if (s > best) { best = s; dir = 1; } } }
        if (i > 0) { const u = get(i - 1, j); if (u > NEG / 2 && u + GAP > best) { best = u + GAP; dir = 2; } }
        if (j > 0) { const l = get(i, j - 1); if (l > NEG / 2 && l + GAP > best) { best = l + GAP; dir = 3; } }
        sc[i * W + c] = best; tb[i * W + c] = dir;
      }
    }
    const map = new Array(n).fill(-1);
    let i = n, j = m;
    while (i > 0 || j > 0) {
      const c = col(i, j); if (c < 0 || c >= W) break;
      const d = tb[i * W + c];
      if (d === 1) { if (sim(A[i - 1], B[j - 1]) > 0) map[i - 1] = j - 1; i--; j--; }
      else if (d === 2) i--;
      else if (d === 3) j--;
      else break;
    }
    return map;
  }

  /** Apply whisper times to the cues. Text (and lane / style) is never written. Returns stats.
   *  The cues are read in the order they sit on the timeline (by start time), NOT in list order, so lines the user dragged
   *  around or stacked on other lanes are still matched against the speech in the right order. */
  function apply(cuesIn, wwords) {
    const cues = cuesIn.map((c, i) => ({ c: c, i: i })).sort((a, b) => (a.c.start - b.c.start) || (a.i - b.i)).map(x => x.c);
    const flat = [];
    cues.forEach((c, ci) => c.words.forEach((w, wi) => flat.push({ ci: ci, wi: wi, t: norm(w.word) })));
    const B = wwords.map(w => norm(w.word));
    const map = align(flat.map(x => x.t), B);
    const times = flat.map((x, k) => map[k] >= 0 ? { s: wwords[map[k]].start, e: wwords[map[k]].end, hit: true } : null);
    const matched = times.filter(Boolean).length;
    if (!matched) return { matched: 0, total: flat.length };
    // interpolate unmatched runs between neighbours (weighted by character count)
    for (let k = 0; k < flat.length; k++) {
      if (times[k]) continue;
      let a = k - 1, b = k; while (b < flat.length && !times[b]) b++;
      const t0 = a >= 0 ? times[a].e : (b < flat.length ? Math.max(0, times[b].s - 0.3 * (b - k)) : 0);
      const t1 = Math.min(b < flat.length ? times[b].s : Infinity, t0 + 0.4 * (b - k));   // an unheard word never stretches over a long silence
      const run = flat.slice(k, b), tot = run.reduce((n, x) => n + Math.max(1, x.t.length), 0);
      let acc = 0;
      run.forEach((x, r) => { const w = Math.max(1, x.t.length); times[k + r] = { s: t0 + (t1 - t0) * acc / tot, e: t0 + (t1 - t0) * (acc + w) / tot, hit: false }; acc += w; });
      k = b - 1;
    }
    const dur = S.state.project.media.duration || Infinity;
    let prevEnd = 0, changed = 0;
    const idxOf = new Map(); flat.forEach((x, k) => idxOf.set(x.ci + ':' + x.wi, k));
    cues.forEach((c, ci) => {
      if (!c.words.length) return;
      const ts = c.words.map((w, wi) => times[idxOf.get(ci + ':' + wi)]);
      let s = Math.max(prevEnd, ts[0].s), e = Math.max(ts[ts.length - 1].e, s + 0.1);
      const nextS = (() => { for (let q = ci + 1; q < cues.length; q++) if (cues[q].words.length) return times[idxOf.get(q + ':0')].s; return dur; })();
      e = Math.min(e, Math.max(s + 0.1, nextS), dur);
      let last = s;
      c.words.forEach((w, wi) => {                                    // monotonic words inside the cue
        const ws = Math.min(Math.max(ts[wi].s, last), e), we = Math.min(Math.max(ts[wi].e, ws), e);
        w.start = ws; w.end = we; last = we;
      });
      if (Math.abs(c.start - s) > 0.001 || Math.abs(c.end - e) > 0.001) changed++;
      c.start = s; c.end = e; prevEnd = e;
    });
    return { matched: matched, total: flat.length, changed: changed };
  }

  S.ai = S.ai || {};
  S.ai.realignCues = apply;                     // exposed for tests
  S.ai._align = align; S.ai._norm = norm;       // shared with subtitle/span-suggest.js (where a sentence should end)
  S.ai.realign = async function (req) {
    const cues = S.state.project.subtitle.cues;
    if (!cues.length) throw new Error('ยังไม่มีซับให้จับเวลา');
    const res = await S.ai.transcribe({ provider: req.provider || 'groq-whisper', file: req.file, language: req.language || 'th', apiKey: req.apiKey, geminiKey: req.geminiKey, geminiModel: req.geminiModel, maxChars: req.maxChars, onStatus: req.onStatus, onProgress: req.onProgress });
    if (!res.words.length) throw new Error('ไม่พบคำพูดในเสียง');
    const before = cues.map(c => c.text), lanes = cues.map(c => c.lane), ids = cues.map(c => c.id);
    if (S.history) S.history.record('realign');
    const stats = apply(cues, res.words);
    S.state.project.subtitle.speech = res.words.map(w => ({ word: w.word, start: w.start, end: w.end }));   // what was heard: the "where should this sentence end" guide reads it
    if (!cues.every((c, i) => c.text === before[i] && c.lane === lanes[i] && c.id === ids[i])) throw new Error('ข้อความถูกเปลี่ยน — ยกเลิก');   // can never happen; guard anyway
    if (S.subtitle.sortCues) S.subtitle.sortCues(cues);
    S.bus.emit('cues:structure', { reason: 'realign' });
    return stats;
  };
})(window.SubEd);
