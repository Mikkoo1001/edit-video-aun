/* =====================================================================
 * SubEd.ref — read a REFERENCE VIDEO and measure how it is edited (pixels + sound only, no AI, no network):
 *
 *   cuts   [{ t, tr, dur, score }]   where the shot changes, and how: 'cut' | 'dissolve' | 'flash' | 'dip'
 *   shots  [{ start, end, motion, amt }]   one per shot: 'none' | 'zoomIn' | 'zoomOut' | 'punch' (+ how much)
 *   sfx    [{ t, type }]             a sound effect heard at a cut: 'whoosh' (swell into the cut) | 'hit' (low thud) | 'pop' (bright tick)
 *
 * PURE (no DOM, run under Node for testing):  detectCuts, shotMotion, detectSfx, analyzeFrames, fft
 * DOM: sampleVideo (plays the reference quietly and takes small pictures), audioFeatures, analyzeVideoFile
 * Frames are tiny: 48x48 grey + a 3x16-bin colour histogram + mean brightness, ~12 per second.
 * ===================================================================== */
(function (S) {
  'use strict';
  const N = 48, clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const median = a => { if (!a.length) return 0; const s = a.slice().sort((x, y) => x - y), m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };

  /* ------------------------------------------------------------ frames */
  /** RGBA (N*N*4) -> { g: Uint8Array(N*N) grey, h: Float32Array(48) colour histogram (sums to 3), l: mean brightness 0..1 } */
  function describe(rgba) {
    const g = new Uint8Array(N * N), h = new Float32Array(48); let sum = 0;
    for (let i = 0, p = 0; i < N * N; i++, p += 4) {
      const r = rgba[p], gg = rgba[p + 1], b = rgba[p + 2], y = (0.299 * r + 0.587 * gg + 0.114 * b) | 0;
      g[i] = y; sum += y; h[r >> 4]++; h[16 + (gg >> 4)]++; h[32 + (b >> 4)]++;
    }
    for (let i = 0; i < 48; i++) h[i] /= N * N;
    return { g: g, h: h, l: sum / (N * N * 255) };
  }
  /** How different two frames look, 0 (same) .. 1 (nothing alike): the larger of the pixel change and the colour change. */
  function diff(a, b) {
    let s = 0; for (let i = 0; i < N * N; i++) s += Math.abs(a.g[i] - b.g[i]);
    const gd = s / (N * N * 255);
    return clamp(Math.max(gd * 2.5, hdiff(a, b)), 0, 1);
  }
  /** Colour change only (histogram distance, 0..1): a zoom or a pan keeps the colours, a different picture does not. */
  function hdiff(a, b) { let hs = 0; for (let i = 0; i < 48; i++) hs += Math.abs(a.h[i] - b.h[i]); return clamp(hs / 6, 0, 1); }

  /* ------------------------------------------------------------ cuts */
  /**
   * frames: [{ t, g, h, l }] in time order. opts.sens 0.5..2 (higher = finds more cuts). -> [{ t, tr, dur, score }]
   * Steps in `diff` between neighbouring pictures, grouped in RUNS of steps above the noise:
   *   one big step                                 = hard cut (timed halfway between the two pictures)
   *   3-12 steps, none of them dominating, colours really change from first to last  = dissolve (timed at the middle)
   *   two cuts <= 0.35 s apart with a very bright / dark picture between them       = flash / dip
   * A long run of steps (fast action) or a zoom (colours stay) is not a cut.
   */
  function detectCuts(frames, opts) {
    opts = opts || {};
    const sens = opts.sens || 1, n = frames.length, d = new Float32Array(n);
    for (let i = 1; i < n; i++) d[i] = diff(frames[i - 1], frames[i]);
    const HI = 0.34 / sens, RUN = 0.14 / Math.sqrt(sens);
    const localMed = i => { const nb = []; for (let j = Math.max(1, i - 8); j <= Math.min(n - 1, i + 8); j++) if (j !== i) nb.push(d[j]); return median(nb); };
    const raw = [];
    for (let i = 1; i < n;) {
      if (d[i] < RUN) { i++; continue; }
      let j = i; while (j + 1 < n && d[j + 1] >= RUN) j++;
      const len = j - i + 1; let m = i; for (let k = i; k <= j; k++) if (d[k] > d[m]) m = k;
      const total = diff(frames[i - 1], frames[j]);
      if (len >= 3 && len <= 12 && total >= 0.4 && hdiff(frames[i - 1], frames[j]) >= 0.25 && d[m] < 0.75 * total) {
        const t0 = frames[i - 1].t, t1 = frames[j].t;
        raw.push({ i: (i + j) >> 1, tr: 'dissolve', dur: +(t1 - t0).toFixed(3), score: total, t: (t0 + t1) / 2 });
      } else if (len === 2 && d[i] >= HI && d[j] >= HI) {                      // in and straight out again (one bright / dark picture between): flash / dip candidate
        raw.push({ i: i, tr: 'cut', dur: 0, score: d[i], t: (frames[i - 1].t + frames[i].t) / 2 });
        raw.push({ i: j, tr: 'cut', dur: 0, score: d[j], t: (frames[j - 1].t + frames[j].t) / 2 });
      } else if (d[m] >= HI && d[m] >= 2.5 * localMed(m) + 0.1) {
        raw.push({ i: m, tr: 'cut', dur: 0, score: d[m], t: (frames[m - 1].t + frames[m].t) / 2 });     // the cut is somewhere between the two pictures
      }
      i = j + 1;
    }
    // two cuts within 0.35 s with a bright / dark stretch between them = one flash / dip
    const out = [];
    for (let k = 0; k < raw.length; k++) {
      const c = raw[k], nx = raw[k + 1];
      if (c.tr === 'cut' && nx && nx.tr === 'cut' && nx.t - c.t <= 0.35) {
        let mx = 0, mn = 1; for (let j = c.i; j < nx.i; j++) { mx = Math.max(mx, frames[j].l); mn = Math.min(mn, frames[j].l); }
        const before = frames[Math.max(0, c.i - 2)].l, after = frames[Math.min(n - 1, nx.i + 1)].l;
        if (mx > 0.82 && mx - Math.max(before, after) > 0.2) { out.push({ t: c.t, tr: 'flash', dur: +(nx.t - c.t).toFixed(3), score: Math.max(c.score, nx.score) }); k++; continue; }
        if (mn < 0.12 && Math.min(before, after) - mn > 0.2) { out.push({ t: c.t, tr: 'dip', dur: +(nx.t - c.t).toFixed(3), score: Math.max(c.score, nx.score) }); k++; continue; }
        out.push({ t: nx.t, tr: 'cut', dur: 0, score: nx.score }); k++; continue;       // a stutter: keep the later one
      }
      out.push({ t: c.t, tr: c.tr, dur: c.dur, score: c.score });
    }
    return out.sort((a, b) => a.t - b.t);
  }

  /* ------------------------------------------------------------ zoom */
  /** How much bigger the content of `late` looks than in `early`: s>1 zoom in, s<1 zoom out. -> { s, gain } gain = how much better s fits than s=1 (0..1).
   *  Searches s in [lo, hi]; pictures a few samples apart (small s) are matched far more reliably than the two ends of a long shot. */
  /** Edge strength image of a frame (cached): zoom matching on edges is far less ambiguous than on raw brightness. */
  function edges(f) {
    if (f.e) return f.e;
    const e = new Float32Array(N * N), g = f.g;
    for (let y = 1; y < N - 1; y++) for (let x = 1; x < N - 1; x++) {
      const gx = g[y * N + x + 1] - g[y * N + x - 1], gy = g[(y + 1) * N + x] - g[(y - 1) * N + x];
      e[y * N + x] = Math.abs(gx) + Math.abs(gy);
    }
    f.e = e; return e;
  }
  function zoomBetween(early, late, lo, hi, step) {
    lo = lo || 0.8; hi = hi || 1.4; step = step || 0.02;
    const C = (N - 1) / 2, M = Math.round(N / 10), a = M, b = N - M, E = edges(early), L = edges(late);
    const cost = s => {
      let sum = 0, cnt = 0;
      for (let y = a; y < b; y++) for (let x = a; x < b; x++) {
        const sx = C + (x - C) / s, sy = C + (y - C) / s;
        if (sx < 0 || sy < 0 || sx > N - 1 || sy > N - 1) continue;
        const x0 = sx | 0, y0 = sy | 0, x1 = Math.min(N - 1, x0 + 1), y1 = Math.min(N - 1, y0 + 1), fx = sx - x0, fy = sy - y0;
        const v = E[y0 * N + x0] * (1 - fx) * (1 - fy) + E[y0 * N + x1] * fx * (1 - fy) + E[y1 * N + x0] * (1 - fx) * fy + E[y1 * N + x1] * fx * fy;
        sum += Math.abs(v - L[y * N + x]); cnt++;
      }
      return cnt ? sum / cnt : 1e9;
    };
    const base = cost(1); let best = 1, bc = base;
    for (let s = lo; s <= hi + 1e-9; s += step) { const c = cost(s); if (c < bc - 1e-9) { bc = c; best = s; } }
    return { s: best, gain: base > 1 ? clamp((base - bc) / base, 0, 1) : 0 };
  }
  /** Per-step zoom along frames a..b (every `stride` samples): [{ ln, ok }] ln = log of the step's scale. */
  function scaleSteps(frames, a, b, stride, range) {
    const out = [];
    for (let k = a; k + stride <= b; k += stride) {
      const z = zoomBetween(frames[k], frames[k + stride], 1 - range, 1 + range, range / 8);
      out.push({ ln: Math.log(z.s), ok: z.gain > 0.05 && z.s !== 1 });
    }
    return out;
  }
  /** Motion of one shot (frames a..b, inclusive): { motion, amt }. Consistent small steps the same way = a slow zoom; a quick zoom-out
   *  settling in the first third of a second, then calm = a punch. */
  function shotMotion(frames, a, b, first) {
    if (b - a < 4) return { motion: 'none', amt: 0 };
    const s0 = first ? a : a + 1, t0 = frames[s0].t;          // after a cut, frames[a] is still the OLD shot; the very first shot starts at frame 0
    // punch: the first ~0.35 s, one sample at a time
    let k = s0; while (k < b && frames[k].t - t0 < 0.35) k++;
    if (k - s0 >= 2 && b - k >= 3) {
      const early = scaleSteps(frames, s0, k, 1, 0.12), sum = early.reduce((m, e) => m + (e.ok ? e.ln : 0), 0), nOk = early.filter(e => e.ok).length;
      if (nOk >= 2 && sum < -0.045) {
        const rest = scaleSteps(frames, k, b - 1, 3, 0.1), rs = rest.reduce((m, e) => m + (e.ok ? e.ln : 0), 0);
        if (!rest.length || Math.abs(rs) < 0.06) return { motion: 'punch', amt: +clamp(Math.exp(-sum) - 1, 0.05, 0.4).toFixed(3) };
      }
    }
    // slow zoom over the whole shot: steps of 3 samples (~0.25 s), the median step times the number of steps
    const st = scaleSteps(frames, s0, b - 1, 3, 0.1), ok = st.filter(e => e.ok);
    if (st.length >= 2 && ok.length >= Math.ceil(st.length * 0.5)) {
      const lns = ok.map(e => e.ln).sort((x, y) => x - y), med = lns[lns.length >> 1], agree = ok.filter(e => Math.sign(e.ln) === Math.sign(med)).length / ok.length;
      const total = med * st.length * 0.55;                      // edge matching over-reads the step by about 2x (measured on shots with a known zoom)
      if (agree >= 0.7 && Math.abs(total) >= 0.04) return total > 0 ? { motion: 'zoomIn', amt: +clamp(Math.exp(total) - 1, 0.05, 0.35).toFixed(3) } : { motion: 'zoomOut', amt: +clamp(Math.exp(-total) - 1, 0.05, 0.35).toFixed(3) };
    }
    return { motion: 'none', amt: 0 };
  }

  /** frames + duration -> { cuts, shots } */
  function analyzeFrames(frames, duration, opts) {
    const cuts = detectCuts(frames, opts).filter(c => c.t >= 0.35 && c.t <= duration - 0.35), shots = [];     // a 'cut' in the first / last few frames is a glitch, not a shot
    const idxAt = t => { let lo = 0, hi = frames.length - 1; while (lo < hi) { const m = (lo + hi + 1) >> 1; if (frames[m].t <= t) lo = m; else hi = m - 1; } return lo; };
    const edges = [0].concat(cuts.map(c => c.t), [duration]);
    for (let i = 0; i + 1 < edges.length; i++) {
      const a = idxAt(edges[i]), b = Math.max(a, idxAt(Math.max(edges[i], edges[i + 1] - 0.001)));
      shots.push(Object.assign({ start: +edges[i].toFixed(3), end: +edges[i + 1].toFixed(3) }, shotMotion(frames, a, b, i === 0)));
    }
    return { cuts: cuts, shots: shots };
  }

  /* ------------------------------------------------------------ sound */
  /** Radix-2 FFT magnitude spectrum of a real signal (length power of 2). -> Float32Array(n/2) */
  function fft(x) {
    const n = x.length, re = new Float64Array(n), im = new Float64Array(n);
    for (let i = 0, j = 0; i < n; i++) { re[j] = x[i]; let m = n >> 1; while (m >= 1 && (j & m)) { j ^= m; m >>= 1; } j |= m; }
    for (let size = 2; size <= n; size <<= 1) {
      const half = size >> 1, ang = -2 * Math.PI / size;
      for (let s = 0; s < n; s += size) for (let k = 0; k < half; k++) {
        const wr = Math.cos(ang * k), wi = Math.sin(ang * k), a = s + k, b = a + half;
        const tr = re[b] * wr - im[b] * wi, ti = re[b] * wi + im[b] * wr;
        re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti;
      }
    }
    const out = new Float32Array(n >> 1); for (let i = 0; i < out.length; i++) out[i] = Math.hypot(re[i], im[i]); return out;
  }
  /** mono 16 kHz Int16/Float32 samples -> per-16 ms { lo, hi } energy in dB (below 400 Hz, above 2.5 kHz) */
  function bandEnergy(pcm, scale) {
    const W = 512, H = 256, win = new Float32Array(W), lo = [], hi = [], buf = new Float32Array(W);
    for (let i = 0; i < W; i++) win[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / (W - 1));
    for (let p = 0; p + W <= pcm.length; p += H) {
      for (let i = 0; i < W; i++) buf[i] = pcm[p + i] * scale * win[i];
      const m = fft(buf); let l = 0, h = 0;
      for (let k = 1; k <= 12; k++) l += m[k] * m[k];
      for (let k = 80; k < 256; k++) h += m[k] * m[k];
      lo.push(10 * Math.log10(l / 12 + 1e-9)); hi.push(10 * Math.log10(h / 176 + 1e-9));
    }
    return { hop: H / 16000, lo: lo, hi: hi };
  }
  /** cuts + band energies -> [{ t, type }]. Heuristic: a burst of sound that stands out from the second before the cut.
   *    hit    = a low-frequency thump that starts at the cut
   *    whoosh = a longer (>= 0.16 s) bright burst that swells into the cut and peaks at / just before it
   *    pop    = a short (< 0.16 s) bright tick at the cut  */
  function detectSfx(cuts, f) {
    const out = [], hop = f.hop, last = f.lo.length - 1, at = t => clamp(Math.round(t / hop), 0, last);
    const mean = (a, t0, t1) => { const i0 = at(t0), i1 = Math.max(i0, at(t1)); let s = 0; for (let i = i0; i <= i1; i++) s += a[i]; return s / (i1 - i0 + 1); };
    const peakIdx = (a, t0, t1) => { const i0 = at(t0), i1 = Math.max(i0, at(t1)); let m = i0; for (let i = i0; i <= i1; i++) if (a[i] > a[m]) m = i; return m; };
    /** the burst (run above `thr`) with the highest peak inside [t0, t1]: { len, peakT } or null */
    const burst = (a, t0, t1, thr) => {
      const i0 = at(t0), i1 = Math.max(i0, at(t1)); let best = null;
      for (let i = i0; i <= i1;) {
        if (a[i] < thr) { i++; continue; }
        let j = i, pk = i; while (j + 1 <= last && a[j + 1] >= thr) { j++; if (a[j] > a[pk]) pk = j; }
        if (a[i] > a[pk]) pk = i;
        if (!best || a[pk] > best.v) best = { v: a[pk], len: (j - i + 1) * hop, peakT: pk * hop };
        i = j + 1;
      }
      return best;
    };
    cuts.forEach(c => {
      const t = c.t; if (t < 0.6) return;
      const baseLo = mean(f.lo, t - 1.1, t - 0.45), baseHi = mean(f.hi, t - 1.1, t - 0.45);
      const lo = burst(f.lo, t - 0.05, t + 0.12, baseLo + 9), loPk = f.lo[peakIdx(f.lo, t - 0.05, t + 0.12)];
      const hi = burst(f.hi, t - 0.5, t + 0.15, baseHi + 8);
      if (lo && loPk - baseLo >= 9 && (!hi || lo.v - baseLo >= hi.v - baseHi - 3)) out.push({ t: +t.toFixed(3), type: 'hit' });
      else if (hi && hi.len >= 0.16 && hi.v - baseHi >= 10 && hi.peakT <= t + 0.08 && hi.peakT >= t - 0.35) out.push({ t: +t.toFixed(3), type: 'whoosh' });
      else if (hi && hi.len < 0.16 && hi.v - baseHi >= 12 && hi.peakT >= t - 0.1 && hi.peakT <= t + 0.14) out.push({ t: +t.toFixed(3), type: 'pop' });
    });
    return out;
  }

  /* ------------------------------------------------------------ DOM: read the file */
  function openVideo(file) {
    return new Promise((resolve, reject) => {
      const v = document.createElement('video'), url = URL.createObjectURL(file);
      let timer = 0;
      const dispose = () => { clearTimeout(timer); v.onerror = v.onloadedmetadata = null; try { v.pause(); v.removeAttribute('src'); v.load(); v.remove(); } catch (e) {} URL.revokeObjectURL(url); };
      const fail = m => { dispose(); reject(new Error(m)); };
      v.muted = true; v.playsInline = true; v.preload = 'auto';
      v.style.cssText = 'position:fixed;right:0;bottom:0;width:4px;height:4px;opacity:0.02;pointer-events:none;';
      document.body.appendChild(v);
      v.onerror = () => fail('เปิดวิดีโอต้นแบบไม่ได้ — ส่วนใหญ่เกิดจากโคเดก H.265/HEVC ที่เบราว์เซอร์ไม่รองรับ ลองแปลงเป็น MP4 (H.264/AAC) แล้วเลือกใหม่');
      v.onloadedmetadata = async () => {
        clearTimeout(timer); if (!v.videoWidth || !v.videoHeight) return fail('ไฟล์นี้ไม่มีภาพที่เบราว์เซอร์ถอดรหัสได้ (เช่น HEVC บางเครื่อง)');
        v.onloadedmetadata = null;
        if (!isFinite(v.duration) || !(v.duration > 0)) {          // no length in the header (screen recording / MediaRecorder WebM): seek far past the end, the browser then learns the real length
          await new Promise(res => { const tm = setTimeout(res, 8000), ok = () => { if (isFinite(v.duration) && v.duration > 0) { clearTimeout(tm); res(); } }; v.addEventListener('durationchange', ok); v.addEventListener('timeupdate', ok); try { v.currentTime = 1e6; } catch (e) { res(); } });
          try { v.currentTime = 0; } catch (e) {}
        }
        if (!isFinite(v.duration) || !(v.duration > 0)) return fail('อ่านความยาวของวิดีโอต้นแบบไม่ได้ — ลองแปลงเป็น MP4 แล้วเลือกใหม่');
        resolve({ v: v, dispose: dispose });
      };
      timer = setTimeout(() => fail('เปิดวิดีโอต้นแบบนานเกินไป'), 20000);
      v.src = url;
    });
  }
  const seekTo = (v, t) => new Promise(res => {
    let done = false; const fin = () => { if (done) return; done = true; clearTimeout(tm); v.removeEventListener('seeked', fin); res(); };
    const tm = setTimeout(fin, 2000); v.addEventListener('seeked', fin);
    const target = Math.min(isFinite(t) ? t : 0, Math.max(0, (isFinite(v.duration) ? v.duration : t) - 0.01));
    if (!isFinite(target)) return fin();
    if (Math.abs(v.currentTime - target) < 1e-4 && v.readyState >= 2) return fin();
    v.currentTime = target;
  });
  /** Quiet playback (2x) with requestVideoFrameCallback -> a tiny picture about every 1/fps s. Falls back to seeking (slower). */
  async function sampleVideo(file, o) {
    o = Object.assign({ fps: 12, maxSeconds: 120, rate: 2, onProgress: null }, o || {});
    const opened = await openVideo(file), v = opened.v;
    try {
      const dur = v.duration, end = Math.min(dur, o.maxSeconds), dt = 1 / o.fps, frames = [];
      const cv = document.createElement('canvas'); cv.width = cv.height = N;
      const cx = cv.getContext('2d', { willReadFrequently: true });
      const grab = t => { cx.drawImage(v, 0, 0, N, N); const f = describe(cx.getImageData(0, 0, N, N).data); f.t = +t.toFixed(3); frames.push(f); if (o.onProgress) o.onProgress(Math.min(1, t / end)); };
      let next = 0, seekFrom = -1;
      if ('requestVideoFrameCallback' in HTMLVideoElement.prototype) {
        v.playbackRate = o.rate;
        await new Promise(resolve => {
          let done = false, last = performance.now(), wd = 0;
          const stop = r => { if (done) return; done = true; clearInterval(wd); try { v.pause(); } catch (e) {} resolve(r); };
          const on = (now, md) => {
            if (done) return; last = performance.now();
            if (md.mediaTime >= next - 1e-6 && next < end) { grab(md.mediaTime); next = md.mediaTime + dt - 1e-4; }
            if (md.mediaTime >= end - dt || v.ended) return stop();
            v.requestVideoFrameCallback(on);
          };
          wd = setInterval(() => { if (performance.now() - last > 4000) stop('stalled'); }, 500);
          v.addEventListener('ended', () => stop(), { once: true });
          v.play().then(() => v.requestVideoFrameCallback(on)).catch(() => stop('stalled'));
        }).then(r => { if (r === 'stalled') seekFrom = frames.length ? frames[frames.length - 1].t + dt : 0; });
      } else seekFrom = 0;
      if (seekFrom >= 0) for (let t = seekFrom; t < end; t += dt) { await seekTo(v, t); grab(t); }
      return { frames: frames, duration: dur, w: v.videoWidth, h: v.videoHeight };
    } finally { opened.dispose(); }
  }
  /** Sound of the reference as band energies, from the streamed 16 kHz mono extractor (MP4/WebM) or a whole-file decode. null = no usable sound. */
  async function audioFeatures(file, onProgress) {
    const lo = [], hi = []; let hop = 0.016;
    try {
      const ch = await S.audio.openChunks(file, { chunkSec: 60 });
      try {
        for (let piece; (piece = await ch.next());) {
          const pcm = new Int16Array(await piece.blob.arrayBuffer(), 44), e = bandEnergy(pcm, 1 / 32768);
          for (let i = 0; i < e.lo.length; i++) { lo.push(e.lo[i]); hi.push(e.hi[i]); } hop = e.hop;
          if (onProgress) onProgress(Math.min(1, lo.length * hop / Math.max(1, ch.duration || 60)));
        }
      } finally { ch.close(); }
      if (lo.length) return { hop: hop, lo: lo, hi: hi };
    } catch (e) { /* fall through */ }
    try {
      const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return null;
      const ac = new AC({ sampleRate: 16000 });
      try {
        const buf = await ac.decodeAudioData(await file.arrayBuffer()), e = bandEnergy(buf.getChannelData(0), 1);
        return { hop: e.hop, lo: e.lo, hi: e.hi };
      } finally { try { ac.close(); } catch (e2) {} }
    } catch (e) { return null; }
  }

  /** The whole job: file -> { name, duration, w, h, cuts, shots, sfx, hasAudio }. o.onProgress(fraction 0..1, message) */
  async function analyzeVideoFile(file, o) {
    o = o || {}; const say = (p, m) => { if (o.onProgress) o.onProgress(p, m); };
    say(0, 'กำลังดูภาพของต้นแบบ');
    const s = await sampleVideo(file, { fps: o.fps || 12, maxSeconds: o.maxSeconds || 120, onProgress: p => say(0.65 * p, 'กำลังดูภาพของต้นแบบ') });
    if (s.frames.length < 6) throw new Error('วิดีโอต้นแบบสั้นเกินไปที่จะวิเคราะห์');
    say(0.66, 'กำลังหาจุดตัดและเอฟเฟกต์ภาพ');
    const res = analyzeFrames(s.frames, Math.min(s.duration, o.maxSeconds || 120), { sens: o.sens });
    say(0.7, 'กำลังฟังเสียงเอฟเฟกต์');
    const feats = await audioFeatures(file, p => say(0.7 + 0.3 * p, 'กำลังฟังเสียงเอฟเฟกต์'));
    const sfx = feats ? detectSfx(res.cuts, feats) : [];
    say(1, 'เสร็จ');
    return { v: 1, name: file.name, duration: +s.duration.toFixed(3), w: s.w, h: s.h, cuts: res.cuts, shots: res.shots, sfx: sfx, hasAudio: !!feats };
  }

  S.ref = { scaleSteps: scaleSteps, describe: describe, diff: diff, hdiff: hdiff, detectCuts: detectCuts, zoomBetween: zoomBetween, shotMotion: shotMotion, analyzeFrames: analyzeFrames,
    fft: fft, bandEnergy: bandEnergy, detectSfx: detectSfx, sampleVideo: sampleVideo, audioFeatures: audioFeatures, analyzeVideoFile: analyzeVideoFile };
})(window.SubEd || (window.SubEd = {}));
