/* =====================================================================
 * SubEd.audioCache — the sound of a clip, taken while the picked file can still be read. No DOM.
 *
 * Why: on a phone a picked File is only a REFERENCE to a gallery / cloud file. When the browser could not keep a private copy of the whole
 * clip (too big, storage full, private window ...) that reference can stop working minutes later, and then "สร้างซับ" finds nothing to read.
 * The SOUND is far smaller than the video (16 kHz mono = ~2 MB per minute), so it is cut out right after the pick, kept in memory, and
 * ai/transcription.js uses it instead of reading the video again.
 *
 *   SubEd.audioCache.prepare(file, { durationHint, onProgress(0..1) }) -> Promise (never rejects)   start / join the extraction
 *   SubEd.audioCache.status(file) -> 'none' | 'running' | 'ready' | 'failed'     SubEd.audioCache.why(file) -> text of the failure
 *   SubEd.audioCache.source(file, chunkSec, onStatus) -> Promise<source|null>    same shape as SubEd.audio.openChunks(); null = nothing cached
 *   SubEd.audioCache.clear()
 * ===================================================================== */
(function (S) {
  'use strict';
  const PIECE = 60, RATE = 16000;
  const jobs = new Map();                                   // key (name|size|lastModified) -> { state, pieces, why, promise, pct }
  const keyOf = f => (f && (f.name + '|' + f.size + '|' + f.lastModified)) || '';

  function wavHeader(samples) {
    const h = new ArrayBuffer(44), v = new DataView(h);
    const str = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
    str(0, 'RIFF'); v.setUint32(4, 36 + samples * 2, true); str(8, 'WAVE'); str(12, 'fmt ');
    v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, RATE, true); v.setUint32(28, RATE * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
    str(36, 'data'); v.setUint32(40, samples * 2, true);
    return h;
  }

  function prepare(file, opts) {
    opts = opts || {};
    const k = keyOf(file);
    if (!k || !S.audio || !S.audio.openChunks) return Promise.resolve();
    const have = jobs.get(k);
    if (have) return have.promise;
    jobs.forEach((j, key) => { if (key !== k) jobs.delete(key); });          // one clip at a time
    const job = { state: 'running', pieces: [], why: '', pct: 0, promise: null };
    job.promise = (async () => {
      let src = null;
      try {
        src = await S.audio.openChunks(file, { chunkSec: PIECE, durationHint: opts.durationHint, noListen: true });
        for (let p; (p = await src.next());) {
          job.pieces.push(p); job.pct = src.progress();
          if (opts.onProgress) { try { opts.onProgress(job.pct); } catch (e) {} }
          if (jobs.get(k) !== job) return;                                    // the clip was closed meanwhile
        }
        job.state = job.pieces.length ? 'ready' : 'failed';
        if (!job.pieces.length) job.why = 'ไม่พบแทร็กเสียง';
      } catch (e) {
        job.state = 'failed'; job.pieces = []; job.why = (e && e.message) || 'error'; job.unreadable = !!(e && e.unreadable); job.unsupported = !!(e && e.unsupported);
      } finally { try { src && src.close(); } catch (e) {} }
    })();
    jobs.set(k, job);
    return job.promise;
  }

  const job = f => jobs.get(keyOf(f));
  const status = f => { const j = job(f); return j ? j.state : 'none'; };
  const why = f => { const j = job(f); return j ? j.why : ''; };
  const failedUnreadable = f => { const j = job(f); return !!(j && j.state === 'failed' && j.unreadable); };

  async function source(file, chunkSec, onStatus) {
    let j = job(file);
    if (!j) return null;
    if (j.state === 'running') { if (onStatus) onStatus('รอเก็บเสียงของคลิปให้เสร็จก่อนสักครู่...'); await j.promise; j = job(file); }
    if (!j || j.state !== 'ready') return null;
    const per = Math.max(1, Math.round((chunkSec || 600) / PIECE)), groups = [];
    for (let i = 0; i < j.pieces.length; i += per) groups.push(j.pieces.slice(i, i + per));
    let gi = 0;
    return {
      cached: true, total: groups.length, progress: () => gi / groups.length, close() {},
      next() {
        if (gi >= groups.length) return Promise.resolve(null);
        const g = groups[gi++];
        const pcm = g.map(p => p.blob.slice(44)), samples = g.reduce((n, p) => n + (p.blob.size - 44) / 2, 0);
        return Promise.resolve({ blob: new Blob([wavHeader(samples)].concat(pcm), { type: 'audio/wav' }), name: 'part' + gi + '.wav', offset: g[0].offset });
      }
    };
  }

  S.audioCache = { prepare: prepare, status: status, why: why, failedUnreadable: failedUnreadable, source: source, clear() { jobs.clear(); } };
})(window.SubEd = window.SubEd || {});
