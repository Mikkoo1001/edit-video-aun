/* =====================================================================
 * SubEd.styleCopy — copy a reference video's caption style onto this project.
 *
 * A STYLE PROFILE is plain JSON in RELATIVE units (fractions of the picture), so one profile fits any
 * clip size:  font / weight / size, outline, shadow, vertical position, entrance animation, and the
 * word-highlight rules (palette, how many lines get a coloured word, colour stays for the whole line).
 *
 *   styleCopy.REFERENCE_1                 profile measured from the first reference clip
 *   styleCopy.apply(profile, parts)       put a profile onto the project (one undo step)
 *   styleCopy.capture()                   read the CURRENT project look back as a profile
 *   styleCopy.autoHighlight(profile)      colour one key word in most lines, following the profile
 *   styleCopy.clearWordColors()           remove every per-word colour (undoable)
 *   styleCopy.exportProfile() / importProfile(file)   save / load a profile as a .json file
 *   styleCopy.analyzeFrames(frames)       PURE (no DOM): RGBA frames -> measured partial profile (incl. the sentence rhythm)
 *   styleCopy.measureLines(frames, stats) PURE: the reference's lines in order -> { lines:[{w,c,s}], ... } (sentence SIZE)
 *   styleCopy.detectAnimation(seq)        PURE: first frames of one caption -> 'none' | 'pop' | 'fade' | 'slide'
 *   styleCopy.analyzeVideoFile(file, o)   DOM: samples a video, returns a profile (merged over the baseline)
 *
 * Layer rule: no DOM at load time (so the pure parts run under Node for testing); DOM is touched only
 * inside analyzeVideoFile / export / import and ui/styleCopy.init().
 * ===================================================================== */
(function (S) {
  'use strict';
  const SCHEMA = 'subed.styleprofile.v1';
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
  const median = a => { if (!a.length) return NaN; const s = a.slice().sort((x, y) => x - y), m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };

  /* ---------- the first reference clip (VID_20261001195613748.mp4, 1080x1920 @60fps) ----------
   * Measured from the clip: caption block centre at 62% of the height, ~9% of the picture width as
   * font size, white fill, thin black outline + small hard drop shadow down-right, hard cut in/out
   * (no pop/fade), 1-3 short words per line, one word per line recoloured for the WHOLE line in a
   * saturated colour (green most often) on roughly 60-70% of the lines. */
  const REFERENCE_1 = {
    schema: SCHEMA, name: 'ต้นแบบ 1 (Ben 10 · 1080x1920)',
    source: { w: 1080, h: 1920, note: 'VID_20261001195613748.mp4' },
    text: { font: "'Prompt',sans-serif", weight: 800, sizeFrac: 0.092, color: '#ffffff', italic: false, thick: 0, sharp: 60 },
    outline: { on: true, color: '#000000', widthFrac: 0.0028 },
    shadow: { on: true, color: '#000000', distFrac: 0.0037, blurFrac: 0.0019, opacity: 100, angle: -45 },
    glow: { on: false },
    bg: { on: false },
    // rhythm = the SENTENCE SIZE, all the way through: short lines of 1-3 words (mostly 2), ~3-12 characters (see subtitle/segmentation.js 'rhythm')
    layout: { pos: 'custom', posY: 0.62, wordsPerLine: 3, maxChars: 12, rhythm: S.subtitle.buildRhythm([
      { w: 2, c: 7, s: 0.8 }, { w: 3, c: 10, s: 1.0 }, { w: 2, c: 8, s: 0.8 }, { w: 1, c: 5, s: 0.6 },
      { w: 3, c: 11, s: 1.0 }, { w: 2, c: 7, s: 0.8 }, { w: 2, c: 9, s: 0.9 }, { w: 3, c: 9, s: 0.9 }
    ], { typical: { w: 2, c: 8, s: 0.8 }, min: { w: 1, c: 3 }, max: { w: 3, c: 12 } }) },
    animation: { fx: 'none' },
    highlight: {
      mode: 'off',                       // 'off' = coloured word shows its colour the whole time the line is shown; 'stay' / 'stayAll' = colour starts when the word is read and stays
      coverage: 0.65, maxPerCue: 1,
      palette: ['#2be72e', '#b0f40e', '#c020e0', '#f34741', '#e5ee1c', '#2dfafc'],
      weights: [4, 2, 1, 1, 1, 1]
    }
  };

  /* ---------- helpers ---------- */
  function pictureWidth() {
    const r = S.ui && S.ui.preview && S.ui.preview.contentRect ? S.ui.preview.contentRect() : null;
    return r && r.w > 0 ? r.w : 360;
  }
  const P = () => S.state.project;
  const deep = o => JSON.parse(JSON.stringify(o));
  const hexOk = c => typeof c === 'string' && /^#[0-9a-f]{6}$/i.test(c);

  function normalizeProfile(p) {
    if (!p || p.schema !== SCHEMA) throw new Error('ไม่ใช่ไฟล์สไตล์ของโปรแกรมนี้ (schema ไม่ตรง)');
    const base = deep(REFERENCE_1), out = deep(p);
    // the sentence size: a saved file without one (older file) gets a plain rhythm from its own wordsPerLine / maxChars
    const own = p.layout || {}, rhythm = S.subtitle.normalizeRhythm(own.rhythm) || S.subtitle.rhythmFromSettings(own.wordsPerLine || base.layout.wordsPerLine, own.maxChars || base.layout.maxChars);
    ['text', 'outline', 'shadow', 'glow', 'bg', 'layout', 'animation', 'highlight'].forEach(k => { out[k] = Object.assign({}, base[k], out[k] || {}); });
    out.layout.rhythm = rhythm;
    out.highlight.palette = (out.highlight.palette || []).filter(hexOk);
    if (!out.highlight.palette.length) out.highlight.palette = base.highlight.palette;
    if (!Array.isArray(out.highlight.weights) || out.highlight.weights.length !== out.highlight.palette.length) out.highlight.weights = out.highlight.palette.map(() => 1);
    return out;
  }

  /* ---------- apply ---------- */
  const ALL_PARTS = { font: true, size: true, outline: true, shadow: true, position: true, animation: true, highlight: true, segmentation: true, opening: true, resetLines: true };

  /**
   * Put a profile onto the project. `parts` switches pieces on/off (see ALL_PARTS). One undo step
   * (cues + global style). Per-line overrides are cleared when resetLines is true so every line really
   * takes the copied look. Returns the style patch that was applied.
   */
  function apply(profile, parts) {
    const pr = normalizeProfile(profile), want = Object.assign({}, ALL_PARTS, parts || {});
    const pw = pictureWidth(), t = pr.text, patch = {};
    if (S.history) S.history.record('style-copy', { style: true });
    if (want.font) {
      patch.font = t.font; patch.weight = t.weight; patch.bold = t.weight >= 600; patch.italic = !!t.italic;
      patch.color = t.color; patch.thick = t.thick || 0; patch.sharp = t.sharp || 0;
      patch.bg = Object.assign({}, pr.bg);
    }
    if (want.size) patch.size = Math.round(t.sizeFrac * pw);
    if (want.outline) patch.outline = { on: !!pr.outline.on, color: pr.outline.color, width: Math.max(0.5, Math.round(pr.outline.widthFrac * pw * 2) / 2) };
    if (want.shadow) {
      patch.shadow = { on: !!pr.shadow.on, color: pr.shadow.color, dist: Math.max(1, Math.round(pr.shadow.distFrac * pw)), blur: Math.max(0, Math.round(pr.shadow.blurFrac * pw)), opacity: pr.shadow.opacity == null ? 100 : pr.shadow.opacity, angle: pr.shadow.angle == null ? -45 : pr.shadow.angle };
      patch.glow = Object.assign({}, pr.glow);
      if (patch.glow.rangeFrac != null) { patch.glow.range = clamp(Math.round(patch.glow.rangeFrac * pw), 1, 40); delete patch.glow.rangeFrac; }
    }
    if (want.position) { patch.pos = pr.layout.pos; patch.posY = clamp(pr.layout.posY, 0.05, 0.97); }
    if (want.animation) patch.fx = pr.animation.fx;
    if (want.highlight) { const mode = S.styleCopy.modeOverride || pr.highlight.mode; patch.karaokeMode = mode; patch.karaoke = mode !== 'off'; patch.highlight = pr.highlight.palette[0]; }
    if (want.segmentation) {                              // copy the SENTENCE SIZE: lines are cut to the reference's rhythm, following the speech
      const rhythm = deep(pr.layout.rhythm);
      rhythm.opening = S.subtitle.normalizeOpening(Object.assign({}, rhythm.opening, { on: want.opening !== false }));   // ประโยคเปิด 2-3-3 / 2-3-2 / 3-3 พยางค์
      Object.assign(P().subtitle.segmentation, { strategy: 'rhythm', wordsPerLine: pr.layout.wordsPerLine, maxChars: pr.layout.maxChars, rhythm: rhythm });
    }
    if (want.resetLines) P().subtitle.cues.forEach(c => { c.style = null; });

    if (want.position && S.subtitle.clearCuePositions) S.subtitle.clearCuePositions(false);   // history was recorded above
    S.style.apply(patch);
    if (S.style.ensureFont) S.style.ensureFont().then(() => S.bus.emit('style:changed'));
    if (want.segmentation) S.bus.emit('segmentation:changed');
    if (want.segmentation && P().subtitle.cues.length && S.subtitle.regroup) S.subtitle.regroup({ from: 'cues', history: false });   // history was recorded above: one undo step
    else S.bus.emit('cues:structure', { reason: 'style-copy' });
    S.styleCopy.lastProfile = pr;
    return patch;
  }

  /* ---------- capture: current look -> profile ---------- */
  /** The sentence size of the project as it is now: its real lines when there are enough, else its segmentation settings. */
  function captureRhythm() {
    const sub = P().subtitle, seg = sub.segmentation, cues = sub.cues.slice().sort((a, b) => a.start - b.start).filter(c => c.words && c.words.length);
    if (cues.length >= 3) {
      const cur = S.subtitle.normalizeRhythm(seg.rhythm);          // keep the opening-sentence setting the project already has
      return S.subtitle.buildRhythm(cues.slice(0, 40).map(c => ({
        w: c.words.length, c: (S.thai && S.thai.visLen) ? S.thai.visLen(c.text || '') : (c.text || '').length,
        s: c.words[c.words.length - 1].end - c.words[0].start
      })), cur ? { opening: cur.opening } : null);
    }
    return S.subtitle.normalizeRhythm(seg.rhythm) || S.subtitle.rhythmFromSettings(seg.wordsPerLine, seg.maxChars);
  }

  function capture(name) {
    const st = P().style, pw = pictureWidth(), cues = P().subtitle.cues, base = deep(REFERENCE_1);
    const used = {}; let colored = 0;
    cues.forEach(c => { let any = false; c.words.forEach(w => { if (w.color) { any = true; used[w.color.toLowerCase()] = (used[w.color.toLowerCase()] || 0) + 1; } }); if (any) colored++; });
    const palette = Object.keys(used).sort((a, b) => used[b] - used[a]);
    return normalizeProfile({
      schema: SCHEMA, name: name || 'สไตล์ที่คัดลอก ' + new Date().toLocaleString('th-TH'),
      source: { w: 0, h: 0, note: 'captured from project' },
      text: { font: st.font, weight: st.weight || (st.bold ? 700 : 400), sizeFrac: +(st.size / pw).toFixed(4), color: st.color, italic: !!st.italic, thick: st.thick || 0, sharp: st.sharp || 0 },
      outline: { on: st.outline.on, color: st.outline.color, widthFrac: +(st.outline.width / pw).toFixed(4) },
      shadow: { on: st.shadow.on, color: st.shadow.color, distFrac: +(st.shadow.dist / pw).toFixed(4), blurFrac: +(st.shadow.blur / pw).toFixed(4), opacity: st.shadow.opacity == null ? 100 : st.shadow.opacity, angle: st.shadow.angle == null ? -45 : st.shadow.angle },
      glow: Object.assign({}, st.glow), bg: Object.assign({}, st.bg),
      layout: { pos: st.pos, posY: st.posY == null ? (st.pos === 'top' ? 0.1 : st.pos === 'mid' ? 0.5 : 0.85) : st.posY, wordsPerLine: P().subtitle.segmentation.wordsPerLine, maxChars: P().subtitle.segmentation.maxChars, rhythm: captureRhythm() },
      animation: { fx: st.fx },
      highlight: {
        mode: st.karaokeMode || 'custom', coverage: cues.length ? +(colored / cues.length).toFixed(2) : base.highlight.coverage, maxPerCue: 1,
        palette: palette.length ? palette : base.highlight.palette, weights: (palette.length ? palette : base.highlight.palette).map(c => used[c] || 1)
      }
    });
  }

  /* ---------- auto highlight ---------- */
  const STOP = new Set(['และ', 'หรือ', 'ที่', 'ซึ่ง', 'อัน', 'ของ', 'ใน', 'จะ', 'ก็', 'เป็น', 'มี', 'ได้', 'ให้', 'แล้ว', 'ไป', 'มา', 'นี้', 'นั้น', 'ว่า', 'กับ', 'แต่', 'ถ้า', 'ก็ได้', 'ครับ', 'ค่ะ', 'คะ', 'นะ', 'จึง', 'เพราะ', 'โดย', 'จาก', 'ถึง', 'แก่', 'เมื่อ', 'the', 'a', 'an', 'of', 'to', 'in', 'and', 'is', 'it']);
  function hash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0) / 4294967296; }
  const vis = s => (S.thai && S.thai.visLen) ? S.thai.visLen(s) : (s || '').length;

  /** Pick the word of a cue most worth colouring: longest non-stop-word, later word wins ties (the punchline). */
  function pickWord(cue) {
    let best = -1, bestLen = 0;
    cue.words.forEach((w, i) => {
      const t = (w.word || '').trim(); if (!t || STOP.has(t)) return;
      const L = vis(t); if (L >= bestLen && L >= 2) { best = i; bestLen = L; }
    });
    return best;
  }

  /**
   * Colour ONE key word in about `coverage` of the lines. Same word -> same colour everywhere (like the
   * reference, where a recurring term keeps its colour); neighbouring lines never repeat the colour.
   * Deterministic: the same transcript always gets the same result. One undo step.
   */
  function autoHighlight(profile, opts) {
    const pr = normalizeProfile(profile || S.styleCopy.lastProfile || REFERENCE_1), hl = pr.highlight, cues = P().subtitle.cues;
    if (!cues.length) return { colored: 0, lines: 0 };
    if (S.history) S.history.record('auto-highlight');
    const pal = hl.palette, wts = hl.weights, total = wts.reduce((a, b) => a + b, 0), byWord = new Map();
    const pickColor = (key, avoid) => {
      if (byWord.has(key)) return byWord.get(key);
      let r = hash('c:' + key) * total, i = 0;
      while (i < pal.length - 1 && r >= wts[i]) { r -= wts[i]; i++; }
      if (pal[i] === avoid) i = (i + 1) % pal.length;
      byWord.set(key, pal[i]); return pal[i];
    };
    let colored = 0, prev = null;
    cues.forEach(c => {
      c.words.forEach(w => { delete w.color; if (w.glow && w.glow.auto) delete w.glow; });
      if (hash('p:' + c.text + ':' + c.start.toFixed(2)) > hl.coverage) { prev = null; return; }
      const wi = pickWord(c); if (wi < 0) { prev = null; return; }
      const col = pickColor(c.words[wi].word.trim(), prev);
      c.words[wi].color = col; prev = col; colored++;
      c.words[wi].glow = S.subtitle.colorGlow(c, c.words[wi], col);      // the coloured word glows in its own colour, not the line's
    });
    S.bus.emit('cues:structure', { reason: 'auto-highlight' });
    return { colored: colored, lines: cues.length };
  }

  function clearWordColors() {
    if (S.history) S.history.record('clear-word-colors');
    P().subtitle.cues.forEach(c => c.words.forEach(w => { delete w.color; delete w.glow; }));
    S.bus.emit('cues:structure', { reason: 'clear-word-colors' });
  }

  /* ---------- export / import ---------- */
  function exportProfile(profile) {
    const pr = profile || S.styleCopy.lastProfile || capture();
    const blob = new Blob([JSON.stringify(pr, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = (pr.name || 'style').replace(/[^\wก-๙-]+/g, '_') + '.style.json';
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    return pr;
  }
  function importProfile(file) {
    return file.text().then(txt => { const pr = normalizeProfile(JSON.parse(txt)); S.styleCopy.lastProfile = pr; return pr; });
  }

  /* =====================================================================
   * ANALYSIS — pure functions over RGBA frames { t, w, h, data:Uint8ClampedArray }
   * ===================================================================== */
  const BAND = [0.25, 0.92];             // captions live in this vertical band of the picture
  const EM_BODY = 0.56;                  // Thai consonant+vowel body height as a fraction of the font size (em)

  /** Measure the white caption text in one frame. null when there is no caption-sized white blob. */
  function frameStats(fr, thr) {
    thr = thr || 232;
    const w = fr.w, h = fr.h, d = fr.data, y0 = Math.floor(h * BAND[0]), y1 = Math.floor(h * BAND[1]);
    const rows = new Uint32Array(y1 - y0); let minX = w, maxX = -1, count = 0, hiCount = 0, lum = 0;
    const hiHue = new Float64Array(12 * 4);                       // per 30deg hue bin: n, r, g, b sums
    for (let y = y0; y < y1; y++) {
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4, r = d[i], g = d[i + 1], b = d[i + 2];
        if (r > thr && g > thr && b > thr) { rows[y - y0]++; count++; lum += Math.min(r, g, b); if (x < minX) minX = x; if (x > maxX) maxX = x; }
      }
    }
    if (count < 0.0012 * w * h) return { count: count, has: false };
    let top = -1, bottom = -1, max = 0;
    for (let i = 0; i < rows.length; i++) if (rows[i] > max) max = rows[i];
    for (let i = 0; i < rows.length; i++) if (rows[i] > 0) { if (top < 0) top = i; bottom = i; }
    let bt = -1, bb = -1;
    for (let i = 0; i < rows.length; i++) if (rows[i] >= 0.4 * max) { if (bt < 0) bt = i; bb = i; }
    // saturated bright pixels that sit next to a dark one (outline / shadow) inside the text rows = coloured words
    const ya = y0 + Math.max(0, top - Math.round(h * 0.01)), yb = Math.min(h - 3, y0 + bottom + Math.round(h * 0.01)), vcol = new Uint8Array(w);
    for (let y = ya; y < yb; y++) {
      for (let x = 0; x < w - 3; x++) {
        const i = (y * w + x) * 4, r = d[i], g = d[i + 1], b = d[i + 2], mx = Math.max(r, g, b), mn = Math.min(r, g, b);
        if (mx < 190 || (mx - mn) / mx < 0.68) continue;
        const j = ((y + 2) * w + x + 2) * 4, k = (y * w + x + 3) * 4;
        if (Math.max(d[j], d[j + 1], d[j + 2]) > 70 && Math.max(d[k], d[k + 1], d[k + 2]) > 70) continue;
        let hue; const df = mx - mn;
        if (mx === r) hue = ((g - b) / df + 6) % 6; else if (mx === g) hue = (b - r) / df + 2; else hue = (r - g) / df + 4;
        const bin = Math.floor(hue * 2) % 12, o = bin * 4;
        hiHue[o]++; hiHue[o + 1] += r; hiHue[o + 2] += g; hiHue[o + 3] += b; hiCount++; vcol[x] = 1;
      }
    }
    // the WHOLE line: a coloured word at either end is not white, so grow the white extent over nearby coloured pixels
    const bodyH = bb - bt + 1, reach = Math.max(3, Math.round(bodyH * 0.9));
    let lx = minX, rx = maxX;
    for (let x = rx + 1, run = 0; x < w && run <= reach; x++) { if (vcol[x]) { rx = x; run = 0; } else run++; }
    for (let x = lx - 1, run = 0; x >= 0 && run <= reach; x--) { if (vcol[x]) { lx = x; run = 0; } else run++; }
    // fingerprint of the text: ink per pixel column inside the text rows. A static caption repeats it (up to noise),
    // a different line of the very same width does not.
    const sig = new Uint8Array(w);
    for (let y = Math.max(0, ya); y < yb; y++) {
      for (let x = lx; x <= rx; x++) { const i = (y * w + x) * 4; if (d[i] > thr && d[i + 1] > thr && d[i + 2] > thr && sig[x] < 255) sig[x]++; }
    }
    for (let x = lx; x <= rx; x++) if (vcol[x] && sig[x] < 255) sig[x]++;
    return {
      has: true, count: count, bright: lum / count, minX: minX, maxX: maxX, top: y0 + top, bottom: y0 + bottom,
      bodyH: bodyH, hiCount: hiCount, hiHue: hiHue, w: w, h: h, lx: lx, rx: rx, sig: sig
    };
  }

  /* Sentence size from pixels. CHAR_BODY = width of one visible Thai character as a fraction of the caption's body height
   * (calibrated by rendering Thai sentences with the app's own fonts); WORD_CHARS = visible characters in an average Thai word. */
  const CHAR_BODY = 1.0, WORD_CHARS = 3.4, LINE_CHANGE = 0.3, MIN_LINE_FRAMES = 3;
  const sigDist = (a, b) => { let d = 0, t = 0; for (let i = 0; i < a.length; i++) { d += Math.abs(a[i] - b[i]); t += a[i] + b[i]; } return t ? d / t : 0; };

  /**
   * The reference's lines IN ORDER with their size: { lines:[{ w words, c characters, s seconds, t start }], count }.
   * `stats` = frames.map(f => frameStats(f)) (pass it in when you already have it). A new line starts when the text
   * disappears, jumps sideways, or its ink pattern changes; blips shorter than MIN_LINE_FRAMES frames (the first
   * frames of a pop-in) are not lines. Characters come from the line's whole width (coloured words included).
   */
  function measureLines(frames, stats, o) {
    o = o || {};
    const st = stats || frames.map(f => frameStats(f)), W = frames[0].w;
    const step = frames.length > 1 ? frames[1].t - frames[0].t : 0.12, out = []; let cur = null;
    const flush = () => {
      if (cur && cur.n >= MIN_LINE_FRAMES) {
        const body = median(cur.body), width = median(cur.width);
        const c = Math.max(1, Math.round(width / (body * CHAR_BODY)));
        out.push({ t: +cur.t0.toFixed(2), w: Math.max(1, Math.round(c / WORD_CHARS)), c: c, s: +(cur.t1 - cur.t0 + step).toFixed(2) });
      }
      cur = null;
    };
    for (let i = 0; i < frames.length; i++) {
      const s = st[i];
      if (!s.has) { flush(); continue; }
      const p = i > 0 && st[i - 1].has ? st[i - 1] : null;
      if (cur && p && (Math.abs(s.lx - p.lx) > W * 0.02 || Math.abs(s.rx - p.rx) > W * 0.02 || sigDist(s.sig, p.sig) > LINE_CHANGE)) flush();
      if (!cur) cur = { t0: frames[i].t, t1: frames[i].t, n: 0, width: [], body: [] };
      cur.t1 = frames[i].t; cur.n++; cur.width.push(s.rx - s.lx + 1); cur.body.push(s.bodyH);
    }
    flush();
    return { lines: out.slice(0, o.max || 40), count: out.length };
  }

  const toHex = (r, g, b) => '#' + [r, g, b].map(v => clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0')).join('');
  /** make a measured colour as vivid as the reference palette (video compression dulls it) */
  function vivid(r, g, b) {
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b); if (mx === 0) return toHex(r, g, b);
    const s = Math.max((mx - mn) / mx, 0.82), k = 240 / mx, R = r * k, G = g * k, B = b * k, m2 = Math.max(R, G, B), n2 = m2 * (1 - s);
    const lift = (v, lo, hi) => hi === lo ? v : n2 + (v - lo) * (m2 - n2) / (hi - lo);
    const lo = Math.min(R, G, B), hi = m2;
    return toHex(lift(R, lo, hi), lift(G, lo, hi), lift(B, lo, hi));
  }

  /**
   * Measure a set of frames sampled through a clip (any spacing, >= ~6 per second recommended).
   * Returns a PARTIAL profile (only what could be measured) + stats; merge it over a baseline.
   */
  function analyzeFrames(frames) {
    const st = frames.map(f => frameStats(f)), on = st.filter(s => s.has);
    if (on.length < 3) return { ok: false, reason: 'ไม่พบข้อความสีขาวแบบคำบรรยายในวิดีโอ (ต้องมีตัวอักษรขาวใหญ่ครึ่งล่างของภาพ)' };
    const W = frames[0].w, H = frames[0].h;
    const posY = median(on.map(s => (s.top + s.bottom) / 2 / H));
    const sizeFrac = median(on.map(s => s.bodyH / EM_BODY / W));
    // highlight palette from every frame's hue bins
    const bins = Array.from({ length: 12 }, () => [0, 0, 0, 0]); let hiTotal = 0, hiFrames = 0;
    on.forEach(s => { if (s.hiCount > 0.0008 * W * H) hiFrames++; for (let b = 0; b < 12; b++) for (let k = 0; k < 4; k++) bins[b][k] += s.hiHue[b * 4 + k]; });
    bins.forEach(b => { hiTotal += b[0]; });
    const picked = bins.map((b, i) => ({ i: i, n: b[0], rgb: b[0] ? [b[1] / b[0], b[2] / b[0], b[3] / b[0]] : [0, 0, 0] }))
      .filter(b => hiTotal && b.n / hiTotal >= 0.06).sort((a, b) => b.n - a.n).slice(0, 6);
    const merged = [];                                              // adjacent hue bins often split ONE colour: merge near-identical ones
    picked.forEach(b => {
      const near = merged.find(m => Math.hypot(m.rgb[0] - b.rgb[0], m.rgb[1] - b.rgb[1], m.rgb[2] - b.rgb[2]) < 70);
      if (near) { const t = near.n + b.n; near.rgb = near.rgb.map((v, k) => (v * near.n + b.rgb[k] * b.n) / t); near.n = t; }
      else merged.push({ rgb: b.rgb.slice(), n: b.n });
    });
    picked.length = 0; merged.sort((a, b) => b.n - a.n).forEach(m => picked.push(m));
    const palette = picked.map(b => vivid(b.rgb[0], b.rgb[1], b.rgb[2]));
    // line changes: a new caption shows up as a jump in the white-blob signature
    const changes = [];
    for (let i = 1; i < st.length; i++) {
      const a = st[i - 1], b = st[i];
      if (b.has && (!a.has || Math.abs(b.minX - a.minX) > W * 0.02 || Math.abs(b.maxX - a.maxX) > W * 0.02 || Math.abs(b.count - a.count) > 0.25 * a.count)) changes.push(frames[i].t);
    }
    const gaps = []; for (let i = 1; i < changes.length; i++) gaps.push(changes[i] - changes[i - 1]);
    const ml = measureLines(frames, st);
    const out = {
      ok: true, frames: frames.length, captionFrames: on.length,
      layout: { pos: 'custom', posY: +clamp(posY, 0.05, 0.97).toFixed(3) },
      text: { sizeFrac: +clamp(sizeFrac, 0.02, 0.2).toFixed(4) },
      highlight: { coverage: +(hiFrames / on.length).toFixed(2) },
      stats: { medianLineSeconds: gaps.length ? +median(gaps).toFixed(2) : null, lines: changes.length }
    };
    // the sentence size: each line's words / characters / seconds, opening first (needs a few lines to mean anything)
    if (ml.lines.length >= 3) out.rhythm = S.subtitle.buildRhythm(ml.lines);
    if (palette.length) { out.highlight.palette = palette; out.highlight.weights = picked.map(b => Math.max(1, Math.round(4 * b.n / picked[0].n))); }
    return out;
  }

  /**
   * seq: frames starting just BEFORE a caption appears until it has settled (fps >= 30 gives best results).
   * Hard cut = nothing changes; pop = the text grows; slide = it moves; fade = it gets brighter.
   */
  function detectAnimation(seq) {
    const st = seq.map(f => frameStats(f, 170)), W = seq.length ? seq[0].w : 1;
    const jump = (a, b) => Math.abs(b.minX - a.minX) > W * 0.02 || Math.abs(b.maxX - a.maxX) > W * 0.02 || Math.abs(b.count - a.count) > 0.25 * a.count;
    let first = -1;
    for (let i = 0; i < st.length - 3; i++) {                       // the LAST caption start that still leaves 3 frames to settle
      if (st[i].has && (i === 0 || !st[i - 1].has || jump(st[i - 1], st[i]))) first = i;
    }
    if (first < 0) return { fx: null, why: 'ไม่พบข้อความขึ้นใหม่ในช่วงที่ดู' };
    const tail = st.slice(-3).filter(s => s.has); if (!tail.length) return { fx: null, why: 'ไม่พบข้อความช่วงท้าย' };
    const f = st[first], H = f.h, fw = f.maxX - f.minX, tw = median(tail.map(s => s.maxX - s.minX));
    const mid = s => (s.top + s.bottom) / 2, scale = fw / tw, alpha = f.bright / median(tail.map(s => s.bright)), dy = (mid(f) - median(tail.map(mid))) / H;
    let fx = 'none';
    if (Math.abs(dy) >= 0.006) fx = 'slide';
    else if (scale < 0.94) fx = 'pop';
    else if (alpha < 0.85) fx = 'fade';
    return { fx: fx, scale: +scale.toFixed(3), alpha: +alpha.toFixed(3), dy: +dy.toFixed(4), onsetIndex: first };
  }

  /* ---------- DOM: sample a video file and analyse it ---------- */
  const SNAPSHOT_MAX = 300 * 1024 * 1024;                           // same limit as ui/media.js
  const MIME_BY_EXT = { mp4: 'video/mp4', m4v: 'video/mp4', mov: 'video/mp4', webm: 'video/webm', mkv: 'video/x-matroska' };
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  /** A picked File is only a reference (cloud drives / lapsed permission -> NotReadableError later). Copy the bytes now. */
  async function readIntoMemory(file) {
    if (file.size > SNAPSHOT_MAX) return file;
    for (let attempt = 0; ; attempt++) {
      try { return new File([await file.arrayBuffer()], file.name, { type: file.type, lastModified: file.lastModified }); }
      catch (e) { if (attempt >= 2) throw e; await sleep(400); }
    }
  }

  /** Say WHY the <video> failed (MediaError codes: 2 network/read, 3 decode, 4 source not supported). */
  function videoErrorMessage(code) {
    if (code === 2) return 'อ่านไฟล์วิดีโอไม่สำเร็จ — ถ้าไฟล์อยู่บนคลาวด์ (Drive / iCloud / OneDrive) ให้คัดลอกมาไว้ในเครื่องก่อน แล้วเลือกใหม่';
    if (code === 3) return 'ถอดรหัสภาพจากวิดีโอนี้ไม่ได้ (ไฟล์อาจเสียหรือใช้โคเดกที่เบราว์เซอร์ไม่รองรับ) — ลองแปลงเป็น MP4 (H.264/AAC) แล้วเลือกใหม่';
    if (code === 0) return 'เปิดวิดีโอนานเกินไป — ลองใช้ไฟล์ที่เล็กลง หรือคัดลอกไฟล์มาไว้ในเครื่องแล้วเลือกใหม่';
    return 'เบราว์เซอร์เปิดวิดีโอนี้ไม่ได้ — ส่วนใหญ่เกิดจากโคเดก H.265/HEVC (วิดีโอจากมือถือ/iPhone) หรือรูปแบบไฟล์ที่ไม่รองรับ ลองแปลงเป็น MP4 (H.264/AAC) แล้วเลือกใหม่';
  }

  /** Load a Blob into a detached <video>; resolves once the picture size is known. */
  function openVideo(blob) {
    return new Promise((resolve, reject) => {
      const v = document.createElement('video'), url = URL.createObjectURL(blob);
      let timer = 0;
      const dispose = () => { clearTimeout(timer); v.onerror = v.onloadedmetadata = null; try { v.removeAttribute('src'); v.load(); } catch (e) {} URL.revokeObjectURL(url); };
      const fail = code => { dispose(); const e = new Error(videoErrorMessage(code)); e.mediaCode = code; reject(e); };
      v.muted = true; v.playsInline = true; v.preload = 'auto';
      v.onerror = () => fail(v.error ? v.error.code : 4);
      v.onloadedmetadata = () => {
        clearTimeout(timer);
        if (!v.videoWidth || !v.videoHeight) return fail(4);        // audio-only, or the video track can't be decoded (e.g. HEVC)
        resolve({ v: v, dispose: dispose });
      };
      timer = setTimeout(() => fail(0), 20000);
      v.src = url;
    });
  }

  async function openVideoFile(file) {
    let src = file;
    try { src = await readIntoMemory(file); }
    catch (e) { console.warn('[style-copy] no in-memory copy, trying the picked file itself:', e); src = file; }   // openVideo() below reports it if the browser really cannot open it
    try { return await openVideo(src); }
    catch (e) {
      // an empty / odd MIME type (.mov, .mkv ...) can make the browser refuse a playable file: retry once with a fitting type
      const ext = ((file.name || '').match(/\.(\w+)$/) || [])[1], mime = ext && MIME_BY_EXT[ext.toLowerCase()];
      if (e.mediaCode === 4 && mime && src.type !== mime) { try { return await openVideo(new Blob([src], { type: mime })); } catch (e2) { /* report the first error */ } }
      throw e;
    }
  }

  async function analyzeVideoFile(file, o) {
    o = Object.assign({ width: 270, step: 0.12, maxSeconds: 40, onProgress: null }, o || {});
    if (o.onProgress) o.onProgress(0, 'กำลังเปิดวิดีโอ');
    const opened = await openVideoFile(file), v = opened.v;
    if (!isFinite(v.duration) || !(v.duration > 0)) {          // no length in the header (screen recording / MediaRecorder WebM): seek far past the end so the browser learns it
      await new Promise(res => { const tm = setTimeout(res, 8000), ok = () => { if (isFinite(v.duration) && v.duration > 0) { clearTimeout(tm); res(); } }; v.addEventListener('durationchange', ok); v.addEventListener('timeupdate', ok); try { v.currentTime = 1e6; } catch (e) { res(); } });
      try { v.currentTime = 0; } catch (e) {}
      if (!isFinite(v.duration) || !(v.duration > 0)) { opened.dispose && opened.dispose(); throw new Error('อ่านความยาวของวิดีโอต้นแบบไม่ได้ — ลองแปลงเป็น MP4 แล้วเลือกใหม่'); }
    }
    let failedCode = 0;
    v.onerror = () => { failedCode = v.error ? v.error.code : 3; };
    const check = () => { if (failedCode) throw new Error(videoErrorMessage(failedCode)); };
    const seek = t => new Promise(res => {
      let done = false, timer = 0;
      const fin = () => { if (done) return; done = true; clearTimeout(timer); v.removeEventListener('seeked', fin); v.removeEventListener('error', fin); res(); };
      const target = Math.min(t, Math.max(0, v.duration - 0.01));
      if (!isFinite(target)) return res();
      v.addEventListener('seeked', fin); v.addEventListener('error', fin); timer = setTimeout(fin, 1500);
      if (Math.abs(v.currentTime - target) < 1e-4 && v.readyState >= 2) return fin();   // already there: no 'seeked' will fire
      v.currentTime = target;
    });
    try {
      const W = o.width, H = Math.round(W * v.videoHeight / v.videoWidth), cv = document.createElement('canvas');
      cv.width = W; cv.height = H; const cx = cv.getContext('2d', { willReadFrequently: true });
      const grab = t => { cx.drawImage(v, 0, 0, W, H); return { t: t, w: W, h: H, data: cx.getImageData(0, 0, W, H).data }; };
      const end = Math.min(v.duration, o.maxSeconds), frames = [], n = Math.floor(end / o.step);
      for (let i = 0; i < n; i++) {
        const t = i * o.step; await seek(t); check(); frames.push(grab(t));
        if (o.onProgress) o.onProgress(0.8 * (i + 1) / n, 'วิเคราะห์ตำแหน่ง ขนาด สี');
      }
      const res = analyzeFrames(frames);
      if (!res.ok) return res;
      // animation: look at the first frames of a few caption onsets (finer step)
      const fine = 1 / 30, onsets = []; let prevOn = false;
      frames.forEach((f, i) => { const s = frameStats(f).has; if (s && !prevOn && i > 0) onsets.push(f.t); prevOn = s; });
      const votes = {};
      const pick = onsets.slice(0, 8);
      for (let k = 0; k < pick.length; k++) {
        const seq = [];
        for (let j = 0; j < 11; j++) { const t = Math.max(0, pick[k] - 0.1 + j * fine); await seek(t); check(); seq.push(grab(t)); }
        const a = detectAnimation(seq); if (a.fx) votes[a.fx] = (votes[a.fx] || 0) + 1;
        if (o.onProgress) o.onProgress(0.8 + 0.2 * (k + 1) / pick.length, 'วิเคราะห์แอนิเมชัน');
      }
      const fx = Object.keys(votes).sort((a, b) => votes[b] - votes[a])[0] || 'none';
      res.animation = { fx: fx, votes: votes };
      res.source = { w: v.videoWidth, h: v.videoHeight, note: file.name };
      if (o.wantLook) {                                           // sharp crops of the caption (for the AI to read the font from)
        if (o.onProgress) o.onProgress(1, 'เก็บภาพตัวอย่างฟอนต์');
        const sts = frames.map(f => frameStats(f)), picks = []; let lastT = -9;
        sts.forEach((s, i) => { if (s.has && frames[i].t - lastT >= 1.2 && picks.length < 3) { picks.push(i); lastT = frames[i].t; } });
        res.lookImages = [];
        for (let k = 0; k < picks.length; k++) {
          const i = picks[k], s = sts[i], LW = 720, LH = Math.round(LW * v.videoHeight / v.videoWidth);
          await seek(frames[i].t + 0.25); check();                  // a little later: a pop-in animation has settled
          const big = document.createElement('canvas'); big.width = LW; big.height = LH;
          big.getContext('2d').drawImage(v, 0, 0, LW, LH);
          const y0 = Math.max(0, Math.round((s.top / s.h - 0.05) * LH)), y1 = Math.min(LH, Math.round((s.bottom / s.h + 0.05) * LH));
          const crop = document.createElement('canvas'); crop.width = LW; crop.height = Math.max(80, y1 - y0);
          crop.getContext('2d').drawImage(big, 0, y0, LW, crop.height, 0, 0, LW, crop.height);
          res.lookImages.push(crop.toDataURL('image/jpeg', 0.88).split(',')[1]);
        }
      }
      return res;
    } finally { opened.dispose(); }
  }

  /** merge an analysis result over a baseline profile (what could not be measured stays from the baseline) */
  function profileFromAnalysis(res, baseline, name) {
    const b = deep(baseline || REFERENCE_1);
    b.name = name || ('จากวิดีโอ ' + ((res.source && res.source.note) || ''));
    if (res.source) b.source = res.source;
    if (res.layout) Object.assign(b.layout, res.layout);
    if (res.text) Object.assign(b.text, res.text);
    if (res.rhythm) { b.layout.rhythm = res.rhythm; b.layout.wordsPerLine = res.rhythm.typical.w; b.layout.maxChars = res.rhythm.max.c; }
    if (res.animation) b.animation = { fx: res.animation.fx };
    if (res.highlight) {
      if (res.highlight.coverage != null) b.highlight.coverage = res.highlight.coverage;
      if (res.highlight.palette) { b.highlight.palette = res.highlight.palette; b.highlight.weights = res.highlight.weights; }
    }
    return normalizeProfile(b);
  }

  /**
   * Put the AI's reading of a reference caption (S.ai.identifyCaptionStyle) onto a profile: font, weight, colours, outline, shadow,
   * glow, box. `font` = { value, weight? } the chosen font option (its own fixed weight wins). Sizes are % of the font size, turned
   * into fractions of the picture width with the measured size. PURE.
   */
  function mergeLook(pr, look, font) {
    if (!look) return pr;
    const sf = (pr.text && pr.text.sizeFrac) || REFERENCE_1.text.sizeFrac, pct = v => (v == null ? null : +(v / 100 * sf).toFixed(5));
    if (font && font.value) { pr.text.font = font.value; pr.text.weight = font.weight || look.weight || pr.text.weight; }
    else if (look.weight) pr.text.weight = look.weight;
    pr.text.italic = !!look.italic;
    if (look.textColor) pr.text.color = look.textColor;
    pr.outline.on = !!look.outline.on;
    if (look.outline.on) { if (look.outline.color) pr.outline.color = look.outline.color; if (look.outline.widthPct != null) pr.outline.widthFrac = pct(Math.max(0.5, look.outline.widthPct)); }
    pr.shadow.on = !!look.shadow.on;
    if (look.shadow.on) {
      if (look.shadow.color) pr.shadow.color = look.shadow.color;
      if (look.shadow.distPct != null) pr.shadow.distFrac = pct(Math.max(0.5, look.shadow.distPct));
      if (look.shadow.blurPct != null) pr.shadow.blurFrac = pct(look.shadow.blurPct);
    }
    pr.glow = look.glow.on ? { on: true, type: look.glow.type, color: look.glow.color || '#ffffff', intensity: look.glow.strength == null ? 60 : Math.max(20, look.glow.strength), rangeFrac: +(sf * 0.35).toFixed(4) } : { on: false };
    pr.bg = look.box.on ? { on: true, color: look.box.color || '#000000', opacity: look.box.opacity == null ? 0.55 : look.box.opacity } : { on: false };
    return pr;
  }

  S.styleCopy = {
    mergeLook: mergeLook,
    SCHEMA: SCHEMA, REFERENCE_1: REFERENCE_1, lastProfile: null, modeOverride: null,   // modeOverride: 'off' | 'stay' | 'stayAll' (set by the pane)
    
    apply: apply, capture: capture, normalizeProfile: normalizeProfile,
    autoHighlight: autoHighlight, clearWordColors: clearWordColors,
    exportProfile: exportProfile, importProfile: importProfile,
    analyzeFrames: analyzeFrames, detectAnimation: detectAnimation, frameStats: frameStats, measureLines: measureLines,
    analyzeVideoFile: analyzeVideoFile, profileFromAnalysis: profileFromAnalysis
  };
})(window.SubEd);
