/* =====================================================================
 * Caption animation catalogue — the single list the UI (chips), the summaries and the renderers agree on.
 * Moved from Shadow Caption Lab: whole line / word by word / letter by letter / continuous motion, plus the "ending" animations.
 *   unit  'all'   the whole line moves at once (the old behaviour)
 *         'word'  every word of the line animates in turn  (stagger = style.fxStep ms)
 *         'char'  every letter (Thai letter + its vowel / tone marks count as one) animates in turn
 *   inf   keeps moving for as long as the line is on screen (breathing, floating, wave, colour run)
 *   lab   a new animation: choosing it also sets the intro length to its natural length (the slider can still change it)
 * IDs of the animations that already existed (pop, fade, slide ...) are unchanged, so old projects, presets and styles keep working.
 * ===================================================================== */
(function (S) {
  'use strict';
  const LIST = [
    // whole line
    { id: 'pop', label: 'ป๊อป', unit: 'all' }, { id: 'fade', label: 'เฟด', unit: 'all' }, { id: 'slide', label: 'เลื่อนขึ้น', unit: 'all' },
    { id: 'slidedown', label: 'เลื่อนลง', unit: 'all' }, { id: 'slideleft', label: 'วิ่งจากซ้าย', unit: 'all' }, { id: 'slideright', label: 'วิ่งจากขวา', unit: 'all' },
    { id: 'zoomin', label: 'Zoom In', unit: 'all' }, { id: 'zoomcolor', label: 'Zoom In + สว่าง', unit: 'all' }, { id: 'slowzoom', label: 'ซูมช้าๆ', unit: 'all' },
    { id: 'zoom', label: 'ซูมลงมา', unit: 'all' }, { id: 'bounce', label: 'เด้ง', unit: 'all' }, { id: 'drop', label: 'ตกลงมา', unit: 'all' },
    { id: 'spin', label: 'หมุนเข้า', unit: 'all' }, { id: 'blur', label: 'เบลอ', unit: 'all' },
    { id: 'flip', label: 'พลิกแกน', unit: 'all', lab: 0.52 }, { id: 'rubber', label: 'ยางยืด', unit: 'all', lab: 0.8 }, { id: 'glitch', label: 'กลิตช์', unit: 'all', lab: 0.6 },
    { id: 'shake', label: 'สั่น', unit: 'all', lab: 0.56 }, { id: 'flicker', label: 'ไฟกะพริบ', unit: 'all', lab: 0.7 }, { id: 'tilt', label: 'เอียงเข้า', unit: 'all', lab: 0.42 },
    { id: 'wipe', label: 'ปัดเผย', unit: 'all', lab: 0.56 }, { id: 'none', label: 'ไม่มี', unit: 'all' },
    // word by word
    { id: 'typing', label: 'ขึ้นทีละคำ', unit: 'all' },                         // the older word-reveal: spreads the words over the intro length
    { id: 'wordhl', label: 'ไฮไลต์ทีละคำ', unit: 'word' }, { id: 'wordbounce', label: 'เด้งทีละคำ', unit: 'word' }, { id: 'wordfade', label: 'เฟดทีละคำ', unit: 'word' },
    { id: 'wordup', label: 'ไถลขึ้นทีละคำ', unit: 'word' }, { id: 'wordzoom', label: 'ซูมทีละคำ', unit: 'word' }, { id: 'wordreveal', label: 'โผล่สะสมทีละคำ', unit: 'word' },
    // letter by letter
    { id: 'chartype', label: 'พิมพ์ดีด', unit: 'char' }, { id: 'charfade', label: 'เฟดทีละตัว', unit: 'char' }, { id: 'charbounce', label: 'เด้งทีละตัว', unit: 'char' },
    { id: 'chardrop', label: 'ตกทีละตัว', unit: 'char' }, { id: 'charup', label: 'ไถลขึ้นทีละตัว', unit: 'char' },
    // continuous
    { id: 'pulse', label: 'หายใจ', unit: 'all', inf: true }, { id: 'float', label: 'ลอย', unit: 'all', inf: true },
    { id: 'wave', label: 'คลื่น', unit: 'char', inf: true }, { id: 'colorrun', label: 'สีวิ่งทีละตัว', unit: 'char', inf: true }
  ];
  const GROUPS = [['all', 'ทั้งประโยค'], ['word', 'ทีละคำ'], ['char', 'ทีละตัวอักษร'], ['inf', 'เคลื่อนไหวต่อเนื่อง']];
  const OUTS = [['none', 'ไม่มี'], ['fade', 'เฟดออก'], ['zoom', 'ขยายหาย'], ['down', 'ไถลลง'], ['shrink', 'ย่อหาย'], ['blur', 'เบลอหาย']];
  const BY_ID = {}; LIST.forEach(a => { BY_ID[a.id] = a; });
  const OUT_LABEL = {}; OUTS.forEach(o => { OUT_LABEL[o[0]] = o[1]; });

  S.fx = {
    list: LIST, groups: GROUPS, outs: OUTS,
    get: id => BY_ID[id] || null,
    label: id => (BY_ID[id] ? BY_ID[id].label : id),
    outLabel: id => OUT_LABEL[id] || id,
    /** 'all' | 'word' | 'char' — what moves one at a time */
    unit: id => (BY_ID[id] && BY_ID[id].unit) || 'all',
    isInf: id => !!(BY_ID[id] && BY_ID[id].inf),
    /** per-word / per-letter / continuous animations do not use the intro-length slider */
    usesLength: id => { const a = BY_ID[id]; return !a || (a.unit === 'all' && !a.inf && a.id !== 'none'); },
    usesStep: id => { const a = BY_ID[id]; return !!a && (a.unit === 'word' || a.unit === 'char'); },
    usesHighlight: id => id === 'wordhl' || id === 'colorrun'
  };
})(window.SubEd);
