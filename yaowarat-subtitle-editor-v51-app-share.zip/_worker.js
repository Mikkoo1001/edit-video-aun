/* Cloudflare Pages "advanced mode" worker (works with dashboard upload, wrangler and Git).
 *   POST /api/transcribe  -> forwards the multipart upload to Groq Whisper and returns Groq's answer.
 *   POST /api/gemini/models/<model>:generateContent, GET /api/gemini/models  -> forwarded to the Gemini API.
 *   everything else       -> static files (env.ASSETS).
 * Why: the browser talks to its OWN origin, so there is no CORS, and Groq is reached from Cloudflare's
 * network (works even if api.groq.com is blocked for the visitor). The user's Groq key travels in the
 * Authorization header, is forwarded as-is, and is never stored or logged. */
const GROQ_URL = 'https://api.groq.com/openai/v1/audio/transcriptions';
const MAX_BYTES = 30 * 1024 * 1024;   // Groq's cap is 25 MB; leave room for multipart overhead
const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta/';
const VERTEX_BASE = 'https://aiplatform.googleapis.com/v1/publishers/google/';   // Vertex AI express mode (keys that start with AQ.)
const GEMINI_MAX_BYTES = 22 * 1024 * 1024;   // Gemini's inline request cap is 20 MB

const json = (obj, status, extra) => new Response(JSON.stringify(obj), {
  status, headers: Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, extra || {})
});
const err = (status, message, extra) => json({ error: { message } }, status, extra);

async function transcribe(request) {
  if (request.method !== 'POST') return err(405, 'Method not allowed', { Allow: 'POST' });

  // same-origin only: a page on another site must not be able to use this endpoint
  const origin = request.headers.get('Origin');
  if (origin && origin !== new URL(request.url).origin) return err(403, 'Cross-origin requests are not allowed');

  const auth = request.headers.get('Authorization') || '';
  if (!/^Bearer \S+$/.test(auth)) return err(401, 'Groq API Key ไม่ถูกต้อง (ไม่ได้ใส่คีย์)');

  const type = request.headers.get('Content-Type') || '';
  if (!/^multipart\/form-data;\s*boundary=/i.test(type)) return err(415, 'Expected multipart/form-data');

  const len = Number(request.headers.get('Content-Length') || 0);
  if (len > MAX_BYTES) return err(413, 'ไฟล์เสียงใหญ่เกินที่ Groq รับได้ (25 MB)');

  let up;
  try {
    up = await fetch(GROQ_URL, { method: 'POST', headers: { Authorization: auth, 'Content-Type': type }, body: request.body });
  } catch (e) {
    return err(502, 'เชื่อมต่อ Groq ไม่ได้ ลองใหม่อีกครั้ง');
  }
  const headers = { 'Content-Type': up.headers.get('Content-Type') || 'application/json', 'Cache-Control': 'no-store' };
  const retryAfter = up.headers.get('Retry-After');   // lets the browser wait out Groq's rate limit (long videos = many requests)
  if (retryAfter) headers['Retry-After'] = retryAfter;
  return new Response(up.body, { status: up.status, headers: headers });
}

async function gemini(request, url) {
  if (request.method !== 'POST' && request.method !== 'GET') return err(405, 'Method not allowed', { Allow: 'GET, POST' });
  const origin = request.headers.get('Origin');
  if (origin && origin !== url.origin) return err(403, 'Cross-origin requests are not allowed');
  const key = request.headers.get('x-goog-api-key') || '';
  if (!/^[\w.-]{20,}$/.test(key)) return err(401, 'Gemini API Key ไม่ถูกต้อง');

  // only the two calls the editor makes; nothing else on the Gemini API is reachable through this proxy
  const rest = url.pathname.slice('/api/gemini/'.length);
  const isGenerate = request.method === 'POST' && /^models\/[A-Za-z0-9._-]+:generateContent$/.test(rest);
  const isList = request.method === 'GET' && rest === 'models';
  if (!isGenerate && !isList) return err(400, 'Unsupported Gemini path');
  if (isGenerate) {
    const len = Number(request.headers.get('Content-Length') || 0);
    if (len > GEMINI_MAX_BYTES) return err(413, 'ไฟล์เสียงใหญ่เกินที่ Gemini รับได้');
  }

  let up;
  try {
    up = await fetch(GEMINI_BASE + rest + (isList ? '?pageSize=200' : ''), {
      method: request.method,
      headers: Object.assign({ 'x-goog-api-key': key }, isGenerate ? { 'Content-Type': 'application/json' } : {}),
      body: isGenerate ? request.body : undefined
    });
  } catch (e) {
    return err(502, 'เชื่อมต่อ Gemini ไม่ได้ ลองใหม่อีกครั้ง');
  }
  return new Response(up.body, { status: up.status, headers: { 'Content-Type': up.headers.get('Content-Type') || 'application/json', 'Cache-Control': 'no-store' } });
}

async function vertex(request, url) {
  if (request.method !== 'POST') return err(405, 'Method not allowed', { Allow: 'POST' });
  const origin = request.headers.get('Origin');
  if (origin && origin !== url.origin) return err(403, 'Cross-origin requests are not allowed');
  const key = request.headers.get('x-goog-api-key') || '';
  if (!/^[\w.-]{20,}$/.test(key)) return err(401, 'Gemini API Key ไม่ถูกต้อง');
  const rest = url.pathname.slice('/api/vertex/'.length);
  if (!/^models\/[A-Za-z0-9._-]+:generateContent$/.test(rest)) return err(400, 'Unsupported Vertex path');
  const len = Number(request.headers.get('Content-Length') || 0);
  if (len > GEMINI_MAX_BYTES) return err(413, 'ไฟล์เสียงใหญ่เกินที่ Gemini รับได้');
  let up;
  try {
    up = await fetch(VERTEX_BASE + rest, { method: 'POST', headers: { 'x-goog-api-key': key, 'Content-Type': 'application/json' }, body: request.body });
  } catch (e) {
    return err(502, 'เชื่อมต่อ Gemini ไม่ได้ ลองใหม่อีกครั้ง');
  }
  return new Response(up.body, { status: up.status, headers: { 'Content-Type': up.headers.get('Content-Type') || 'application/json', 'Cache-Control': 'no-store' } });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/share-target') return Response.redirect(url.origin + '/?shared=0', 303);
    if (url.pathname === '/api/transcribe') return transcribe(request);
    if (url.pathname.startsWith('/api/gemini/')) return gemini(request, url);
    if (url.pathname.startsWith('/api/vertex/')) return vertex(request, url);
    return env.ASSETS.fetch(request);
  }
};
